local btnToggleNeckFX = ac.ControlButton('__APP_CSPoptionsToggle/Toggle NeckFX')

btnToggleNeckFX:onPressed(function()
    -- Documents\Assetto Corsa\cfg\extension\neck.ini
    -- [BASIC]
    -- ENABLED=1
    local fname = ac.getFolder(ac.FolderID.ExtCfgUser)..'/neck.ini'
    local neckini = ac.INIConfig.load(fname, ac.INIFormat.Default)
    local curr = neckini:get("BASIC", "ENABLED", 0) == 1
    neckini:setAndSave("BASIC", "ENABLED", not curr)
    ui.toast(ui.Icons.Info, 'NeckFX '..tostring(not curr))
end)

function script.windowMain(dt)
    -- ui.alignTextToFramePadding()
    ui.text('Toggle NeckFX:')
    ui.sameLine(160)
    btnToggleNeckFX:control(vec2(120, 0))
end
