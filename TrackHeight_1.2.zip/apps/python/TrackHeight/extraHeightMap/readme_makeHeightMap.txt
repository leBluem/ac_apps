-has nothing to do with the TrackHeigth app

-standalone python script
-you need to have python installed
 needs PIL pillow image lib installed (pip install pillow)

-generate a nice track height map from AI line
-generates two images, second scaled down to 2535 pixels in with

Use provided "dragNdrop.....cmd",
that calls python for you, if its properly installed/integrated into windows

or use like this:
python makeHeightMap.py c:\path_to_some\fastlane.ai
