#v1.2

### usually read from ini, if anything goes wrong, those are defaults
gAPPSIZE     = 1.0   # *100 = percent
gOPACITY     = 0.0
gPREVIEWBACK = 50    # no marker when 0
gPREVIEWFORW = 250   #
gHEIGHT_MULT = 2.0   # height scaling default: 2
gWIDTH_MULT  = 1.0   # ""
gSTEPPING    = 5     # steps
gCOLORMULT   = 8     # default: 2
gDRAWBLOCKS  = True
gDRAWTEXT    = False
gGRAPHTRANS  = 0.0

import ac, acsys
import configparser, os.path, traceback, io, math, struct, codecs
from shutil import copyfile

###############

app = 0
error = 0
btimerMsg = True
timer = 0.0
timerMsg = 0.5
bHideTimerOn     = False
hideTimer        = -1.0

lastPoT = 0.0
appMsg  =''
sVer = ''
currAltitude = 0.0
lastAltitude = 0.0

sTrack =''
sLayout =''
sFileOverlay =''
sFileCameras =''

ailineYOFFSET = 100
AI_LINE_LENGTH = 0.0
AI_LINE = []
AI_LINE_dM = []
AI_LINE_rgb = []

btnAPPSIZEplus = 0
btnAPPSIZEminus = 0
btnOPACITYplus=0
btnOPACITYminus=0
btnPREVIEWBACKplus=0
btnPREVIEWBACKminus=0
btnPREVIEWFORWplus=0
btnPREVIEWFORWminus=0
btnHEIGHT_MULTplus=0
btnHEIGHT_MULTminus=0
btnWIDTH_MULTplus=0
btnWIDTH_MULTminus=0
btnSTEPPINGplus=0
btnSTEPPINGminus=0
btnCOLOR_MULTplus=0
btnCOLOR_MULTminus=0
btnGRAPHTRANSplus=0
btnGRAPHTRANSminus=0
btnDRAWBLOCKStoggle=0
btnDRAWTEXTtoggle=0

#####################################################################

class ExtGL:
    CULL_MODE_FRONT = 0
    CULL_MODE_BACK = 1
    CULL_MODE_NONE = 2
    CULL_MODE_WIREFRAME = 4
    CULL_MODE_WIREFRAME_SMOOTH = 7
    BLEND_MODE_OPAQUE = 0
    BLEND_MODE_ALPHA_BLEND = 1
    BLEND_MODE_ALPHA_TEST = 2
    BLEND_MODE_ALPHA_ADD = 4
    BLEND_MODE_MULTIPLY_BOTH = 5
    FONT_ALIGN_LEFT = 0
    FONT_ALIGN_RIGHT = 1
    FONT_ALIGN_CENTER = 2

class FontMeasures:
    def __init__(self, name, italic, bold, size, ratio, distance, heightCompensation, widthCompensation):
        self.n = name					#font name
        self.i = italic					#font italic
        self.b = bold					#font bold
        self.s = size					#font multiplier for one pixel height
        self.r = ratio					#font width compared to height
        self.d = distance				#font distance between the leftmost point of one letter and another, avareage
        self.h = heightCompensation		#font height offset to put it centered vertically
        self.w = widthCompensation		#font width offset to put it centered horizontally
        self.f = 0						#font object to be used in rendering
        return

def getSettingsValue(parser, section, option, value, boolean = False):
    if parser.has_option(str(section), str(option)):
        if boolean:
            return parser.getboolean(str(section), option)
        else:
            return parser.get(str(section), str(option))
    else:
        return str(value)

#######################################################

def isASCII(data):
    try:
        data.encode('ascii', 'ignore').decode('ascii').strip()
    except UnicodeDecodeError:
        return False
    else:
        return True

def find_str(s, char):
    index = 0
    if len(char)>0 and char in s:
        c = char[0]
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index
            index += 1
    return -1

### one of the app...CFGValue() funcs has a bug, it cant distinct btw SHOWNM and SHOWNM_TORQ
def appReadCFGValue(path, section, valname, default):
    try:
        result=default
        sect = ''
        if os.path.isfile(path):
            # ac.log(path)
            goOn = False
            s = ''
            try:
                with codecs.open(path, 'r', 'utf_8', errors='ignore') as file:
                    s = file.read()
            except:
                with codecs.open(path, 'r', errors='ignore') as file:
                    s = file.read()
            ss = str(s).split('\n')
            for sss in ss: # for all lines
                sss=sss.strip()
                if find_str(sss, '--')!=0 and find_str(sss, ';')!=0 and find_str(sss, '#')!=0:
                    if ('[' in sss) and (']' in sss):
                        sect = sss
                    if (section=='' or sect=='['+section+']') and (valname in sss):
                        v = sss.replace(' = ', '=').split('=')
                        if len(v)>1:
                            if section=='' and '--' in v[1]:
                                w = v[1].split('--')
                                if len(w)>0:
                                    result = w[0].replace(' ', '')
                            elif ';' in v[1]:
                                w = v[1].split(';')
                                if len(w)>0:
                                    result = w[0].replace(' ', '')
                            else:
                                result = v[1]
    except:
        ac.log('tyre_app_ext: \n' + path + ' \n' + traceback.format_exc())
        ac.console('tyre_app_ext: \n' + path + ' \n' + traceback.format_exc())
    # ac.log(valname + ' = ' + result)
    return result

### one of the app...CFGValue() funcs has a bug, it cant distinct btw SHOWNM and SHOWNM_TORQ
def appWriteCFGValue(path, section, valname, value, createNonExistant=False):
    global lbChng
    try:
        if not os.path.isfile(path) and createNonExistant:
            with io.open(path, 'w', encoding='utf-8') as f:
                f.write('; created by sol_weather app\n['+section+']\n'+valname+'='+str(value)+'\n')
                # ac.log('settings cleaned')
            return
        if os.path.isfile(path):
            with io.open(path, 'r', encoding='utf-8') as f:
                s=f.read()
            #ac.log('first: \n' + s + '\n\n\n\n\n')
            currsection = ''
            t = ''
            idx = -1
            sectid = -1
            found = False
            sEqual = ' = ' if '.lua' in str(path).lower() else '='
            ss = str(s).split('\n')
            for sss in ss:
                idx+=1
                if find_str(sss, '--')!=0 and find_str(sss, ';')!=0 and find_str(sss, '#')!=0:
                    if find_str(sss, '[')==0 and (']' in sss):
                        currsection = sss.split('[')[1].split(']')[0]
                    if find_str(sss, '['+section+']')==0:
                        sectid = idx
                    if find_str(sss, valname)==0 and currsection==section:
                        # ss[idx] = valname + ' = ' + str(value)
                        found = True
                        if '--' in sss:
                            iFound = find_str(sss,'--')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        elif ';' in sss:
                            iFound = find_str(sss,';')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        elif '#' in sss:
                            iFound = find_str(sss,'#')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        else:
                            ss[idx] = valname + sEqual + str(value)
                else:
                    ss[idx] = sss
                t = t + ss[idx] + '\n'
            if found == False and sectid>=0:
                # insert
                found = True
                # t = t[:sectid+1] + valname + sEqual + str(value)+'\n' + t[sectid+1:]
                ss=t.split('\n')
                ss.insert(sectid+1, valname + sEqual + str(value))
                t= '\n'.join(s for s in ss)
            elif found == False:
                # append
                found = True
                t = t[sectid+1:].strip() + '\n\n[' + section + ']\n' + valname + sEqual + str(value)+'\n'
            if found == True:
                f=io.open(path, 'w', encoding='utf8') # write
                f.write(t.strip()+'\n')
                f.close()
        else:
            ac.log('! no ' + str(path))
    except:
        ac.log("TrackHeightApp error: " + section + ' - ' + valname+'\n'+ str(path) + '\n' + traceback.format_exc())
        ac.log(section + ' - ' + valname+'\n'+str(path) + '\n' + traceback.format_exc())

###############################################################################

def appAPPSIZEplus(*args):
    global gAPPSIZE
    if gAPPSIZE<4.0:
        gAPPSIZE += 0.1
    on_click_app_window(0,0)

def appAPPSIZEminus(*args):
    global gAPPSIZE
    if gAPPSIZE>=0.6:
        gAPPSIZE -= 0.1
    on_click_app_window(0,0)

def appOPACITYplus(*args):
    global gOPACITY
    if gOPACITY<=0.9:
        gOPACITY += 0.1
    on_click_app_window(0,0)

def appOPACITYminus(*args):
    global gOPACITY
    if gOPACITY>=0.1:
        gOPACITY -= 0.1
    on_click_app_window(0,0)

def appPREVIEWBACKplus(*args):
    global gPREVIEWBACK
    if gPREVIEWBACK<500:
        gPREVIEWBACK += 10
    on_click_app_window(0,0)

def appPREVIEWBACKminus(*args):
    global gPREVIEWBACK
    if gPREVIEWBACK>=10:
        gPREVIEWBACK -= 10
    on_click_app_window(0,0)

def appPREVIEWFORWplus(*args):
    global gPREVIEWFORW
    if gPREVIEWFORW<500:
        gPREVIEWFORW += 10
    on_click_app_window(0,0)

def appPREVIEWFORWminus(*args):
    global gPREVIEWFORW
    if gPREVIEWFORW>=10:
        gPREVIEWFORW -= 10
    on_click_app_window(0,0)

def appHEIGHT_MULTplus(*args):
    global gHEIGHT_MULT
    if gHEIGHT_MULT<5.9:
        gHEIGHT_MULT += 0.1
    on_click_app_window(0,0)

def appHEIGHT_MULTminus(*args):
    global gHEIGHT_MULT
    if gHEIGHT_MULT>=0.5:
        gHEIGHT_MULT -= 0.1
    on_click_app_window(0,0)

def appWIDTH_MULTplus(*args):
    global gWIDTH_MULT
    if gWIDTH_MULT<4.0:
        gWIDTH_MULT += 0.1
    on_click_app_window(0,0)

def appWIDTH_MULTminus(*args):
    global gWIDTH_MULT
    if gWIDTH_MULT>=0.6:
        gWIDTH_MULT -= 0.1
    on_click_app_window(0,0)

def appSTEPPINGplus(*args):
    global gSTEPPING
    if gSTEPPING<20:
        gSTEPPING += 1
    on_click_app_window(0,0)

def appSTEPPINGminus(*args):
    global gSTEPPING
    if gSTEPPING>=2:
        gSTEPPING -= 1
    on_click_app_window(0,0)

def appCOLOR_MULTplus(*args):
    global gCOLORMULT
    if gCOLORMULT<32:
        gCOLORMULT += 1
    ReadAILine()
    on_click_app_window(0,0)

def appCOLOR_MULTminus(*args):
    global gCOLORMULT
    if gCOLORMULT>=2:
        gCOLORMULT -= 1
    ReadAILine()
    on_click_app_window(0,0)

def appGRAPHTRANSminus(*args):
    global gGRAPHTRANS
    if gGRAPHTRANS>=0.2:
        gGRAPHTRANS -= 0.1
    on_click_app_window(0,0)

def appGRAPHTRANSplus(*args):
    global gGRAPHTRANS
    if gGRAPHTRANS<=0.9:
        gGRAPHTRANS += 0.1
    on_click_app_window(0,0)

def appDRAWBLOCKStoggle(*args):
    global gDRAWBLOCKS
    gDRAWBLOCKS = not gDRAWBLOCKS
    on_click_app_window(0,0)

def appDRAWTEXTtoggle(*args):
    global gDRAWTEXT
    gDRAWTEXT = not gDRAWTEXT
    on_click_app_window(0,0)

def appOnActivated(*args):
    on_click_app_window(0,0)

def on_click_app_window(arg1, arg2):
    global app, bHideTimerOn, hideTimer, gCOLORMULT
    global btnAPPSIZEplus, btnAPPSIZEminus, btnOPACITYplus, btnOPACITYminus, btnPREVIEWBACKplus, btnPREVIEWBACKminus, btnPREVIEWFORWplus, btnPREVIEWFORWminus, btnCOLOR_MULTminus, btnCOLOR_MULTplus, btnGRAPHTRANSplus, btnGRAPHTRANSminus
    global btnHEIGHT_MULTplus, btnHEIGHT_MULTminus, btnWIDTH_MULTplus, btnWIDTH_MULTminus, btnSTEPPINGplus, btnSTEPPINGminus, btnDRAWBLOCKStoggle, btnDRAWTEXTtoggle, ailineYOFFSET
    bHideTimerOn = True
    hideTimer = 5.0
    ailineYOFFSET = 100 * gAPPSIZE
    ac.setIconPosition(app, -50, 0)
    ac.setVisible(btnAPPSIZEminus     ,1)
    ac.setVisible(btnAPPSIZEplus      ,1)
    ac.setVisible(btnOPACITYminus     ,1)
    ac.setVisible(btnOPACITYplus      ,1)
    ac.setVisible(btnPREVIEWBACKminus ,1)
    ac.setVisible(btnPREVIEWBACKplus  ,1)
    ac.setVisible(btnPREVIEWFORWminus ,1)
    ac.setVisible(btnPREVIEWFORWplus  ,1)
    ac.setVisible(btnHEIGHT_MULTminus ,1)
    ac.setVisible(btnHEIGHT_MULTplus  ,1)
    ac.setVisible(btnWIDTH_MULTminus  ,1)
    ac.setVisible(btnWIDTH_MULTplus   ,1)
    ac.setVisible(btnSTEPPINGminus    ,1)
    ac.setVisible(btnSTEPPINGplus     ,1)
    ac.setVisible(btnCOLOR_MULTminus  ,1)
    ac.setVisible(btnCOLOR_MULTplus   ,1)
    ac.setVisible(btnGRAPHTRANSplus   ,1)
    ac.setVisible(btnGRAPHTRANSminus  ,1)
    ac.setVisible(btnDRAWBLOCKStoggle ,1)
    ac.setVisible(btnDRAWTEXTtoggle   ,1)

    ac.setSize(app, (gPREVIEWBACK + gPREVIEWFORW + 10) * gAPPSIZE * gWIDTH_MULT, 101*gAPPSIZE)

    ac.setPosition(btnAPPSIZEminus      ,  0, -45)
    ac.setPosition(btnAPPSIZEplus       ,  25, -45)

    ac.setPosition(btnOPACITYminus      ,  60, -45)
    ac.setPosition(btnOPACITYplus       ,  85, -45)
    ac.setPosition(btnGRAPHTRANSminus   , 120, -45)
    ac.setPosition(btnGRAPHTRANSplus    , 145, -45)
    ac.setPosition(btnPREVIEWBACKminus  , 180, -45)
    ac.setPosition(btnPREVIEWBACKplus   , 205, -45)
    ac.setPosition(btnPREVIEWFORWminus  , 240, -45)
    ac.setPosition(btnPREVIEWFORWplus   , 265, -45)
    ac.setPosition(btnHEIGHT_MULTminus  , 300, -45)
    ac.setPosition(btnHEIGHT_MULTplus   , 325, -45)
    ac.setPosition(btnWIDTH_MULTminus   , 360, -45)
    ac.setPosition(btnWIDTH_MULTplus    , 385, -45)
    ac.setPosition(btnSTEPPINGminus     , 420, -45)
    ac.setPosition(btnSTEPPINGplus      , 445, -45)
    ac.setPosition(btnCOLOR_MULTminus   , 480, -45)
    ac.setPosition(btnCOLOR_MULTplus    , 505, -45)
    ac.setPosition(btnDRAWBLOCKStoggle  , 540, -45)
    ac.setPosition(btnDRAWTEXTtoggle    , 575, -45)

    ac.setSize(btnAPPSIZEminus, 25, 20)
    ac.setSize(btnAPPSIZEplus , 25, 20)
    ac.setSize(btnOPACITYplus, 25, 20)
    ac.setSize(btnOPACITYminus, 25, 20)
    ac.setSize(btnPREVIEWBACKplus, 25, 20)
    ac.setSize(btnPREVIEWBACKminus, 25, 20)
    ac.setSize(btnPREVIEWFORWplus, 25, 20)
    ac.setSize(btnPREVIEWFORWminus, 25, 20)
    ac.setSize(btnHEIGHT_MULTplus, 25, 20)
    ac.setSize(btnHEIGHT_MULTminus, 25, 20)
    ac.setSize(btnWIDTH_MULTplus, 25, 20)
    ac.setSize(btnWIDTH_MULTminus, 25, 20)
    ac.setSize(btnSTEPPINGplus, 25, 20)
    ac.setSize(btnSTEPPINGminus, 25, 20)
    ac.setSize(btnCOLOR_MULTplus, 25, 20)
    ac.setSize(btnCOLOR_MULTminus, 25, 20)
    ac.setSize(btnGRAPHTRANSplus, 25, 20)
    ac.setSize(btnGRAPHTRANSminus, 25, 20)
    ac.setSize(btnDRAWBLOCKStoggle, 25, 20)
    ac.setSize(btnDRAWTEXTtoggle, 25, 20)

    ac.setText(btnAPPSIZEminus    , '-\n    size ' + str(round(gAPPSIZE, 1)))
    ac.setText(btnOPACITYminus    , '-\n  bg '+ str(round(gOPACITY,1)))
    ac.setText(btnPREVIEWBACKminus, '-\n   back '+ str(gPREVIEWBACK))
    ac.setText(btnPREVIEWFORWminus, '-\n    forw '+ str(gPREVIEWFORW))
    ac.setText(btnHEIGHT_MULTminus, '-\n      hMul '+ str(round(gHEIGHT_MULT,1)))
    ac.setText(btnWIDTH_MULTminus , '-\n      wdth '+ str(round(gWIDTH_MULT,1)))
    ac.setText(btnSTEPPINGminus   , '-\n      step '+ str(gSTEPPING))
    ac.setText(btnCOLOR_MULTminus , '-\n    col '+ str(int(gCOLORMULT)))
    ac.setText(btnGRAPHTRANSminus , '-\n    fg '+ str(round(gGRAPHTRANS,1)))
    ac.setText(btnDRAWBLOCKStoggle, 'fill\n'+ str(gDRAWBLOCKS))
    ac.setText(btnDRAWTEXTtoggle  , 'text\n'+ str(gDRAWTEXT))

def acMain(ac_version):
    global app, label, btnSetBackCar, error, sVer
    global vaoToggleButton, vaoDebugButton, lightsDebugButton, copyCameraCoordsButton, copyCameraCoordsButton2
    global doorToggleButton, driverToggleButton, bDetailed, btnResetCar, btnResetStats
    global sTrack, sLayout, sFileOverlay, sFileCameras, btnTimeAttack, btnCameraAdd, btnToggleDetail, btnCameraAuto
    global gAPPSIZE, gOPACITY, gPREVIEWBACK, gPREVIEWFORW, gHEIGHT_MULT, gWIDTH_MULT, gSTEPPING, gCOLORMULT, gDRAWBLOCKS, gDRAWTEXT, gGRAPHTRANS
    global f1, hideTimer
    global btnAPPSIZEplus, btnAPPSIZEminus, btnOPACITYplus, btnOPACITYminus, btnPREVIEWBACKplus, btnPREVIEWBACKminus, btnPREVIEWFORWplus, btnPREVIEWFORWminus, btnCOLOR_MULTminus, btnCOLOR_MULTplus, btnGRAPHTRANSminus, btnGRAPHTRANSplus
    global btnHEIGHT_MULTplus, btnHEIGHT_MULTminus, btnWIDTH_MULTplus, btnWIDTH_MULTminus, btnSTEPPINGplus, btnSTEPPINGminus, btnDRAWBLOCKStoggle, btnDRAWTEXTtoggle

    ac.ext_setStrictMode()
    ac.initFont(0, "Segoe UI", 0, 1)
    try:
        f1 = FontMeasures("Segoe UI", 0, 0, 1.25, 0.69, 0.629, 0.616, 0.066)
        f1.f = ac.ext_glFontCreate(f1.n, f1.s, f1.i, f1.b)
    except:
        error = 20
        ac.log('TrackHeight: CustomShadersPatch not active., some features disabled.')

    app = ac.newApp("TrackHeight") # for the icon to be found
    ac.setTitle(app, "")
    ac.setFontAlignment(app, 'left')
    ac.addRenderCallback(app, onFormRender)
    ac.addOnClickedListener     (app, on_click_app_window)
    ac.addOnAppActivatedListener(app, appOnActivated)

    label = ac.addLabel(app, "") # label for all the output
    ac.setFontSize(label, 12)
    sTrack = ac.getTrackName(0)
    sLayout = ac.getTrackConfiguration(0)

    try:
        settingsParser = None
        if os.path.isfile("apps/python/TrackHeight/settings/settings.ini"):
            settingsParser = configparser.ConfigParser()
            settingsParser.optionxform = str
            settingsParser.read("apps/python/TrackHeight/settings/settings.ini")
            # bDetailed      = getSettingsValue(settingsParser, 'GENERAL', 'DETAILS', bDetailed, True)
            gAPPSIZE      = float(getSettingsValue(settingsParser, 'GENERAL', "APPSIZE", str(gAPPSIZE), False))
            gOPACITY      = float(getSettingsValue(settingsParser, 'GENERAL', "OPACITY", str(gOPACITY), False))
            gPREVIEWBACK  = int  (getSettingsValue(settingsParser, 'GENERAL', "PREVIEWBACK", str(int(gPREVIEWBACK)), False))
            gPREVIEWFORW  = int  (getSettingsValue(settingsParser, 'GENERAL', "PREVIEWFORW", str(int(gPREVIEWFORW)), False))
            gHEIGHT_MULT  = float(getSettingsValue(settingsParser, 'GENERAL', "HEIGHT_MULT", str(gHEIGHT_MULT), False))
            gWIDTH_MULT   = float(getSettingsValue(settingsParser, 'GENERAL', "WIDTH_MULT", str(gWIDTH_MULT), False))
            gSTEPPING     = int  (getSettingsValue(settingsParser, 'GENERAL', "STEPPING", str(gSTEPPING), False))
            gCOLORMULT    = int  (getSettingsValue(settingsParser, 'GENERAL', "COLORMULT", str(int(gCOLORMULT)), False))
            gGRAPHTRANS   = float(getSettingsValue(settingsParser, 'GENERAL', "GRAPHTRANS", str(gGRAPHTRANS), False))
            gDRAWBLOCKS   =       getSettingsValue(settingsParser, 'GENERAL', "DRAWBLOCKS", gDRAWBLOCKS  , True)
            gDRAWTEXT     =       getSettingsValue(settingsParser, 'GENERAL', "DRAWTEXT", gDRAWTEXT      , True)

            # gSTEPPING = float( appReadCFGValue(settingsFilePath,  'GENERAL', 'STEPPING', str( gSTEPPING )) )
            # gCOLORMULT= float(   appReadCFGValue(settingsFilePath,   'GENERAL', 'COLORMULT', str(gCOLORMULT)) )
            # if str(appReadCFGValue(settingsFilePath,              'GENERAL', 'TYRELOAD_ENABLED', str( bShowTyreload ) )) == "False":
            #     bShowTyreload = False

    except:
        ac.log("TrackHeight: " + traceback.format_exc())

    ReadAILine()
    btnAPPSIZEminus = ac.addButton(app, "-")
    btnAPPSIZEplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnAPPSIZEminus, appAPPSIZEminus)
    ac.addOnClickedListener(btnAPPSIZEplus , appAPPSIZEplus)

    btnOPACITYminus = ac.addButton(app, "-")
    btnOPACITYplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnOPACITYminus, appOPACITYminus)
    ac.addOnClickedListener(btnOPACITYplus , appOPACITYplus)

    btnPREVIEWBACKminus = ac.addButton(app, "-")
    btnPREVIEWBACKplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnPREVIEWBACKminus, appPREVIEWBACKminus)
    ac.addOnClickedListener(btnPREVIEWBACKplus , appPREVIEWBACKplus)

    btnPREVIEWFORWminus = ac.addButton(app, "-")
    btnPREVIEWFORWplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnPREVIEWFORWminus, appPREVIEWFORWminus)
    ac.addOnClickedListener(btnPREVIEWFORWplus , appPREVIEWFORWplus)

    btnHEIGHT_MULTminus = ac.addButton(app, "-")
    btnHEIGHT_MULTplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnHEIGHT_MULTminus, appHEIGHT_MULTminus)
    ac.addOnClickedListener(btnHEIGHT_MULTplus , appHEIGHT_MULTplus)

    btnWIDTH_MULTminus = ac.addButton(app, "-")
    btnWIDTH_MULTplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnWIDTH_MULTminus, appWIDTH_MULTminus)
    ac.addOnClickedListener(btnWIDTH_MULTplus , appWIDTH_MULTplus)

    btnSTEPPINGminus = ac.addButton(app, "-")
    btnSTEPPINGplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnSTEPPINGminus, appSTEPPINGminus)
    ac.addOnClickedListener(btnSTEPPINGplus , appSTEPPINGplus)

    btnCOLOR_MULTminus = ac.addButton(app, "-")
    btnCOLOR_MULTplus  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnCOLOR_MULTminus, appCOLOR_MULTminus)
    ac.addOnClickedListener(btnCOLOR_MULTplus , appCOLOR_MULTplus)

    btnGRAPHTRANSminus = ac.addButton(app, "-")
    btnGRAPHTRANSplus = ac.addButton(app, "+")
    ac.addOnClickedListener(btnGRAPHTRANSminus, appGRAPHTRANSminus)
    ac.addOnClickedListener(btnGRAPHTRANSplus , appGRAPHTRANSplus)

    btnDRAWBLOCKStoggle  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnDRAWBLOCKStoggle, appDRAWBLOCKStoggle)

    btnDRAWTEXTtoggle = ac.addButton(app, "-")
    ac.addOnClickedListener(btnDRAWTEXTtoggle, appDRAWTEXTtoggle)

    on_click_app_window(0,0)
    hideTimer        = 0.1
    return "TrackHeight"

def appHideControls():
    global btnAPPSIZEplus, btnAPPSIZEminus, btnOPACITYplus, btnOPACITYminus, btnPREVIEWBACKplus, btnPREVIEWBACKminus, btnPREVIEWFORWplus, btnPREVIEWFORWminus, btnCOLOR_MULTminus, btnCOLOR_MULTplus, btnGRAPHTRANSplus, btnGRAPHTRANSminus
    global btnHEIGHT_MULTplus, btnHEIGHT_MULTminus, btnWIDTH_MULTplus, btnWIDTH_MULTminus, btnSTEPPINGplus, btnSTEPPINGminus, btnDRAWBLOCKStoggle, btnDRAWTEXTtoggle
    ac.setIconPosition(app, 0, -20000)
    ac.setVisible(btnAPPSIZEplus      , 0)
    ac.setVisible(btnAPPSIZEminus     , 0)
    ac.setVisible(btnOPACITYminus     , 0)
    ac.setVisible(btnOPACITYplus      , 0)
    ac.setVisible(btnPREVIEWBACKminus , 0)
    ac.setVisible(btnPREVIEWBACKplus  , 0)
    ac.setVisible(btnPREVIEWFORWminus , 0)
    ac.setVisible(btnPREVIEWFORWplus  , 0)
    ac.setVisible(btnHEIGHT_MULTminus , 0)
    ac.setVisible(btnHEIGHT_MULTplus  , 0)
    ac.setVisible(btnWIDTH_MULTminus  , 0)
    ac.setVisible(btnWIDTH_MULTplus   , 0)
    ac.setVisible(btnSTEPPINGminus    , 0)
    ac.setVisible(btnSTEPPINGplus     , 0)
    ac.setVisible(btnCOLOR_MULTminus  , 0)
    ac.setVisible(btnCOLOR_MULTplus   , 0)
    ac.setVisible(btnGRAPHTRANSminus  , 0)
    ac.setVisible(btnGRAPHTRANSplus   , 0)
    ac.setVisible(btnDRAWBLOCKStoggle , 0)
    ac.setVisible(btnDRAWTEXTtoggle   , 0)


def acUpdate(delta_t):
    global error, timer, appMsg, label, timerMsg, btimerMsg, app
    global tick_counter, max_tick, frame_counter, frame_buffer, time_elapsed, current_fps, MAX_fps, MIN_fps, MAX_lights, MIN_lights
    global odd, lx, ly, lz, lastFrom, sVer, currentSector, sCamCoords, sOrientationFORW, checkpointC, bDetailed, sOrientationFORWtimeattack
    global previousSector, sOVERLAYS_INI, sFileOverlay, bWrittenOverlaysINI, bRecordTimeAttack, iCheckpointHeight, bWrittenCamerasINI, bRecordCameras, sFileCameras
    global lastPoT, currCar
    global lastAltitude, currAltitude, bHideTimerOn, hideTimer, gOPACITY

    try:
        timer += delta_t
        if bHideTimerOn:
            hideTimer -= delta_t
            if hideTimer <= 0.0:
                bHideTimerOn = False
                appHideControls()

        if timer > 0.133:
            timer = 0.0
            try:
                ac.setBackgroundOpacity(app, gOPACITY)
                ac.drawBorder(app, 0)
                if error<10:
                    lastAltitude = currAltitude
                    currAltitude = ac.ext_getAltitude(0)
            except:
                if error<10:
                    error+=1
                ac.setTitle(app, "no fast_lane.ai \nor\ncsp not active")
    except:
        ac.log("TrackHeight error: " + traceback.format_exc())

def acShutdown(*args):
    global gAPPSIZE, gOPACITY, gPREVIEWBACK, gPREVIEWFORW, gHEIGHT_MULT, gWIDTH_MULT, gSTEPPING, gCOLORMULT, gDRAWBLOCKS, gDRAWTEXT, gGRAPHTRANS
    settingsFilePath = "apps/python/TrackHeight/settings/settings.ini"
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'APPSIZE'    , str(round(gAPPSIZE, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'OPACITY'    , str(round(gOPACITY, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'PREVIEWBACK',       str(gPREVIEWBACK),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'PREVIEWFORW',       str(gPREVIEWFORW),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'HEIGHT_MULT', str(round(gHEIGHT_MULT, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'WIDTH_MULT' , str(round(gWIDTH_MULT, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'STEPPING'   ,       str(gSTEPPING),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'COLOR_MULT' , str(  int(gCOLORMULT)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'GRAPHTRANS' , str(round(gGRAPHTRANS, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'DRAWBLOCKS' ,       str(gDRAWBLOCKS),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'DRAWTEXT'   ,       str(gDRAWTEXT),True)
    return

#######################################################

def distance(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2 )

def distance2d(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 )

def appDrawLine(x1,y1,x2,y2,width=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1        ,y1)
    ac.glVertex2f(x2-width/2,y2)
    ac.glVertex2f(x2        ,y2)
    ac.glVertex2f(x1+width/2,y1)
    ac.glEnd()

def appDrawLine3(x1,y1,x2,y2,height=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1         )
    ac.glVertex2f(x2,y2-height/2)
    ac.glVertex2f(x2,y2         )
    ac.glVertex2f(x1,y1+height/2)
    ac.glEnd()

def appDrawLine4(x1,y1,x2,y2):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x1,y2)
    ac.glVertex2f(x2,y2)
    ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawLine5(x1,y1,x2,y2,y3):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x1,y3)
    ac.glVertex2f(x2,y2)
    ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawText(t, r, g, b, a, x, y, sz):
    global f1
    ac.ext_glFontColor(f1.f, r, g, b, a)
    ac.ext_glFontUse(f1.f, t, x, y, sz, ExtGL.FONT_ALIGN_LEFT)

def appDrawTextShadow(t, a, x, y, sz):
    global f1
    ac.ext_glFontColor(f1.f, 0, 0, 0, a)
    ac.ext_glFontUse(f1.f, t, x, y, sz, ExtGL.FONT_ALIGN_LEFT)

def clamp(n, minn, maxn):
    if n < minn:
        return minn
    elif n > maxn:
        return maxn
    else:
        return n

def ReadAILine():
    global sFileCameras, sTrack, sLayout, AI_LINE, AI_LINE_LENGTH, AI_LINE_dM, AI_LINE_rgb, gCOLORMULT
    sFileAI     = 'content/tracks/' + sTrack+            '/ai/fast_lane.ai'
    if sLayout!='':
        sFileAI = 'content/tracks/' + sTrack+'/'+sLayout+'/ai/fast_lane.ai'
    if not os.path.isfile(sFileAI) or os.path.getsize(sFileAI)<=24:
        ac.log('No "fast_lane.ai" found')
        return
    try:
        with open(sFileAI, "rb") as buffer:
            # should be at start, but do it anyway
            buffer.seek(0)
            # read header, detailCount is number of data points available
            header, detailCount, u1, u2 = struct.unpack("4i", buffer.read(4 * 4))

            data_ideal   = []
            data_detail  = []
            AI_LINE      = []
            AI_LINE_rgb  = []
            AI_LINE_dM   = []
            AI_LINE_LENGTH = 0.0

            # read ideal-line data
            for i in range(detailCount):       # 4 floats, one integer
                data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
                x , z , y, dist, id = data_ideal[i]
                coordscurr = ( float(x), -float(y), float(z)  )
                if i>0:
                    AI_LINE_LENGTH += distance( coordscurr, coordslast )
                coordslast = coordscurr

            # read more details data
            for i in range(detailCount):        # 18 floats
                data_detail.append(struct.unpack("18f", buffer.read(4 * 18)))

            xl, zl, yl, distl, idl = data_ideal[len(data_ideal)-1] # last point
            ldM = 0.0
            for i in range(len(data_ideal)):
                x, z, y, dist, id = data_ideal[i]
                coordsAI = ( float(x), -float(y), float(z)  )
                direction = -math.degrees( math.atan2(yl - y, x - xl))
                _wallLeft  = data_detail[i][6]
                x          = x + math.cos((-direction + 90) * math.pi / 180) * _wallLeft
                y          = y - math.sin((-direction + 90) * math.pi / 180) * _wallLeft
                coordsL    = ( float(x), -float(y), float(z)  )
                _wallRight = data_detail[i][7]
                x          = x + math.cos((-direction - 90) * math.pi / 180) * _wallRight
                y          = y - math.sin((-direction - 90) * math.pi / 180) * _wallRight
                coordsR    = ( float(x), -float(y), float(z)  )
                # ac.log( str(round(coordsL[0],6)) +','+str(round(coordsL[2],6)) +','+str(round(coordsL[1],6)))

                # slope at this point
                xa = distl - dist
                xb = z - zl
                if xa!=0.0:
                    # dM = xb / xa * gCOLORMULT
                    dM = clamp( xb / xa * gCOLORMULT , -1.0, 1.0)
                else:
                    dM = 0.0
                # dM = -math.degrees(math.atan(xb/xa))
                # ldM = dM
                ldM = (ldM + dM) / 2.0  # do small interpolation
                r=0.75  #=1.0
                g=0.75  #=1.0
                b=0.75  #=1.0
                if abs(ldM) > 0.02:
                    if dM>0.0:
                        r=0.5-abs(ldM/2)
                        g=0.5+abs(ldM/2)
                        b=r
                    else:
                        r=0.5+abs(ldM/2)
                        g=0.5-abs(ldM/2)
                        b=g
                color1=[r, g, b]

                AI_LINE_dM.append(dM)      # Slope in percent
                AI_LINE_rgb.append(color1) # color for this amount of slope
                AI_LINE.append(coordsAI)

                yl = y
                xl = x
                zl = z
                distl = dist
                # ac.log( str(xa) + ' - ' + str(xb) + ' - ' + str(color1))

        # ac.log(str(AI_LINE_LENGTH) + ' - ' + str(len(AI_LINE)))
    except:
        data_ideal   = []
        data_detail  = []
        AI_LINE      = []
        ac.log("TrackHeight error: " + traceback.format_exc())

###############################################################################

def onFormRender(deltaT):
    global error, bHideTimerOn, gDRAWTEXT, gDRAWBLOCKS, lastAltitude, currAltitude, AI_LINE_LENGTH, AI_LINE, YOFFSET, gPREVIEWBACK, gPREVIEWFORW, ailineYOFFSET, gHEIGHT_MULT, gSTEPPING, gCOLORMULT, gAPPSIZE, gGRAPHTRANS
    try:
        if len(AI_LINE)>0:
            lix=0
            liy=0
            currPoT = ac.getCarState(ac.getFocusedCar(), acsys.CS.NormalizedSplinePosition)
            currAIid = int( len(AI_LINE) * currPoT )
            currAIid = currAIid - (currAIid % gSTEPPING)
            AIid = currAIid - gPREVIEWBACK
            if AIid<0:
                AIid = len(AI_LINE)-1 + AIid
            i1=1
            i2=gPREVIEWBACK + gPREVIEWFORW
            YOFFSET = - AI_LINE[currAIid][2] * gHEIGHT_MULT

            ### dummy drawing text or sometimes drawing fails , wtf?
            if error<10:
                appDrawText('.', 1,1,1,1,0,0, 0.01)

            while i1 < i2:
                ix = (i1+3) * gAPPSIZE * gWIDTH_MULT
                iy = - AI_LINE[AIid][2]*gHEIGHT_MULT - YOFFSET + ailineYOFFSET/gHEIGHT_MULT*gAPPSIZE + gHEIGHT_MULT*gAPPSIZE
                if liy==0.0:
                    liy = iy

                # draw the height profile
                if i1 > 0:
                    a=0.75 # default transperancy for almost flat <1%
                    # only with color when above +-1%
                    if abs(AI_LINE_dM[AIid])>0.005:
                        a=gGRAPHTRANS + abs(AI_LINE_dM[AIid]*gGRAPHTRANS)

                    # now actually draw one part

                    #def appDrawLine5(x1,y1,x2,y2,y3):
                    if gDRAWBLOCKS:
                        # appDrawLine(ix, ailineYOFFSET, ix+gSTEPPING, iy, gSTEPPING*2)
                        #appDrawLine5(ix             , ailineYOFFSET*gAPPSIZE, ix+gSTEPPING*gAPPSIZE*gWIDTH_MULT, iy  , liy-1)
                        x1=ix
                        y1=ailineYOFFSET*gAPPSIZE
                        x2=ix+gSTEPPING*gAPPSIZE*gWIDTH_MULT
                        y2=iy
                        y3=liy-1
                    else:
                        #appDrawLine(lix, liy+5, ix+gSTEPPING, iy-5)
                        #appDrawLine5(lix+gSTEPPING-1,                  liy+5, ix+gSTEPPING-1                   , iy-5, liy-5)
                        x1=lix+gSTEPPING-1
                        y1=liy+5
                        x2=ix+gSTEPPING-1
                        y2=iy-5
                        y3=liy-5

                    ac.glBegin(acsys.GL.Quads)
                    ac.glColor4f(AI_LINE_rgb[AIid][0], AI_LINE_rgb[AIid][1], AI_LINE_rgb[AIid][2], 1)
                    ac.glVertex2f(x1,y1)
                    ac.glColor4f(AI_LINE_rgb[AIid][0], AI_LINE_rgb[AIid][1], AI_LINE_rgb[AIid][2], 1)
                    ac.glVertex2f(x1,y3)
                    ac.glColor4f(AI_LINE_rgb[AIid][0], AI_LINE_rgb[AIid][1], AI_LINE_rgb[AIid][2], 1)
                    ac.glVertex2f(x2,y2)
                    ac.glColor4f(AI_LINE_rgb[AIid][0], AI_LINE_rgb[AIid][1], AI_LINE_rgb[AIid][2], 1)
                    ac.glVertex2f(x2,y1)
                    ac.glEnd()

                        # iy-=1
                lix = ix
                liy = iy

                i1 += gSTEPPING
                AIid += gSTEPPING
                if AIid>=len(AI_LINE):
                    AIid = 0

            if error<10:
                # position marker/text over all if done
                if AI_LINE_dM[currAIid]>0.0:
                    sAdd='▽ '
                else:
                    sAdd='△ '
                if gDRAWTEXT:
                    sAdd = str(round(-AI_LINE_dM[currAIid]/gCOLORMULT*100,1)) +'%  |  '+ str(round(currAltitude, 1)) +'m\n' + sAdd
                else:
                    sAdd = "\n" + sAdd
                ix = gPREVIEWBACK
                iy = - AI_LINE[currAIid][2]*gHEIGHT_MULT - YOFFSET + ailineYOFFSET/gHEIGHT_MULT*gAPPSIZE/2
                # always draw up / down symbol
                appDrawTextShadow(sAdd, 0.9, ix-1+gAPPSIZE*gWIDTH_MULT-2, iy-1, 12*gAPPSIZE)
                appDrawTextShadow(sAdd, 0.9, ix-1+gAPPSIZE*gWIDTH_MULT-2, iy  , 12*gAPPSIZE)
                appDrawText(      sAdd, AI_LINE_rgb[currAIid][0], AI_LINE_rgb[currAIid][1], AI_LINE_rgb[currAIid][2], 0.9, ix-2+gAPPSIZE*gWIDTH_MULT-2, iy-1, 12*gAPPSIZE)
    except:
        ac.log("TrackHeight: " + traceback.format_exc())

