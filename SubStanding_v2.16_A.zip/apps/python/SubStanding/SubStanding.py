# Name:       SubStanding for Assetto Corsa
# Version:    v2.16 A
# Author:     Sylvain Villet, AW939, leBluem
# Contact:    sylvain.villet@gmail.com
# Date:       22.09.2017
# upDate:     07.06.2025 (leBluem)
# Desc.:      This app provides standings and positions
#             in a subgroup of the cars, that can be
#             the same car as the player or a class like
#             LMP1, GT2, GT3 etc defined here.
#             It also provides the global standing with
#             the same design (max 36 cars).
#             The app can be fully configured from the SubStanding_config widget.
#
#             Feel free to add, remove or modify the "classes"
#             definitions in the Substanding_classes/classes.ini file.
#
# Thanks:     - Rombik for the sim_info module
#             - Rivali (OV1Info) and Fernando Deutsch (ferito-LiveCarTracker)
#             for the inspiration and example
#             - ExOAte for the beta tests and ideas

import ac
import acsys
import sys
import os
import configparser
import json
import time
import platform
import math
import traceback
import functools
import random

# import libraries
try:
    if platform.architecture()[0] == "64bit":
      sysdir='apps/python/SubStanding/SubStanding_dll/stdlib64'
    else:
      sysdir='apps/python/SubStanding/SubStanding_dll/stdlib'
    sys.path.insert(0, sysdir)
    os.environ['PATH'] = os.environ['PATH'] + ";."

    from SubStanding_lib.sim_info import info
except:
    ac.log("SubStanding: Error importing libraries: %s" % traceback.format_exc())
    raise

## Classes from the classes.ini file
classes = []

currentClass = 0
btnClassprev = 0
btnClassnext = 0

## Teammates and rivals from the drivers.ini file
teammates = []
rivals = []
ignored = []

serverIp = ""

# Global variables
didJustReset = False
spacing = 6
firstSpacing = 30
fontSizeConfig = 16
fontStandings = -1
fontStandingsBold = -1
fontMonoBold = -1

maxDriverCount = 32
raceMode = -1
sectorCount = 3

driversFullList = []
focusedCar = 0
sessionBestLap = None
sessionBestLapText = None
sessionBestSectors = []
myDriver = 0
myBestLap = None
myLastLap = None
# sectors based on miniSectorCount (+1 for the time when reaching the finish again)
myBestLapSectors = [] # sector times in s, first sector is 0, last sector is the laptime
myCurrentLapSectors = [] # sector times in s, not normalized, first sector is time at start of the lap
myLastLapSectors = [] # sector times in s, not normalized, first sector is time at start of the lap
trackLength = 0
miniSectorCount = 1
lastUpdateTime = 1000000
lastUpdateTimeDelta = 1000000

badge=[]
livery=[]
miniSkin=[]
nationFlags={}

# fallback if classTagColors is not configured
driverClassColorOptions = [
    (0.5, 0.5, 0.5, 1), # grey (for unknown)
    (0, 0.5, 1, 1), # blue
    (1, 0, 0, 1), # red
    (1, 1, 0, 1), # yellow
    (0, 1, 0.5, 1), # green
    (0.5, 0, 1, 1), # violet
]

debug = 0
cpuUsage = 0

# Objects
SubStandings = {
    "model": 0,
    "class": 0,
    "global": 0,
    "relative": 0,
    "class2": 0
}

SubStandingsConfigs = {
    "general": {
        # overall
        "updateTime": 200,
        "flattenUpdates": 1,
        ## Positions
        "showLogoPos": 0,
        "showTitlePos": 1,
        "fontSizePos": 32,
        "opacityPos": 50,
        "showBorderPos": 1
    },
    "colors": {},
    "distanceColors": {},
    "timeColors": {},
    "model": 0,
    "class": 0,
    "global": 0,
    "relative": 0
}

SubPositions = {
    "model": 0,
    "class": 0,
    "global": 0,
    "class2": 0
}

BottomAnchors = {
    "SubStanding_Global": 0,
    "SubStanding_Relative": 0,
    "SubStanding_SameCar": 0,
    "SubStanding_Class": 0,
    "SubStanding_Class2": 0
}

config = 0
configApp = 0

def getJSONCarname(carnameid):
    carname =""
    try:
        CAR_JSON_PATH = "content/cars/%s/ui/ui_car.json" % carnameid
        with open(CAR_JSON_PATH, 'r', encoding="utf-8") as json_data:
            # the ui_car.json is full of invalid json, so we need to replace invalid characters first
            json_string = json_data.read().replace('\n', ' ').replace('\t', ' ')
            data = json.loads(json_string)
            return data["name"]
    except:
        ac.log("SubStanding: Error in 'name' %s: %s" % (carnameid, traceback.format_exc()))
    return carname


def acMain(ac_version):
    try:
        global classes, currentClass
        global trackLength, miniSectorCount, cpuUsage, startTime
        global config, classesConfig, configApp
        global fontStandings, fontStandingsBold, fontMonoBold
        global badge, livery, miniSkin, driverClassColors
        global teammates, rivals, ignored, maxDriverCount
        global myDriver, driversFullList
        global sessionBestSectors

        config = configparser.ConfigParser(inline_comment_prefixes=';')
        config.read(["apps/python/SubStanding/settings/settings_defaults.ini", "apps/python/SubStanding/settings/settings.ini"], encoding='utf-8')

        # Global
        SubStandingsConfigs["general"]["updateTime"] = config.getint("GLOBAL", "updateTime")
        SubStandingsConfigs["general"]["flattenUpdates"] = config.getint("GLOBAL", "flattenUpdates")
        SubStandingsConfigs["general"]["useClassTags"] = config.getint("GLOBAL", "useClassTags")
        SubStandingsConfigs["general"]["classTags"] = list(filter(lambda t: t != "",map(lambda t: t.strip(), config.get("GLOBAL", "classTags").split(","))))
        SubStandingsConfigs["general"]["classTagColors"] = list(filter(lambda t: t != "", map(lambda t: t.strip(), config.get("GLOBAL", "classTagColors").split(","))))
        SubStandingsConfigs["general"]["classTagSpecialChars"] = config.get("GLOBAL", "classTagSpecialChars")
        SubStandingsConfigs["general"]["togglenameinterval"] = 0
        SubStandingsConfigs["general"]["togglenameinterval"] = config.getint("GLOBAL", "togglenameinterval")

        # Colors
        SubStandingsConfigs["colors"]["ownColor"] = getColorFromHex(config.get("COLORS", "owncolor"), defaultColor = (0, 1, 1, 1))
        SubStandingsConfigs["colors"]["leaderColor"] = getColorFromHex(config.get("COLORS", "leadercolor"), defaultColor = (1, 1, 1, 1))
        SubStandingsConfigs["colors"]["teamColor"] = getColorFromHex(config.get("COLORS", "teamcolor"), defaultColor = (0, 1, 1, 1))
        SubStandingsConfigs["colors"]["rivalColor"] = getColorFromHex(config.get("COLORS", "rivalcolor"), defaultColor = (1, 0, 1, 1))

        # Distance Colors
        SubStandingsConfigs["distanceColors"]["behindColor"] = getColorFromHex(config.get("DISTANCE_COLORS", "behindcolor"), defaultColor = (0, 1, 0.5, 1))
        SubStandingsConfigs["distanceColors"]["behindLappedColor"] = getColorFromHex(config.get("DISTANCE_COLORS", "behindlappedcolor"), defaultColor = (0, 0.5, 1, 1))
        SubStandingsConfigs["distanceColors"]["aheadColor"] = getColorFromHex(config.get("DISTANCE_COLORS", "aheadcolor"), defaultColor = (1, 0.5, 0, 1))
        SubStandingsConfigs["distanceColors"]["aheadLappedColor"] = getColorFromHex(config.get("DISTANCE_COLORS", "aheadlappedcolor"), defaultColor = (1, 1, 0, 1))

        # Time Colors
        SubStandingsConfigs["timeColors"]["sessionBest"] = getColorFromHex(config.get("TIME_COLORS", "sessionbest"), defaultColor = (1, 0.3, 1, 1))
        SubStandingsConfigs["timeColors"]["personalBest"] = getColorFromHex(config.get("TIME_COLORS", "personalbest"), defaultColor = (0, 1, 0.5, 1))

        # Standings
        SubStandingsConfigs["global"] = loadStandingsConfig("STANDINGS_GLOBAL", False)
        SubStandingsConfigs["class"] = loadStandingsConfig("STANDINGS_CLASS", False)
        SubStandingsConfigs["class2"] = loadStandingsConfig("STANDINGS_CLASS2", False)
        SubStandingsConfigs["model"] = loadStandingsConfig("STANDINGS_SAME_CAR", False)
        SubStandingsConfigs["relative"] = loadStandingsConfig("STANDINGS_RELATIVE", True)

        # Positions
        SubStandingsConfigs["general"]["showLogoPos"]   = config.getint("POSITIONS", "showLogoPos")
        SubStandingsConfigs["general"]["showTitlePos"]  = config.getint("POSITIONS", "showTitlePos")
        SubStandingsConfigs["general"]["fontSizePos"]   = config.getint("POSITIONS", "fontSizePos")
        SubStandingsConfigs["general"]["opacityPos"]    = config.getint("POSITIONS", "opacityPos")
        SubStandingsConfigs["general"]["showBorderPos"] = config.getint("POSITIONS", "showBorderPos")

        BottomAnchors["SubStanding_Global"] = config.getint("WINDOW", "bottomAnchorGlobal")
        BottomAnchors["SubStanding_Relative"] = config.getint("WINDOW", "bottomAnchorRelative")
        BottomAnchors["SubStanding_SameCar"] = config.getint("WINDOW", "bottomAnchorSameCar")
        BottomAnchors["SubStanding_Class"] = config.getint("WINDOW", "bottomAnchorClass")
        BottomAnchors["SubStanding_Class2"] = config.getint("WINDOW", "bottomAnchorClass")

        fontStandings = ac.ext_glFontCreate("Default", 16, 0, 0)
        fontStandingsBold = ac.ext_glFontCreate("Default", 16, 0, 1)
        fontMonoBold = ac.ext_glFontCreate("Consolas", 16, 0, 1)
        ac.ext_glFontColor(fontMonoBold, (0,0,0,1))

        # Get classes
        try:
            classesConfig = configparser.ConfigParser()
            classesConfig.read("apps/python/SubStanding/SubStanding_classes/classes.ini", encoding='utf-8')

            for eachSection in classesConfig.sections():
                classTmp = []
                classTmp.append(eachSection)
                for eachItem in classesConfig.items(eachSection):
                    classTmp.append(eachItem[1])
                classes.append(classTmp)
        except Exception as e:
            ac.log("SubStanding Error reading classes.ini: %s" % str(e))

        myCarName = ac.getCarName(0)

        maxDriverCount = ac.getCarsCount()

        sessionBestSectors = [0] * sectorCount

        # Get teammates and rivals
        try:
            driversConfig = configparser.ConfigParser()
            driversConfig.read("apps/python/SubStanding/SubStanding_drivers/drivers.ini", encoding='utf-8')

            for eachSection in driversConfig.sections():
                if eachSection == "TEAMMATES":
                    for eachItem in driversConfig.items(eachSection):
                        teammates.append(eachItem[1])
                elif eachSection == "RIVALS":
                    for eachItem in driversConfig.items(eachSection):
                        rivals.append(eachItem[1])
                elif eachSection == "IGNORED":
                    for eachItem in driversConfig.items(eachSection):
                        ignored.append(eachItem[1])
        except Exception as e:
            ac.log("SubStanding Error reading drivers.ini: %s" % str(e))

        # trackLength in meters
        trackLength = ac.getTrackLength(0)
        miniSectorCount = math.floor(trackLength / 50) # every 50m
        startTime = time.time()

        # Get all needed infos
        for index in range(maxDriverCount):
            driver = initDriver(index)
            if index == 0:
                myDriver = driver

            driversFullList.append(driver)


            # badges / liveries / miniSkins
            if type(driver["carName"]) == type(""):
                driver["carNameFull"] = getJSONCarname(driver["carName"])

                # Badge
                textureId = ac.newTexture("content/cars/" + driver["carName"] + "/ui/badge.png")
                if textureId >= 0:
                    badge.append(textureId)
                else:
                    badge.append(-1)

                # Livery
                # ie \content\cars\gd_austin_100\skins\GreenMatte\preview.jpg
                sSkin = ac.getCarSkin(index)
                textureId = -1
                if os.path.isfile(            "content/cars/" + driver["carName"] + "/skins/" + sSkin + "/livery.png"):
                    textureId = ac.newTexture("content/cars/" + driver["carName"] + "/skins/" + sSkin + "/livery.png")
                elif os.path.isfile(          "content/cars/" + driver["carName"] + "/skins/" + sSkin + "/livery.jpg"):
                    textureId = ac.newTexture("content/cars/" + driver["carName"] + "/skins/" + sSkin + "/livery.jpg")
                livery.append(textureId)

                # Mini Skin
                textureId = -1
                # ac.log("content/cars/" + carName + "/skins/" + sSkin + "/preview.png")
                if os.path.isfile(            "content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview_mini.png"):
                    textureId = ac.newTexture("content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview_mini.png")
                elif os.path.isfile(          "content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview_mini.jpg"):
                    textureId = ac.newTexture("content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview_mini.jpg")
                elif os.path.isfile(          "content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview.png"):
                    textureId = ac.newTexture("content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview.png")
                elif os.path.isfile(          "content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview.jpg"):
                    textureId = ac.newTexture("content/cars/" + driver["carName"] + "/skins/" + sSkin + "/preview.jpg")
                miniSkin.append(textureId)
            else:
                badge.append(-1)
                livery.append(-1)
                miniSkin.append(-1)

        calculateDriverClasses()
        # ac.log("clas       " + myDriver["class"])
        # ac.log("clas clean " + cleanDriverClass(myDriver["class"]))
        driverclass = str(cleanDriverClass(myDriver["class"]))

        SubStandings["global"]   = StandingWindow("SubStanding_Global"  , ac.newApp("SubStanding_Global")  , "Global"     , SubStandingsConfigs["global"], 0)
        SubStandings["relative"] = StandingWindow("SubStanding_Relative", ac.newApp("SubStanding_Relative"), "Relative"   , SubStandingsConfigs["relative"], 1)
        SubStandings["model"]    = StandingWindow("SubStanding_SameCar" , ac.newApp("SubStanding_SameCar") , "Same Car"   , SubStandingsConfigs["model"], 0)
        SubStandings["class"]    = StandingWindow("SubStanding_Class"   , ac.newApp("SubStanding_Class")   , driverclass  , SubStandingsConfigs["class"], 0)
        currentClass = SubStandingsConfigs["general"]["classTags"].index(myDriver["class"])
        if currentClass>0:
            currentClass=0
        elif currentClass==0 and len(SubStandingsConfigs["general"]["classTags"])>0:
            currentClass=1
        # SubStandings["class2"]   = StandingWindow("SubStanding_Class2", ac.newApp("SubStanding_Class2"), classes[currentClass], SubStandingsConfigs["class2"], 0)
        # SubStandings["class2"]   = StandingWindow("SubStanding_Class2", ac.newApp("SubStanding_Class2"), cleanDriverClass(myDriver["class"]), SubStandingsConfigs["class2"], 0)
        SubStandings["class2"]   = StandingWindow("SubStanding_Class2"  , ac.newApp("SubStanding_Class2"), SubStandingsConfigs["general"]["classTags"][currentClass], SubStandingsConfigs["class2"], 0)

        SubPositions["model"]    = PositionWindow(ac.newApp("SubStanding_SameCar_Pos"), "Same Car")
        SubPositions["class"]    = PositionWindow(ac.newApp("SubStanding_Class_Pos"), cleanDriverClass(myDriver["class"]))
        SubPositions["class2"]   = PositionWindow(ac.newApp("SubStanding_Class_Pos2"), SubStandingsConfigs["general"]["classTags"][currentClass]) # cleanDriverClass(myDriver["class"]))
        # SubPositions["class2"]   = PositionWindow(ac.newApp("SubStanding_Class_Pos2"), classes[currentClass])# "#GT2") # cleanDriverClass(myDriver["class"]))
        # SubPositions["class2"]   = PositionWindow(ac.newApp("SubStanding_Class_Pos2"), classes[currentClass])# "#GT3") # cleanDriverClass(myDriver["class"]))
        SubPositions["global"]   = PositionWindow(ac.newApp("SubStanding_Global_Pos"), "Global")

        configApp = SubStanding_config(ac.newApp("SubStanding_config"), "SubStanding config", fontSizeConfig)

        ac.addRenderCallback(SubStandings["model"].window, onRenderCallbackStandingModel)
        ac.addRenderCallback(SubStandings["class"].window, onRenderCallbackStandingClass)
        ac.addRenderCallback(SubStandings["class2"].window, onRenderCallbackStandingClass2)
        ac.addRenderCallback(SubStandings["global"].window, onRenderCallbackStandingGlobal)
        ac.addRenderCallback(SubStandings["relative"].window, onRenderCallbackStandingRelative)

        ac.addRenderCallback(SubPositions["model"].window, onRenderCallbackPositionModel)
        ac.addRenderCallback(SubPositions["class"].window, onRenderCallbackPositionClass)
        ac.addRenderCallback(SubPositions["class2"].window, onRenderCallbackPositionClass2)
        ac.addRenderCallback(SubPositions["global"].window, onRenderCallbackPositionGlobal)

        ac.addRenderCallback(configApp.window, onRenderCallbackConfig)

        ac.setText(btnClassnext, "  >   " + str(currentClass+1) + "/" + str(len(SubStandingsConfigs["general"]["classTags"])))

        if debug:
            cpuUsage = CpuUsage("SubStanding_CpuUsage", "CPU Usage", 16)

        return "SubStanding"
    except:
        ac.log("SubStanding: Error in acMain: %s" % traceback.format_exc())

def initDriver(index):
    return {
            "carId":        index,
            "connected":    ac.isConnected(index),
            "driverName":   ac.getDriverName(index),
            "nation":       ac.getDriverNationCode(index),
            "carName":      ac.getCarName(index),
            "carNameFull":  getJSONCarname(ac.getCarName(index)),
            "class":        getDriverClassByCar(ac.getCarName(index)),
            "bestLap":      ac.getCarState(index, acsys.CS.BestLap),
            "lastLap":      ac.getCarState(index, acsys.CS.LastLap),
            "lapCount":     ac.getCarState(index, acsys.CS.LapCount),
            "speedMS":      ac.getCarState(index, acsys.CS.SpeedMS),
            "distance":     ac.getCarState(index, acsys.CS.LapCount) + ac.getCarState(index, acsys.CS.NormalizedSplinePosition),
            "lapDistance":  ac.getCarState(index, acsys.CS.NormalizedSplinePosition),
            "tyres":        ac.getCarTyreCompound(index),
            "isInPitLine":  ac.isCarInPitline(index),
            "currentMiniSector": -1,
            "miniSectorTimes": [None] * miniSectorCount, # array of all mini sector times in seconds. Unknown times will be None
            "currentSector": -1,
            "sectorTimes": [0] * sectorCount,
            "bestSectorTimes": [0] * sectorCount,
            "pitStops":     0,
            "pitEntryFlag": False,
            "raceStartFlag": True
        }

def loadStandingsConfig(key, isRelative):
    configItem = {
        "showLogo": config.getint(key, "showlogo"),
        "showTitle": config.getint(key, "showtitle"),
        "fontSize": config.getint(key, "fontsize"),
        "fontWeight": config.get(key, "fontweight"),
        "opacity": config.getint(key, "opacity"),
        "bottomAnchor": config.getint(key, "bottomanchor"),

        "showBorder": config.getint(key, "showborder"),
        "showRowBackground": config.getint(key, "showrowbackground"),
        "clickToSpectate": config.get(key, "clicktospectate"),

        "nameMode": config.get(key, "namemode"),
        "showClass": config.getint(key, "showclass"),
        "showNation": config.getint(key, "shownation"),
        "showBadge": config.get(key, "showbadge"),
        "showTyres": config.getint(key, "showtyres"),
        "showPitStops": config.getint(key, "showpitstops"),
        "showInterval": config.get(key, "showinterval"),
        "deltaSign": config.get(key, "deltasign"),
        "highlightDeltas": config.getint(key, "highlightdeltas"),
        "showBestLap": config.get(key, "showbestlap"),
        "showLastLap": config.get(key, "showlastlap"),
        "colorBestLaps": config.getint(key, "colorbestlaps"),
        "showSectors": config.get(key, "showsectors"),
        "colorSectors": config.getint(key, "colorsectors"),

        "showGlobalPosition": 1, # to be overridden for actually configurable standings
        "unit": config.get(key, "unit"),
        "driverDisplayed": config.getint(key, "driverdisplayed"),
        "topDriversDisplayed": config.getint(key, "topdriversdisplayed"),
    }

    if isRelative:
        configItem["colorAt"] = config.getint(key, "colorat")
        configItem["showGap"] = config.getint(key, "showgap") # as int for bool selection
        configItem["showLapDiffRelative"] = config.getint(key, "showlapdiffrelative")
    else:
        if key != "STANDINGS_GLOBAL":
            configItem["showGlobalPosition"] = config.getint(key, "showglobalposition")
        configItem["showGap"] = config.get(key, "showgap") # as string for multi mode
        configItem["showGapMode"] = config.get(key, "showgapmode")

    configItem["elementOrder"] = ["position", "class", "badge", "livery", "miniskin", "nationFlag", "name", "tyres", "pit", "interval", "gapToFirst", "bestLap", "lastLap", "sectors"]

    return configItem

def writeStandingsConfig(fileKey, configKey, isRelative):
    config.set(fileKey, "showLogo", str(SubStandingsConfigs[configKey]["showLogo"]))
    config.set(fileKey, "showTitle", str(SubStandingsConfigs[configKey]["showTitle"]))
    config.set(fileKey, "fontSize", str(SubStandingsConfigs[configKey]["fontSize"]))
    config.set(fileKey, "fontWeight", str(SubStandingsConfigs[configKey]["fontWeight"]))
    config.set(fileKey, "opacity", str(SubStandingsConfigs[configKey]["opacity"]))
    config.set(fileKey, "bottomAnchor", str(SubStandingsConfigs[configKey]["bottomAnchor"]))

    config.set(fileKey, "showBorder", str(SubStandingsConfigs[configKey]["showBorder"]))
    config.set(fileKey, "showRowBackground", str(SubStandingsConfigs[configKey]["showRowBackground"]))
    config.set(fileKey, "clickToSpectate", str(SubStandingsConfigs[configKey]["clickToSpectate"]))
    config.set(fileKey, "nameMode", str(SubStandingsConfigs[configKey]["nameMode"]))
    config.set(fileKey, "showClass", str(SubStandingsConfigs[configKey]["showClass"]))
    config.set(fileKey, "showNation", str(SubStandingsConfigs[configKey]["showNation"]))
    config.set(fileKey, "showBadge", str(SubStandingsConfigs[configKey]["showBadge"]))
    config.set(fileKey, "showTyres", str(SubStandingsConfigs[configKey]["showTyres"]))
    config.set(fileKey, "showPitStops", str(SubStandingsConfigs[configKey]["showPitStops"]))
    config.set(fileKey, "showInterval", str(SubStandingsConfigs[configKey]["showInterval"]))
    config.set(fileKey, "showGap", str(SubStandingsConfigs[configKey]["showGap"]))
    config.set(fileKey, "deltaSign", str(SubStandingsConfigs[configKey]["deltaSign"]))
    config.set(fileKey, "highlightDeltas", str(SubStandingsConfigs[configKey]["highlightDeltas"]))
    config.set(fileKey, "showBestLap", str(SubStandingsConfigs[configKey]["showBestLap"]))
    config.set(fileKey, "showLastLap", str(SubStandingsConfigs[configKey]["showLastLap"]))
    config.set(fileKey, "colorBestLaps", str(SubStandingsConfigs[configKey]["colorBestLaps"]))
    config.set(fileKey, "showSectors", str(SubStandingsConfigs[configKey]["showSectors"]))
    config.set(fileKey, "colorSectors", str(SubStandingsConfigs[configKey]["colorSectors"]))
    if configKey != "global" and not isRelative:
        config.set(fileKey, "showGlobalPosition", str(SubStandingsConfigs[configKey]["showGlobalPosition"]))

    config.set(fileKey, "unit", str(SubStandingsConfigs[configKey]["unit"]))
    config.set(fileKey, "driverDisplayed", str(SubStandingsConfigs[configKey]["driverDisplayed"]))
    config.set(fileKey, "topDriversDisplayed", str(SubStandingsConfigs[configKey]["topDriversDisplayed"]))

    if isRelative:
        config.set(fileKey, "colorAt", str(SubStandingsConfigs[configKey]["colorAt"]))
        config.set(fileKey, "showLapDiffRelative", str(SubStandingsConfigs[configKey]["showLapDiffRelative"]))
    else:
        config.set(fileKey, "showGapMode", str(SubStandingsConfigs[configKey]["showGapMode"]))

def writeParameters():
    try:
        config.set("GLOBAL", "updateTime", str(SubStandingsConfigs["general"]["updateTime"]))
        config.set("GLOBAL", "flattenUpdates", str(SubStandingsConfigs["general"]["flattenUpdates"]))
        config.set("GLOBAL", "useClassTags", str(SubStandingsConfigs["general"]["useClassTags"]))
        config.set("GLOBAL", "classTags", str(",".join(SubStandingsConfigs["general"]["classTags"])))
        config.set("GLOBAL", "classTagColors", str(",".join(SubStandingsConfigs["general"]["classTagColors"])))
        config.set("GLOBAL", "classTagSpecialChars", str(SubStandingsConfigs["general"]["classTagSpecialChars"]))
        config.set("GLOBAL", "togglenameinterval", str(SubStandingsConfigs["general"]["togglenameinterval"]))

        writeStandingsConfig("STANDINGS_GLOBAL", "global", False)
        writeStandingsConfig("STANDINGS_CLASS", "class", False)
        writeStandingsConfig("STANDINGS_CLASS2", "class2", False)
        writeStandingsConfig("STANDINGS_SAME_CAR", "model", False)
        writeStandingsConfig("STANDINGS_RELATIVE", "relative", True)

        config.set("POSITIONS", "showLogoPos", str(SubStandingsConfigs["general"]["showLogoPos"]))
        config.set("POSITIONS", "showTitlePos", str(SubStandingsConfigs["general"]["showTitlePos"]))
        config.set("POSITIONS", "fontSizePos",  str(SubStandingsConfigs["general"]["fontSizePos"]))
        config.set("POSITIONS", "opacityPos",  str(SubStandingsConfigs["general"]["opacityPos"]))
        config.set("POSITIONS", "showBorderPos", str(SubStandingsConfigs["general"]["showBorderPos"]))

        config.set("WINDOW", "bottomAnchorGlobal", str(BottomAnchors["SubStanding_Global"]))
        config.set("WINDOW", "bottomAnchorRelative", str(BottomAnchors["SubStanding_Relative"]))
        config.set("WINDOW", "bottomAnchorSameCar", str(BottomAnchors["SubStanding_SameCar"]))
        config.set("WINDOW", "bottomAnchorClass", str(BottomAnchors["SubStanding_Class"]))
        config.set("WINDOW", "bottomAnchorClass", str(BottomAnchors["SubStanding_Class2"]))

        configFile = open("apps/python/SubStanding/settings/settings.ini", 'w', encoding="utf-8")
        config.write(configFile)
        configFile.close()

    except:
        ac.log("SubStanding: Error in writeParameters: %s" % traceback.format_exc())

def refreshAllParameters():
    try:
        SubStandings["model"].refreshParameters()
        SubStandings["class"].refreshParameters()
        SubStandings["class2"].refreshParameters()
        SubStandings["global"].refreshParameters()
        SubStandings["relative"].refreshParameters()

        SubPositions["model"].refreshParameters()
        SubPositions["class"].refreshParameters()
        SubPositions["class2"].refreshParameters()
        SubPositions["global"].refreshParameters()

    except:
        ac.log("SubStanding: Error in refreshAllParameters: %s" % traceback.format_exc())

def refreshAndWriteParameters():
    try:
        refreshAllParameters()

        writeParameters()

    except:
        ac.log("SubStanding: Error in refreshAndWriteParameters: %s" % traceback.format_exc())

def resetVariableState():
    global didJustReset
    didJustReset = True

    refreshAllParameters()
    for eachDriver in driversFullList:
        eachDriver.update(initDriver(eachDriver["carId"]))

    global myBestLap, myBestLapSectors, myCurrentLapSectors
    myBestLap = []
    myBestLapSectors = []
    myCurrentLapSectors = []

    global sessionBestLap, sessionBestLapText, sessionBestSectors
    sessionBestLap = None
    sessionBestLapText = None
    sessionBestSectors = [0] * sectorCount

def getNationTexture(nationCode):
    if not nationCode in nationFlags:
        nationFlags[nationCode] = ac.newTexture("content/gui/NationFlags/%s.png" % nationCode)
    return nationFlags[nationCode]

def calculateDriverClasses():
    global driverClassColors, classes

    allDrivers = driversFullList.copy()
    allDrivers.sort(key=lambda tup: tup["carId"])

    classesRace = []
    driverClassColorsTemp = []
    myDriver

    for driver in allDrivers:
        driver["class"] = "No class"

        # classes by tag
        driverClass = getDriverClassByCar(driver["carName"])
        if driverClass:
            if SubStandingsConfigs["general"]["useClassTags"]:
                driver["class"] = driverClass
                if not driverClass in classesRace:
                    classesRace.append(driverClass)

                color = getColorForClassTag(driverClass) if len(SubStandingsConfigs["general"]["classTagColors"]) > 0 else driverClassColorOptions[(classesRace.index(driverClass) + 1) % len(driverClassColorOptions)]

                driverClassColorsTemp.append(color)
            # classes by classes.ini
            else:
                if not driverClass in classesRace:
                    classesRace.append(driverClass)
                color = driverClassColorOptions[(classesRace.index(driverClass) + 1) % len(driverClassColorOptions)]
                driverClassColorsTemp.append(color)
                driver["class"] = driverClass

        # no class found
        if len(driverClassColorsTemp) == driver["carId"]:
            driverClassColorsTemp.append(driverClassColorOptions[0])

    driverClassColors = driverClassColorsTemp

    ac.log("SubStanding: Classes in Race: %s" % ",".join(classesRace))

def getColorFromHex(hexColor, defaultColor=None):
    hexColorCode = hexColor.replace("#", "")

    if len(hexColorCode) != 6 and len(hexColorCode) != 8:
        return defaultColor

    return (int(hexColorCode[:2], 16)/255., int(hexColorCode[2:4], 16)/255., int(hexColorCode[4:6], 16)/255., int(hexColorCode[6:8], 16)/255. if len(hexColorCode) == 8 else 1.)

def getColorForClassTag(driverClass):
    classTagColors = SubStandingsConfigs["general"]["classTagColors"]
    classTagIndex = SubStandingsConfigs["general"]["classTags"].index(driverClass)

    if len(classTagColors) > classTagIndex and (len(classTagColors[classTagIndex]) == 6 or len(classTagColors[classTagIndex]) == 8):
        return getColorFromHex(classTagColors[classTagIndex])
    else:
        ac.log("SubStanding Error: No valid class color found for tag %s (index %i). Check whether there are enough entries in the classTagColors and if the color is 6 or 8 characters long." % (driverClass, classTagIndex))
        return driverClassColorOptions[0]

def getDriverClassByCar(carName):
    return getDriverClassByCarForTags(carName) if SubStandingsConfigs["general"]["useClassTags"] else getDriverClassByCarForClassesIni(carName)

def getDriverClassByCarForTags(carName):
    try:
        with open("content/cars/" + carName + "/ui/ui_car.json", 'r', encoding="utf-8") as json_data:
            # the ui_car.json is full of invalid json, so we need to replace invalid characters first
            json_string = json_data.read().replace('\n', ' ').replace('\t', ' ')
            data = json.loads(json_string)
            carTags = [tag.upper() for tag in data["tags"]]
            for tag in SubStandingsConfigs["general"]["classTags"]:
                if tag.upper() in carTags:
                    return tag
    except:
        ac.log("SubStanding: Error in getDriverClassByCarForTags for name %s: %s" % (carName, traceback.format_exc()))

    return None

def getDriverClassByCarForClassesIni(carName):
    global classes

    for eachClass in classes:
        if carName in eachClass:
            return eachClass[0]

    return None

def cleanDriverClass(driverClass):
    className = driverClass
    for character in SubStandingsConfigs["general"]["classTagSpecialChars"]:
        className = className.replace(character, " ")
    return className.strip()

def isModeDependentItemVisible(value):
    # fallback for bool values
    if isinstance(value, int):
        return value == 1

    # practice/quali
    if value == "2":
        return raceMode != 2
    # race
    elif value == "3":
        return raceMode == 2
    else:
        # only visible on 1
        return value == "1"

def getFont(value):
    if value == "bold":
        return fontStandingsBold

    return fontStandings

def acUpdate(deltaT):
    global lastUpdateTime, lastUpdateTimeDelta

    # full data update
    lastUpdateTime += deltaT
    if lastUpdateTime > float(SubStandingsConfigs["general"]["updateTime"])/1000:
        lastUpdateTime = 0
        updateData()

    # divided row updates
    lastUpdateTimeDelta += deltaT
    if lastUpdateTimeDelta > float(SubStandingsConfigs["general"]["updateTime"])/(1000 * (10 if SubStandingsConfigs["general"]["flattenUpdates"] else 1)):
        updateDelta(lastUpdateTime, lastUpdateTimeDelta)
        lastUpdateTimeDelta = 0

def updateData():
    try:
        global didJustReset, raceMode, sectorCount, focusedCar, myDriver, driversFullList, startTime, sessionBestLap, sessionBestLapText, myBestLap, myLastLap, myBestLapSectors, myCurrentLapSectors, myLastLapSectors, ignored

        if debug:
            cpuUsage.startMeasure()

        # check race mode change (e.g. in weekend modes)
        if raceMode != info.graphics.session:
            raceMode = info.graphics.session
            resetVariableState()

        if sectorCount != info.static.sectorCount:
            sectorCount = info.static.sectorCount
            resetVariableState()

        modelStanding = []
        classStanding = []
        classStanding2 = []
        globalStanding = []

        focusedCarId = ac.getFocusedCar()
        focusedCar = myDriver

        # Get all needed infos
        for driver in driversFullList:
            index = driver["carId"]
            driver["connected"]   = ac.isConnected(index)

            # jump to next driver if not connected
            if not driver["connected"] or driver["driverName"] in ignored:
                driver["distance"] = 9999
                driver["distance"] = -1
                continue

            if index == focusedCarId:
                focusedCar = driver

            driver["driverName"]  = ac.getDriverName(index)
            driver["nation"]      = ac.getDriverNationCode(index)
            driver["carName"]     = ac.getCarName(index)
            driver["carNameFull"] = getJSONCarname(ac.getCarName(index))
            driver["bestLap"]     = ac.getCarState(index, acsys.CS.BestLap)
            driver["lastLap"]     = ac.getCarState(index, acsys.CS.LastLap)
            driver["speedMS"]     = ac.getCarState(index, acsys.CS.SpeedMS)
            driver["tyres"]       = ac.getCarTyreCompound(index)

            # update distances only if bigger, close to the line count and distance might not be consistent and jump a lap back
            lapCount = ac.getCarState(index, acsys.CS.LapCount)
            lapDistance = ac.getCarState(index, acsys.CS.NormalizedSplinePosition)
            if not (lapCount + lapDistance < driver["distance"] and lapDistance < 0.1 and driver["lapDistance"] > 0.9):
                driver["lapCount"]    = lapCount
                driver["lapDistance"] = lapDistance
                driver["distance"]    = driver["lapCount"] + driver["lapDistance"]

            if driver["bestLap"] > 0 and (not sessionBestLap or sessionBestLap > driver["bestLap"]):
                sessionBestLap = driver["bestLap"]
                sessionBestLapText = timeToString(sessionBestLap)

            isInPitLine = ac.isCarInPitline(index)

            # Race
            if raceMode == 2:
                # Trying to resolve the race start problem
                if driver["raceStartFlag"]:
                    if driver["lapCount"] == 0:
                        if driver["distance"] > 0.7:
                            driver["distance"] -= 1.0
                        elif driver["distance"] > 0.0:
                            driver["raceStartFlag"] = False

                        driver["pitStops"] = 0
                    else:
                        driver["raceStartFlag"] = False

                # Pit entry
                if isInPitLine and not driver["isInPitLine"]:
                    driver["pitEntryFlag"] = True
                # Pit exit
                elif driver["pitEntryFlag"] and not isInPitLine and driver["isInPitLine"]:
                    driver["pitEntryFlag"] = False
                    driver["pitStops"] += 1
            else:
                driver["pitStops"] = 0
                driver["raceStartFlag"] = False

            driver["isInPitLine"] = isInPitLine

            # mini sector timings
            if not driver["raceStartFlag"] and driver["speedMS"] > 1:
                updateSectorsForDriver(driver)
                updateMiniSectorsForDriver(driver)

        # Sort the global standing by distance or best lap
        # Race
        if raceMode == 2:
            #sort by distance
            driversFullList.sort(key=lambda tup: tup["distance"], reverse=True)

        # Practice, qualif
        else:
            # Only display drivers with a valid best lap
            for eachDriver in driversFullList:
                if eachDriver["bestLap"] == 0:
                    eachDriver["bestLap"] = 9999999

            #sort by bestLap
            driversFullList.sort(key=lambda tup: tup["bestLap"])

        globalStanding = [d for d in driversFullList if d["connected"] and not (d["driverName"] in ignored)]
        if not focusedCar in globalStanding:
            focusedCar = globalStanding[0]

        allCarsStopped = True
        # Extract sub-standings
        for driverIndex, eachDriver in enumerate(globalStanding):
            eachDriver["position"] = driverIndex

            if allCarsStopped and eachDriver["connected"]:
                allCarsStopped = eachDriver["speedMS"] <= 1

        # reset the raceStartFlag assuming a session restart
        if allCarsStopped:
            if not didJustReset:
                resetVariableState()
        else:
            didJustReset = False

        updateViews(modelStanding, classStanding, classStanding2, globalStanding)

        if debug:
            cpuUsage.stopMeasure()
            cpuUsage.updateView()

    except:
        ac.log("SubStanding: Error in acUpdate: %s" % traceback.format_exc())

def updateDelta(lastUpdateTime, lastUpdateTimeDelta):
    try:
        updateViewsDelta(lastUpdateTime, lastUpdateTimeDelta)

    except:
        ac.log("SubStanding: Error in acUpdate: %s" % traceback.format_exc())

def updateViews(modelStanding, classStanding, classStanding2, globalStanding): # Update positions
    modelCount = 0
    myModelPos = 0
    classCount = 0
    classCount2 = 0
    myClassPos = 0
    myClassPos2 = 0
    globalCount = 0
    myGlobalPos = 0

    if SubStandings["model"].isActive or SubPositions["model"].isActive:
        modelStanding = [d for d in globalStanding if d["carName"] == myDriver["carName"]]
        modelCount = len(modelStanding)
        if focusedCar in modelStanding:
            myModelPos = modelStanding.index(focusedCar) + 1
        else:
            myModelPos = 0

    if SubStandings["class"].isActive or SubPositions["class"].isActive:
        classStanding = [d for d in globalStanding if d["class"] == myDriver["class"]]
        classCount = len(classStanding)
        if focusedCar in classStanding:
            myClassPos = classStanding.index(focusedCar) + 1
        else:
            myClassPos = 0

    global currentClass
    classStanding2 = []
    if SubStandings["class2"].isActive or SubPositions["class2"].isActive:
        # ac.log("myDriver[class] "  + myDriver["class"])
        # ac.log("myDriver[class] "  + str((classes[currentClass])))
        # classStanding2 = [d for d in globalStanding if d["class"] == myDriver["class"]]
        # classStanding2 = [d for d in globalStanding if d["class"] == "#GT3"]
        # classStanding2 = [d for d in globalStanding if d["class"] == "#GT2"]
        classStanding2 = [d for d in globalStanding if d["class"] == SubStandingsConfigs["general"]["classTags"][currentClass]]
        classCount2 = len(classStanding2)
        # ac.log("classCount2 " + str(classCount2))
        if focusedCar in classStanding2:
            myClassPos2 = classStanding2.index(focusedCar) + 1
        else:
            myClassPos2 = 0

    if SubPositions["global"].isActive:
        globalCount = len(globalStanding)
        if focusedCar in globalStanding:
            myGlobalPos = globalStanding.index(focusedCar) + 1
        else:
            myGlobalPos = 0

    # Update the views
    if len(modelStanding) > 0:
        SubStandings["model"].updateView(modelStanding)
    if len(classStanding) > 0:
        SubStandings["class"].updateView(classStanding)
    if len(classStanding2) > 0:
        SubStandings["class2"].updateView(classStanding2)
    # else:

    if len(globalStanding) > 0:
        SubStandings["global"].updateView(globalStanding)
    if len(globalStanding) > 0:
        SubStandings["relative"].updateView(globalStanding)

    SubPositions["model"].updateView(myModelPos, modelCount)
    SubPositions["class"].updateView(myClassPos, classCount)
    # todo
    SubPositions["class2"].updateView(myClassPos2, classCount2)
    SubPositions["global"].updateView(myGlobalPos, globalCount)

def updateViewsDelta(lastUpdateTime, lastUpdateTimeDelta): # Update positions
    SubStandings["model"].updateViewLabels(lastUpdateTime, lastUpdateTimeDelta)
    SubStandings["class"].updateViewLabels(lastUpdateTime, lastUpdateTimeDelta)
    SubStandings["class2"].updateViewLabels(lastUpdateTime, lastUpdateTimeDelta)
    SubStandings["global"].updateViewLabels(lastUpdateTime, lastUpdateTimeDelta)
    SubStandings["relative"].updateViewLabels(lastUpdateTime, lastUpdateTimeDelta)

def onRenderCallbackStandingModel(deltaT):
    try:
        SubStandings["model"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackStandingModel: %s" % traceback.format_exc())

def onRenderCallbackStandingClass(deltaT):
    try:
        SubStandings["class"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackStandingClass: %s" % traceback.format_exc())

def onRenderCallbackStandingClass2(deltaT):
    try:
        SubStandings["class2"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackStandingClass2: %s" % traceback.format_exc())

def onRenderCallbackStandingGlobal(deltaT):
    try:
        SubStandings["global"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackStandingGlobal: %s" % traceback.format_exc())

def onRenderCallbackStandingRelative(deltaT):
    try:
        SubStandings["relative"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackStandingRelative: %s" % traceback.format_exc())

def onRenderCallbackPositionModel(deltaT):
    try:
        SubPositions["model"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackPositionModel: %s" % traceback.format_exc())

def onRenderCallbackPositionClass(deltaT):
    try:
        SubPositions["class"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackPositionClass: %s" % traceback.format_exc())

def onRenderCallbackPositionClass2(deltaT):
    try:
        SubPositions["class2"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackPositionClass2: %s" % traceback.format_exc())

def onRenderCallbackPositionGlobal(deltaT):
    try:
        SubPositions["global"].onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackPositionGlobal: %s" % traceback.format_exc())

def onRenderCallbackConfig(deltaT):
    try:
        configApp.onRenderCallback(deltaT)
    except:
        ac.log("SubStanding: Error in onRenderCallbackConfig: %s" % traceback.format_exc())

def updateSectorsForDriver(driver):
    lastSector = driver["currentSector"]
    currentSector = ac.ext_getCurrentSector(driver["carId"])
    try:
        if currentSector != lastSector:
            if currentSector > 0:
                driver["sectorTimes"][lastSector] = float(ac.ext_getPreviousSectorTime(driver["carId"]))
            elif currentSector == 0:
                driver["sectorTimes"][lastSector] = float("%.1f" % ((driver["lastLap"]/1000) - (sum(driver["sectorTimes"]) - driver["sectorTimes"][lastSector])))

            # check for personal best
            if not driver["bestSectorTimes"][lastSector] or driver["sectorTimes"][lastSector] < driver["bestSectorTimes"][lastSector]:
                global sessionBestSectors
                driver["bestSectorTimes"][lastSector] = driver["sectorTimes"][lastSector]

                # check for global best
                if not sessionBestSectors[lastSector] or driver["sectorTimes"][lastSector] < sessionBestSectors[lastSector]:
                    sessionBestSectors[lastSector] = driver["sectorTimes"][lastSector]

            driver["currentSector"] = currentSector
    # might happen if the info.static.sectorCount was not correctly initialed on acMain
    except:
        sessionBestSectors = [0] * sectorCount
        driver.update(initDriver(driver["carId"]))

def updateMiniSectorsForDriver(driver):
    global miniSectorCount

    if miniSectorCount <= 0:
        return

    # update mini sector times for driver if new mini sectors were entered
    previousMiniSector = driver["currentMiniSector"]
    currentMiniSector = math.floor(driver["lapDistance"] * miniSectorCount)

    missingMiniSectors = range(driver["currentMiniSector"] + 1, currentMiniSector + 1 if currentMiniSector >= driver["currentMiniSector"] else currentMiniSector + 1 + miniSectorCount)
    missingMiniSectors = [s % miniSectorCount for s in missingMiniSectors]

    success = True
    # do not update if more than n sectors were passed since the last update (teleport indicator)
    if len(missingMiniSectors) < 10 and not driver["isInPitLine"]:
        for selectedMiniSector in missingMiniSectors:
            success = updateMiniSectorForDriver(driver, selectedMiniSector, previousMiniSector)
            if not success:
                break
    else:
        success = False

    # reset as previousMiniSector was found to be invalid
    if not success:
        driver["miniSectorTimes"] = [None] * miniSectorCount
        driver["miniSectorTimes"][currentMiniSector] = time.time()
        driver["currentMiniSector"] = currentMiniSector
        myCurrentLapSectors = []

def updateMiniSectorForDriver(driver, selectedMiniSector, previousMiniSector):
    global myDriver, miniSectorCount, myBestLap, myLastLap, myBestLapSectors, myCurrentLapSectors, myLastLapSectors

    distanceFromMiniSector = (driver["lapDistance"] * miniSectorCount - selectedMiniSector) * 50 # distance from last mini sector in m
    if distanceFromMiniSector < 0: # new lap started, but miniSector is at the end of the lap
        distanceFromMiniSector += trackLength

    timeAtMiniSector = time.time() - (distanceFromMiniSector / driver["speedMS"] if driver["speedMS"] > 1 else 0)

    # check for invalid time calculations (caused e.g. py porting to the pits)
    if previousMiniSector >= 0:
        if driver["miniSectorTimes"][previousMiniSector]:
            timeToMiniSector = time.time() - driver["miniSectorTimes"][previousMiniSector]
            speedToMiniSector = abs((distanceFromMiniSector + 50 * ((miniSectorCount + selectedMiniSector - previousMiniSector) % miniSectorCount)) / timeToMiniSector)

            # more than 500 m/s (1800 km/h)
            if speedToMiniSector > 500:
                return False
            # invalid estimation fallback, should not occur in practice
            elif timeAtMiniSector < driver["miniSectorTimes"][previousMiniSector]:
                timeAtMiniSector = time.time()
        # no previousMiniSector time
        else:
            return False

    # store best lap informations
    if driver["carId"] == 0:
        # update bestLap and reset
        if selectedMiniSector == 0:
            myCurrentLapSectors.append(timeAtMiniSector)
            myLastLapSectors = myCurrentLapSectors
            myCurrentLapSectors = []

        # lastLap/bestLap updated
        if driver["lastLap"] > 0 and (not myLastLap or myLastLap != driver["lastLap"]) and len(myLastLapSectors) == miniSectorCount + 1:
            myLastLap = driver["lastLap"]
            # update best sectors
            if myDriver["bestLap"] > 0 and not driver["isInPitLine"] and (not myBestLap or (myDriver["bestLap"] / 1000) < myBestLap):
                lapStart = myLastLapSectors[0]
                normalizedLapSectors = [t - lapStart for t in myLastLapSectors]
                myBestLap = myDriver["bestLap"] / 1000
                myBestLapSectors = normalizedLapSectors
                ac.log("SubStanding: Best Sectors: " + ",".join(["%.2f" % time for time in myBestLapSectors]))
            else:
                ac.log("SubStanding: Not best. Current Best %s, InPit %s, myBestLap %s" % (timeToString(myDriver["bestLap"]), driver["isInPitLine"], myBestLap))
            # reset to correctly detect both values updated
            myLastLapSectors = []

        # add current sector time
        if len(myCurrentLapSectors) == selectedMiniSector:
            myCurrentLapSectors.append(timeAtMiniSector)
        else:
            # ac.log("SubStanding: best lap calculation, sector count does not match. Was %i, but selected is: %i" % (len(myCurrentLapSectors), selectedMiniSector))
            pass

    driver["miniSectorTimes"][selectedMiniSector] = timeAtMiniSector
    driver["currentMiniSector"] = selectedMiniSector

    return True

timer = 0.0
timerflag = True

class StandingWindow:

    def __init__(self, name, window, headerName, standingsConfig, isRelative):
        try:

            self.name = name
            self.headerName = headerName
            self.window = window
            self.isActive = False
            self.standingsConfig = standingsConfig

            ac.addOnAppActivatedListener(self.window, standingActivated)
            ac.addOnAppDismissedListener(self.window, standingDismissed)

            global btnClassprev, btnClassnext
            if name=="SubStanding_Class2":
                btnClassprev = ac.addButton(self.window, "<")
                btnClassnext = ac.addButton(self.window, ">")
                ac.setFontAlignment(    btnClassnext, "left")
                ac.setPosition(         btnClassprev, 40, 2)
                ac.setPosition(         btnClassnext, 80, 2)
                ac.setSize(             btnClassprev, 25, 25)
                ac.setSize(             btnClassnext, 25, 25)
                ac.drawBorder(          btnClassprev, 0)
                ac.drawBorder(          btnClassnext, 0)
                ac.drawBackground(      btnClassprev, 0)
                ac.drawBackground(      btnClassnext, 0)
                ac.setBackgroundOpacity(btnClassprev, 0.5)
                ac.setBackgroundOpacity(btnClassnext, 0.5)
                ac.addOnClickedListener(btnClassprev, onClassChangePrev)
                ac.addOnClickedListener(btnClassnext, onClassChangeNext)


            self.listeners = {
                "click": lambda *args: self.onClick(args[0], args[1])
            }
            ac.addOnClickedListener(self.window, self.listeners["click"])

            # collection of StandingsRow elements to keep track of the current state and label rendering
            self.rows = []
            self.updateData = None
            self.lastUpdateIndex = 0

            self.currentDriversDisplayed = 1
            self.isRelative = isRelative

            self.width = -1
            self.height = -1

            self.isMouseDown = False
            self.driverToBeSelected = None

            self.refreshParameters()
        except:
            ac.log("SubStanding: Error in StandingWindow constructor: %s" % traceback.format_exc())

    def setHeader(self, s):
        self.headerName = s

    def refreshParameters(self):
        if self.standingsConfig["showLogo"]:
            ac.setIconPosition(self.window, 0, 0)
        else:
            ac.setIconPosition(self.window, -10000, -10000)

        # always hide the original title element, will be customly rendered
        ac.setTitle(self.window, "")

        if self.standingsConfig["showLogo"] or self.standingsConfig["showTitle"]:
            self.firstSpacing = self.standingsConfig["fontSize"] + 2 * spacing
        else:
            self.firstSpacing = 0

        width      = 0
        height     = self.firstSpacing + (self.standingsConfig["fontSize"] + spacing) * self.currentDriversDisplayed

        for index in range(self.standingsConfig["driverDisplayed"] + self.standingsConfig["topDriversDisplayed"] + 1):
            # append an additional row if there are more displayed drivers than previously
            # will not get less, only on next restart, as labels cannot be deleted
            if len(self.rows) <= index:
                self.rows.append(StandingsRow(self.window, self.isRelative))

            # adjust position
            self.rows[index].refreshParameters(index, self.firstSpacing, self.standingsConfig)
            if self.rows[index].width > width:
                width = self.rows[index].width

        firstRow = self.rows[0]
        self.deltaHighlightAreaInt = {
            "visible": firstRow.labelWidths["interval"] > 0,
            "x": firstRow.leftOffsets["interval"],
            "y": self.firstSpacing,
            "width": firstRow.labelWidths["interval"]
        }
        self.deltaHighlightAreaGap = {
            "visible": firstRow.labelWidths["gapToFirst"] > 0,
            "x": firstRow.leftOffsets["gapToFirst"],
            "y": self.firstSpacing,
            "width": firstRow.labelWidths["gapToFirst"]
        }

        # Adjust window size, opacity and border
        self.setSize(width, height)
        ac.setBackgroundOpacity(self.window, float(self.standingsConfig["opacity"])/100)
        ac.drawBorder(self.window, self.standingsConfig["showBorder"])

    def setSize(self, width, height):
        # while dragging do not resize the window
        # otherwise on spectate clicks the window might be accidentally repositioned
        # should automatically be retried in the next view update
        if not self.isMouseDown and (height != self.height or width != self.width):
            self.width = width
            self.height = height
            ac.setSize(self.window, width, height)
            ac.setBackgroundOpacity(self.window, float(self.standingsConfig["opacity"])/100)
            ac.drawBorder(self.window, self.standingsConfig["showBorder"])

    def updateBottomAnchorPosition(self):
        bottomAnchorPosition = int(ac.getPosition(self.window)[1] + self.height)
        if bottomAnchorPosition != BottomAnchors[self.name]:
            BottomAnchors[self.name] = bottomAnchorPosition
            return True
        return False

    def calculateRelativeStanding(self, standing):
        relativeStanding = standing.copy()
        relativeStanding.sort(key=lambda source: focusedCar["lapDistance"] - source["lapDistance"])

        focusedPosition = relativeStanding.index(focusedCar)
        targetPosition = math.ceil(len(relativeStanding) / 2.0) - 1 # middle or one above
        rotationAmount = focusedPosition - targetPosition

        # only two drivers, order for closest distance
        if len(relativeStanding) == 2:
            # due to sort, value of 0 always > value of 1
            rotationAmount = 0 if relativeStanding[0]["lapDistance"] - relativeStanding[1]["lapDistance"] < 0.5 else 1

        relativeStanding = relativeStanding[rotationAmount:] + relativeStanding[:rotationAmount]

        return relativeStanding

    def updateView(self, originalStanding):
        global focusedCar

        # cancel update if inactive
        if not self.isActive:
            return

        try:
            leader = originalStanding[0]
            standing = originalStanding if not self.isRelative else self.calculateRelativeStanding(originalStanding)

            focusedIndex = standing.index(focusedCar) if focusedCar in standing else 0
            firstIndex = focusedIndex - (self.standingsConfig["driverDisplayed"] - 1)/2
            lastIndex = focusedIndex + (self.standingsConfig["driverDisplayed"] - 1)/2 + 1 # exclusive, thus +1

            if firstIndex < 0:
                lastIndex -= firstIndex
                firstIndex = 0

            if lastIndex > len(standing):
                firstIndex = max(0, firstIndex - (lastIndex - len(standing)))
                lastIndex = len(standing)

            firstIndex = int(firstIndex)
            lastIndex = int(lastIndex)

            driversWithIndex = [(idx, d) for idx, d in enumerate(standing)]
            displayedDrivers = driversWithIndex[firstIndex:lastIndex]

            if not self.isRelative and self.standingsConfig["topDriversDisplayed"] > 0:
                displayedDrivers = driversWithIndex[:min(self.standingsConfig["topDriversDisplayed"], firstIndex)] + ([[-1, "border"]] if self.standingsConfig["topDriversDisplayed"] < firstIndex else []) + displayedDrivers
            elif self.isRelative and self.standingsConfig["topDriversDisplayed"] > 0:
                displayedDrivers = [(idx, d) for idx, d in enumerate(originalStanding)][:self.standingsConfig["topDriversDisplayed"]] + [[-1, "border"]] + displayedDrivers

            self.currentDriversDisplayed = len(displayedDrivers)


            self.updateData = [originalStanding, standing, displayedDrivers, focusedIndex, leader]

            # Adjust window size, opacity and border
            self.setSize(self.width, self.firstSpacing + (self.standingsConfig["fontSize"] + spacing)*self.currentDriversDisplayed)

        except:
            ac.log("SubStanding: Error in StandingWindow.updateView: %s" % traceback.format_exc())


    def updateViewLabels(self, lastUpdateTime, lastUpdateTimeDelta):
        if not self.updateData:
            return

        originalStanding, standing, displayedDrivers, focusedIndex, leader = self.updateData

        fullInterval = float(SubStandingsConfigs["general"]["updateTime"])/1000
        targetRatio = lastUpdateTime / fullInterval
        startIndex = self.lastUpdateIndex + 1
        targetIndex = math.floor(len(self.rows) * targetRatio)
        targetIndex = targetIndex if targetIndex > self.lastUpdateIndex else targetIndex + len(self.rows)

        if startIndex == targetIndex and lastUpdateTimeDelta > fullInterval / 2:
            targetIndex += len(self.rows)

        # iterate over related rows to make sure they are displayed/hidden as expected (must be done to react on connect/disconnects)
        for index in range(startIndex, targetIndex):
            labelIndex = index % len(self.rows)
            row = self.rows[labelIndex]
            if labelIndex < len(displayedDrivers):
                driverIndex, driver = displayedDrivers[labelIndex]

                isTopDriver = labelIndex < min(self.standingsConfig["topDriversDisplayed"], len(originalStanding))

                # display a split row with just a line
                if driverIndex == -1 and driver == "border":
                    row.setIsSplitBorder(True)
                    continue

                row.setVisible(True)
                row.setIsSplitBorder(False)
                row.setIsFocus(driverIndex == focusedIndex)
                row.setCarId(driver["carId"])
                row.setNationCode(driver["nation"])

                # Refresh position and name
                row.setPositionLabel("%i" % ((driver["position"] if self.standingsConfig["showGlobalPosition"] else driverIndex)+1))

                if SubStandingsConfigs["general"]["togglenameinterval"]==-1:
                    row.setNameLabel(driver["carNameFull"])
                elif SubStandingsConfigs["general"]["togglenameinterval"]==0:
                    row.setNameLabel(driver["driverName"])
                elif SubStandingsConfigs["general"]["togglenameinterval"]>0:
                    global timer, timerflag
                    timer = timer + lastUpdateTimeDelta
                    if timer>SubStandingsConfigs["general"]["togglenameinterval"]:
                        timerflag = not timerflag
                        timer = 0.0
                    if timerflag:
                        row.setNameLabel(driver["carNameFull"])
                    else:
                        row.setNameLabel(driver["driverName"])

                row.setTyresLabel(driver["tyres"])

                if driver["isInPitLine"]:
                    row.setPitLabel("PIT")
                elif raceMode == 2:
                    row.setPitLabel("%ip" % driver["pitStops"])
                else:
                    row.setPitLabel("")

                # init lapDiff for row color
                delta = 0 # might be cached for relative to not calculate it twice
                lapDiff = 0

                # calculate lapDiff
                if self.isRelative and not isTopDriver:
                    (delta, lapDiff) = self.calculateDistanceDeltaAndLapDiffRelative(driver, focusedCar, driverIndex - focusedIndex)
                # Race (interval times)
                elif raceMode == 2:
                    delta = leader["distance"] - driver["distance"]
                    lapDiff = abs(int(delta))

                rowColor = (1, 1, 1, 1)
                if driver["carId"] == 0:
                    # Color my car in light blue
                    rowColor = SubStandingsConfigs["colors"]["ownColor"]
                elif not self.isRelative and driverIndex == 0:
                    rowColor = SubStandingsConfigs["colors"]["leaderColor"]
                else:
                    rowColor = self.calculateRowColor(driver, abs(lapDiff) >= 1)

                row.setRowColor(*rowColor)

                # calculate interval
                if isModeDependentItemVisible(self.standingsConfig["showInterval"]):

                    intervalColor = (1, 1, 1, 1)
                    intervalLabelText = "Lap %i" % (driver["lapCount"] + 1)
                    referenceCar = focusedCar

                    if self.isRelative and not isTopDriver:
                        # My car
                        if driver != focusedCar:
                            # Update delta string and color
                            (intervalColor, intervalLabelText) = self.calculateIntervalRelative(driver, focusedCar, delta, lapDiff, driverIndex - focusedIndex)

                    # Race (interval times)
                    else:
                        referenceCar = (originalStanding if self.isRelative else standing)[driverIndex - 1] if driverIndex > 0 else driver
                        if  raceMode == 2:
                            (intervalColor, intervalLabelText) = self.calculateInterval(driver, referenceCar, referenceCar["distance"] - driver["distance"]) if driverIndex != 0 else (SubStandingsConfigs["colors"]["leaderColor"], "Interval")
                        else:
                            intervalLabelText = self.getLapTimeDifferenceString(referenceCar["bestLap"], driver["bestLap"]) if referenceCar != driver else "Interval"
                            intervalColor = (1, 1, 1, 1) if driverIndex != 0 else SubStandingsConfigs["colors"]["leaderColor"]

                    # Update row color for my car
                    if driver["carId"] == 0:
                        # Color my car in light blue
                        intervalColor = SubStandingsConfigs["colors"]["ownColor"]

                    intervalLabelText = self.addSignToDelta(standing.index(referenceCar), driverIndex, intervalLabelText)

                    row.setIntervalLabel(intervalLabelText)
                    row.setIntervalColor(*intervalColor)

                # calculate gap
                if isModeDependentItemVisible(self.standingsConfig["showGap"]):

                    labelText = "-"
                    referenceCar = leader

                    # Race (interval times)
                    if self.isRelative:
                        if raceMode == 2:
                            leaderDelta = leader["distance"] - driver["distance"]
                            leaderLapDiff = abs(int(leaderDelta))
                            if leaderLapDiff < 1:
                                labelText = self.calculateIntervalRelative(driver, leader, leaderDelta, leaderLapDiff, 1)[1] if leader != driver else "Leader"
                            else:
                                labelText = self.getLapDifferenceString(leaderDelta)

                    else:
                        referenceCar = focusedCar if self.standingsConfig["showGapMode"] == "focused" else leader
                        if raceMode == 2:
                            firstCar, secondCar = (referenceCar, driver) if referenceCar["distance"] >= driver["distance"] else (driver, referenceCar)
                            refDelta = firstCar["distance"] - secondCar["distance"]
                            labelText = self.calculateInterval(secondCar, firstCar, refDelta)[1] if referenceCar != driver else "Gap"
                        else:
                            labelText = self.getLapTimeDifferenceString(referenceCar["bestLap"], driver["bestLap"]) if referenceCar != driver else "Gap"

                    labelText = self.addSignToDelta(standing.index(referenceCar), driverIndex, labelText)

                    row.setGapToFirstLabel(labelText)

                # update best and last lap
                row.setBestLapLabel(timeToString(driver["bestLap"]))
                row.setLastLapLabel(timeToString(driver["lastLap"]))
                if isModeDependentItemVisible(self.standingsConfig["showSectors"]):
                    row.setSectorLabels(
                        ["%.1f" % s if s > 0 else "-" for s in driver["sectorTimes"]],
                        [driver["sectorTimes"][i] > 0 and driver["sectorTimes"][i] == driver["bestSectorTimes"][i] for i in range(len(driver["sectorTimes"]))],
                        [driver["sectorTimes"][i] > 0 and driver["sectorTimes"][i] == sessionBestSectors[i] for i in range(len(driver["sectorTimes"]))],
                        (driver["currentSector"] + sectorCount - 1) % sectorCount
                    )


            # hide other rows
            else:
                row.setVisible(False)

            self.lastUpdateIndex = labelIndex

    def calculateRowColor(self, driver, isLapped):
        alpha = 1 if not isLapped else 0.6

        # Position and name in blue for the teammates, pink for the rivals and white for the others
        if driver["driverName"] in teammates:
            return SubStandingsConfigs["colors"]["teamColor"][:3] + (alpha,)
        elif driver["driverName"] in rivals:
            return SubStandingsConfigs["colors"]["rivalColor"][:3] + (alpha,)
        else:
            return (1, 1, 1, alpha)

    # global distance calculation
    def calculateInterval(self, driver, driverInFront, delta):
        # race not yet started
        if driver["raceStartFlag"]:
            return ((1, 1, 1, 1), "-")

        intervalColor = SubStandingsConfigs["colors"]["leaderColor"]
        intervalLabelText = "Lap %.0f" % (driver["lapCount"] + 1)

        if driverInFront != driver:
            # update label text, seconds/meters
            if abs(delta) < 1 and trackLength > 0:
                if self.standingsConfig["unit"] == "metric" or self.standingsConfig["unit"] == "imperial":
                    intervalLabelText = self.getDistanceGapString(delta)
                elif self.standingsConfig["unit"] == "time":
                    intervalLabelText = self.getSectorBasedGapAbsString(delta, driverInFront, driver)
                # update color
                intervalColor = (1, 1, 1, 1)
            # laps
            else:
                intervalLabelText = self.getLapDifferenceString(delta)
                # lapped cars color
                intervalColor = (1, 1, 1, 0.6)

        return (intervalColor, intervalLabelText)

    # delta, lapDiff as tuple
    def calculateDistanceDeltaAndLapDiffRelative(self, driverA, driverB, indexDiff):
        isRace = raceMode == 2

        # use lapDistance + lapCount because of circular interpretation for relative and lap difference based on position in relative
        delta = 0.0
        if indexDiff < 0: # other driver above player in list
            delta = driverA["lapDistance"] - driverB["lapDistance"]
        else: # other player below in player list
            delta = driverB["lapDistance"] - driverA["lapDistance"]

        # lap difference calc
        lapDiff = 0
        if isRace: # calculate lap difference only in race mode
            driverALapCount = driverA["lapCount"] - (1 if driverA["raceStartFlag"] and driverA["lapCount"] == 0 else 0)
            driverBLapCount = driverB["lapCount"] - (1 if driverB["raceStartFlag"] and driverB["lapCount"] == 0 else 0)
            lapDiff = math.copysign(driverBLapCount - driverALapCount, driverB["position"] - driverA["position"])

        if delta < 0:
            delta += 1
            if isRace:
                lapDiff += math.copysign(1, indexDiff)

        return (delta, lapDiff)

    # relative distance calculation
    def calculateIntervalRelative(self, driver, selectedDriver, delta, lapDiff, indexDiff):
        intervalColor = self.calculateIntervalColorRelative(math.copysign(delta*trackLength, -indexDiff), lapDiff)
        intervalLabelText = "-"

        # update label text
        if self.standingsConfig["unit"] == "metric" or self.standingsConfig["unit"] == "imperial":
            intervalLabelText = self.getDistanceGapString(delta)
        elif self.standingsConfig["unit"] == "time":
            intervalLabelText = self.getSectorBasedEstimatedLiveGapAbsString(delta, selectedDriver if indexDiff >= 0 else driver, driver if indexDiff >= 0 else selectedDriver)

        intervalLabelText = intervalLabelText + ((" (%+.0f)" % abs(lapDiff)) if self.standingsConfig["showLapDiffRelative"] and abs(lapDiff) > 0 else "")

        return (intervalColor, intervalLabelText)

    def calculateIntervalColorRelative(self, distance, lapDiff):
        # update color
        # colorFactor
        colorFactor = 1.0
        if(self.standingsConfig["colorAt"] > 0):
            colorFactor = 1-max(min(float(abs(distance))/self.standingsConfig["colorAt"], 1.0), 0.0) # 0 if > colorAt, 1 if distance == 0, clamped to [0,1]

        # white fallback
        intervalColor = (1, 1, 1, 1)

        if colorFactor <= 0.0:
            # White (only fallback)
            intervalColor = (1, 1, 1, 1)
        if lapDiff > 0:
            # Default Yellow (car is > 1 lap in front)
            intervalColor = [1 - ((1-c)*colorFactor) for c in SubStandingsConfigs["distanceColors"]["aheadLappedColor"]][:3] + [1,]
        elif lapDiff < 0:
            # Default Blue (car is > 1 lap in behind)
            intervalColor = [1 - ((1-c)*colorFactor) for c in SubStandingsConfigs["distanceColors"]["behindLappedColor"]][:3] + [1,]
        elif distance > 0:
            # Default Orange
            intervalColor = [1 - ((1-c)*colorFactor) for c in SubStandingsConfigs["distanceColors"]["aheadColor"]][:3] + [1,]
        elif distance < 0:
            # Default Turkish
            intervalColor = [1 - ((1-c)*colorFactor) for c in SubStandingsConfigs["distanceColors"]["behindColor"]][:3] + [1,]

        return intervalColor

    ## distance calculations

    def getLapDifferenceString(self, delta):
        return "%.1f laps" % delta

    def getDistanceGapString(self, delta):
        distance = delta * trackLength

        if self.standingsConfig["unit"] == "metric":
            return "%.0f m" % distance
        elif self.standingsConfig["unit"] == "imperial":
            if distance < 1609:
                return "%.0f ft" % (distance*3.28)
            else:
                return "%.1f mi" % (distance/1609)

    def getSpeedDistanceEstimationGapString(self, delta, baseDriver, targetDriver):
        distance = delta * trackLength
        speedAvg = (baseDriver["speedMS"] + targetDriver["speedMS"])/2
        if speedAvg < 15:
            speedAvg = 15
        return "%.1f s" % abs(distance/speedAvg)

    def getSectorBasedGapAbsString(self, delta, baseDriver, targetDriver):
        currentMiniSector = targetDriver["currentMiniSector"]
        # if driver is close enough to lap so that miniSectors switch too often
        if miniSectorCount and delta > 1.0 * ((miniSectorCount - 1.2) / miniSectorCount):
            return self.getLapDifferenceString(delta)
        elif miniSectorCount and (targetDriver["miniSectorTimes"][currentMiniSector] and baseDriver["miniSectorTimes"][currentMiniSector]
            # there might still be invalid sector times on short tracks, so make sure the gap is not too big
            and abs(targetDriver["miniSectorTimes"][currentMiniSector] - baseDriver["miniSectorTimes"][currentMiniSector]) < 1000):
            deltaTime = targetDriver["miniSectorTimes"][currentMiniSector] - baseDriver["miniSectorTimes"][currentMiniSector]
            #ac.log("Last Sector: %s - %s: delta %.2f, currentMiniSector %.2f" % (baseDriver["carId"], targetDriver["carId"], deltaTime, currentMiniSector))
            return "%.1f s" % abs(deltaTime)
        # fallback to laps if first driver is wrong and has no valid sector times (e.g. by porting to the pits)
        else:
            return self.getSpeedDistanceEstimationGapString(delta, baseDriver, targetDriver)

    def getSectorBasedEstimatedLiveGapAbsString(self, delta, baseDriver, targetDriver):
        if myBestLap and miniSectorCount and len(myBestLapSectors) == miniSectorCount + 1:
            bestLap = myBestLapSectors[-1]
            baseDriverEstimatedTime = self.estimateTimeUntilPosition(baseDriver["lapDistance"])
            targetDriverEstimatedTime = self.estimateTimeUntilPosition(targetDriver["lapDistance"])

            deltaTime = (baseDriverEstimatedTime - targetDriverEstimatedTime + bestLap) % bestLap
            #ac.log("Live Est: %s (%.2f) - %s (%.2f) : delta %.2f, bestLap %.2f" % (baseDriver["carId"], baseDriver["lapDistance"], targetDriver["carId"], targetDriver["lapDistance"], deltaTime, bestLap))
            return "%.1f s" % abs(deltaTime)
        else:
            return self.getSectorBasedGapAbsString(delta, baseDriver, targetDriver)

    def estimateTimeUntilPosition(self, lapDistance):
        currentMiniSector = math.floor(lapDistance * miniSectorCount)
        currentMiniSectorProgress = (lapDistance * miniSectorCount) % 1
        miniSectorDuration = myBestLapSectors[currentMiniSector + 1] - myBestLapSectors[currentMiniSector]
        return myBestLapSectors[currentMiniSector] + currentMiniSectorProgress * miniSectorDuration

    def getLapTimeDifferenceString(self, baseLapTime, targetLapTime):
        if not targetLapTime or targetLapTime <= 0 or targetLapTime == 9999999:
            return "-"

        interval = (targetLapTime - baseLapTime)/1000
        if interval >= 1000:
            return "-"

        return "%.3f s" % ((targetLapTime - baseLapTime)/1000)

    def addSignToDelta(self, referenceCarIndex, driverIndex, label):
        if self.standingsConfig["deltaSign"] != "disabled" and len(label) > 0 and label[0].isdigit():
            if self.standingsConfig["deltaSign"] == "enabled":
                sign = "+" if referenceCarIndex < driverIndex else "-"
            else:
                sign = "+" if referenceCarIndex > driverIndex else "-"
            return sign + label
        return label

    ## rendering

    def onActivated(self):
        self.isActive = True
        ac.log("SubStanding: Activated %s" % self.name)

    def onDismissed(self):
        self.isActive = False
        ac.log("SubStanding: Dismissed %s" % self.name)

    def onRenderCallback(self, deltaT):
        if not self.isActive:
            self.onActivated()

        # opacity otherwise glitches after clicks
        ac.setBackgroundOpacity(self.window, float(self.standingsConfig["opacity"])/100)
        # reposition so that bottom is where it was before
        if self.isMouseDown and not (ac.ext_isButtonPressed(1) or ac.ext_isButtonPressed(2) or ac.ext_isButtonPressed(4)):
            # ac.log("SubStanding: MouseUp after click on window %s, will update bottom anchor" % self.name)
            self.isMouseDown = False
            updateBottomAnchorPositions()

            # select driver onMouseUp
            if self.driverToBeSelected != None:
                ac.focusCar(self.driverToBeSelected)
                self.driverToBeSelected = None

        # sreposition window to bottom anchro
        elif self.standingsConfig["bottomAnchor"] and not self.isMouseDown and ac.getPosition(self.window)[1] != BottomAnchors[self.name] - self.height:
            ac.setPosition(self.window, ac.getPosition(self.window)[0], BottomAnchors[self.name] - self.height)

        if self.standingsConfig["highlightDeltas"] and (self.deltaHighlightAreaInt["visible"] or self.deltaHighlightAreaGap["visible"]):
            ac.glColor4f(0.4,0.4,0.4,0.2)
            if self.deltaHighlightAreaInt["visible"]:
                ac.glQuad(self.deltaHighlightAreaInt["x"], self.deltaHighlightAreaInt["y"], self.deltaHighlightAreaInt["width"], self.height - self.firstSpacing)

            if self.deltaHighlightAreaGap["visible"]:
                ac.glQuad(self.deltaHighlightAreaGap["x"], self.deltaHighlightAreaGap["y"], self.deltaHighlightAreaGap["width"], self.height - self.firstSpacing)

        if self.standingsConfig["showTitle"]:
            font = getFont(self.standingsConfig["fontWeight"])
            ac.ext_glFontColor(font, (1,1,1,1))
            ac.ext_glFontUse(font, self.headerName, [self.width/2, -spacing/32 * self.standingsConfig["fontSize"] + spacing], self.standingsConfig["fontSize"] / 16, 2)

        for index, row in enumerate(self.rows):
            row.render()

    def onClick(self, x, y):
        self.isMouseDown = True
        if self.standingsConfig["clickToSpectate"] != "disabled":
            affectedRow = next((row for row in self.rows if 0 <= y - row.topOffset < self.standingsConfig["fontSize"] + spacing), None)
            if affectedRow and affectedRow.visible and not affectedRow.isSplitBorder and (self.standingsConfig["clickToSpectate"] != "position" or x <= affectedRow.labelWidths["position"]):
                # mark to be selected onMouseUp
                self.driverToBeSelected = affectedRow.carId


# SubStanding related functions

def updateBottomAnchorPositions():
    if (SubStandings["global"].updateBottomAnchorPosition() or
            SubStandings["relative"].updateBottomAnchorPosition() or
            SubStandings["model"].updateBottomAnchorPosition() or
            SubStandings["class"].updateBottomAnchorPosition() or
            SubStandings["class2"].updateBottomAnchorPosition()):
        refreshAndWriteParameters()

def standingActivated(app):
    for name in SubStandings:
        subStanding = SubStandings[name]
        if subStanding.window == app:
            subStanding.onActivated()

def standingDismissed(app):
    for name in SubStandings:
        subStanding = SubStandings[name]
        if subStanding.window == app:
            subStanding.onDismissed()


def onClassChangePrev(*arg):
    global currentClass, SubStandings, SubStandingsConfigs, btnClassnext
    currentClass = currentClass-1
    if currentClass<0:
        currentClass = len(SubStandingsConfigs["general"]["classTags"])-1
    ac.setText(btnClassnext, "  >   " + str(currentClass+1) + "/" + str(len(SubStandingsConfigs["general"]["classTags"])))
    # currentDriversDisplayed

    # ac.log(" be : " + SubStandingsConfigs["general"]["classTags"][currentClass])
    for name in SubStandings:
        subStanding = SubStandings[name]
        if subStanding.name == "SubStanding_Class2":
            subStanding.rows = []
            subStanding.currentDriversDisplayed = 1
            subStanding.setHeader(SubStandingsConfigs["general"]["classTags"][currentClass])
            subStanding.updateData = None
            subStanding.lastUpdateIndex = 0
            subStanding.currentDriversDisplayed = 1
            subStanding.width = -1
            subStanding.height = -1
            subStanding.isMouseDown = False
            subStanding.driverToBeSelected = None
            subStanding.refreshParameters()
            # ac.log("should be : " + SubStandingsConfigs["general"]["classTags"][currentClass])
            break
    refreshAllParameters()

def onClassChangeNext(*arg):
    global currentClass, SubStandings, SubStandingsConfigs, btnClassnext
    # SubStandings["class2"]
    currentClass = currentClass+1
    if currentClass>=len(SubStandingsConfigs["general"]["classTags"]):
        currentClass = 0
    ac.setText(btnClassnext, "  >   " + str(currentClass+1) + "/" + str(len(SubStandingsConfigs["general"]["classTags"])))

    ac.log(" be : " + SubStandingsConfigs["general"]["classTags"][currentClass])

    for name in SubStandings:
        subStanding = SubStandings[name]
        if subStanding.name == "SubStanding_Class2":
            subStanding.rows = []
            subStanding.currentDriversDisplayed = 1
            subStanding.setHeader(SubStandingsConfigs["general"]["classTags"][currentClass])
            subStanding.updateData = None
            subStanding.lastUpdateIndex = 0
            subStanding.currentDriversDisplayed = 1
            subStanding.width = -1
            subStanding.height = -1
            subStanding.isMouseDown = False
            subStanding.driverToBeSelected = None
            subStanding.refreshParameters()
            # ac.log("should be : " + SubStandingsConfigs["general"]["classTags"][currentClass])
            break
    refreshAllParameters()


"""
Content of a row in the standings.
"""
class StandingsRow:
    def __init__(self, window, isRelative):
        self.isRelative = isRelative
        self.visible = False

        self.renderFunctions = []

        self.rowColor = (1, 1, 1, 1)
        self.intervalColor = (1, 1, 1, 1)
        self.classColor = (0.5, 0.5, 0.5, 1)
        self.badge = -1
        self.livery = -1
        self.miniSkin = -1
        self.nationFlag = -1
        self.nationCode = -1
        self.sectorsPersonalBest = []
        self.sectorsSessionBest = []
        self.lastSector = 0

        self.index = 0
        self.carId = -1
        self.isFocus = False
        self.isSplitBorder = False
        self.firstSpacing = 0

        self.labelWidths = {
            "position": 0,
            "badge": 0,
            "livery": 0,
            "miniskin": 0,
            "nationFlag": 0,
            "name": 0,
            "tyres": 0,
            "pit": 0,
            "interval": 0,
            "gapToFirst": 0,
            "bestLap": 0,
            "lastLap": 0,
        }

        self.labelTexts = {
            "position": "",
            "name": "",
            "displayName": "",
            "tyres": "",
            "pit": "",
            "interval": "",
            "gapToFirst": "",
            "bestLap": "",
            "lastLap": "",
            "sectors": ["-"] * sectorCount
        }

        self.width = 0

    def setVisible(self, visible):
        if self.visible != visible:
            self.visible = visible
            self.updateRenderFunctions()

    def refreshParameters(self, index, firstSpacing, standingsConfig):
        self.index = index
        self.standingsConfig = standingsConfig

        fontSize = self.standingsConfig["fontSize"]

        self.labelWidths = {
            "position": fontSize * 1.6 + 2,
            "class": self.standingsConfig["showClass"] * fontSize * 0.4,
            "nationFlag": fontSize + spacing if self.standingsConfig["showNation"] else 0,
            "name": self.getNameWidth(),
            "tyres": self.standingsConfig["showTyres"] * (fontSize*1.6 + spacing),
            "pit": self.standingsConfig["showPitStops"] * (fontSize*2 + spacing),
            "interval": fontSize * (8 if self.isRelative and self.standingsConfig["showLapDiffRelative"] else 5) if isModeDependentItemVisible(self.standingsConfig["showInterval"]) else 0,
            "gapToFirst": fontSize*5 if isModeDependentItemVisible(self.standingsConfig["showGap"]) and (not self.isRelative or raceMode == 2) else 0,
            "bestLap": fontSize * 5 + spacing if isModeDependentItemVisible(self.standingsConfig["showBestLap"]) else 0,
            "lastLap": fontSize * 5 + spacing if isModeDependentItemVisible(self.standingsConfig["showLastLap"]) else 0,
            "sectors": (fontSize * 3 * sectorCount + spacing) if isModeDependentItemVisible(self.standingsConfig["showSectors"]) else 0,
        }
        self.labelWidths.update(self.getBadgeWidths())

        self.topOffset = firstSpacing + index*(self.standingsConfig["fontSize"]+spacing)
        self.topTextOffset = self.topOffset - 1

        self.leftOffsets = {}
        currentOffset = 0

        for label in self.standingsConfig["elementOrder"]:
            self.leftOffsets[label] = currentOffset
            currentOffset += self.labelWidths[label]

        self.width = currentOffset

        self.labelTexts["name"] = "" # reset

        self.updateRenderFunctions()

    def getNameWidth(self):
        widthName  = self.standingsConfig["fontSize"] * 10
        if self.standingsConfig["nameMode"] == "first" or self.standingsConfig["nameMode"] == "last":
            widthName = self.standingsConfig["fontSize"] * 7
        elif (
            self.standingsConfig["nameMode"] == "f_last" or self.standingsConfig["nameMode"] == "first_l" or
            self.standingsConfig["nameMode"] == "f_dot_last" or self.standingsConfig["nameMode"] == "first_l_dot"
        ):
            widthName = self.standingsConfig["fontSize"] * 8
        elif self.standingsConfig["nameMode"] == "fl" or self.standingsConfig["nameMode"] == "3_last":
            widthName = self.standingsConfig["fontSize"] * 3

        if self.standingsConfig["fontWeight"] == "bold":
            widthName *= 1.3

        return widthName

    def getBadgeWidths(self):
        widths = {
            "badge": 0,
            "livery": 0,
            "miniskin": 0,
        }

        if self.standingsConfig["showBadge"] == "1":
            widths["badge"] = self.standingsConfig["fontSize"] + spacing
        elif self.standingsConfig["showBadge"] == "2":
            widths["livery"] = self.standingsConfig["fontSize"] + spacing
        elif self.standingsConfig["showBadge"] == "3":
            widths["miniskin"] = self.standingsConfig["fontSize"] * 2 + spacing
        elif self.standingsConfig["showBadge"] == "4":
            widths["badge"] = self.standingsConfig["fontSize"] + spacing
            widths["livery"] = self.standingsConfig["fontSize"] + spacing

        return widths

    def setPositionLabel(self, text):
        if self.labelTexts["position"] != text:
            self.labelTexts["position"] = text

    def setNameLabel(self, text):
        if self.labelTexts["name"] != text:
            self.labelTexts["name"] = text
            self.labelTexts["displayName"] = self.getDriverDisplayName(text)

    def setTyresLabel(self, text):
        if self.labelTexts["tyres"] != text:
            self.labelTexts["tyres"] = text

    def setPitLabel(self, text):
        if self.labelTexts["pit"] != text:
            self.labelTexts["pit"] = text

    def setIntervalLabel(self, text):
        if self.labelTexts["interval"] != text:
            self.labelTexts["interval"] = text

    def setGapToFirstLabel(self, text):
        if self.labelTexts["gapToFirst"] != text:
            self.labelTexts["gapToFirst"] = text

    def setBestLapLabel(self, text):
        if self.labelTexts["bestLap"] != text:
            self.labelTexts["bestLap"] = text

    def setLastLapLabel(self, text):
        if self.labelTexts["lastLap"] != text:
            self.labelTexts["lastLap"] = text

    def setSectorLabels(self, texts, isPersonalBest, isSessionBest, lastSector):
        if self.labelTexts["sectors"] != texts:
            self.labelTexts["sectors"] = texts
        if self.sectorsPersonalBest != isPersonalBest:
            self.sectorsPersonalBest = isPersonalBest
        if self.sectorsSessionBest != isSessionBest:
            self.sectorsSessionBest = isSessionBest
        if self.lastSector != lastSector:
            self.lastSector = lastSector

    def setIntervalColor(self, colorR, colorG, colorB, colorAlpha):
        if (colorR, colorG, colorB, colorAlpha) != self.intervalColor:
            self.intervalColor = (colorR, colorG, colorB, colorAlpha)

    def setRowColor(self, colorR, colorG, colorB, colorAlpha):
        if (colorR, colorG, colorB, colorAlpha) != self.rowColor:
            self.rowColor = (colorR, colorG, colorB, colorAlpha)

    def setCarId(self, carId):
        self.carId = carId
        self.badge = badge[self.carId]
        self.livery = livery[self.carId]
        self.miniSkin = miniSkin[self.carId]

    def setNationCode(self, nationCode):
        if self.nationCode != nationCode:
            self.nationCode = nationCode
            self.nationFlag = getNationTexture(nationCode)

    def setIsFocus(self, active):
        if self.isFocus != active:
            self.isFocus = active
            self.updateRenderFunctions()

    def setIsSplitBorder(self, active):
        if self.isSplitBorder != active:
            self.isSplitBorder = active
            self.updateRenderFunctions()

    def getDriverDisplayName(self, name):
        nameParts = name.split(" ")

        if self.standingsConfig["nameMode"] != "first_last" and len(nameParts) > 1:
            first, last = nameParts[0], nameParts[-1]

            if self.standingsConfig["nameMode"] == "first":
                name = first[:14]
            elif self.standingsConfig["nameMode"] == "last":
                name = last[:14]
            elif self.standingsConfig["nameMode"] == "f_last":
                name = ("%s %s" % (first[0], last))[:16]
            elif self.standingsConfig["nameMode"] == "first_l":
                name = ("%s %s" % (first, last[0]))[:16]
            elif self.standingsConfig["nameMode"] == "f_dot_last":
                name = ("%s. %s" % (first[0], last))[:16]
            elif self.standingsConfig["nameMode"] == "first_l_dot":
                name = ("%s %s." % (first, last[0]))[:16]
            elif self.standingsConfig["nameMode"] == "fl":
                name = ("%s%s" % (first[0], last[0]))[:2]
            elif self.standingsConfig["nameMode"] == "3_last":
                name = last[:3].upper()
        elif self.standingsConfig["nameMode"] != "first_last" and len(nameParts) == 1:
            if self.standingsConfig["nameMode"] == "fl":
                name = name[:2]
            elif self.standingsConfig["nameMode"] == "3_last":
                name = name[:3].upper()
        else:
            name = name[:20]

        return name

    def updateRenderFunctions(self):
        global focusedCar

        self.renderFunctions = []

        if self.isSplitBorder:
            self.renderFunctions.append(self.renderLineSeparator)
        elif self.visible:

            if self.standingsConfig["showRowBackground"]:
                if self.isFocus:
                    self.renderFunctions.append(self.renderFocusBackground)
                elif self.index % 2 == 0:
                    self.renderFunctions.append(self.renderOddBackground)

            self.renderFunctions.append(self.setRenderFont)

            # position
            self.renderFunctions.append(self.renderPosition)

            # class indicator
            if self.standingsConfig["showClass"]:
                self.renderFunctions.append(self.renderClassIndicator)
                # ac.log("shown: " + str(self.standingsConfig["showClass"]))

            # other texts
            self.renderFunctions.append(self.renderName)

            # all texts with "rowColor"
            if self.standingsConfig["showTyres"]:
                self.renderFunctions.append(self.renderTyres)
            if self.standingsConfig["showPitStops"]:
                self.renderFunctions.append(self.renderPitStops)
            if self.labelWidths["gapToFirst"] > 0:
                self.renderFunctions.append(self.renderGapToFirst)
            if isModeDependentItemVisible(self.standingsConfig["showBestLap"]):
                self.renderFunctions.append(self.renderBestLap)
            if isModeDependentItemVisible(self.standingsConfig["showLastLap"]):
                self.renderFunctions.append(self.renderLastLap)
            if isModeDependentItemVisible(self.standingsConfig["showSectors"]):
                self.renderFunctions.append(self.renderSectors)

            # images
            if self.standingsConfig["showBadge"] == "1":
                self.renderFunctions.append(self.renderBadge)
            elif self.standingsConfig["showBadge"] == "2":
                self.renderFunctions.append(self.renderLivery)
            elif self.standingsConfig["showBadge"] == "3":
                self.renderFunctions.append(self.renderMiniSkin)
            elif self.standingsConfig["showBadge"] == "4":
                self.renderFunctions.append(self.renderBadge)
                self.renderFunctions.append(self.renderLivery)

            if self.standingsConfig["showNation"]:
                self.renderFunctions.append(self.renderNationFlag)

            # interval (intervalColor)
            if isModeDependentItemVisible(self.standingsConfig["showInterval"]):
                self.renderFunctions.append(self.renderInterval)

    def render(self):
        # execute activated render functions
        for fnc in self.renderFunctions:
            fnc()

    def setRenderFont(self):
        self.font = getFont(self.standingsConfig["fontWeight"])

    def renderLineSeparator(self):
        ac.glColor4f(1,1,1,0.25)
        ac.glQuad(0, self.topOffset + 0.5*(self.standingsConfig["fontSize"]+spacing), self.width, 1)

    def renderFocusBackground(self):
        ac.glColor4f(0.4,0.4,0.4,0.7)
        ac.glQuad(0, self.topOffset, self.width, self.standingsConfig["fontSize"] + spacing)

    def renderOddBackground(self):
        ac.glColor4f(0.2,0.2,0.2,0.4)
        ac.glQuad(0, self.topOffset, self.width, self.standingsConfig["fontSize"] + spacing)

    def renderPosition(self):
        ac.glColor4f(self.rowColor[0], self.rowColor[1], self.rowColor[2], self.rowColor[3])
        ac.glQuad(self.leftOffsets["position"] + 1, self.topOffset + 1, self.labelWidths["position"] - 2, self.standingsConfig["fontSize"] + spacing - 2)
        ac.ext_glFontUse(fontMonoBold, self.labelTexts["position"], [self.leftOffsets["position"] + self.labelWidths["position"] - 4, self.topTextOffset + 2], self.standingsConfig["fontSize"] / 16, 1)

    def renderClassIndicator(self):
        classColor = driverClassColors[self.carId]
        ac.glColor4f(classColor[0], classColor[1], classColor[2], classColor[3])
        ac.glQuad(self.leftOffsets["class"] + 1, self.topOffset + 1, self.labelWidths["class"] - 2, self.standingsConfig["fontSize"] + spacing - 2)

    def renderName(self):
        ac.ext_glFontColor(self.font, self.rowColor)
        ac.ext_glFontUse(self.font, self.labelTexts["displayName"], [self.leftOffsets["name"] + spacing/2, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 0)

    def renderTyres(self):
        ac.ext_glFontUse(self.font, self.labelTexts["tyres"], [self.leftOffsets["tyres"] + self.labelWidths["tyres"]/2, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 2)

    def renderPitStops(self):
        if len(self.labelTexts["pit"]) > 0:
            ac.ext_glFontUse(self.font, self.labelTexts["pit"], [self.leftOffsets["pit"] + self.labelWidths["pit"]/2, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 2)

    def renderBestLap(self):
        # color
        if self.standingsConfig["colorBestLaps"]:
            # session best (purple)
            if self.labelTexts["bestLap"] == sessionBestLapText:
                ac.ext_glFontColor(self.font, SubStandingsConfigs["timeColors"]["sessionBest"])
            # not session best (white, no row color because of potential confusion)
            else:
                ac.ext_glFontColor(self.font, (1, 1, 1, 1))

        ac.ext_glFontUse(self.font, self.labelTexts["bestLap"], [self.leftOffsets["bestLap"] + self.labelWidths["bestLap"] - spacing, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 1)

    def renderLastLap(self):
        # add color
        if self.standingsConfig["colorBestLaps"] and self.labelTexts["lastLap"] != timeToString(0):
            # pb but no session best (green)
            if self.labelTexts["lastLap"] == self.labelTexts["bestLap"] and self.labelTexts["bestLap"] != sessionBestLapText:
                ac.ext_glFontColor(self.font, SubStandingsConfigs["timeColors"]["personalBest"])
            # no pb but has session best (white, no row color because of potential confusion)
            elif self.labelTexts["lastLap"] != self.labelTexts["bestLap"]:
                ac.ext_glFontColor(self.font, (1, 1, 1, 1))
            # session best but best laps are not displayed (otherwise the color is already set due to render order)
            elif not isModeDependentItemVisible(self.standingsConfig["showBestLap"]):
                ac.ext_glFontColor(self.font, SubStandingsConfigs["timeColors"]["sessionBest"])

        ac.ext_glFontUse(self.font, self.labelTexts["lastLap"], [self.leftOffsets["lastLap"] + self.labelWidths["lastLap"] - spacing, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 1)

    def renderSectors(self):
        if (len(self.labelTexts["sectors"]) == 0
            or len(self.sectorsSessionBest) == 0
            or len(self.sectorsPersonalBest) == 0):
            return

        widthPerSector = (self.labelWidths["sectors"] - spacing) / len(self.labelTexts["sectors"])
        alpha = 1
        lastColor = None
        for sectorIndex in range(len(self.labelTexts["sectors"])):
            if sectorIndex > self.lastSector:
                alpha = 0.6

            color = (1, 1, 1, alpha)
            if self.standingsConfig["colorSectors"]:
                if self.sectorsSessionBest[sectorIndex]:
                    color = SubStandingsConfigs["timeColors"]["sessionBest"][:3] + (alpha,)
                elif self.sectorsPersonalBest[sectorIndex]:
                    color = SubStandingsConfigs["timeColors"]["personalBest"][:3] + (alpha,)

            if color != lastColor:
                ac.ext_glFontColor(self.font, color)
                lastColor = color

            ac.ext_glFontUse(self.font, self.labelTexts["sectors"][sectorIndex], [self.leftOffsets["sectors"] + (widthPerSector * (sectorIndex+1)), self.topTextOffset], self.standingsConfig["fontSize"] / 16, 1)

    def renderBadge(self):
        ac.glColor4f(1,1,1,1)
        ac.glQuadTextured(self.leftOffsets["badge"] + spacing/2, self.topOffset + spacing/2, self.standingsConfig["fontSize"], self.standingsConfig["fontSize"], self.badge)

    def renderLivery(self):
        ac.glColor4f(1,1,1,1)
        ac.glQuadTextured(self.leftOffsets["livery"] + spacing/2, self.topOffset + spacing/2, self.standingsConfig["fontSize"], self.standingsConfig["fontSize"], self.livery)

    def renderMiniSkin(self):
        ac.glColor4f(1,1,1,1)
        ac.glQuadTextured(self.leftOffsets["miniskin"] + spacing/2, self.topOffset, self.standingsConfig["fontSize"]*2, self.standingsConfig["fontSize"]*1.5, self.miniSkin)

    def renderNationFlag(self):
        ac.glColor4f(1,1,1,1)
        ac.glQuadTextured(self.leftOffsets["nationFlag"] + spacing/2, self.topOffset + spacing/2, self.standingsConfig["fontSize"], self.standingsConfig["fontSize"], self.nationFlag)

    def renderInterval(self):
        ac.ext_glFontColor(self.font, self.intervalColor)
        ac.ext_glFontUse(self.font, self.labelTexts["interval"], [self.leftOffsets["interval"] + self.labelWidths["interval"] - spacing, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 1)

    def renderGapToFirst(self):
        ac.ext_glFontUse(self.font, self.labelTexts["gapToFirst"], [self.leftOffsets["gapToFirst"] + self.labelWidths["gapToFirst"] - spacing, self.topTextOffset], self.standingsConfig["fontSize"] / 16, 1)

class PositionWindow:
    def __init__(self, window, headerName):
        self.headerName = headerName
        self.window = window
        self.isActive = False

        ac.addOnAppActivatedListener(self.window, positionActivated)
        ac.addOnAppDismissedListener(self.window, positionDismissed)

        ac.setTitle(self.window, headerName)

        self.label = ac.addLabel(self.window, "x/x")
        ac.setFontAlignment(self.label, 'center')

        self.refreshParameters()

    def refreshParameters(self):
        if SubStandingsConfigs["general"]["showLogoPos"]:
            ac.setIconPosition(self.window, 0, 0)
        else:
            ac.setIconPosition(self.window, -10000, -10000)

        if SubStandingsConfigs["general"]["showTitlePos"]:
            ac.setTitle(self.window, self.headerName)
        else:
            ac.setTitle(self.window, "")

        fontSizePos = SubStandingsConfigs["general"]["fontSizePos"]

        width  = fontSizePos*2 + 80
        height = fontSizePos + 50

        ac.setSize(self.window, width, height)

        ac.setPosition(self.label, 0, height/2 - fontSizePos/2)
        ac.setSize(self.label, width, fontSizePos)
        ac.setFontSize(self.label, fontSizePos)

    def updateView(self, myPos, carCount):
        if not self.isActive:
            return

        ac.setText(self.label, "%d/%d" % (myPos, carCount))

    def onActivated(self):
        self.isActive = True
        ac.log("SubStanding: Activated %s" % self.headerName)

    def onDismissed(self):
        self.isActive = False
        ac.log("SubStanding: Dismissed %s" % self.headerName)

    def onRenderCallback(self, deltaT):
        if not self.isActive:
            self.onActivated()

        ac.setBackgroundOpacity(self.window, float(SubStandingsConfigs["general"]["opacityPos"])/100)
        ac.drawBorder(self.window, SubStandingsConfigs["general"]["showBorderPos"])

def positionActivated(app):
    for name in SubPositions:
        subPosition = SubPositions[name]
        if subPosition.window == app:
            subPosition.onActivated()

def positionDismissed(app):
    for name in SubPositions:
        subPosition = SubPositions[name]
        if subPosition.window == app:
            subPosition.onDismissed()

def timeToString(time):
    if time <= 0 or time == 9999999:
        return "-:--.---"
    else:
        return "%d:%02d.%03d" % (int(time/60000), int((time%60000)/1000), time%1000)

class SubStanding_config:

    def __init__(self, window, headerName, fontSize):
        self.window = window
        self.fontSize = fontSize
        self.isActive = False
        self.listeners = {}

        ac.addOnAppActivatedListener(self.window, configActivated)
        ac.addOnAppDismissedListener(self.window, configDismissed)

        ac.setTitle(self.window, headerName)

        widthLeft       = fontSize*15
        widthCenter     = fontSize*8
        widthRight      = fontSize*5

        # window size
        self.width = widthLeft + widthCenter + widthRight + 2*spacing

        # load pages

        self.pages = [
            self.createGeneralPage(),
            self.createStandingsWindowPage("Relative Standing 1/2", "relative"),
            self.createStandingsContentPage("Relative Standing 2/2", "relative"),
            self.createStandingsWindowPage("Global Standing 1/2", "global"),
            self.createStandingsContentPage("Global Standing 2/2", "global"),
            self.createStandingsWindowPage("Class Standing 1/2", "class"),
            self.createStandingsContentPage("Class Standing 2/2", "class"),
            self.createStandingsWindowPage("Same Car Standing 1/2", "model"),
            self.createStandingsContentPage("Same Car Standing 2/2", "model")
        ]

        self.pageProgress = ac.addSpinner(self.window, "Page")
        ac.setRange(self.pageProgress, 1, len(self.pages))
        ac.setFontSize(self.pageProgress, fontSize)
        ac.setPosition(self.pageProgress, widthLeft + widthCenter - 10, firstSpacing + spacing*2)
        ac.setSize(self.pageProgress, widthRight, fontSize*1.5)
        self.listeners["pageChange"] = lambda *args: self.openPage(int(ac.getValue(self.pageProgress)))
        ac.addOnValueChangeListener(self.pageProgress, self.listeners["pageChange"])

        self.page = -1
        self.openPage(1)

    def openPage(self, pageNr):
        if pageNr - 1 != self.page:
            self.page = pageNr - 1
            ac.setValue(self.pageProgress, pageNr)
            for i, page in enumerate(self.pages):
                page.setVisible(self.page == i)

            self.updateSize()

    def updateSize(self):
        ac.setSize(self.window, self.width, self.pages[self.page].getCurrentTopOffset())

    def createGeneralPage(self):
        page = ConfigPage(self.window, self.fontSize, "General")

        page.addPlusMinusItem("Refresh every", "%i ms", SubStandingsConfigs["general"]["updateTime"], 100, 0, 1000, updateConfFunc("general", "updateTime"))
        page.addBoolItem("Flatten updates", SubStandingsConfigs["general"]["flattenUpdates"], updateConfFunc("general", "flattenUpdates"))
        page.addBoolItem("Use Class Tags", SubStandingsConfigs["general"]["useClassTags"], lambda val: [updateConfFunc("general", "useClassTags")(val), calculateDriverClasses()])
        page.addInputItem("Class Tags", "See Content Manager")
        page.addInputItem("Class Tag Colors", "See Content Manager")
        page.addInputItem("Class Tags Special Chars", "See Content Manager")
        page.addBlankLine()

        page.addHeading("Position:")
        page.addBoolItem("Show AC logo", SubStandingsConfigs["general"]["showLogoPos"], updateConfFunc("general", "showLogoPos"))
        page.addBoolItem("Show title", SubStandingsConfigs["general"]["showTitlePos"], updateConfFunc("general", "showTitlePos"))
        page.addPlusMinusItem("Font size", "%i", SubStandingsConfigs["general"]["fontSizePos"], 1, 3, 100, updateConfFunc("general", "fontSizePos"))
        page.addPlusMinusItem("Opacity", "%i%%", SubStandingsConfigs["general"]["opacityPos"], 10, 0, 100, updateConfFunc("general", "opacityPos"))
        page.addBoolItem("Show border", SubStandingsConfigs["general"]["showBorderPos"], updateConfFunc("general", "showBorderPos"))

        return page

    def createStandingsWindowPage(self, title, standingKey):
        page = ConfigPage(self.window, self.fontSize, title)

        page.addHeading("Window:")
        page.addBoolItem("Show AC logo", SubStandingsConfigs[standingKey]["showLogo"], updateConfFunc(standingKey, "showLogo"))
        page.addBoolItem("Show title", SubStandingsConfigs[standingKey]["showTitle"], updateConfFunc(standingKey, "showTitle"))
        page.addPlusMinusItem("Font size", "%i", SubStandingsConfigs[standingKey]["fontSize"], 1, 3, 100, updateConfFunc(standingKey, "fontSize"))
        page.addListSwitchItem("Font weight", [("normal", "Normal"), ("bold", "Bold")], SubStandingsConfigs[standingKey]["fontWeight"], updateConfFunc(standingKey, "fontWeight"))
        page.addPlusMinusItem("Opacity", "%i%%", SubStandingsConfigs[standingKey]["opacity"], 10, 0, 100, updateConfFunc(standingKey, "opacity"))
        page.addBoolItem("Show border", SubStandingsConfigs[standingKey]["showBorder"], updateConfFunc(standingKey, "showBorder"))
        page.addBoolItem("Show row background", SubStandingsConfigs[standingKey]["showRowBackground"], updateConfFunc(standingKey, "showRowBackground"))
        page.addBoolItem("Anchor to bottom", SubStandingsConfigs[standingKey]["bottomAnchor"], updateConfFunc(standingKey, "bottomAnchor"))
        page.addListSwitchItem("Click to Spectate", [("disabled", "Disabled"), ("full", "Full Row"), ("position", "Position")], SubStandingsConfigs[standingKey]["clickToSpectate"], updateConfFunc(standingKey, "clickToSpectate"))

        return page


    def createStandingsContentPage(self, title, standingKey):
        page = ConfigPage(self.window, self.fontSize, title)

        page.addHeading("Content:")
        page.addListSwitchItem("Name mode", [("first_last", "First Last"), ("first", "First"), ("last", "Last"), ("f_last", "F Last"), ("f_dot_last", "F. Last"), ("first_l", "First L"), ("first_l_dot", "First L."), ("fl", "FL"), ('3_last', 'LAS')], SubStandingsConfigs[standingKey]["nameMode"], updateConfFunc(standingKey, "nameMode"))
        page.addBoolItem("Show class indicator", SubStandingsConfigs[standingKey]["showClass"], updateConfFunc(standingKey, "showClass"))
        page.addBoolItem("Show nation flag", SubStandingsConfigs[standingKey]["showNation"], updateConfFunc(standingKey, "showNation"))
        page.addListSwitchItem("Show badge mode", [("0", "Disabled"), ("1", "Badge"), ("2", "Livery"), ("3", "Mini Skin"), ("4", "Badge + Livery")], SubStandingsConfigs[standingKey]["showBadge"], updateConfFunc(standingKey, "showBadge"))
        page.addBoolItem("Show tyres", SubStandingsConfigs[standingKey]["showTyres"], updateConfFunc(standingKey, "showTyres"))
        page.addBoolItem("Show pit stops", SubStandingsConfigs[standingKey]["showPitStops"], updateConfFunc(standingKey, "showPitStops"))
        page.addListSwitchItem("Show intervals", [("0", "Never"), ("1", "Always"), ("2", "Practice/Quali"), ("3", "Race")], SubStandingsConfigs[standingKey]["showInterval"], updateConfFunc(standingKey, "showInterval"))
        if standingKey == "relative":
            page.addBoolItem("Show gap to first (race only)", int(SubStandingsConfigs[standingKey]["showGap"]), updateConfFunc(standingKey, "showGap"))
        else:
            page.addListSwitchItem("Show gap", [("0", "Never"), ("1", "Always"), ("2", "Practice/Quali"), ("3", "Race")], SubStandingsConfigs[standingKey]["showGap"], updateConfFunc(standingKey, "showGap"))
            page.addListSwitchItem("- gap mode", [("leader", "Leader"), ("focused", "Focused Car")], SubStandingsConfigs[standingKey]["showGapMode"], updateConfFunc(standingKey, "showGapMode"))
        page.addListSwitchItem("- delta signs (+/-)", [("disabled", "Disabled"), ("enabled", "Enabled"), ("inverted", "Inverted")], SubStandingsConfigs[standingKey]["deltaSign"], updateConfFunc(standingKey, "deltaSign"))
        page.addBoolItem("- highlight interval/gap", SubStandingsConfigs[standingKey]["highlightDeltas"], updateConfFunc(standingKey, "highlightDeltas"))
        if standingKey == "relative":
            page.addBoolItem("- show lap difference", SubStandingsConfigs[standingKey]["showLapDiffRelative"], updateConfFunc(standingKey, "showLapDiffRelative"))
        page.addListSwitchItem("Show best lap", [("0", "Never"), ("1", "Always"), ("2", "Practice/Quali"), ("3", "Race")], SubStandingsConfigs[standingKey]["showBestLap"], updateConfFunc(standingKey, "showBestLap"))
        page.addListSwitchItem("Show last lap", [("0", "Never"), ("1", "Always"), ("2", "Practice/Quali"), ("3", "Race")], SubStandingsConfigs[standingKey]["showLastLap"], updateConfFunc(standingKey, "showLastLap"))
        page.addBoolItem("- color best laps", SubStandingsConfigs[standingKey]["colorBestLaps"], updateConfFunc(standingKey, "colorBestLaps"))
        page.addListSwitchItem("Show sectors", [("0", "Never"), ("1", "Always"), ("2", "Practice/Quali"), ("3", "Race")], SubStandingsConfigs[standingKey]["showSectors"], updateConfFunc(standingKey, "showSectors"))
        page.addBoolItem("- color sectors", SubStandingsConfigs[standingKey]["colorSectors"], updateConfFunc(standingKey, "colorSectors"))
        page.addBlankLine()

        if standingKey in ["class", "model"]:
            page.addBoolItem("Show Global Position", SubStandingsConfigs[standingKey]["showGlobalPosition"], updateConfFunc(standingKey, "showGlobalPosition"))
            page.addBlankLine()

        page.addListSwitchItem("Unit", [("metric", "Metric (m)"), ("imperial", "Imperial (ft / mi)"), ("time", "Time (s)")], SubStandingsConfigs[standingKey]["unit"], updateConfFunc(standingKey, "unit"))
        page.addBlankLine()
        if standingKey == "relative":
            page.addPlusMinusItem("Color distance", "%i m", SubStandingsConfigs[standingKey]["colorAt"], 50, 0, 5000, updateConfFunc(standingKey, "colorAt"))
        page.addPlusMinusItem("Drivers Displayed", "%i", SubStandingsConfigs[standingKey]["driverDisplayed"], 2, 3, 50, updateConfFunc(standingKey, "driverDisplayed"))
        page.addPlusMinusItem("Top Drivers Displayed", "%i", SubStandingsConfigs[standingKey]["topDriversDisplayed"], 1, 0, 50, updateConfFunc(standingKey, "topDriversDisplayed"))

        return page

    def onRenderCallback(self, deltaT):
        if not self.isActive:
            self.onActivated()
        ac.setBackgroundOpacity(self.window, 1.0)
        self.pages[self.page].checkRefresh()

    def onActivated(self):
        self.isActive = True
        ac.log("SubStanding: Activated Config")

    def onDismissed(self):
        self.isActive = False
        ac.log("SubStanding: Dismissed Config")

def configActivated(app):
    configApp.onActivated()

def configDismissed(app):
    configApp.onDismissed()

class ConfigPage:

    def __init__(self, window, fontSize, title):
        self.window = window
        self.fontSize = fontSize
        self.configItems = []

        self.titleLabel = ac.addLabel(window, "")
        ac.setFontSize(self.titleLabel, fontSize*1.2)
        ac.setCustomFont(self.titleLabel, "Arial", 0, 1)
        ac.setPosition(self.titleLabel, spacing, firstSpacing + spacing)
        ac.setFontAlignment(self.titleLabel, 'left')
        ac.setText(self.titleLabel, title)

    def addBoolItem(self, name, currentValue, callback):
        item = ConfigEntryBool(self.window, self.getCurrentTopOffset(), self.fontSize, name, currentValue, callback)
        self.configItems.append(item)

    def addListSwitchItem(self, name, values, currentValue, callback):
        item = ConfigEntryListSwitch(self.window, self.getCurrentTopOffset(), self.fontSize, name, values, currentValue, callback)
        self.configItems.append(item)

    def addPlusMinusItem(self, name, textTemplate, currentValue, interval, minVal, maxVal, callback):
        item = ConfigEntryPlusMinus(self.window, self.getCurrentTopOffset(), self.fontSize, name, textTemplate, currentValue, interval, minVal, maxVal, callback)
        self.configItems.append(item)

    def addInputItem(self, name, currentValue):
        item = ConfigEntryText(self.window, self.getCurrentTopOffset(), self.fontSize, name, currentValue)
        self.configItems.append(item)

    def addHeading(self, name):
        item = ConfigEntryHeading(self.window, self.getCurrentTopOffset(), self.fontSize, name)
        self.configItems.append(item)

    def addBlankLine(self):
        self.configItems.append(None)

    def getCurrentTopOffset(self):
        return firstSpacing + (self.fontSize*1.8 + spacing*4) + len(self.configItems)*(self.fontSize*1.5+spacing)

    def setVisible(self, visible):
        ac.setVisible(self.titleLabel, visible)
        for configItem in self.configItems:
            if configItem:
                configItem.setVisible(visible)

    def checkRefresh(self):
        for configItem in self.configItems:
            if configItem and configItem.needsRefresh:
                configItem.refresh()

class ConfigEntryHeading:

    def __init__(self, window, topOffset, fontSize, name):
        widthLeft       = fontSize*15

        self.leftLabel = ac.addLabel(window, "")
        ac.setFontSize(self.leftLabel, fontSize)
        ac.setCustomFont(self.leftLabel, "Arial", 0, 1)
        ac.setPosition(self.leftLabel, spacing, topOffset)
        ac.setSize(self.leftLabel, widthLeft, fontSize+spacing)
        ac.setFontAlignment(self.leftLabel, 'left')
        ac.setText(self.leftLabel, name)

        self.needsRefresh = False

    def setVisible(self, visible):
        ac.setVisible(self.leftLabel, visible)

class ConfigEntryBool:

    def __init__(self, window, topOffset, fontSize, name, currentValue, callback):
        widthLeft       = fontSize*15
        widthCenter     = fontSize*8
        widthRight      = fontSize*5

        self.value = currentValue
        self.callback = callback
        self.listeners = {}

        self.leftLabel = ac.addLabel(window, "")
        ac.setFontSize(self.leftLabel, fontSize)
        ac.setPosition(self.leftLabel, spacing, topOffset)
        ac.setSize(self.leftLabel, widthLeft, fontSize+spacing)
        ac.setFontAlignment(self.leftLabel, 'left')
        ac.setText(self.leftLabel, name)

        self.centerLabel = ac.addLabel(window, "")
        ac.setFontSize(self.centerLabel, fontSize)
        ac.setPosition(self.centerLabel, spacing + widthLeft, topOffset)
        ac.setSize(self.centerLabel, widthCenter, fontSize+spacing)
        ac.setFontAlignment(self.centerLabel, 'left')

        self.changeButton = ac.addButton(window, "Change")
        ac.setFontSize(self.changeButton, fontSize)
        ac.setPosition(self.changeButton, spacing + widthLeft + widthCenter, topOffset)
        ac.setSize(self.changeButton, fontSize*4, fontSize*1.5)

        # needs to be stored in an object, otherwise it's not correctly working
        self.listeners["button"] = self.onClick
        ac.addOnClickedListener(self.changeButton, self.listeners["button"])

        self.updateValueText()
        self.needsRefresh = False

    def onClick(self, *args):
        self.value = 0 if self.value else 1
        self.callback(self.value)
        self.updateValueText()

    def updateValueText(self):
        ac.setText(self.centerLabel, "Yes" if self.value else "No")

    def setVisible(self, visible):
        ac.setVisible(self.leftLabel, visible)
        ac.setVisible(self.centerLabel, visible)
        ac.setVisible(self.changeButton, visible)

class ConfigEntryListSwitch:

    def __init__(self, window, topOffset, fontSize, name, values, currentValue, callback):
        widthLeft       = fontSize*15
        widthCenter     = fontSize*8
        widthRight      = fontSize*5

        self.values = values
        self.value = list(map(lambda t: t[0], self.values)).index(currentValue)
        self.callback = callback
        self.listeners = {}

        self.leftLabel = ac.addLabel(window, "")
        ac.setFontSize(self.leftLabel, fontSize)
        ac.setPosition(self.leftLabel, spacing, topOffset)
        ac.setSize(self.leftLabel, widthLeft, fontSize+spacing)
        ac.setFontAlignment(self.leftLabel, 'left')
        ac.setText(self.leftLabel, name)

        self.centerLabel = ac.addLabel(window, "")
        ac.setFontSize(self.centerLabel, fontSize)
        ac.setPosition(self.centerLabel, spacing + widthLeft, topOffset)
        ac.setSize(self.centerLabel, widthCenter, fontSize+spacing)
        ac.setFontAlignment(self.centerLabel, 'left')

        self.changeButton = ac.addButton(window, "Change")
        ac.setFontSize(self.changeButton, fontSize)
        ac.setPosition(self.changeButton, spacing + widthLeft + widthCenter, topOffset)
        ac.setSize(self.changeButton, fontSize*4, fontSize*1.5)

        # needs to be stored in an object, otherwise it's not correctly working
        self.listeners["button"] = self.onClick
        ac.addOnClickedListener(self.changeButton, self.listeners["button"])

        self.updateValueText()
        self.needsRefresh = False

    def onClick(self, *args):
        self.value = (self.value + 1) % len(self.values)
        self.callback(self.values[self.value][0])
        self.updateValueText()

    def updateValueText(self):
        ac.setText(self.centerLabel, self.values[self.value][1])

    def setVisible(self, visible):
        ac.setVisible(self.leftLabel, visible)
        ac.setVisible(self.centerLabel, visible)
        ac.setVisible(self.changeButton, visible)

class ConfigEntryPlusMinus:

    def __init__(self, window, topOffset, fontSize, name, template, currentValue, interval, minVal, maxVal, callback):
        widthLeft       = fontSize*15
        widthCenter     = fontSize*8
        widthRight      = fontSize*5

        self.template = template
        self.value = currentValue
        self.callback = callback
        self.listeners = {}

        self.interval = interval
        self.min = minVal
        self.max = maxVal

        self.leftLabel = ac.addLabel(window, "")
        ac.setFontSize(self.leftLabel, fontSize)
        ac.setPosition(self.leftLabel, spacing, topOffset)
        ac.setSize(self.leftLabel, widthLeft, fontSize+spacing)
        ac.setFontAlignment(self.leftLabel, 'left')
        ac.setText(self.leftLabel, name)

        self.centerLabel = ac.addLabel(window, "")
        ac.setFontSize(self.centerLabel, fontSize)
        ac.setPosition(self.centerLabel, spacing + widthLeft, topOffset)
        ac.setSize(self.centerLabel, widthCenter, fontSize+spacing)
        ac.setFontAlignment(self.centerLabel, 'left')

        self.plusButton = ac.addButton(window, "+")
        ac.setFontSize(self.plusButton, fontSize)
        ac.setPosition(self.plusButton, spacing + widthLeft + widthCenter, topOffset)
        ac.setSize(self.plusButton, fontSize*1.5, fontSize*1.5)
        self.listeners["plus"] = self.onPlus
        ac.addOnClickedListener(self.plusButton, self.listeners["plus"])

        self.minusButton = ac.addButton(window, "-")
        ac.setFontSize(self.minusButton, fontSize)
        ac.setPosition(self.minusButton, spacing + widthLeft + widthCenter + fontSize*2.5, topOffset)
        ac.setSize(self.minusButton, fontSize*1.5, fontSize*1.5)
        self.listeners["minus"] = self.onMinus
        ac.addOnClickedListener(self.minusButton, self.listeners["minus"])

        self.updateValueText()
        self.needsRefresh = False

    def onPlus(self, *args):
        self.value = min(self.max, self.value + self.interval)
        self.updateValueText()
        self.callback(self.value)

    def onMinus(self, *args):
        self.value = max(self.min, self.value - self.interval)
        self.updateValueText()
        self.callback(self.value)

    def updateValueText(self):
        ac.setText(self.centerLabel, self.template % self.value)

    def setVisible(self, visible):
        ac.setVisible(self.leftLabel, visible)
        ac.setVisible(self.centerLabel, visible)
        ac.setVisible(self.plusButton, visible)
        ac.setVisible(self.minusButton, visible)

class ConfigEntryText:

    def __init__(self, window, topOffset, fontSize, name, currentValue):
        widthLeft       = fontSize*15
        widthCenter     = fontSize*8
        widthRight      = fontSize*5

        self.value = currentValue
        # self.callback = callback
        self.listeners = {}

        self.leftLabel = ac.addLabel(window, "")
        ac.setFontSize(self.leftLabel, fontSize)
        ac.setPosition(self.leftLabel, spacing, topOffset)
        ac.setSize(self.leftLabel, widthLeft, fontSize+spacing)
        ac.setFontAlignment(self.leftLabel, 'left')
        ac.setText(self.leftLabel, name)

        self.centerLabel = ac.addLabel(window, "")
        ac.setFontSize(self.centerLabel, fontSize)
        ac.setPosition(self.centerLabel, spacing + widthLeft, topOffset)
        ac.setSize(self.centerLabel, widthCenter + widthRight - spacing*2, fontSize+spacing)
        ac.setFontAlignment(self.centerLabel, 'left')
        ac.setText(self.centerLabel, self.value)

        # input does not scroll and is written over boundaries, so disabled
        #self.input = ac.addTextInput(window, "TEXT_INPUT")
        #ac.setText(self.input, self.value)
        #ac.setFontSize(self.input, fontSize)
        #ac.setPosition(self.input, spacing + widthLeft, topOffset)
        #ac.setSize(self.input, widthCenter + widthRight - spacing*2, fontSize*1.5)

        # needs to be stored in an object, otherwise it's not correctly working
        #self.listeners["input"] = self.onValidate
        #ac.addOnValidateListener(self.input, self.listeners["input"])

        self.needsRefresh = False

    def onValidate(self, *args):
        self.value = ac.getText(self.input)
        self.callback(self.value)
        self.needsRefresh = True

    def setVisible(self, visible):
        ac.setVisible(self.leftLabel, visible)
        ac.setVisible(self.centerLabel, visible)

    def refresh(self):
        ac.setText(self.input, self.value)
        if ac.getText(self.input) == self.value:
            self.needsRefresh = False

def updateConfFunc(obj, item):
    return functools.partial(setConfigItem, SubStandingsConfigs[obj], item)

def setConfigItem(configObject, item, val):
    configObject[item] = val
    refreshAndWriteParameters()

class CpuUsage:
    def __init__(self, name, headerName, fontSize):
        self.headerName = headerName
        self.window = ac.newApp(name)
        ac.setTitle(self.window, headerName)

        self.firstSpacing = firstSpacing

        widthLeft       = fontSize*6
        widthRight      = fontSize*5
        self.width      = widthLeft + widthRight + 2*spacing
        height          = self.firstSpacing + (fontSize + spacing)*5

        ac.setSize(self.window, self.width, height)

        self.leftLabel = []
        self.rightLabel = []

        for index in range(5):
            self.leftLabel.append(ac.addLabel(self.window, ""))
            ac.setFontSize(self.leftLabel[index], fontSize)
            ac.setPosition(self.leftLabel[index], spacing, self.firstSpacing + index*(fontSize+spacing))
            ac.setSize(self.leftLabel[index], widthLeft, fontSize+spacing)
            ac.setFontAlignment(self.leftLabel[index], 'left')

            self.rightLabel.append(ac.addLabel(self.window, ""))
            ac.setFontSize(self.rightLabel[index], fontSize)
            ac.setPosition(self.rightLabel[index], spacing + widthLeft, self.firstSpacing + index*(fontSize+spacing))
            ac.setSize(self.rightLabel[index], widthRight, fontSize+spacing)
            ac.setFontAlignment(self.rightLabel[index], 'right')

        ac.setText(self.leftLabel[0], "Avg time:")
        ac.setText(self.leftLabel[1], "Min time:")
        ac.setText(self.leftLabel[2], "Max time:")
        ac.setText(self.leftLabel[3], "Avg period:")
        ac.setText(self.leftLabel[4], "Avg load:")

        self.avg = 0
        self.min = 0
        self.max = 999999
        self.avgperiod = 0
        self.avgload = 0

        self.startTime = 0
        self.lastStartTime = 0
        self.delta = 0

    def startMeasure(self):
        self.startTime = time.perf_counter()

        if self.lastStartTime == 0:
            self.lastStartTime = self.startTime

        self.lastPeriod = self.startTime - self.lastStartTime
        self.lastStartTime = self.startTime

    def stopMeasure(self):
        self.delta = time.perf_counter() - self.startTime

        if self.avg == 0:
            self.avg = self.delta
            self.min = self.delta
            self.max = self.delta
        else:
            self.avg = self.avg*0.9 + self.delta*0.1
            if self.delta < self.min:
                self.min = self.delta
            elif self.delta > self.max:
                self.max = self.delta

        if self.avgperiod == 0:
            self.avgperiod = self.lastPeriod
        else:
            self.avgperiod = self.avgperiod*0.9 + self.lastPeriod*0.1

        if self.avgperiod == 0:
            self.avgload = 0
        else:
            self.avgload = self.avg/self.avgperiod*100

    def updateView(self):
        ac.setText(self.rightLabel[0], "%.3f ms" % (self.avg*1000))
        ac.setText(self.rightLabel[1], "%.3f ms" % (self.min*1000))
        ac.setText(self.rightLabel[2], "%.3f ms" % (self.max*1000))
        ac.setText(self.rightLabel[3], "%.3f ms" % (self.avgperiod*1000))
        ac.setText(self.rightLabel[4], "%.3f %%" % self.avgload)
