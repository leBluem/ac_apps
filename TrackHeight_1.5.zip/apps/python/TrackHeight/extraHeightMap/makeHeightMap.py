from PIL import Image
import sys, os.path, traceback, math, struct
import numpy

gGRAPHTRANS      = 0.5   # top: 0.0, bottom: 1.0

gCOLORMULT       = 4     # default: 4
bGrayScaled      = False # True #
colorblind       = 0     # 0,1,2,3
minSlopeColoring = 0.01  # 0.01 = 1% slope , the higher -> the more white parts (representing flat)
AI_LINE_LENGTH   = 0.0

def clamp(n, minn, maxn):
    if n < minn:
        return minn
    elif n > maxn:
        return maxn
    else:
        return n

def distance(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2 )

def ReadAILine():
    global sTrack, sLayout, AI_LINE_LENGTH, gCOLORMULT, colorblind
    try:
        sFileAI     = sys.argv[1]
        if not os.path.isfile(sFileAI) or os.path.getsize(sFileAI)<=24:
            print('Not found or too small')
            return
        with open(sFileAI, "rb") as buffer:
            # read header, detailCount is number of data points available
            _, detailCount, _, _ = struct.unpack("4i", buffer.read(4 * 4))

            data_ideal   = []
            AI_LINE_LENGTH = 0.0
            minz=1000000
            maxz=-1000000
            # read ideal-line data
            for i in range(detailCount):       # 4 floats, one integer
                data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
                x , z , y, dist, _ = data_ideal[i]
                coordscurr = ( float(x), -float(y), float(z)  )
                if z<minz:
                    minz=z
                if z>maxz:
                    maxz=z
                if i>0:
                    AI_LINE_LENGTH += distance( coordscurr, coordslast )
                coordslast = coordscurr

            height=int(abs(minz)+abs(maxz))

            print(str(AI_LINE_LENGTH) + ' | ' + str(detailCount) + ' , diff: ' + str(height) + ' (min ' +  str(minz) + ' , max ' +  str(maxz))
            arr = numpy.zeros([ height,detailCount,4])
            arr[:,:,0] = [  [0]*detailCount]*height
            arr[:,:,1] = [  [0]*detailCount]*height
            arr[:,:,2] = [  [0]*detailCount]*height
            arr[:,:,3] = [  [0]*detailCount]*height

            _, zl, _, distl, _ = data_ideal[len(data_ideal)-1] # last point
            ldM = 0.0
            for i in range(len(data_ideal)):
                _, z, _, dist, _ = data_ideal[i]
                # get slope vals
                xa = distl - dist
                xb = z - zl
                # save for next loop
                zl = z
                distl = dist

                # dM = -math.degrees(math.atan(xb/xa))
                if xa!=0.0:
                    dM = clamp( xb / xa * gCOLORMULT , -1.0, 1.0)
                else:
                    dM = 0.0   # should never happen, but...
                ldM = dM
                #ldM = (ldM + dM) / 2.0  # do small interpolation
                r=0.5
                g=0.5
                b=0.5
                a=1.0  ###0.5+(gGRAPHTRANS/2)
                if abs(dM) > minSlopeColoring:
                    if dM>0.01:
                        g=0.5+abs(ldM/2)
                        if bGrayScaled:
                            r=abs(ldM)*2
                            g=r
                            b=r
                        else:
                            r=0.5-abs(ldM/2)
                            b=r
                    else:
                        r=0.5+abs(ldM/2)
                        if bGrayScaled:
                            g=abs(ldM)*2
                            r=g
                            b=g
                        else:
                            g=0.5-abs(ldM/2)
                            b=g
                    a = clamp ( (1.0-gGRAPHTRANS) + abs(dM/2) , 0, 1)

                for j in range(int(z+height/2)):
                    arr[height-j-1,i,3] = a*255
                    if colorblind==1:
                        arr[height-j-1,i,0] = g*255
                        arr[height-j-1,i,1] = b*255
                        arr[height-j-1,i,2] = r*255
                    elif colorblind==2:
                        arr[height-j-1,i,0] = b*255
                        arr[height-j-1,i,1] = r*255
                        arr[height-j-1,i,2] = g*255
                    elif colorblind==3:
                        arr[height-j-1,i,0] = b*255
                        arr[height-j-1,i,1] = g*255
                        arr[height-j-1,i,2] = r*255
                    else:
                        arr[height-j-1,i,0] = r*255
                        arr[height-j-1,i,1] = g*255
                        arr[height-j-1,i,2] = b*255

        myImage = Image.fromarray(numpy.ubyte(arr), 'RGBA')
        # save raw unscaled
        myImage.save('result.png')

        # scale 2540-5 pixel width
        newImage = myImage.resize([2535, height], resample=Image.NEAREST)
        # newImage = myImage.resize([2535, height], resample=Image.BICUBIC)

        # save (down) scaled
        newImage.save('result_scaled.png')

        os.startfile('result_scaled.png')
    except:
        print("TrackHeight error: " + traceback.format_exc())

ReadAILine()
