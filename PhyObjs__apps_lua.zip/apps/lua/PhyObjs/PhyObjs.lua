-- PhyObjs by leBluem
--v1.0 - 10 sept 2024
-- added AC_POBJECT reset button

ac.setWindowTitle('main', "PhyObjs v1.0")


local function readACConfig(ini, sec, key, def)
    local inifile = ac.INIConfig.load(ini)
    return inifile:get(sec, key, def)
end

local function writeACConfig(ini, sec, key, val)
    local inifile = ac.INIConfig.load(ini)
    inifile:set(sec, key, val)
    inifile:save(ini)
end


--local PhyOBJsStates = table.new(128,0)
local acobjs = ac.findNodes('trackRoot:yes'):findMeshes("AC_POBJECT?")
local lastHit = ""
local hitcount = 0

local sim = ac.getSim()



local keydelay = 0
local pos_POBJ = nil --@vec3()
local pos_POBJ2 = nil --@vec3()
local fntSize = 18
local fntSizeSmall = 12
local checkPhyOBJs = true

local appini = 'apps/lua/PhyObjs/PhyObjs.ini'
fntSize = readACConfig(appini, 'USERSETTINGS', 'FONTSIZE', 18)
fntSizeSmall = math.floor(0.666*fntSize)
checkPhyOBJs = readACConfig(appini, 'USERSETTINGS', 'ENABLED', checkPhyOBJs)

local joystickbuttonreset    = ac.ControlButton('__APP_PhyObjs_reset')

local Bpts = {}
local Bnames = {}

local vUp = vec3(0, 1, 0)
local vDown = vec3(0, -1, 0)
local ucTurn = vec2(0.0, 0.0)

local function snapToTrackSurface(pos, gap)
    local p = pos
    local v1 = vec3()
    physics.raycastTrack(v1:set(0, 10, 0):add(p), vDown, 20, p) --, v1)
    p.y = p.y + (gap or 0.3)
end

local sesstimeleft = sim.sessionTimeLeft



function Reset()
    lastHit = ""
    hitcount = 0
    pos_POBJ = nil
    pos_POBJ2 = nil
    physics.resetTrackPhysicsObject("?")
    --ac.findNodes('trackRoot:yes'):findMeshes("AC_POBJECT?"):setMaterialProperty('ksEmissive', 0)
    table.clear(Bpts)
    table.clear(Bnames)
end




function script.Draw3D(dt)  --script.renderTrack()
    for i = 1, #Bpts do
        render.debugArrow(Bpts[i][1], Bpts[i][2], 0.25, rgbm.colors.red*10)
    end
end

function script.update(dt)

    if sim.sessionTimeLeft >= sesstimeleft then
        sesstimeleft = sim.sessionTimeLeft
        Reset()
    end

    if checkPhyOBJs then
        for i = 0,128 do
            if ac.getCar(i) then
                -- ac.hasTrackPhysicsObjectCollidedWithCar(i, objname, ..)
                -- ac.getCarIndexTrackPhysicsObjectCollidedWith(name)
                local obj = ac.getTrackPhysicsObjectNameHitByCar(i)
                if obj~=nil and obj~=lastHit and not table.contains(Bnames, obj) then
                    pos_POBJ2 = ac.findNodes('trackRoot:yes'):findMeshes(obj):getParent():getPosition()
                    pos_POBJ = vec3(pos_POBJ2.x, pos_POBJ2.y+1.5, pos_POBJ2.z)

                    table.insert(Bnames, obj)
                    table.insert(Bpts, {[1]=pos_POBJ, [2]=pos_POBJ2} )
                    lastHit = obj
                    hitcount = hitcount + 1
                end
            else
                break
            end
        end
    end


    if keydelay>0.0 then
        keydelay = keydelay - dt
        return
    end
    if keydelay<=0.0 then
        if joystickbuttonreset:down() and not sim.isReplayActive and not sim.isPaused then
            Reset()
            keydelay = 0.188
        end
    end

end

local v1 = vec2(10, 60)
local v2 = vec2(90, 0)

function script.windowMain(dt)
    -- if bBackground then
    --     ui.drawRectFilled(vec2(0,0), vec2(ui.windowSize().x, ui.windowSize().y), rgbm(0,0,0,0.25))
    -- end

    ui.beginOutline()


    ui.dwriteDrawText('Objects hit: '..hitcount, ui.fontSize()*1.5, v1, rgbm.colors.white)

    if ui.checkbox("Enabled", checkPhyOBJs) then
        checkPhyOBJs = not checkPhyOBJs
        if checkPhyOBJs then
            writeACConfig(appini, 'USERSETTINGS', 'ENABLED', true)
        else
            writeACConfig(appini, 'USERSETTINGS', 'ENABLED', false)
            Reset()
        end
    end

    ui.sameLine()
    ui.setCursorX(ui.windowWidth()-100)
    if physics.allowed() then
        if ui.button("reset\nAC_PObjects") then
            Reset()
        end
    end

    ui.newLine()
    ui.newLine()
    ui.text('reset:')
    ui.sameLine(0,0)
    joystickbuttonreset:control(v2)

    ui.endOutline(rgbm.colors.black, 0.25)
end
