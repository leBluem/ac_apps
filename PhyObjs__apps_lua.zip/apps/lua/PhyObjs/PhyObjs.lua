-- PhyObjs by leBluem
--v1.0 - 10 sept 2024
-- added AC_POBJECT reset button
--v1.1 - 11 apr 2025
-- more options for reset and invalidating lap on contact

ac.setWindowTitle('main', "PhyObjs v1.1")

local function readACConfig(ini, sec, key, def)
    local inifile = ac.INIConfig.load(ini)
    return inifile:get(sec, key, def)
end

local function writeACConfig(ini, sec, key, val)
    local inifile = ac.INIConfig.load(ini)
    inifile:set(sec, key, val)
    inifile:save(ini)
end



local sim = ac.getSim()
local appini = 'apps/lua/PhyObjs/PhyObjs.ini'
local checkPhyOBJs = readACConfig(appini, 'USERSETTINGS', 'ENABLED', true)
local InvalidateLap = readACConfig(appini, 'USERSETTINGS', 'INVALIDATELAP', true)
local ResetTime = readACConfig(appini, 'USERSETTINGS', 'RESETTIME', 0)

local joystickbuttonreset    = ac.ControlButton('__APP_PhyObjs_reset')

-- local acobjs = ac.findNodes('trackRoot:yes'):findMeshes("AC_POBJECT?")
--local PhyOBJsStates = table.new(128,0)

local Bpts = {}
local Bnames = {}
local pos_POBJ = nil --@vec3()
local pos_POBJ2 = nil --@vec3()

local sesstimeleft = sim.sessionTimeLeft
local timer = 0.0
local lastHit = ""
local hitcount = 0
local keydelay = 0

function Reset()
    lastHit = ""
    hitcount = 0
    pos_POBJ = nil
    pos_POBJ2 = nil
    physics.resetTrackPhysicsObject("?")
    --ac.findNodes('trackRoot:yes'):findMeshes("AC_POBJECT?"):setMaterialProperty('ksEmissive', 0)
    table.clear(Bpts)
    table.clear(Bnames)
end



function script.Draw3D(dt)  --script.renderTrack()
    for i = 1, #Bpts do
        render.debugArrow(Bpts[i][1], Bpts[i][2], 0.25, rgbm.colors.red*10)
    end
end


function script.update(dt)

    if timer>0.0 and ResetTime>0.0 then
        timer = timer-dt
        if timer<=0.0 then
            Reset()
        end
    end

    if sim.sessionTimeLeft >= sesstimeleft then
        sesstimeleft = sim.sessionTimeLeft
        Reset()
    end

    if checkPhyOBJs then
        for i = 0,128 do
            local car = ac.getCar(i)
            if car then
                -- ac.hasTrackPhysicsObjectCollidedWithCar(i, objname, ..)
                -- ac.getCarIndexTrackPhysicsObjectCollidedWith(name)
                local obj = ac.getTrackPhysicsObjectNameHitByCar(i)
                if obj~=nil and obj~=lastHit and not table.contains(Bnames, obj) then
                    pos_POBJ2 = ac.findNodes('trackRoot:yes'):findMeshes(obj):getParent():getPosition()
                    pos_POBJ = vec3(pos_POBJ2.x, pos_POBJ2.y+1.5, pos_POBJ2.z)

                    table.insert(Bnames, obj)
                    table.insert(Bpts, {[1]=pos_POBJ, [2]=pos_POBJ2} )
                    lastHit = obj
                    hitcount = hitcount + 1
                    timer = ResetTime
                    if InvalidateLap and physics.allowed() and car.isLapValid then
                        physics.markLapAsSpoiled(i)
                        ui.toast(ui.Icons.AppWindow, 'Lap Invalidated!')
                    end
                end
            else
                break
            end
        end
    end


    if keydelay>0.0 then
        keydelay = keydelay - dt
        return
    end
    if keydelay<=0.0 then
        if joystickbuttonreset:down() and not sim.isReplayActive and not sim.isPaused then
            Reset()
            keydelay = 0.188
        end
    end

end

local v1 = vec2(10, 60)
local v2 = vec2(90, 0)

function script.windowMain(dt)
    -- if bBackground then
    --     ui.drawRectFilled(vec2(0,0), vec2(ui.windowSize().x, ui.windowSize().y), rgbm(0,0,0,0.25))
    -- end

    ui.beginOutline()

    ui.dwriteDrawText('Objects hit: '..hitcount, ui.fontSize()*1.5, v1, rgbm.colors.white)

    if ui.checkbox("Enabled", checkPhyOBJs) then
        checkPhyOBJs = not checkPhyOBJs
        if checkPhyOBJs then
            writeACConfig(appini, 'USERSETTINGS', 'ENABLED', true)
        else
            writeACConfig(appini, 'USERSETTINGS', 'ENABLED', false)
            Reset()
        end
    end

    ui.sameLine()
    ui.setCursorX(ui.windowWidth()-100)
    if physics.allowed() then
        if ui.button("reset\nAC_PObjects") then
            Reset()
        end
    end

    ui.newLine()
    ui.newLine()
    ui.text('reset:')
    ui.sameLine(0,0)
    joystickbuttonreset:control(v2)

    ui.sameLine()
    if physics.allowed() then
        if ui.checkbox("Invalidate lap", InvalidateLap) then
            InvalidateLap = not InvalidateLap
            if InvalidateLap then
                writeACConfig(appini, 'USERSETTINGS', 'INVALIDATELAP', true)
            else
                writeACConfig(appini, 'USERSETTINGS', 'INVALIDATELAP', false)
            end
        end
    else
        ui.text("ExtendedPhysics off, cannot make laps invalid")
    end

    ResetTime, changed = ui.slider("Reset after", ResetTime, 0, 120, "%d secs"%ResetTime)
    if changed then
        ResetTime = math.floor(ResetTime)
        if InvalidateLap then
            writeACConfig(appini, 'USERSETTINGS', 'RESETTIME', ResetTime)
        else
            writeACConfig(appini, 'USERSETTINGS', 'RESETTIME', ResetTime)
        end
    end

    ui.endOutline(rgbm.colors.black, 0.25)
end
