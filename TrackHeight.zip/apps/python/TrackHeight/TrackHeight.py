# TrackHeightMap v1.4

### usually read from ini, if anything goes wrong, those are defaults
gAPPSIZE     = 1.0   # *100 = percent
gOPACITY     = 0.0
gPREVIEWBACK = 50    # no marker when 0
gPREVIEWFORW = 250   #
gHEIGHT_MULT = 2.0   # height scaling default: 2
gWIDTH_MULT  = 1.0   # ""
gSTEPPING    = 5     # steps
gCOLORMULT   = 8     # default: 2
gDRAWBLOCKS  = True
gDRAWTEXT    = False
gGRAPHTRANS  = 0.0
bSHOWMARKER  = True
rtIndex0 = 0
bCSPActive = False
gW=0
gH=0
marginW=0
marginH=0
lbInfo = 0
fntsize=12
btnMode=0
bMode=True

import ac
import acsys
import configparser, os, traceback, io, math, struct, codecs

###############

app = 0
error = 0
btimerMsg = True
timer = 0.0
timerMsg = 0.5
bHideTimerOn     = False
hideTimer        = -1.0

lastPoT = 0.0
appMsg  =''
sVer = ''
currAltitude = 0.0
lastAltitude = 0.0
minz=1000000.0
maxz=-1000000.0
basealtitude = -100000000

sTrack =''
sLayout =''
sFileOverlay =''
sFileCameras =''

ailineYOFFSET = 100
AI_LINE_LENGTH = 0.0
AI_LINE = []
AI_LINE_dM = []
AI_LINE_rgb = []

btnAPPSIZEplus = 0
btnAPPSIZEminus = 0
btnOPACITYplus=0
btnOPACITYminus=0
btnPREVIEWBACKplus=0
btnPREVIEWBACKminus=0
btnPREVIEWFORWplus=0
btnPREVIEWFORWminus=0
btnHEIGHT_MULTplus=0
btnHEIGHT_MULTminus=0
btnWIDTH_MULTplus=0
btnWIDTH_MULTminus=0
btnSTEPPINGplus=0
btnSTEPPINGminus=0
btnCOLOR_MULTplus=0
btnCOLOR_MULTminus=0
btnGRAPHTRANSplus=0
btnGRAPHTRANSminus=0
btnDRAWBLOCKStoggle=0
btnDRAWTEXTtoggle=0
btnSHOWMARKER=0

#####################################################################

class ExtGL:
    CULL_MODE_FRONT = 0
    CULL_MODE_BACK = 1
    CULL_MODE_NONE = 2
    CULL_MODE_WIREFRAME = 4
    CULL_MODE_WIREFRAME_SMOOTH = 7
    BLEND_MODE_OPAQUE = 0
    BLEND_MODE_ALPHA_BLEND = 1
    BLEND_MODE_ALPHA_TEST = 2
    BLEND_MODE_ALPHA_ADD = 4
    BLEND_MODE_MULTIPLY_BOTH = 5
    FONT_ALIGN_LEFT = 0
    FONT_ALIGN_RIGHT = 1
    FONT_ALIGN_CENTER = 2

class FontMeasures:
    def __init__(self, name, italic, bold, size, ratio, distance, heightCompensation, widthCompensation):
        self.n = name					#font name
        self.i = italic					#font italic
        self.b = bold					#font bold
        self.s = size					#font multiplier for one pixel height
        self.r = ratio					#font width compared to height
        self.d = distance				#font distance between the leftmost point of one letter and another, avareage
        self.h = heightCompensation		#font height offset to put it centered vertically
        self.w = widthCompensation		#font width offset to put it centered horizontally
        self.f = 0						#font object to be used in rendering
        return

def getSettingsValue(parser, section, option, value, boolean = False):
    if parser.has_option(str(section), str(option)):
        if boolean:
            return parser.getboolean(str(section), option)
        else:
            return parser.get(str(section), str(option))
    else:
        return str(value)

#######################################################

def isASCII(data):
    try:
        data.encode('ascii', 'ignore').decode('ascii').strip()
    except UnicodeDecodeError:
        return False
    else:
        return True

def find_str(s, char):
    index = 0
    if len(char)>0 and char in s:
        c = char[0]
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index
            index += 1
    return -1

### one of the app...CFGValue() funcs has a bug, it cant distinct btw SHOWNM and SHOWNM_TORQ
def appReadCFGValue(path, section, valname, default):
    try:
        result=default
        sect = ''
        if os.path.isfile(path):
            # ac.log(path)
            goOn = False
            s = ''
            try:
                with codecs.open(path, 'r', 'utf_8', errors='ignore') as file:
                    s = file.read()
            except:
                with codecs.open(path, 'r', errors='ignore') as file:
                    s = file.read()
            ss = str(s).split('\n')
            for sss in ss: # for all lines
                sss=sss.strip()
                if find_str(sss, '--')!=0 and find_str(sss, ';')!=0 and find_str(sss, '#')!=0:
                    if ('[' in sss) and (']' in sss):
                        sect = sss
                    if (section=='' or sect=='['+section+']') and (valname in sss):
                        v = sss.replace(' = ', '=').split('=')
                        if len(v)>1:
                            if section=='' and '--' in v[1]:
                                w = v[1].split('--')
                                if len(w)>0:
                                    result = w[0].replace(' ', '')
                            elif ';' in v[1]:
                                w = v[1].split(';')
                                if len(w)>0:
                                    result = w[0].replace(' ', '')
                            else:
                                result = v[1]
    except:
        ac.log('trackheight: \n' + path + ' \n' + traceback.format_exc())
        # ac.console('trackheight: \n' + path + ' \n' + traceback.format_exc())
    # ac.log(valname + ' = ' + result)
    return result

### one of the app...CFGValue() funcs has a bug, it cant distinct btw SHOWNM and SHOWNM_TORQ
def appWriteCFGValue(path, section, valname, value, createNonExistant=False):
    global lbChng
    try:
        if not os.path.isfile(path) and createNonExistant:
            with io.open(path, 'w', encoding='utf-8') as f:
                f.write('; created by sol_weather app\n['+section+']\n'+valname+'='+str(value)+'\n')
                # ac.log('settings cleaned')
            return
        if os.path.isfile(path):
            with io.open(path, 'r', encoding='utf-8') as f:
                s=f.read()
            #ac.log('first: \n' + s + '\n\n\n\n\n')
            currsection = ''
            t = ''
            idx = -1
            sectid = -1
            found = False
            sEqual = ' = ' if '.lua' in str(path).lower() else '='
            ss = str(s).split('\n')
            for sss in ss:
                idx+=1
                if find_str(sss, '--')!=0 and find_str(sss, ';')!=0 and find_str(sss, '#')!=0:
                    if find_str(sss, '[')==0 and (']' in sss):
                        currsection = sss.split('[')[1].split(']')[0]
                    if find_str(sss, '['+section+']')==0:
                        sectid = idx
                    if find_str(sss, valname)==0 and currsection==section:
                        # ss[idx] = valname + ' = ' + str(value)
                        found = True
                        if '--' in sss:
                            iFound = find_str(sss,'--')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        elif ';' in sss:
                            iFound = find_str(sss,';')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        elif '#' in sss:
                            iFound = find_str(sss,'#')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        else:
                            ss[idx] = valname + sEqual + str(value)
                else:
                    ss[idx] = sss
                t = t + ss[idx] + '\n'
            if found == False and sectid>=0:
                # insert
                found = True
                # t = t[:sectid+1] + valname + sEqual + str(value)+'\n' + t[sectid+1:]
                ss=t.split('\n')
                ss.insert(sectid+1, valname + sEqual + str(value))
                t= '\n'.join(s for s in ss)
            elif found == False:
                # append
                found = True
                t = t[sectid+1:].strip() + '\n\n[' + section + ']\n' + valname + sEqual + str(value)+'\n'
            if found == True:
                f=io.open(path, 'w', encoding='utf8') # write
                f.write(t.strip()+'\n')
                f.close()
        else:
            ac.log('! no ' + str(path))
    except:
        ac.log("TrackHeightApp error: " + section + ' - ' + valname+'\n'+ str(path) + '\n' + traceback.format_exc())
        ac.log(section + ' - ' + valname+'\n'+str(path) + '\n' + traceback.format_exc())

###############################################################################

def appAPPSIZEplus(*args):
    global gAPPSIZE
    global lastgW
    lastgW=0
    if gAPPSIZE<4.0:
        gAPPSIZE += 0.1
    on_click_app_window(0,0)

def appAPPSIZEminus(*args):
    global gAPPSIZE
    if gAPPSIZE>=0.6:
        gAPPSIZE -= 0.1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appOPACITYplus(*args):
    global gOPACITY
    if gOPACITY<=0.9:
        gOPACITY += 0.1
    on_click_app_window(0,0)

def appOPACITYminus(*args):
    global gOPACITY
    if gOPACITY>=0.1:
        gOPACITY -= 0.1
    on_click_app_window(0,0)

def appPREVIEWBACKplus(*args):
    global gPREVIEWBACK, gPREVIEWFORW
    if gPREVIEWBACK<500 and gPREVIEWBACK<gPREVIEWFORW:
        gPREVIEWBACK += 10
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appPREVIEWBACKminus(*args):
    global gPREVIEWBACK
    if gPREVIEWBACK>=10:
        gPREVIEWBACK -= 10
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appPREVIEWFORWplus(*args):
    global gPREVIEWFORW
    if gPREVIEWFORW<500:
        gPREVIEWFORW += 10
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appPREVIEWFORWminus(*args):
    global gPREVIEWFORW
    if gPREVIEWFORW>=10:
        gPREVIEWFORW -= 10
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appHEIGHT_MULTplus(*args):
    global gHEIGHT_MULT
    if gHEIGHT_MULT<5.9:
        gHEIGHT_MULT += 0.1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appHEIGHT_MULTminus(*args):
    global gHEIGHT_MULT
    if gHEIGHT_MULT>=0.5:
        gHEIGHT_MULT -= 0.1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appWIDTH_MULTplus(*args):
    global gWIDTH_MULT
    if gWIDTH_MULT<10.0:
        gWIDTH_MULT += 0.1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appWIDTH_MULTminus(*args):
    global gWIDTH_MULT
    if gWIDTH_MULT>=0.6:
        gWIDTH_MULT -= 0.1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appSTEPPINGplus(*args):
    global gSTEPPING
    if gSTEPPING<20:
        gSTEPPING += 1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appSTEPPINGminus(*args):
    global gSTEPPING
    if gSTEPPING>=2:
        gSTEPPING -= 1
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appCOLOR_MULTplus(*args):
    global gCOLORMULT
    if gCOLORMULT<32:
        gCOLORMULT += 1
    global lastgW
    lastgW=0
    ReadAILine()
    on_click_app_window(0,0)

def appCOLOR_MULTminus(*args):
    global gCOLORMULT
    if gCOLORMULT>=1:
        gCOLORMULT -= 1
    global lastgW
    lastgW=0
    ReadAILine()
    on_click_app_window(0,0)

def appGRAPHTRANSminus(*args):
    global gGRAPHTRANS
    if gGRAPHTRANS>=0.2:
        gGRAPHTRANS -= 0.1
    on_click_app_window(0,0)

def appGRAPHTRANSplus(*args):
    global gGRAPHTRANS
    if gGRAPHTRANS<=0.9:
        gGRAPHTRANS += 0.1
    on_click_app_window(0,0)

def appDRAWBLOCKStoggle(*args):
    global gDRAWBLOCKS
    gDRAWBLOCKS = not gDRAWBLOCKS
    global lastgW
    lastgW=0
    on_click_app_window(0,0)

def appDRAWTEXTtoggle(*args):
    global gDRAWTEXT
    gDRAWTEXT = not gDRAWTEXT
    on_click_app_window(0,0)

def appMARKERtoggle(*args):
    global bSHOWMARKER
    bSHOWMARKER = not bSHOWMARKER
    on_click_app_window(0,0)

def appOnActivated(*args):
    on_click_app_window(0,0)

def getSetting(cfgdef, cfg, sect, value, valdef):
    res = valdef
    if cfgdef!=None and cfgdef.has_option(sect, value):
        res = cfgdef[sect][value]
        if ';' in res:
            res = res.split(';')[0]
    if cfg.has_option(sect, value):
        res = cfg[sect][value]
        if ';' in res:
            res = res.split(';')[0]
    return str(res)

def acMain(ac_version):
    global app, label, btnSetBackCar, error, sVer
    global vaoToggleButton, vaoDebugButton, lightsDebugButton, copyCameraCoordsButton, copyCameraCoordsButton2
    global doorToggleButton, driverToggleButton, bDetailed, btnResetCar, btnResetStats
    global sTrack, sLayout, sFileOverlay, sFileCameras, btnTimeAttack, btnCameraAdd, btnToggleDetail, btnCameraAuto
    global gAPPSIZE, gOPACITY, gPREVIEWBACK, gPREVIEWFORW, gHEIGHT_MULT, gWIDTH_MULT, gSTEPPING, gCOLORMULT, gDRAWBLOCKS, gDRAWTEXT, gGRAPHTRANS
    global f1, hideTimer
    global btnAPPSIZEplus, btnAPPSIZEminus, btnOPACITYplus, btnOPACITYminus, btnPREVIEWBACKplus, btnPREVIEWBACKminus, btnPREVIEWFORWplus, btnPREVIEWFORWminus, btnCOLOR_MULTminus, btnCOLOR_MULTplus, btnGRAPHTRANSminus, btnGRAPHTRANSplus
    global btnHEIGHT_MULTplus, btnHEIGHT_MULTminus, btnWIDTH_MULTplus, btnWIDTH_MULTminus, btnSTEPPINGplus, btnSTEPPINGminus, btnDRAWBLOCKStoggle, btnDRAWTEXTtoggle, btnSHOWMARKER, bSHOWMARKER
    global rtIndex0, bCSPActive, btnMode, bMode

    ### ac.ext_setStrictMode()
    ac.initFont(0, "Segoe UI", 0, 1)

    try:
        f1 = FontMeasures("Segoe UI", 0, 0, 1.25, 0.69, 0.629, 0.616, 0.066)
        f1.f = ac.ext_glFontCreate(f1.n, f1.s, f1.i, True)
        bCSPActive = True
    except:
        error = 20
        ac.log('TrackHeight: CustomShadersPatch not active., some features disabled.')

    app = ac.newApp("TrackHeight") # for the icon to be found
    ac.setTitle(app, "")
    ac.setFontAlignment(app, 'left')
    ac.addRenderCallback(app, onFormRender)
    ac.addOnClickedListener     (app, on_click_app_window)
    ac.addOnAppActivatedListener(app, appOnActivated)

    label = ac.addLabel(app, "") # label for all the output
    ac.setFontSize(label, 12)
    sTrack = ac.getTrackName(0)
    sLayout = ac.getTrackConfiguration(0)

    try:
        settingsParser = None
        if os.path.isfile("apps/python/TrackHeight/settings/settings.ini"):
            settingsParser = configparser.ConfigParser()
            settingsParser.optionxform = str
            settingsParser.read("apps/python/TrackHeight/settings/settings.ini")
            # bDetailed      = getSettingsValue(settingsParser, 'GENERAL', 'DETAILS', bDetailed, True)
            gAPPSIZE      = float(getSettingsValue(settingsParser, 'GENERAL', "APPSIZE", str(gAPPSIZE), False))
            gOPACITY      = float(getSettingsValue(settingsParser, 'GENERAL', "OPACITY", str(gOPACITY), False))
            gPREVIEWBACK  = int  (getSettingsValue(settingsParser, 'GENERAL', "PREVIEWBACK", str(int(gPREVIEWBACK)), False))
            gPREVIEWFORW  = int  (getSettingsValue(settingsParser, 'GENERAL', "PREVIEWFORW", str(int(gPREVIEWFORW)), False))
            gHEIGHT_MULT  = float(getSettingsValue(settingsParser, 'GENERAL', "HEIGHT_MULT", str(gHEIGHT_MULT), False))
            gWIDTH_MULT   = float(getSettingsValue(settingsParser, 'GENERAL', "WIDTH_MULT", str(gWIDTH_MULT), False))
            gSTEPPING     = int  (getSettingsValue(settingsParser, 'GENERAL', "STEPPING", str(gSTEPPING), False))
            gCOLORMULT    = int  (getSettingsValue(settingsParser, 'GENERAL', "COLORMULT", str(int(gCOLORMULT)), False))
            gGRAPHTRANS   = float(getSettingsValue(settingsParser, 'GENERAL', "GRAPHTRANS", str(gGRAPHTRANS), False))
            gDRAWBLOCKS   =       getSettingsValue(settingsParser, 'GENERAL', "DRAWBLOCKS", gDRAWBLOCKS  , True)
            gDRAWTEXT     =       getSettingsValue(settingsParser, 'GENERAL', "DRAWTEXT", gDRAWTEXT      , True)
            bSHOWMARKER   =       getSettingsValue(settingsParser, 'GENERAL', "MARKER", bSHOWMARKER      , True)
            bMode         =       getSettingsValue(settingsParser, 'GENERAL', "MODE", bMode      , False)
            # gSTEPPING = float( appReadCFGValue(settingsFilePath,  'GENERAL', 'STEPPING', str( gSTEPPING )) )
            # gCOLORMULT= float(   appReadCFGValue(settingsFilePath,   'GENERAL', 'COLORMULT', str(gCOLORMULT)) )
            # if str(appReadCFGValue(settingsFilePath,              'GENERAL', 'TYRELOAD_ENABLED', str( bShowTyreload ) )) == "False":
            #     bShowTyreload = False
    except:
        ac.log("TrackHeight: " + traceback.format_exc())

    ReadAILine()
    btnAPPSIZEplus  = ac.addButton(app, "+")
    btnAPPSIZEminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnAPPSIZEminus, appAPPSIZEminus)
    ac.addOnClickedListener(btnAPPSIZEplus , appAPPSIZEplus)

    btnOPACITYplus  = ac.addButton(app, "+")
    btnOPACITYminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnOPACITYminus, appOPACITYminus)
    ac.addOnClickedListener(btnOPACITYplus , appOPACITYplus)

    btnPREVIEWBACKplus  = ac.addButton(app, "+")
    btnPREVIEWBACKminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnPREVIEWBACKminus, appPREVIEWBACKminus)
    ac.addOnClickedListener(btnPREVIEWBACKplus , appPREVIEWBACKplus)

    btnPREVIEWFORWplus  = ac.addButton(app, "+")
    btnPREVIEWFORWminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnPREVIEWFORWminus, appPREVIEWFORWminus)
    ac.addOnClickedListener(btnPREVIEWFORWplus , appPREVIEWFORWplus)

    btnHEIGHT_MULTplus  = ac.addButton(app, "+")
    btnHEIGHT_MULTminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnHEIGHT_MULTminus, appHEIGHT_MULTminus)
    ac.addOnClickedListener(btnHEIGHT_MULTplus , appHEIGHT_MULTplus)

    btnWIDTH_MULTplus  = ac.addButton(app, "+")
    btnWIDTH_MULTminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnWIDTH_MULTminus, appWIDTH_MULTminus)
    ac.addOnClickedListener(btnWIDTH_MULTplus , appWIDTH_MULTplus)

    btnSTEPPINGplus  = ac.addButton(app, "+")
    btnSTEPPINGminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnSTEPPINGminus, appSTEPPINGminus)
    ac.addOnClickedListener(btnSTEPPINGplus , appSTEPPINGplus)

    btnCOLOR_MULTplus  = ac.addButton(app, "+")
    btnCOLOR_MULTminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnCOLOR_MULTminus, appCOLOR_MULTminus)
    ac.addOnClickedListener(btnCOLOR_MULTplus , appCOLOR_MULTplus)

    btnGRAPHTRANSplus = ac.addButton(app, "+")
    btnGRAPHTRANSminus = ac.addButton(app, "-")
    ac.addOnClickedListener(btnGRAPHTRANSminus, appGRAPHTRANSminus)
    ac.addOnClickedListener(btnGRAPHTRANSplus , appGRAPHTRANSplus)

    btnDRAWBLOCKStoggle  = ac.addButton(app, "+")
    ac.addOnClickedListener(btnDRAWBLOCKStoggle, appDRAWBLOCKStoggle)

    btnDRAWTEXTtoggle = ac.addButton(app, "-")
    ac.addOnClickedListener(btnDRAWTEXTtoggle, appDRAWTEXTtoggle)

    btnSHOWMARKER = ac.addButton(app, "marker")
    ac.addOnClickedListener(btnSHOWMARKER, appMARKERtoggle)

    btnMode = ac.addButton(app, "mode")
    ac.addOnClickedListener(btnMode, appMODEtoggle)

    ac.setPosition(btnAPPSIZEminus      ,   0, -45)
    ac.setPosition(btnAPPSIZEplus       ,  35, -45)
    ac.setPosition(btnOPACITYminus      ,  80, -45)
    ac.setPosition(btnOPACITYplus       , 115, -45)
    ac.setPosition(btnGRAPHTRANSminus   , 170, -45)
    ac.setPosition(btnGRAPHTRANSplus    , 205, -45)
    ac.setPosition(btnPREVIEWBACKminus  , 260, -45)
    ac.setPosition(btnPREVIEWBACKplus   , 295, -45)
    ac.setPosition(btnPREVIEWFORWminus  , 345, -45)
    ac.setPosition(btnPREVIEWFORWplus   , 380, -45)
    ac.setPosition(btnSTEPPINGminus     , 430, -45)
    ac.setPosition(btnSTEPPINGplus      , 465, -45)


    ac.setPosition(btnHEIGHT_MULTminus  ,   0, -100)
    ac.setPosition(btnHEIGHT_MULTplus   ,  35, -100)
    ac.setPosition(btnWIDTH_MULTminus   ,  80, -100)
    ac.setPosition(btnWIDTH_MULTplus    , 115, -100)
    ac.setPosition(btnDRAWTEXTtoggle    , 170, -100)
    ac.setPosition(btnSHOWMARKER        , 225, -100)
    ac.setPosition(btnMode              , 280, -100)
    ac.setPosition(btnDRAWBLOCKStoggle  , 335, -100)
    ac.setPosition(btnCOLOR_MULTminus   , 380, -100)
    ac.setPosition(btnCOLOR_MULTplus    , 415, -100)

    ac.setSize(btnAPPSIZEminus        , 34, 43)
    ac.setSize(btnAPPSIZEplus         , 34, 43)
    ac.setSize(btnOPACITYplus         , 34, 43)
    ac.setSize(btnOPACITYminus        , 34, 43)
    ac.setSize(btnPREVIEWBACKplus     , 34, 43)
    ac.setSize(btnPREVIEWBACKminus    , 34, 43)
    ac.setSize(btnPREVIEWFORWplus     , 34, 43)
    ac.setSize(btnPREVIEWFORWminus    , 34, 43)

    ac.setSize(btnHEIGHT_MULTplus     , 34, 43)
    ac.setSize(btnHEIGHT_MULTminus    , 34, 43)
    ac.setSize(btnWIDTH_MULTplus      , 34, 43)
    ac.setSize(btnWIDTH_MULTminus     , 34, 43)
    ac.setSize(btnDRAWTEXTtoggle      , 44, 43)
    ac.setSize(btnSHOWMARKER          , 44, 43)
    ac.setSize(btnMode                , 44, 43)

    ac.setSize(btnSTEPPINGplus        , 34, 43)
    ac.setSize(btnSTEPPINGminus       , 34, 43)
    ac.setSize(btnCOLOR_MULTplus      , 34, 43)
    ac.setSize(btnCOLOR_MULTminus     , 34, 43)
    ac.setSize(btnGRAPHTRANSplus      , 34, 43)
    ac.setSize(btnGRAPHTRANSminus     , 34, 43)
    ac.setSize(btnDRAWBLOCKStoggle    , 34, 43)

    ac.setBackgroundOpacity(btnAPPSIZEminus        , 0.9)
    ac.setBackgroundOpacity(btnAPPSIZEplus         , 0.9)
    ac.setBackgroundOpacity(btnOPACITYplus         , 0.9)
    ac.setBackgroundOpacity(btnOPACITYminus        , 0.9)
    ac.setBackgroundOpacity(btnPREVIEWBACKplus     , 0.9)
    ac.setBackgroundOpacity(btnPREVIEWBACKminus    , 0.9)
    ac.setBackgroundOpacity(btnPREVIEWFORWplus     , 0.9)
    ac.setBackgroundOpacity(btnPREVIEWFORWminus    , 0.9)
    ac.setBackgroundOpacity(btnHEIGHT_MULTplus     , 0.9)
    ac.setBackgroundOpacity(btnHEIGHT_MULTminus    , 0.9)
    ac.setBackgroundOpacity(btnWIDTH_MULTplus      , 0.9)
    ac.setBackgroundOpacity(btnWIDTH_MULTminus     , 0.9)
    ac.setBackgroundOpacity(btnSTEPPINGplus        , 0.9)
    ac.setBackgroundOpacity(btnSTEPPINGminus       , 0.9)
    ac.setBackgroundOpacity(btnCOLOR_MULTplus      , 0.9)
    ac.setBackgroundOpacity(btnCOLOR_MULTminus     , 0.9)
    ac.setBackgroundOpacity(btnGRAPHTRANSplus      , 0.9)
    ac.setBackgroundOpacity(btnGRAPHTRANSminus     , 0.9)
    ac.setBackgroundOpacity(btnDRAWBLOCKStoggle    , 0.9)
    ac.setBackgroundOpacity(btnDRAWTEXTtoggle      , 0.9)
    ac.setBackgroundOpacity(btnSHOWMARKER          , 0.9)
    ac.setBackgroundOpacity(btnMode          , 0.9)

    on_click_app_window(0,0)
    hideTimer        = 0.1
    return "TrackHeight"

def appHideControls():
    global btnAPPSIZEplus, btnAPPSIZEminus, btnOPACITYplus, btnOPACITYminus, btnPREVIEWBACKplus, btnPREVIEWBACKminus, btnPREVIEWFORWplus, btnPREVIEWFORWminus, btnCOLOR_MULTminus, btnCOLOR_MULTplus, btnGRAPHTRANSplus, btnGRAPHTRANSminus
    global btnHEIGHT_MULTplus, btnHEIGHT_MULTminus, btnWIDTH_MULTplus, btnWIDTH_MULTminus, btnSTEPPINGplus, btnSTEPPINGminus, btnDRAWBLOCKStoggle, btnDRAWTEXTtoggle, label, btnSHOWMARKER
    global label, btnMode, btnSHOWMARKER
    ac.setIconPosition(app, 0, -20000)
    if not gDRAWTEXT:
        ac.setVisible(label,0)
    ac.setSize(label, gW-1-gPREVIEWBACK, 25*gAPPSIZE)

    ac.setVisible(btnAPPSIZEplus      , 0)
    ac.setVisible(btnAPPSIZEminus     , 0)
    ac.setVisible(btnOPACITYminus     , 0)
    ac.setVisible(btnOPACITYplus      , 0)
    ac.setVisible(btnPREVIEWBACKminus , 0)
    ac.setVisible(btnPREVIEWBACKplus  , 0)
    ac.setVisible(btnPREVIEWFORWminus , 0)
    ac.setVisible(btnPREVIEWFORWplus  , 0)
    ac.setVisible(btnHEIGHT_MULTminus , 0)
    ac.setVisible(btnHEIGHT_MULTplus  , 0)
    ac.setVisible(btnWIDTH_MULTminus  , 0)
    ac.setVisible(btnWIDTH_MULTplus   , 0)
    ac.setVisible(btnSTEPPINGminus    , 0)
    ac.setVisible(btnSTEPPINGplus     , 0)
    ac.setVisible(btnCOLOR_MULTminus  , 0)
    ac.setVisible(btnCOLOR_MULTplus   , 0)
    ac.setVisible(btnGRAPHTRANSminus  , 0)
    ac.setVisible(btnGRAPHTRANSplus   , 0)
    ac.setVisible(btnDRAWBLOCKStoggle , 0)
    ac.setVisible(btnDRAWTEXTtoggle   , 0)
    ac.setVisible(btnSHOWMARKER       , 0)
    ac.setVisible(btnMode             , 0)


def acShutdown(*args):
    global gAPPSIZE, gOPACITY, gPREVIEWBACK, gPREVIEWFORW, gHEIGHT_MULT, gWIDTH_MULT, gSTEPPING, gCOLORMULT, gDRAWBLOCKS, gDRAWTEXT, gGRAPHTRANS, bSHOWMARKER, bMode
    global bCSPActive, rtIndex0
    if bCSPActive and rtIndex0>-1:
        ac.ext_disposeRenderTarget(rtIndex0)
    settingsFilePath = "apps/python/TrackHeight/settings/settings.ini"
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'APPSIZE'    , str(round(gAPPSIZE, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'OPACITY'    , str(round(gOPACITY, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'PREVIEWBACK',       str(gPREVIEWBACK),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'PREVIEWFORW',       str(gPREVIEWFORW),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'HEIGHT_MULT', str(round(gHEIGHT_MULT, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'WIDTH_MULT' , str(round(gWIDTH_MULT, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'STEPPING'   ,       str(gSTEPPING),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'COLORMULT'  , str(  int(gCOLORMULT)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'GRAPHTRANS' , str(round(gGRAPHTRANS, 1)),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'DRAWBLOCKS' ,       str(gDRAWBLOCKS),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'DRAWTEXT'   ,       str(gDRAWTEXT),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'MARKER'     ,       str(bSHOWMARKER),True)
    appWriteCFGValue(settingsFilePath, 'GENERAL', 'MODE'       ,       str(bMode),True)
    return

#######################################################

def appDrawLine(x1,y1,x2,y2,width=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x2-width/2,y2)
    ac.glVertex2f(x1        ,y1)
    ac.glVertex2f(x1+width/2,y1)
    ac.glVertex2f(x2        ,y2)
    ac.glEnd()

def appDrawLine3(x1,y1,x2,y2,height=4):
    ac.glBegin(acsys.GL.Quads)
    if y2-height/2<y1:
        #ac.log("A")
        ac.glVertex2f(x1,y1         )
        ac.glVertex2f(x2,y2-height/2)
        ac.glVertex2f(x2,y2         )
        ac.glVertex2f(x1,y1+height/2)
    else:
        #ac.log("B")
        ac.glVertex2f(x1,y2-height/2)
        ac.glVertex2f(x2,y1         )
        ac.glVertex2f(x2,y1+height/2)
        ac.glVertex2f(x1,y2         )
    ac.glEnd()

def appDrawLine4(x1,y1,x2,y2):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x1,y2)
    ac.glVertex2f(x2,y2)
    ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawLine5(x1,y1,x2,y2,y3):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x1,y3)
    ac.glVertex2f(x2,y2)
    ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawLine0(r,g,b,a,x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Quads)
  ac.glColor4f(r,g,b,a)
  ac.glVertex2f(x1,y2-width/2)
  ac.glVertex2f(x2,y1-width/2)
  ac.glVertex2f(x2,y1)
  ac.glVertex2f(x1,y2)
  ac.glEnd()

def appDrawLine00(x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Quads)
  ac.glVertex2f(x1,y2-width/2)
  ac.glVertex2f(x2,y1-width/2)
  ac.glVertex2f(x2,y1)
  ac.glVertex2f(x1,y2)
  ac.glEnd()

def appDrawLineA(r,g,b,a,x1,y1,x2,y2,width=1):
  w=width/2
  if y1==y2:
    appDrawLine0(r,g,b,a,x1,y1,x2,y2,width)
  else:
    ac.glBegin(acsys.GL.Quads)
    ac.glColor4f(r,g,b,a)
    if y2<y1:
      ac.glVertex2f(x1-w,y1-w)
      ac.glVertex2f(x2-w,y2-w)
      ac.glVertex2f(x2+w,y2+w)
      ac.glVertex2f(x1+w,y1+w)
    else:
      ac.glVertex2f(x1-w,y1-w)
      ac.glVertex2f(x2-w,y2-w)
      ac.glVertex2f(x2+w,y2+w)
      ac.glVertex2f(x1+w,y1+w)
    ac.glEnd()

def appDrawLineQuad1(x1,y1,x2,y2,width=1):
  w=width/2
  if y1==y2:
    appDrawLine00(x1,y1,x2,y2,width)
  else:
    ac.glBegin(acsys.GL.Quads)
    if y2<y1:
      ac.glVertex2f(x1-w,y1-w)
      ac.glVertex2f(x2-w,y2-w)
      ac.glVertex2f(x2+w,y2+w)
      ac.glVertex2f(x1+w,y1+w)
    else:
      ac.glVertex2f(x1-w,y1-w)
      ac.glVertex2f(x2-w,y2-w)
      ac.glVertex2f(x2+w,y2+w)
      ac.glVertex2f(x1+w,y1+w)
    ac.glEnd()

def appDrawLineLEB0(x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Lines)
  ac.glVertex2f(    x1     , y1)
  ac.glVertex2f(    x2     , y2)
  for i in range(1,int(width)):
    ac.glVertex2f(  x1, y1+i)
    ac.glVertex2f(  x2, y2+i)
  ac.glEnd()

def appDrawLineLEB1(x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Lines)
  ac.glVertex2f(    x1     , y1)
  ac.glVertex2f(    x2     , y2)
  for i in range(1,int(width)):
    ac.glVertex2f(  x1+i, y1)
    ac.glVertex2f(  x2+i, y2)
  ac.glEnd()

def appDrawLineCalced(x1,y1,x2,y2, width=2):
    if y1==y2:
        appDrawLineLEB0(x1,y1,x2,y2,width)
    elif x1==x2:
        appDrawLineLEB1(x1,y1,x2,y2,width)
    else:
        direction = ( -math.degrees( math.atan2(y1 - y2, x2 - x1)))
        dx1 = math.cos((-direction + 90) * math.pi / 180) * width*0.5
        dy1 = math.sin((-direction + 90) * math.pi / 180) * width*0.5
        dx2 = math.cos((-direction - 90) * math.pi / 180) * width*0.5
        dy2 = math.sin((-direction - 90) * math.pi / 180) * width*0.5
        ac.glBegin(acsys.GL.Quads)
        ac.glVertex2f(x2-dx2, y2+dy2)
        ac.glVertex2f(x1+dx1, y1-dy1)
        ac.glVertex2f(x1-dx1, y1+dy1)
        ac.glVertex2f(x2+dx2, y2-dy2)
        ac.glEnd()


def appDrawText(t, r, g, b, a, x, y, sz):
    global f1
    ac.ext_glFontColor(f1.f, r, g, b, a)
    ac.ext_glFontUse(f1.f, t, x, y, sz, ExtGL.FONT_ALIGN_LEFT)

def appDrawTextShadow(t, a, x, y, sz):
    global f1
    ac.ext_glFontColor(f1.f, 0, 0, 0, a)
    ac.ext_glFontUse(f1.f, t, x, y, sz, ExtGL.FONT_ALIGN_LEFT)

def clamp(n, minn, maxn):
    if n < minn:
        return minn
    elif n > maxn:
        return maxn
    else:
        return n

def distance(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2 )

def distance2d(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 )

bClosedTrack = False

def ReadAILine():
    global sFileCameras, sTrack, sLayout, AI_LINE, AI_LINE_LENGTH, AI_LINE_dM, AI_LINE_rgb, gCOLORMULT
    global minz, maxz, bClosedTrack

    sFileAI     = 'content/tracks/' + sTrack+            '/ai/fast_lane.ai'
    if sLayout!='':
        sFileAI = 'content/tracks/' + sTrack+'/'+sLayout+'/ai/fast_lane.ai'
    if not os.path.isfile(sFileAI) or os.path.getsize(sFileAI)<=24:
        ac.log('No "fast_lane.ai" found')
        return
    try:
        with open(sFileAI, "rb") as buffer:
            # should be at start, but do it anyway
            buffer.seek(0)
            # read header, detailCount is number of data points available
            header, detailCount, u1, u2 = struct.unpack("4i", buffer.read(4 * 4))

            data_ideal   = []
            data_detail  = []
            AI_LINE      = []
            AI_LINE_rgb  = []
            AI_LINE_dM   = []
            AI_LINE_LENGTH = 0.0

            # read ideal-line data
            for i in range(detailCount):       # 4 floats, one integer
                data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
                x , z , y, dist, id = data_ideal[i]
                coordscurr = ( float(x), -float(y), float(z)  )
                if i>0:
                    AI_LINE_LENGTH += distance( coordscurr, coordslast )
                coordslast = coordscurr

            # read more details data
            for i in range(detailCount):        # 18 floats
                data_detail.append(struct.unpack("18f", buffer.read(4 * 18)))

            xl, zl, yl, distl, idl = data_ideal[len(data_ideal)-1] # last point
            ldM = 0.0
            for i in range(len(data_ideal)):
                x, z, y, dist, id = data_ideal[i]
                coordsAI = [ float(x), -float(y), float(z)  ]
                if z<minz:
                    minz=z
                if z>maxz:
                    maxz=z

                # slope at this point
                xa = distl - dist
                xb = zl - z
                if xa!=0.0:
                    #dM = xb / xa * gCOLORMULT
                    #dM = - clamp( xb / xa *0.5, -90, 90)
                    #dM = - clamp( xb / xa *0.625, -90, 90)
                    dM = - clamp( xb / xa *1, -90, 90)
                else:
                    dM = 0.0
                # dM = -math.degrees(math.atan(xb/xa))
                #ldM = dM
                ldM = (ldM + dM) / 2.0  # do small interpolation
                r=0.65  #=1.0
                g=0.65  #=1.0
                b=0.65  #=1.0
                if abs(ldM) > 0.005:
                    if dM>0.0:
                        r=0.5-abs(ldM* gCOLORMULT)
                        g=0.5+abs(ldM* gCOLORMULT)
                        if gCOLORMULT==0:
                            r=0.5+abs(ldM)
                            g=r
                        b=r
                    else:
                        r=0.5+abs(ldM* gCOLORMULT)
                        g=0.5-abs(ldM* gCOLORMULT)
                        if gCOLORMULT==0:
                            r=0.5-abs(ldM)
                            g=r
                        b=g
                color1=[r, g, b]

                AI_LINE_dM.append(dM)      # Slope in percent
                AI_LINE_rgb.append(color1) # color for this amount of slope
                AI_LINE.append(coordsAI)

                yl = y
                xl = x
                zl = z
                distl = dist

            # is closed track?
            bClosedTrack = False
            if distance(AI_LINE[len(AI_LINE)-1], AI_LINE[0]) < 20.0:
                bClosedTrack = True

            ##for i in range(len(AI_LINE)):
            ##    AI_LINE[i][2] = AI_LINE[i][2]/(maxz-minz)*50

        # ac.log(str(AI_LINE_LENGTH) + ' - ' + str(len(AI_LINE)))
    except:
        data_ideal   = []
        data_detail  = []
        AI_LINE      = []
        ac.log("TrackHeight error: " + traceback.format_exc())

###############################################################################

lastgW=0
lastgH=0

def CreateFullMap():
    if bCSPActive:
        ac.ext_bindRenderTarget(rtIndex0)
        ac.ext_clearRenderTarget(rtIndex0)
    for ix in range(gW):
        AIid = int(ix/gW * len(AI_LINE))
        # iy   = - (AI_LINE[AIid][2]-minz) / (maxz-minz) * gH +
        iy   = gH - (AI_LINE[AIid][2]-minz) / (maxz-minz) * gH - gH/2
        ac.glColor4f(AI_LINE_rgb[AIid][0], AI_LINE_rgb[AIid][1], AI_LINE_rgb[AIid][2],gGRAPHTRANS)
        if gDRAWBLOCKS:
            appDrawLine( marginW+ix          , marginH+    ailineYOFFSET*2        , marginW+ix+gSTEPPING, marginH+iy+ailineYOFFSET           , 1)
        else:
            appDrawLine3(marginW+ix+gSTEPPING, marginH+iy+ailineYOFFSET+4*gAPPSIZE, marginW+ix          , marginH+iy+ailineYOFFSET+4*gAPPSIZE, 8*gAPPSIZE)
    if bCSPActive:
        ### restores original render target to continue drawing app to
        ac.ext_restoreRenderTarget()
        ac.ext_generateMips(rtIndex0)

def appMODEtoggle(*args):
    global bMode, rtIndex0
    bMode= not bMode
    if bMode and rtIndex0>0:
        CreateFullMap()
    on_click_app_window(0,0)


### update all variables on buttons, set app window size +++
def on_click_app_window(arg1, arg2):
    global app, bHideTimerOn, hideTimer, gCOLORMULT
    global btnAPPSIZEplus, btnAPPSIZEminus, btnOPACITYplus, btnOPACITYminus, btnPREVIEWBACKplus, btnPREVIEWBACKminus, btnPREVIEWFORWplus
    global btnPREVIEWFORWminus, btnCOLOR_MULTminus, btnCOLOR_MULTplus, btnGRAPHTRANSplus, btnGRAPHTRANSminus
    global btnHEIGHT_MULTplus, btnHEIGHT_MULTminus, btnWIDTH_MULTplus, btnWIDTH_MULTminus, btnSTEPPINGplus, btnSTEPPINGminus, btnDRAWBLOCKStoggle, btnDRAWTEXTtoggle, ailineYOFFSET, btnSHOWMARKER
    global gPREVIEWBACK, gPREVIEWFORW, gAPPSIZE, gWIDTH_MULT, bSHOWMARKER, btnMode
    global gW, gH, label, rtIndex0, bCSPActive, marginW, marginH
    global lastgW, lastgH
    bHideTimerOn = True
    hideTimer = 5.0
    ac.setIconPosition(app, -50, 0)
    gW = int((gPREVIEWBACK + gPREVIEWFORW) * gAPPSIZE*gWIDTH_MULT)
    gH = int(100*gAPPSIZE*gHEIGHT_MULT)
    ac.setSize(app, gW, gH)
    fntsize = 12 * gAPPSIZE
    ailineYOFFSET = gH/2
    marginW=0
    marginH=0
    if bCSPActive:
        marginW=gW
        marginH=gH
        if ( (lastgW!=gW or lastgH!=gH) or rtIndex0==0):
            lastgW=gW
            lastgH=gH
            if rtIndex0>0:
                ac.ext_disposeRenderTarget(rtIndex0)
                rtIndex0=0
            rtIndex0 = ac.ext_createRenderTarget(gW*3, gH*3, False)
            if bMode and rtIndex0:
                CreateFullMap()

    ac.setPosition(label, 1+gPREVIEWBACK, gH)
    ac.setSize(label, gW-1-gPREVIEWBACK, 50*gAPPSIZE)

    ac.setBackgroundOpacity(label, gOPACITY)
    ac.setFontSize(label, 16*gAPPSIZE)
    ac.setVisible(label, 1)

    ac.setVisible(btnAPPSIZEminus     ,1)
    ac.setVisible(btnAPPSIZEplus      ,1)
    ac.setVisible(btnOPACITYminus     ,1)
    ac.setVisible(btnOPACITYplus      ,1)
    ac.setVisible(btnHEIGHT_MULTminus ,1)
    ac.setVisible(btnHEIGHT_MULTplus  ,1)
    ac.setVisible(btnWIDTH_MULTminus  ,1)
    ac.setVisible(btnWIDTH_MULTplus   ,1)
    ac.setVisible(btnCOLOR_MULTminus  ,1)
    ac.setVisible(btnCOLOR_MULTplus   ,1)
    ac.setVisible(btnGRAPHTRANSplus   ,1)
    ac.setVisible(btnGRAPHTRANSminus  ,1)
    ac.setVisible(btnDRAWTEXTtoggle   ,1)
    ac.setVisible(btnSHOWMARKER       ,1)
    ac.setVisible(btnMode             ,1)
    ac.setVisible(btnDRAWBLOCKStoggle ,1)
    if not bMode:
        ac.setVisible(btnPREVIEWBACKminus ,1)
        ac.setVisible(btnPREVIEWBACKplus  ,1)
        ac.setVisible(btnPREVIEWFORWminus ,1)
        ac.setVisible(btnPREVIEWFORWplus  ,1)
        ac.setVisible(btnSTEPPINGminus    ,1)
        ac.setVisible(btnSTEPPINGplus     ,1)
    else:
        ac.setVisible(btnPREVIEWBACKminus ,0)
        ac.setVisible(btnPREVIEWBACKplus  ,0)
        ac.setVisible(btnPREVIEWFORWminus ,0)
        ac.setVisible(btnPREVIEWFORWplus  ,0)
        ac.setVisible(btnSTEPPINGminus    ,0)
        ac.setVisible(btnSTEPPINGplus     ,0)

    ac.setText(btnAPPSIZEminus    ,    '-\n    size ' + str(round(gAPPSIZE, 1)))
    ac.setText(btnOPACITYminus    ,    '-\n  bg '+ str(round(gOPACITY,1)))
    ac.setText(btnPREVIEWBACKminus,    '-\n   back '+ str(gPREVIEWBACK))
    ac.setText(btnPREVIEWFORWminus,    '-\n    forw '+ str(gPREVIEWFORW))
    ac.setText(btnHEIGHT_MULTminus,    '-\n      hMul '+ str(round(gHEIGHT_MULT,1)))
    ac.setText(btnWIDTH_MULTminus ,    '-\n      wdth '+ str(round(gWIDTH_MULT,1)))
    ac.setText(btnSTEPPINGminus   ,    '-\n      step '+ str(gSTEPPING))
    ac.setText(btnCOLOR_MULTminus ,    '-\n    col '+ str(int(gCOLORMULT)))
    ac.setText(btnGRAPHTRANSminus ,    '-\n    fg '+ str(round(gGRAPHTRANS,1)))
    ac.setText(btnDRAWBLOCKStoggle, 'fill\n'+ str(gDRAWBLOCKS))
    ac.setText(btnDRAWTEXTtoggle  , 'text\n'+ str(gDRAWTEXT))
    ac.setText(btnSHOWMARKER      , 'marker\n'+ str(bSHOWMARKER))
    if bMode:
        ac.setText(btnMode            , 'mode\n'+ 'full')
    else:
        ac.setText(btnMode            , 'mode\n'+ 'zoomed')


def appGetBaseTrackHeight():
    global sTrack
    settingsParser = None
    if os.path.isfile("apps/python/TrackHeight/base_altitudes.ini"):
        settingsParser = configparser.ConfigParser()
        settingsParser.optionxform = str
        settingsParser.read("apps/python/TrackHeight/base_altitudes.ini")
        return float(getSetting(settingsParser, settingsParser, 'TRACKS_ALTITUDES', sTrack.lower(), 0.0))
    return 0.0

def appSetBaseTrackHeight(newheight):
    global sTrack
    settingsParser = None
    basefile = "apps/python/TrackHeight/base_altitudes.ini"
    if os.path.isfile(basefile):
        settingsParser = configparser.ConfigParser()
        settingsParser.optionxform = str
        settingsParser.read(basefile)
        orig = float(getSetting(settingsParser, settingsParser, 'TRACKS_ALTITUDES', sTrack.lower(), "0.0"))
        if newheight!=orig:
            settingsParser['TRACKS_ALTITUDES'][sTrack] = str(newheight)
            with open(basefile, 'w') as configfile:
                settingsParser.write(configfile, space_around_delimiters=False)


def acUpdate(deltaT):
    global error, timer, appMsg, label, timerMsg, btimerMsg, app
    global tick_counter, max_tick, frame_counter, frame_buffer, time_elapsed, current_fps, MAX_fps, MIN_fps, MAX_lights, MIN_lights
    global odd, lx, ly, lz, lastFrom, sVer, currentSector, sCamCoords, sOrientationFORW, checkpointC, bDetailed, sOrientationFORWtimeattack
    global previousSector, sOVERLAYS_INI, sFileOverlay, bWrittenOverlaysINI, bRecordTimeAttack, iCheckpointHeight, bWrittenCamerasINI, bRecordCameras, sFileCameras
    global lastPoT, currCar, currPoT
    global lastAltitude, currAltitude, bHideTimerOn, hideTimer, gOPACITY
    global minz, maxz, basealtitude, AI_LINE
    global bCSPActive, rtIndex0, gWIDTH_MULT, gHEIGHT_MULT, gAPPSIZE, gW, gH

    try:
        timer += deltaT
        if bHideTimerOn:
            hideTimer -= deltaT
            if hideTimer <= 0.0:
                bHideTimerOn = False
                appHideControls()
        if basealtitude==-100000000:
            if bCSPActive:
                basealtitude = ac.ext_getBaseAltitude(0)
                #ac.log('TrackHeight: Base Altitude    ' + sTrack + '=' + str(round(basealtitude,1)))
                appSetBaseTrackHeight(round(basealtitude,1))
            else:
                basealtitude = appGetBaseTrackHeight()

        if timer > 0.10:
            timer = 0.0
            currPoT = ac.getCarState(ac.getFocusedCar(), acsys.CS.NormalizedSplinePosition)
            try:
                ac.setBackgroundOpacity(app, gOPACITY)
                ac.drawBorder(app, 0)
                if bCSPActive:
                    lastAltitude = currAltitude
                    currAltitude = ac.ext_getAltitude(0) ### - basealtitude # + basealtitude  minz

                    if rtIndex0==0:
                        rtIndex0 = ac.ext_createRenderTarget(gW*3, gH*3, False)

                    ### start drawing into render target, not on screen
                    RenderHeightMap(deltaT)
                    ### restores original render target to continue drawing app to
                else:
                    currAltitude = basealtitude + AI_LINE[int(currPoT * len(AI_LINE))][2]
            except:
                if error<10:
                    error+=1
                ac.setTitle(app, "no fast_lane.ai \nor\ncsp not active")
                ac.log("TrackHeight error: " + traceback.format_exc())
    except:
        ac.log("TrackHeight error: " + traceback.format_exc())

###############################################################################

def onFormRender(deltaT):
    global bCSPActive, rtIndex0, gW, gH, ix, iy, carPitchSin
    if bCSPActive and rtIndex0>0:
        ### blend painted image on app window
        # ac.ext_glSetBlendMode(1)
        ac.glColor4f(1,1,1,1)
        ac.glBegin(acsys.GL.Quads)
        ac.ext_glSetTexture(rtIndex0, 0)
        ac.ext_glVertexTex(-gW  , -gH  , 0, 0)
        ac.ext_glVertexTex(-gW  ,  gH*2, 0, 1)
        ac.ext_glVertexTex( gW*2,  gH*2, 1, 1)
        ac.ext_glVertexTex( gW*2, -gH  , 1, 0)
        ac.glEnd()
    else:
        RenderHeightMap(deltaT)
    crossmult=15*gAPPSIZE
    ac.glColor4f(0,0,0,0.75*gGRAPHTRANS)
    appDrawLineCalced(ix-crossmult               , iy-crossmult*carPitchSin   , ix+crossmult               , iy+crossmult*carPitchSin, 5)
    appDrawLineCalced(ix-crossmult*carPitchSin   , iy+crossmult               , ix+crossmult*carPitchSin   , iy-crossmult            , 5)
    ac.glColor4f(1,1,1,gGRAPHTRANS)
    appDrawLineCalced(ix-crossmult               , iy-crossmult*carPitchSin   , ix+crossmult               , iy+crossmult*carPitchSin, 3)
    appDrawLineCalced(ix-crossmult*carPitchSin   , iy+crossmult               , ix+crossmult*carPitchSin   , iy-crossmult            , 3)


def appDrawLineQuad0(x1,y1,x2,y2,width=4):
    #ac.glBegin(acsys.GL.Triangles)
    ac.glBegin(acsys.GL.Quads)
    if x1>x2:
        ac.glVertex2f(x1,y1+1)
        ac.glVertex2f(x1,y1-1)
        ac.glVertex2f(x2,y2-width/2)
        ac.glVertex2f(x2,y2+width/2)
    else:
        ac.glVertex2f(x2,y2-width/2)
        ac.glVertex2f(x1,y1-1)
        ac.glVertex2f(x1,y1+1)
        ac.glVertex2f(x2,y2+width/2)
    ac.glEnd()


def RenderHeightMap(deltaT):
    global error, bHideTimerOn, gDRAWTEXT, gDRAWBLOCKS, lastAltitude, currAltitude, AI_LINE_LENGTH, AI_LINE, bSHOWMARKER
    global ailineYOFFSET
    global gPREVIEWBACK, gPREVIEWFORW, gHEIGHT_MULT, gSTEPPING, gCOLORMULT, gAPPSIZE, gGRAPHTRANS
    global minz, maxz, basealtitude, AI_LINE_rgb
    global currPoT, gH, gW, bCSPActive, fntsize, marginW, marginH, ix, iy, carPitchSin
    ### dummy drawing text or sometimes drawing fails , wtf?
    # if bCSPActive:
    #     appDrawText('.', 1,1,1,1,0,0, 0.01)

    if len(AI_LINE)>0:
        lix=0
        liy=0
        currAIid = int( len(AI_LINE) * currPoT )
        currAIid = currAIid - (currAIid % gSTEPPING) ### always pick same intervals
        #ac.console(str(currAIid))
        #ac.console(str(len(AI_LINE)))
        if currAIid>=len(AI_LINE):
            currAIid = len(AI_LINE)-1
        #if bClosedTrack and AIid>gPREVIEWBACK:
        AIid = currAIid - gPREVIEWBACK
        #else:
        #    AIid = 0
        if AIid<0 and bClosedTrack:
            AIid = len(AI_LINE)-1 + AIid

        i1=1
        i2=(gPREVIEWBACK + gPREVIEWFORW) * gWIDTH_MULT * gAPPSIZE

        if not bMode:
            if bCSPActive:
                ac.ext_bindRenderTarget(rtIndex0)
                ac.ext_clearRenderTarget(rtIndex0)
            YOFFSET = - AI_LINE[currAIid][2]*2
            # draw the height profile
            while i1 < i2:
                ix = i1
                iy = - AI_LINE[AIid][2]*2 - YOFFSET
                if i1>1:
                    if (AIid>gPREVIEWBACK/100 and not bClosedTrack and AIid<len(AI_LINE)) or bClosedTrack:
                        if AIid % (gSTEPPING) == 0:
                            # now actually draw one part
                            ac.glColor4f(AI_LINE_rgb[AIid][0], AI_LINE_rgb[AIid][1], AI_LINE_rgb[AIid][2],gGRAPHTRANS)
                            if gDRAWBLOCKS:
                                appDrawLine( marginW+ix          , marginH+    ailineYOFFSET*2         , marginW+ ix+gSTEPPING, marginH+iy+ailineYOFFSET           , gSTEPPING*2)
                            else:
                                appDrawLine3(marginW+ix+gSTEPPING, marginH+liy+ailineYOFFSET+4*gAPPSIZE, marginW+lix          , marginH+iy+ailineYOFFSET+4*gAPPSIZE, 8*gAPPSIZE)
                lix = ix
                liy = iy-4

                i1 += 1 # HEIGHT_steps
                AIid += 1 # HEIGHT_steps
                if AIid>=len(AI_LINE):
                    if not bClosedTrack:
                        break
                    AIid = 0

            if bCSPActive:
                ac.ext_restoreRenderTarget()
        else:
            if not bCSPActive:
                CreateFullMap()

        ### testing lines
        # ac.glColor4f(0,0,0,0.9)
        # appDrawLine( 0, 0, gW, gH, 10)
        # ac.glColor4f(1,1,1,0.9)
        # appDrawLine( gW, gH, gW*2, gH*2, 10)
        # ac.glColor4f(0,0,0,0.9)
        # appDrawLine( gW*2, gH*2, gW*3, gH*3, 10)


        carPitch=AI_LINE_dM[currAIid]
        carPitchSin=AI_LINE_dM[currAIid]*3
        # position marker
        if bSHOWMARKER:
            if bMode:
                ix = currAIid/len(AI_LINE)*gW
                iy = gH - (AI_LINE[currAIid][2]-minz) / (maxz-minz) * gH
            else:
                ix = gPREVIEWBACK
                iy = - AI_LINE[currAIid][2]*2 -YOFFSET + ailineYOFFSET

        # text over all if done
        sAdd=''
        if -carPitch>=0.0:
            sAdd = ( ' +' + str( round(-math.degrees(carPitch), 1) ) + '°  |  +'
                          + str( round(-math.tan(carPitch)*100,1)) + '%' + '  |  '
                          + str( round(currAltitude, 1)) + 'm\n')
        else:
            sAdd = ( ' '  + str( round(-math.degrees(carPitch), 1) ) + '°  |  '
                          + str( round(-math.tan(carPitch)*100,1)) + '%' + '  |  '
                          + str( round(currAltitude, 1)) + 'm\n')
        if bHideTimerOn:
            sAdd = sAdd + ('\n  lowest/highest point: '
                          + str(round(minz+basealtitude,1)) + '/'
                          + str(round(maxz+basealtitude,1)) + 'm ('
                          + str(round(maxz-minz,1)) + 'm)\n')

        ac.setText(label, (sAdd).replace('\n\n','\n').strip()
                #    +
                #    '\n' + str(round(AI_LINE[currAIid][2]-minz,1))+
                #    '\n' + str(round(currAltitude,1))+
                #    '\n' + str(round(minz,1)) +
                #    '\n' + str(round(maxz,1))
                   )
