-- JumpAIline by leBluem


-- textures use, first one is the original texture from "..content\textures\"
local TexturesAILine = {}
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/content/texture/ideal_line.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_mono.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_mono_slim.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_mono_slim_tiny.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_5.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_6.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_7.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_8.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_9.png')
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_10.png')

local trackMeshes --@ac.SceneReference
local carMeshes --@ac.SceneReference
trackMeshes = ac.findNodes('trackRoot:yes'):findMeshes("?")
carMeshes = ac.findNodes('carsRoot:yes'):findMeshes("?")
--local ACideal = ac.findMeshes("materials:IDEAL_LINE")
--local ACideal = ac.findMeshes("NONAME")
--local ACideal = basenode:findMeshes("materials:ksIdealLine"):setMaterialProperty('ksEmissive', 50)
--ac.debug("number of meshes" , #ACideal)


ac.setWindowTitle('main', tostring(#trackMeshes).." track  /  " ..tostring(#carMeshes).." car objs" ..
" - JumpAILine v2.52")

--v2.52 - 11 dec 2024
--sorry for fast update AGAIN
--fixed single color AI line still getting brighter in corners
--
--v2.51 - 11 dec 2024
--sorry for fast update
--added key/button binds for new features
--fixed not being pushed when using key-binds, push was already there when using ui buttons
--
--v2.5 - 11 dec 2024
--fixed arrangement of some ui parts
--fixed AI line not shrinked to road in tunnels
--added option to draw AI line with a single color
--added option to offset AI yellow/red coloring, from 0.5 to 5.0 (50 to 500 percent)
--adjusted lowest glowmult brightness to be same as AC ai-line
--added "MEM" and "jump MEM" buttons,
----"MEM" saves your current car position and direction
----"jump MEM" jumps to saved car position and sets same direction (be careful on another track :) )
--
--v2.4 - 12 nov 2024
-- fixed loading next/prev option, thx @Damgam!
--
--v2.3 - 23 oct 2024
-- fixed loading some options, thx @Skuby!
-- fixed messed up section names (ie on Brands Hatch Indy)
-- added option to hide sections reload button
--
--v2.2 - 11 oct 2024
-- Kindly added by ___@Damgam___, thank you very much!
-- --added smoothly fading colors to dynamic ai line
-- added 6 more ai line graphics
-- added option to skip parts in ai line
--
--v2.1 - 1 sept 2024
-- small fix to make border/ideal buttons work when game is paused
--
--v2.0 - 30 aug 2024
-- fixed glow with/without LCS
-- re-added FFB silencing before jumps
-- added option to change ai border color
--
--v1.9 - 11 july 2024
-- fixed prev/next sections display
--
--v1.8 - 3 july 2024
-- fixed bugs
--
--v1.7 - 2 july 2024
-- fixed silly "#" mistakes
--
--v1.6 - 1 july 2024
-- dynamic ideal line now also working with CSP 0.2.3
-- added drawing ideal/border a bit backwards too
-- removed ffb thing as it would reset your ffb to 0 in some cases
--
--v1.5 - 25 june 2024
-- fixed last fix not fixing what it should have fixed
--
--v1.4 - 21 june 2024
-- border/ideal being available too in all other modes than practice/hotlap
--
--v1.3 - 12 june 2024
-- added AI line rendering with dynamic yellow/red parts, 4 different ideal graphics available
-- reload button for "sections.ini"
-- added dropdown for Section-names
-- added PointOfTrack (PoT) display to km's, click to copy value
-- added fontsize/color/glow mult/buttons as options
--
--v1.2 - 30 april 2024
-- fixed folder missing for the app in ..ac\apps\lua\
-- FFB is turned off when jumping
--
--v1.1 - 28 april 2024
-- AI borders are projected to ground
-- added control mapping for ai borders, rendered length has a slider now
-- made km/sections optional
--
--v1.0 - 26 april 2024
-- initial version


local function readACConfig(ini, sec, key, def)
    local inifile = ac.INIConfig.load(ini)
    return inifile:get(sec, key, def)
end

local function writeACConfig(ini, sec, key, val)
    local inifile = ac.INIConfig.load(ini)
    inifile:set(sec, key, val)
    inifile:save(ini)
end



-- --   clone meshes test not working :(  -- --
-- local carMeshes ---@ac.SceneReference
-- local newMesh ---@ac.SceneReference
-- carMeshes = ac.findNodes('carsRoot:yes'):findMeshes("estprelude_doorglass_L")
-- if carMeshes then
--     local vertices = carMeshes:getVertices() -- getVertices()
--     --local indices = carMeshes:getVertices():
--     ac.debug("vertices", vertices)
--     if vertices then
--         newMesh = carMeshes:clone() -- :createMesh("newglass", carMeshes:materialName(1), vertices, , true, true )
--         if newMesh then
--             ac.debug("newMesh", newMesh)
--             newMesh:setPosition(newMesh:getPosition() + axisZ*0.5 )  --alterVertices()
--         end
--     end
-- end




local BLeft={}
local BRight={}
local BDir={}
local BIdealL={}
local BIdealR={}
local BGas={}
local BBrake={}
local Sects = {}



local sTrack = string.lower( ac.getTrackID() )
local sCar = string.lower( ac.getCarID(0) )
local sLayout = string.lower( ac.getTrackLayout() )
local sectINI = ""
local appini = 'apps/lua/JumpAILine/JumpAILine.ini'
local vidini = ac.getFolder('ac.FolderID.Cfg')..'/video.ini'
local acini = ac.getFolder('ac.FolderID.Root')..'/system/cfg/assetto_corsa.ini'

-- local aiFolder = ac.getFolder(ac.FolderID.CurrentTrackLayout)..'\\ai\\'
local aiFolder = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackFullID("\\") .. "\\ai\\"
local dataFolder = ac.getFolder(ac.FolderID.CurrentTrackLayout)..'\\data\\'
local splineFilename = aiFolder..'fast_lane.ai'
--splineFilename = dataFolder..'ideal_line.ai'
local bDrawWalls = false -- true
--local bDrawWalls = true
local CUSTOM_MULT = tonumber( readACConfig(appini, 'USERSETTINGS', 'CUSTOM_MULT', 1.0) )
local glowmult   = math.max(1, tonumber( readACConfig(appini, 'USERSETTINGS', 'GLOWMULT', 1) ))
local jumpdist   = tonumber( readACConfig(appini, 'USERSETTINGS', 'JUMPDIST', 50) )
-- draw AI line and borders a bit behind the car
local leadinCount = tonumber( readACConfig(appini, 'USERSETTINGS', 'LEADINCOUNT', 0) )
-- rendered IdealLine parts
local ai_renderlength = tonumber( readACConfig(appini, 'USERSETTINGS', 'AI_RENDERLENGTH', 200) )
-- rendered Border parts
local border_renderlength = tonumber( readACConfig(appini, 'USERSETTINGS', 'BORDER_RENDERLENGTH', 200) )
-- part length in meters
local partlen = math.floor ( readACConfig(appini, 'USERSETTINGS', 'BORDER_DISTANCE', 1) )
local brdDist = 1.5525/2 --math.floor ( readACConfig(appini, 'USERSETTINGS', 'BORDER_DISTANCE', 1) )
-- percent of spline length
--local borderDist = brdDist/sim.trackLengthM   --- those meters above in percent of track
local borderDist = 1/(#BGas)/2   --- those meters above in percent of track



-- -- local AISpline = require('AISpline')
-- -- local spline = nil ---@type AISpline
-- -- if io.fileExists(splineFilename) then
-- --     spline = AISpline(splineFilename)
-- --     ac.debug('#spline.points', #spline.points)
-- -- end

local function ReadAILINE()
    local f = io.open(splineFilename, 'rb')
    if not f then
        ac.debug("could not open 'fast_lane.ai'", splineFilename)
    else
        -- ac.perfBegin('load fast_lane')
        local pos
        local content = f:read("a")
        local header, detailCount, u1, u2 = 0, 0, 0, 0

        -- 4 floats -- header, detailCount, u1, u2
        header, pos = string.unpack("=I4", content, pos)
        detailCount, pos = string.unpack("=I4", content, pos)
        _, pos = string.unpack("=I4", content, pos)
        _, pos = string.unpack("=I4", content, pos)

        local x,y,z,dist,id=0.0,0.0,0.0,0.0,0
        for i = 1, detailCount do
            -- 4 floats, one integer
            x,    pos = string.unpack("=f", content, pos)
            y,    pos = string.unpack("=f", content, pos)
            z,    pos = string.unpack("=f", content, pos)
            dist, pos = string.unpack("=f", content, pos)
            id,   pos = string.unpack("=I4", content, pos)
        end

        BGas = table.new(detailCount,0)
        BBrake = table.new(detailCount,0)
        -- ac.debug("detailCount", detailCount)
        local gas, brake = 1.0, 1.0
        for i = 1, detailCount do
            -- 20 floats
            _,    pos = string.unpack("=f", content, pos)  -- unk            float()  0
            _,    pos = string.unpack("=f", content, pos)  -- speed          float()  1
            gas,  pos = string.unpack("=f", content, pos)  -- gas            float()  2
            brake,pos = string.unpack("=f", content, pos)  -- brake          float()  3
            _,    pos = string.unpack("=f", content, pos)  -- obsoleteLatG   float()  4
            _,    pos = string.unpack("=f", content, pos)  -- radius         float()  5
            _,    pos = string.unpack("=f", content, pos)  -- sideLeft       float()  6
            _,    pos = string.unpack("=f", content, pos)  -- sideRight      float()  7
            _,    pos = string.unpack("=f", content, pos)  -- camber         float()  8
            _,    pos = string.unpack("=f", content, pos)  -- direction      vec3x()  9
            _,    pos = string.unpack("=f", content, pos)  -- normalx        vec3y() 10
            _,    pos = string.unpack("=f", content, pos)  -- normaly        vec3z() 11
            _,    pos = string.unpack("=f", content, pos)  -- normalz        float() 12
            _,    pos = string.unpack("=f", content, pos)  -- length         vec3x() 13
            _,    pos = string.unpack("=f", content, pos)  -- forwardVectorx vec3y() 14
            _,    pos = string.unpack("=f", content, pos)  -- forwardVectory vec3z() 15
            _,    pos = string.unpack("=f", content, pos)  -- forwardVectorz float() 16
            _,    pos = string.unpack("=f", content, pos)  -- tag            float() 17

            -- _,    pos = string.unpack("=f", content, pos)  -- speed         float()
            -- _,    pos = string.unpack("=f", content, pos)  -- gas           float()
            -- gas,  pos = string.unpack("=f", content, pos)  -- brake         float()
            -- brake,pos = string.unpack("=f", content, pos)  -- obsoleteLatG  float()
            -- _,    pos = string.unpack("=f", content, pos)  -- radius        float()
            -- _,    pos = string.unpack("=f", content, pos)  -- sideLeft      float()
            -- _,    pos = string.unpack("=f", content, pos)  -- sideRight     float()
            -- _,    pos = string.unpack("=f", content, pos)  -- camber        float()
            -- _,    pos = string.unpack("=f", content, pos)  -- direction     float()
            -- _,    pos = string.unpack("=f", content, pos)  -- normal        vec3x()
            -- _,    pos = string.unpack("=f", content, pos)  -- normal        vec3y()
            -- _,    pos = string.unpack("=f", content, pos)  -- normal        vec3z()
            -- _,    pos = string.unpack("=f", content, pos)  -- length        float()
            -- _,    pos = string.unpack("=f", content, pos)  -- forwardVector vec3x()
            -- _,    pos = string.unpack("=f", content, pos)  -- forwardVector vec3y()
            -- _,    pos = string.unpack("=f", content, pos)  -- forwardVector vec3z()
            -- _,    pos = string.unpack("=f", content, pos)  -- tag           float()
            -- _,    pos = string.unpack("=f", content, pos)  -- grade         float()

            BGas[i] = gas
            BBrake[i] = brake
        end
        f:close()
        -- ac.perfEnd('load fast_lane')
        ai_renderlength = math.min(ai_renderlength, #BGas)
        ai_renderlength = math.min(ai_renderlength, #BGas)
        borderDist = 1/(#BGas)/2   --- those meters above in percent of track

    end
end
if ac.getPatchVersionCode()>=3044 then
    ReadAILINE()
end



local sim = ac.getSim()
local car = ac.getCar(0)
local carp = ac.getCarPhysics(0)
local carNode = ac.findNodes('carRoot:0')
local carstw = carNode:findNodes('STEER_HR')
carMeshes = carstw:findMeshes('?')



local pushForce = 150
local second = 0.0
local secondadd = 0.25
local gapdefault = 0.3
local currSect = 0
local prevSect = nil
local nextSect = nil
local keydelay = 0.0

local ffbTimer = 0.0
local lastFFB = 0.0

-- "Documents\Assetto Corsa\cfg\gameplay.ini"
-- local gameplayini = ac.getFolder(ac.FolderID.Documents) .. "/Assetto Corsa/cfg/gameplay.ini"
-- local USE_MPH = ac.INIConfig.load(gameplayini):get('OPTIONS', 'USE_MPH', 0)



local WheelHidden = tonumber( readACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '0') )
local DriverHidden = tonumber( readACConfig(acini, 'DRIVER', 'HIDE', '0') )

local fntSize = 18 --@integer
local fntSizeSmall = 12 --@integer
fntSize = math.floor( tonumber( readACConfig(appini, 'USERSETTINGS', 'FONTSIZE', 18) ))
fntSizeSmall = math.floor(0.666*fntSize)

local idealTexture = math.floor(tonumber( readACConfig(appini, 'USERSETTINGS', 'IDEALTEXTURE', 1) ))
local texAIline = TexturesAILine[idealTexture]
local rendertex = render.glTexture(texAIline)
local idealscale = 1


local joystickbuttonideal      = ac.ControlButton('__APP_JumpAILINE_ideal')
local joystickbuttonreset      = ac.ControlButton('__APP_JumpAILINE_reset')
local joystickbuttonstepback   = ac.ControlButton('__APP_JumpAILINE_stepback')
local joystickbuttonstepforw   = ac.ControlButton('__APP_JumpAILINE_stepforw')
local joystickbuttonsectPrev   = ac.ControlButton('__APP_JumpAILINE_sectPrev')
local joystickbuttonsectNext   = ac.ControlButton('__APP_JumpAILINE_sectNext')
local joystickbuttonAI         = ac.ControlButton('__APP_JumpAILINE_AI')
local joystickbuttonMEM        = ac.ControlButton('__APP_JumpAILINE_MEM')
local joystickbuttonJUMPMEM    = ac.ControlButton('__APP_JumpAILINE_JUMPMEM')
local joystickbuttonAIoffsetUP = ac.ControlButton('__APP_JumpAILINE_AIoffsetUP')
local joystickbuttonAIoffsetDN = ac.ControlButton('__APP_JumpAILINE_AIoffsetDN')

local bBackground                = true --$boolean
if readACConfig(appini, 'CONTROLS', 'BACKGROUND'     , "1") == "0" then bBackground = false end
local bSections                  = true --$boolean
if readACConfig(appini, 'CONTROLS', 'Sections'       , "1") == "0" then bSections = false end
local bAIonlyWhenNotGreen        = true --$boolean
if readACConfig(appini, 'CONTROLS', 'AIWHENNOTGREEN' , "1") == "0" then bAIonlyWhenNotGreen = false end
local bAIonlyWhenNotYellow       = true --$boolean
if readACConfig(appini, 'CONTROLS', 'AIWHENNOTYELLOW', "1") == "0" then bAIonlyWhenNotYellow = false end
local bButtonReload              = true --$boolean
if readACConfig(appini, 'CONTROLS', 'ButtonReload'   , "1") == "0" then bButtonReload = false end

local bKMs           = false --$boolean
if readACConfig(appini, 'CONTROLS', 'KMs'       , "0") == "1" then bKMs = true end
local bPoT           = false --$boolean
if readACConfig(appini, 'CONTROLS', 'PoT'       , "0") == "1" then bPoT = true end
local bButtons       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'Buttons'   , "0") == "1" then bButtons = true end
local bAIborders     = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIBORDERS' , "0") == "1" then bAIborders = true end
local bAIideal       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIIDEAL'   , "0") == "1" then bAIideal = true end
local bAImonocolor   = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIMONOCOLOR'   , "0") == "1" then bAImonocolor = true end

local AIskipVar = tonumber ( readACConfig(appini, 'CONTROLS', 'SKIPAIPARTS', 4) )
--$integer



local rgbSections = rgbm.colors.white
local rgbCurrentSection --@rgbm
local rgbSingleColor --@rgbm
local editcolor --@rgbm
local editcolor2 --@rgbm
local editcolor3 --@rgbm
local rgbBorder --@rgbm

local scol = readACConfig(appini, 'USERSETTINGS', "SECTIONCOLOR", "0.5,1,0.5,1")
if scol~="" then
    local col = string.split(scol,',')
    rgbCurrentSection = rgbm(tonumber(col[1]), tonumber(col[2]), tonumber(col[3]), 1)
    editcolor = rgbCurrentSection:clone()
end

scol = readACConfig(appini, 'USERSETTINGS', "BORDERCOLOR", "1,0,0,1")
if scol~="" then
    local col = string.split(scol,',')
    rgbBorder = rgbm(tonumber(col[1]), tonumber(col[2]), tonumber(col[3]), 1)
    editcolor2 = rgbBorder:clone()
end

scol = readACConfig(appini, 'USERSETTINGS', "AISINGLECOLOR", "0,1,0,1")
if scol~="" then
    local col = string.split(scol,',')
    rgbSingleColor = rgbm(tonumber(col[1]), tonumber(col[2]), tonumber(col[3]), 1)
    editcolor3 = rgbSingleColor:clone()
end



local textsteer = ''
local textdriver = ''
local p1 = vec3(0,0,0)
local p2 = vec3(0,0,0)
local p3 = vec3(0,0,0)
local dist = 0.0
local cSpline = 0.0





local first = true
local function LoadSectionsIni(sectINI)
-- [SECTION_0]
-- IN=0.152
-- OUT=0.190
-- TEXT=T1
    table.clear(Sects)
    if not io.fileExists(sectINI) then
        ac.debug('sectINI not found:', sectINI)
        if first then
            first=false
        else
            ui.toast(ui.Icons.AppWindow, 'sections.ini not found:'..sectINI)
        end
    else
        local i = 0
        local j = 0
        local sectName = "SECTION_"..i
        local sectText = readACConfig(sectINI, sectName, "TEXT", "")
        local lastsectText = ""
        while sectText ~= "" do
            local sectIN = tonumber ( readACConfig(sectINI, sectName, "IN", "-1") )
            local sectOUT = tonumber ( readACConfig(sectINI, sectName, "OUT", "-1") )
            if sectIN>-1 and sectOUT>-1 then
                --ac.debug('a ' .. j, sectText)
                if lastsectText == sectText then
                    Sects[j-1][2] = sectOUT
                else
                    if j>0 and Sects[0][0] == sectText then
                        Sects[0][1] = sectIN
                    else
                        table.insert(Sects, j, {[0]=sectText, [1]=sectIN, [2]=sectOUT})
                        j=j+1
                        lastsectText = sectText
                    end
                end
            end
            i=i+1
            sectName = "SECTION_"..i
            sectText = readACConfig(sectINI, sectName, "TEXT", "")
        end
        -- make sure its sorted
        table.sort(Sects, function (a, b) return a[1] < b[1] end)
        if first then
            first=false
        else
            ui.toast(ui.Icons.AppWindow, 'sections.ini Loaded!')
        end
    end
end


local function CheckIfInsideINOUT(pin, pout, splinepos)
    if pout<pin then
        -- from end of track, wrapping over to start of track/next lap
        if splinepos>pin then
            return true
        elseif splinepos<pout then
            return true
        end
    else
        -- normal section has to be inside those two bounds
        if splinepos>=pin and splinepos<pout then
            return true
        end
    end
    return false
end

local function CheckCurrentSection()
    if car ~= nil then
        local cSpline = car.splinePosition
        local lastS = -1
        currSect = -1
        prevSect = nil
        nextSect = nil
        for k,v in pairs(Sects) do
            if CheckIfInsideINOUT(v[1], v[2], cSpline) then
                if k+1<=#Sects then
                    nextSect = Sects[k+1]
                else
                    nextSect = Sects[0]
                end
                currSect = k
                break
            end
            if cSpline<v[1] and cSpline<v[2] then
                break
            end
            lastS = k
        end
        if currSect>=0 then
            if currSect-1>-1 then
                prevSect = Sects[currSect-1]
            else
                prevSect = Sects[#Sects]
            end
            if currSect+1>#Sects then
                nextSect = Sects[0]
            else
                nextSect = Sects[currSect+1]
            end
        else
            if lastS==-1 then
                prevSect = Sects[#Sects]
            else
                prevSect = Sects[lastS]
            end
            if lastS+1<=#Sects then
                nextSect=Sects[lastS+1]
            else
                nextSect=Sects[0]
            end
        end
    end
end




local function FFBdisable()
    if lastFFB==0.0 then
        ffbTimer = 0.85
        lastFFB = car.ffbMultiplier
        ac.setFFBMultiplier(0)
    end
end




local function SetBack()
  if car ~= nil then
    cSpline = car.splinePosition
    p1 = ac.trackProgressToWorldCoordinate(cSpline)
    p3 = p1
    p2 = p3
    dist = 0.0
    while dist<=jumpdist and dist<sim.trackLengthM do
      cSpline = cSpline - 0.0001
      if cSpline<0.0 then
        cSpline = cSpline + 1.0
      end
      p3 = p2
      p2 = ac.trackProgressToWorldCoordinate(cSpline)
      dist = p1:distance(p2)
    end
    if cSpline>0.0 then
        FFBdisable()
        physics.setCarPosition(0, p2, vec3(p2.x-p3.x,p2.y-p3.y,p2.z-p3.z))
        --physics.setCarPosition(0, pos, vec3(1,0,0))
    end
  end
end


local function SetForw()
  if car ~= nil then
    cSpline = car.splinePosition --# -0.001
    if cSpline<0.0 then
      cSpline=0.999
    end
    p1 = ac.trackProgressToWorldCoordinate(cSpline)
    p3 = p1
    p2 = p3
    dist = 0.0
    while dist<=jumpdist and dist<sim.trackLengthM do
      cSpline = cSpline + 0.0001
      if cSpline>1.0 then
        cSpline = 0.0
      end
      p3 = p2
      p2 = ac.trackProgressToWorldCoordinate(cSpline)
      dist = p1:distance(p2)
    end
    if cSpline>0.0 then
        FFBdisable()
        physics.setCarPosition(0, p2, vec3(p3.x-p2.x,p3.y-p2.y,p3.z-p2.z))
        --physics.setCarPosition(0, pos, vec3(1,0,0))
    end
  end
end



local function Reset()
    FFBdisable()
    ac.resetCar()
end

local function SetPits()
    FFBdisable()
    physics.teleportCarTo(0, ac.SpawnSet.Pits)
end


local function settexts()
  if WheelHidden==1 then
    textsteer = 'Show\nstwheel'
  else
    textsteer = 'Hide\nstwheel'
  end
  if DriverHidden==1 then
    textdriver = 'Show\ndriver'
  else
    textdriver = 'Hide\ndriver'
  end
end
settexts()


local function ToggleSteeringWheel()
  if carMeshes~=nil then
    if WheelHidden==0 then
      WheelHidden = 1
      carMeshes:setVisible(false)
      writeACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '1')
    else
      WheelHidden = 0
      carMeshes:setVisible(true)
      writeACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '0')
    end
  end
  settexts()
end

local function ToggleDriver()
  if car.isDriverVisible then
    DriverHidden = 1
    ac.setDriverVisible(0, false)
    writeACConfig(acini, 'DRIVER', 'HIDE', '1')
  else
    DriverHidden = 0
    ac.setDriverVisible(0, true)
    writeACConfig(acini, 'DRIVER', 'HIDE', '0')
  end
  settexts()
end

function CheckForStalledAI()
    if physics.allowed() then
        for i=2, sim.carsCount do
            local carl = ac.getCar(i)
            if carl and
               carl.isAIControlled and
               not carl.isInPit and
               not carl.isInPitlane and
               carl.speedKmh<5
            then
                --if sim.physicsLate>10 then
                physics.teleportCarTo(i, ac.SpawnSet.Pits)
            end
        end
    end
end



---------------------------------------------------------------------------------------------

local function DrawTextWithShadows(s, fntsize, algn, xy1, xy2, wrap, col)
    local xy3 = xy1
    local xy4 = xy2
    xy3.x=xy3.x-2
    xy3.y=xy3.y-2
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy3, xy4, wrap, rgbm.colors.black )
    xy3.x=xy3.x-1
    xy3.y=xy3.y-1
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy3, xy4, wrap, rgbm.colors.black )
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy1, xy2, wrap, col )
end

local function DrawTextACWithShadows(s, fntsize, xy1, xy2, col)
    ui.setCursorX(0)
    ui.setCursorY(0)
    local xy3 = xy1
    local xy4 = xy2
    xy3.x=xy3.x-2
    xy3.y=xy3.y-2
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.acText(s, vec2(math.floor(fntsize/2),fntsize), 0, rgbm.colors.black, 0, true)
    xy3.x=xy3.x-1
    xy3.y=xy3.y-1
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.acText(s, vec2(math.floor(fntsize/2),fntsize), 0, rgbm.colors.black, 0, true)
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.acText(s, vec2(math.floor(fntsize/2),fntsize), 0, col, 0, true)
    -- ui.dwriteTextAligned( s, fntsize, algn, xy1, xy2, wrap, col )
end



local function JumpSection(cSpline)
    if car ~= nil then
        local p1 = ac.trackProgressToWorldCoordinate(cSpline)
        local p3 = p1
        local p2 = p3
        local dist = 0.0
        local cSpline2 = cSpline

        while dist<=1 and dist<sim.trackLengthM do
            cSpline2 = cSpline2 + 0.001
            if cSpline2>1.0 then
                cSpline2 = 0.0
            end
            p3 = p2
            p2 = ac.trackProgressToWorldCoordinate(cSpline2)
            dist = p1:distance(p2)
        end

        if dist>0.0 then
            -- set new car position
            local direction = vec3(p3.x-p2.x,p3.y-p2.y,p3.z-p2.z)
            physics.setCarPosition(0, p2, direction)
        end
    end
end




local function pushCar(dt)
    local passivePush = pushForce * car.mass * dt * 100 * car.gas
    --ac.debug("passivePush", passivePush)
    physics.addForce(0, vec3(0, 0, 0), true, vec3(0, 0, passivePush), true)
end








local vUp = vec3(0, 1, 0)
local vDown = vec3(0, -1, 0)
local ucTurn = vec2(0.0, 0.0)

-- project to ground
local function snapToTrackSurface(pos, gap)
    local p = pos
    local v1 = vec3()
    physics.raycastTrack(v1:set(0, 0.5, 0):add(p), vDown, 2, p) --, v1)
    p.y = p.y + 0.05  -- (gap or 0.03)
end

local function CreateBorders()
    if car ~= nil and borderDist>0.0 and ac.hasTrackSpline() then
        local carState = ac.getCar(0)
        BLeft={}
        BRight={}
        BDir={}
        BIdealL={}
        BIdealR={}

        local cSpline2 = 0
        local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
        local side = ac.getTrackAISplineSides(cSpline2)
        cSpline2 = borderDist
        local p2 = p1
        --:copyTo(p2)    -- ac.trackProgressToWorldCoordinate(cSpline2)
        local c = 1
        local lastdir = -1080.0
        while cSpline2<=1.0 do
            if c==1 then
                side = vec2(side.y, side.x)
                c=c+1
            end
            --dist = p1:distance(p2)
            --dist>=1.0 and
            --if p1~=p2 and p2.x~=0 and p2.y~=0 and p2.z~=0 then
            local dir = -math.deg( math.atan2(p1.z-p2.z, p1.x-p2.x) )
            local roll = -math.deg( math.atan2(p1.x-p2.x, p1.z-p2.z) )
            local xL = p1.x + math.cos((dir + 90) * math.pi / 180) * side.x
            local yL = p1.z - math.sin((dir + 90) * math.pi / 180) * side.x
            local xR = p1.x + math.cos((dir - 90) * math.pi / 180) * side.y
            local yR = p1.z - math.sin((dir - 90) * math.pi / 180) * side.y
            local zL = p1.y-0.33
            local zR = p1.y-0.33
            local p4 = vec3(xL, zL, yL)
            local p5 = vec3(xR, zR, yR)

            snapToTrackSurface(p4, gapdefault)
            snapToTrackSurface(p5, gapdefault)
            snapToTrackSurface(p1, gapdefault)

            table.insert(BLeft, p4)
            table.insert(BRight, p5)
            --table.insert(BDir, dir)
            if lastdir~=-1080.0 then
                table.insert(BDir, math.rad((dir+lastdir)/2))
            end
            lastdir = dir

            local v1 = vec3(p1.x + math.cos((dir + 90) * math.pi / 180)*idealscale, p1.y, p1.z - math.sin((dir + 90) * math.pi / 180)*idealscale)
            local v2 = vec3(p1.x + math.cos((dir - 90) * math.pi / 180)*idealscale, p1.y, p1.z - math.sin((dir - 90) * math.pi / 180)*idealscale)
            snapToTrackSurface(v1, 0.05)
            snapToTrackSurface(v2, 0.05)
            table.insert(BIdealL, v1)
            table.insert(BIdealR, v2)

            p1:copyTo(p2)
            cSpline2 = cSpline2 + borderDist
            p1 = ac.trackProgressToWorldCoordinate(cSpline2)
            side = ac.getTrackAISplineSides(cSpline2)
        end -- while


        -- must interpolate first bc might be a strange distance from last
        BLeft   [1] = vec3((BLeft  [2].x+BLeft  [#BLeft  ].x)/2, (BLeft  [2].y+BLeft  [#BLeft  ].y)/2, (BLeft  [2].z+BLeft  [#BLeft  ].z)/2)
        BRight  [1] = vec3((BRight [2].x+BRight [#BRight ].x)/2, (BRight [2].y+BRight [#BRight ].y)/2, (BRight [2].z+BRight [#BRight ].z)/2)
        BIdealL [1] = vec3((BIdealL [2].x+BIdealL [#BIdealL ].x)/2, (BIdealL [2].y+BIdealL [#BIdealL ].y)/2, (BIdealL [2].z+BIdealL [#BIdealL ].z)/2)
        BIdealR [1] = vec3((BIdealR [2].x+BIdealR [#BIdealR ].x)/2, (BIdealR [2].y+BIdealR [#BIdealR ].y)/2, (BIdealR [2].z+BIdealR [#BIdealR ].z)/2)

        -- ac.debug("#BLeft", #BLeft)
        -- ac.debug("#BGas", #BGas)
        -- ac.debug("borderDist", borderDist)
        -- ac.debug("#BGas/sim.trackLengthM", 1/#BGas)

    end -- if car ~= nil
end


local function DrawBorders(cSpline)
    if #BLeft>0 then
        local stepswanted = border_renderlength -- 50 --math.floor(#BLeft)
        --local stepswanted = math.floor(#BLeft / 2)
        local currID = math.floor(cSpline * #BLeft) - 1 - leadinCount
        currID = currID - currID % partlen
        local nextID = currID + partlen
        local stepsdone = 0
        local exposure = (math.max(0.005, ac.getSim().whiteReferencePoint-0.1))/25

        while stepsdone<stepswanted do
            if currID>#BLeft then
                currID = 1
                nextID = partlen
            end
            if nextID>#BLeft then
                nextID = partlen -- nextID - #BLeft
            end
            if BLeft[nextID] and BLeft [currID] and currID>0 and nextID>0 and currID<#BLeft and nextID<#BLeft then
                if not bDrawWalls then
                    render.debugLine(BLeft [currID], BLeft [nextID], rgbBorder * glowmult * exposure)
                    render.debugLine(BRight[currID], BRight[nextID], rgbBorder * glowmult * exposure)
                else
                    render.debugPlane(vec3((BLeft [currID]+BLeft [nextID])/2),
                                vec3(   -math.sin(BDir[currID]), 0,
                                        -math.cos(BDir[currID])),
                                rgbBorder*glowmult * exposure, 3)
                    render.debugPlane(vec3((BRight [currID]+BRight [nextID])/2),
                                vec3(   math.sin(BDir[currID]), 0,
                                        math.cos(BDir[currID])),
                                rgbBorder*glowmult * exposure, 3)
                end
            end
            stepsdone = stepsdone + partlen
            currID = currID + partlen
            nextID = currID + partlen
        end
    end
end


local flag=false

local lineFadeLevelCurrent = 0
local lineFadeLevelTarget = 0
local lineFadeRedCurrent = 0
local lineFadeGreenCurrent = 0
local lineFadeRedTarget = 0
local lineFadeGreenTarget = 0

local function DrawAILine(cSpline)
    local stepswanted = ai_renderlength
    local currID = math.floor(cSpline * #BLeft) + 1 - leadinCount
    currID = currID - ((currID % 4))
    local nextID = currID + 1
    -- local currIDSP = math.floor(cSpline * #spline.points) + 1
    local currIDSP = math.floor(cSpline * #BGas)+1
    currIDSP = currIDSP - ((currIDSP % 4))
    local nextIDSP = currIDSP + 1
    local stepsdone = 0

    -- if currIDSP<#spline.payloads and currIDSP>1 then
    --     local speeddiff = car.speedKmh - spline.payloads[currIDSP].speed
    --     ac.debug("speed__diff", speeddiff)
    --     -- ac.debug("speed_curr", car.speedKmh)
    --     -- ac.debug("tag_should", spline.payloads[currID].tag)
    --     -- ac.debug("car.splinePosition"               , car.splinePosition)
    --     -- ac.debug("brake", spline.payloads[currIDSP].brake)
    --     -- ac.debug("gas", spline.payloads[currIDSP].gas)
    --     -- ac.debug("grade", spline.payloads[currIDSP].grade*100)
    --     -- ac.debug("obsoleteLatG", spline.payloads[currIDSP].obsoleteLatG)
    --     ac.debug("speed", spline.payloads[currIDSP].speed)
    --     -- ac.debug("normal", spline.payloads[currIDSP].normal)
    --     -- ac.debug("gas*speed", spline.payloads[currIDSP].gas*spline.payloads[currIDSP].speed)
    --     -- ac.debug("camber", spline.payloads[currIDSP].camber)
    -- end
    -- ac.debug("len ailine", #BBrake)
    -- ac.debug("len borders", #BLeft)
    -- ac.debug("brdDist*car.speedKmh/1000", brdDist) -- *car.speedKmh/5)

    local ucTurn2 = ac.getTrackUpcomingTurn(0)
    local exposure = (math.max(0.002, ac.getSim().whiteReferencePoint-0.1))/20
    local color = rgbm(0,1,0,glowmult)
    local distanceFade = math.max(0, ((stepswanted-10)-stepsdone)/stepswanted)
    ucTurn = vec2(ucTurn2.x*CUSTOM_MULT, ucTurn2.y)

    -- ucTurn.x = ucTurn.x + ucTurn.x*CUSTOM_MULT
    -- ac.debug("ucTurn.x dist ", ucTurn.x)
    -- ac.debug("ucTurn.y angle", ucTurn.y)
    -- ac.debug("ucTurn2.x dist ", ucTurn2.x)
    -- ac.debug("gas"           , spline.payloads[currIDSP].gas)
    -- ac.debug("brake"         , spline.payloads[currIDSP].brake)

    render.setBlendMode(4)
    while stepsdone<stepswanted do
        if currIDSP==0 then
            currIDSP = 1
            nextIDSP = 4
        end
        if currIDSP>#BGas then
            currIDSP = currIDSP - #BGas
            nextIDSP = currIDSP+4
            if nextIDSP>#BGas then
                nextIDSP = nextIDSP - #BGas
            end
        end
        if currID==0 then
            currID = 1
            nextID = 4
        end
        if currID>#BLeft then
            currID = currID - #BLeft
            nextID = currID+4
            if nextID>#BLeft then
                nextID = nextID - #BLeft
            end
        end

        if stepsdone>2 then

            distanceFade = math.max(0, ((stepswanted-10)-stepsdone)/stepswanted)

            if (math.abs(ucTurn.y)>=100 and ucTurn.x<2*car.speedKmh/25) then
                lineFadeLevelTarget = 8
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0
            elseif (math.abs(ucTurn.y)>=80 and ucTurn.x<2*car.speedKmh/20) then
                lineFadeLevelTarget = 4
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0
            elseif (math.abs(ucTurn.y)>=60 and ucTurn.x<2*car.speedKmh/17.5) then
                lineFadeLevelTarget = 2
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0
            elseif (math.abs(ucTurn.y)>=40 and ucTurn.x+1<2*car.speedKmh/15) then
                lineFadeLevelTarget = 1
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0
            elseif (math.abs(ucTurn.y)>=36.25 and ucTurn.x+2<2*car.speedKmh/10) then
                if bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.75
                end
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0.25
            elseif (math.abs(ucTurn.y)>=32.5 and ucTurn.x+3<2*car.speedKmh/8) then
                if bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.5
                end
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0.5
            elseif (math.abs(ucTurn.y)>=27.75 and ucTurn.x+4<2*car.speedKmh/6) then
                if bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.25
                end
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 0.75
            elseif ((math.abs(ucTurn.y)>=25 and ucTurn.x+5<2*car.speedKmh/4)) then
                if bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.01
                end
                lineFadeRedTarget = 1
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=21.875 and ucTurn.x+5<2*car.speedKmh/3.5)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.8
                end
                lineFadeRedTarget = 0.875
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=18.75 and ucTurn.x+5<2*car.speedKmh/3)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.4
                end
                lineFadeRedTarget = 0.75
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=15.625 and ucTurn.x+5<2*car.speedKmh/2.5)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.2
                end
                lineFadeRedTarget = 0.675
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=12.5 and ucTurn.x+5<2*car.speedKmh/2)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.1
                end
                lineFadeRedTarget = 0.5
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=9.375 and ucTurn.x+5<2*car.speedKmh/1.5)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.05
                end
                lineFadeRedTarget = 0.375
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=6.25 and ucTurn.x+5<2*car.speedKmh/1)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.025
                end
                lineFadeRedTarget = 0.25
                lineFadeGreenTarget = 1
            elseif ((math.abs(ucTurn.y)>=3.125 and ucTurn.x+5<2*car.speedKmh/0.5)) then
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0.0125
                end
                lineFadeRedTarget = 0.125
                lineFadeGreenTarget = 1
            else
                if not bAIonlyWhenNotYellow then
                    lineFadeLevelTarget = 0
                elseif bAIonlyWhenNotGreen then
                    lineFadeLevelTarget = 1
                else
                    lineFadeLevelTarget = 0
                end
                lineFadeRedTarget = 0
                lineFadeGreenTarget = 1
            end

            if lineFadeLevelCurrent ~= lineFadeLevelTarget then
                if lineFadeLevelCurrent < lineFadeLevelTarget then
                    lineFadeLevelCurrent = lineFadeLevelCurrent + (lineFadeLevelTarget-lineFadeLevelCurrent)*(0.4/stepswanted)
                else
                    lineFadeLevelCurrent = lineFadeLevelCurrent + (lineFadeLevelTarget-lineFadeLevelCurrent)*(0.2/stepswanted)
                end
            end
            if lineFadeRedCurrent ~= lineFadeRedTarget then
                if lineFadeRedCurrent < lineFadeRedTarget then
                    lineFadeRedCurrent = lineFadeRedCurrent + (lineFadeRedTarget-lineFadeRedCurrent)*(0.4/stepswanted)
                else
                    lineFadeRedCurrent = lineFadeRedCurrent + (lineFadeRedTarget-lineFadeRedCurrent)*(0.2/stepswanted)
                end
            end
            if lineFadeGreenCurrent ~= lineFadeGreenTarget then
                if lineFadeGreenCurrent > lineFadeGreenTarget then
                    lineFadeGreenCurrent = lineFadeGreenCurrent + (lineFadeGreenTarget-lineFadeGreenCurrent)*(0.4/stepswanted)
                else
                    lineFadeGreenCurrent = lineFadeGreenCurrent + (lineFadeGreenTarget-lineFadeGreenCurrent)*(0.2/stepswanted)
                end
            end

            if AIskipVar<8 or (AIskipVar>=8 and (currID % AIskipVar == 0)) then
                if bAImonocolor then
                    color = rgbm(rgbSingleColor.r, rgbSingleColor.g, rgbSingleColor.b, glowmult*exposure*distanceFade)
                else
                    color = rgbm(lineFadeRedCurrent,lineFadeGreenCurrent,0,glowmult*lineFadeLevelCurrent*exposure*distanceFade)
                end
                render.glSetColor(color)
                render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
            end
            --render.glBegin(render.GLPrimitiveType.Quads)
            --render.quad(v1, v2, v3, v4, color, rendertex)
            --render.glEnd()
        end
        stepsdone = stepsdone + 4
        currIDSP = currIDSP + 1
        nextIDSP = currIDSP + 1
        currID = currID + 4
        nextID = currID + 4

    end

end



local function DrawAILineOrig(cSpline)
    -- if spline then
    local stepswanted = ai_renderlength
    local currID = math.floor(cSpline * #BLeft) + 1 - leadinCount
    currID = currID - ((currID % 4))
    local nextID = currID + 1
    -- local currIDSP = math.floor(cSpline * #spline.points) + 1
    local currIDSP = math.floor(cSpline * #BGas)+1
    currIDSP = currIDSP - ((currIDSP % 4))
    local nextIDSP = currIDSP + 1
    local stepsdone = 0

    if currIDSP==0 then
        currIDSP = 1
        nextIDSP = 4
    end
    if currIDSP>#BGas then
        currIDSP = currIDSP - #BGas
        nextIDSP = currIDSP+4
        if nextIDSP>#BGas then
            nextIDSP = nextIDSP - #BGas
        end
    end
    if currID==0 then
        currID = 1
        nextID = 4
    end
    if currID>#BLeft then
        currID = currID - #BLeft
        nextID = currID+4
        if nextID>#BLeft then
            nextID = nextID - #BLeft
        end
    end

    render.setBlendMode(4)

    ucTurn = ac.getTrackUpcomingTurn(0)


    local mult = 1
    --if ucTurn.x<brdDist*car.speedKmh/5 /ucTurn.x then
    mult = (ucTurn.x + math.abs(ucTurn.y))/20/2
    mult = ucTurn.x/(brdDist*car.speedKmh)*4 + math.abs(math.rad(ucTurn.y))/2
    --end
    -- math.abs(ucTurn.y)>=40
    -- and ucTurn.x<brdDist*car.speedKmh/10
    -- ac.debug("mult", mult)
    -- ac.debug("mult.x dist", ucTurn.x)
    -- ac.debug("mult.y angle", ucTurn.y)
    local color = rgbm(0,math.max(1,mult),0,10)
    -- if mult<1.0 then
    --     color = rgbm(math.max(0.5, 0.5+mult), math.max(0,0.5-mult), 0, 10)
    -- end
    -- render.glSetColor(color)
    -- render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
    -- render.quad(BLeft [currID], BRight [currID],
    --             BRight[nextID], BLeft[nextID],
    --             color, texAIline)


    -- if currIDSP<#spline.payloads and currIDSP>1 then
    --     local speeddiff = car.speedKmh - spline.payloads[currIDSP].speed
    --     ac.debug("speed__diff", speeddiff)
    --     -- ac.debug("speed_curr", car.speedKmh)
    --     -- ac.debug("tag_should", spline.payloads[currID].tag)
    --     -- ac.debug("car.splinePosition"               , car.splinePosition)
    --     -- ac.debug("brake", spline.payloads[currIDSP].brake)
    --     -- ac.debug("gas", spline.payloads[currIDSP].gas)
    --     -- ac.debug("grade", spline.payloads[currIDSP].grade*100)
    --     -- ac.debug("obsoleteLatG", spline.payloads[currIDSP].obsoleteLatG)
    --     ac.debug("speed", spline.payloads[currIDSP].speed)
    --     -- ac.debug("normal", spline.payloads[currIDSP].normal)
    --     -- ac.debug("gas*speed", spline.payloads[currIDSP].gas*spline.payloads[currIDSP].speed)
    --     -- ac.debug("camber", spline.payloads[currIDSP].camber)
    -- end
    -- ac.debug("len ailine", #BBrake)
    -- ac.debug("len borders", #BLeft)
    -- ac.debug("brdDist*car.speedKmh/1000", brdDist) -- *car.speedKmh/5)

    -- ac.debug("ucTurn.x dist ", ucTurn.x)
    -- ac.debug("ucTurn.y angle", ucTurn.y)
    -- ac.debug("gas"  , #BGas)
    -- ac.debug("brake", #BBrake)
    -- stepsdone = 100000000

    while stepsdone<stepswanted do
        if currIDSP==0 then
            currIDSP = 1
            nextIDSP = 4
        end
        if currIDSP>#BGas then
            currIDSP = currIDSP - #BGas
            nextIDSP = currIDSP+4
            if nextIDSP>#BGas then
                nextIDSP = nextIDSP - #BGas
            end
        end
        if currID==0 then
            currID = 1
            nextID = 4
        end
        if currID>#BLeft then
            currID = currID - #BLeft
            nextID = currID+4
            if nextID>#BLeft then
                nextID = nextID - #BLeft
            end
        end
        if stepsdone>2 then
            local rgb = 1
            local color = rgbm(0,rgb,0,glowmult)
            if    (math.abs(ucTurn.y)>=40
                    and ucTurn.x<brdDist*car.speedKmh/10
                    and BGas[currIDSP]<=0.1)
                    or BBrake[currIDSP]>=0.001
                --     and spline.payloads[currIDSP].gas<=0.1)
                --  or spline.payloads[currIDSP].brake>=0.001
            then
                color = rgbm(rgb,0,0,glowmult)
                render.glSetColor(color)
                render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
            elseif ((math.abs(ucTurn.y)>=25 and ucTurn.x<brdDist*car.speedKmh/5) or
                (BGas[currIDSP]<=0.0) ) and
                not (BGas[currIDSP]==0.0 and
                BBrake[currIDSP]==0.0)
                -- (spline.payloads[currIDSP].gas<=0.0) ) and
                --    not (spline.payloads[currIDSP].gas==0.0 and
                --         spline.payloads[currIDSP].brake==0.0)
            then
                if bAIonlyWhenNotYellow then
                    color = rgbm(rgb,rgb,0,glowmult)
                    render.glSetColor(color)
                    render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
                end
            elseif bAIonlyWhenNotGreen then
                color = rgbm(0,rgb,0,glowmult)
                render.glSetColor(color)
                render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
            end

            --render.glBegin(render.GLPrimitiveType.Quads)
            --render.quad(v1, v2, v3, v4, color, rendertex)
            --render.glEnd()
        end
        stepsdone = stepsdone + 4
        currIDSP = currIDSP + 1
        nextIDSP = currIDSP + 1
        currID = currID + 4
        nextID = currID + 4
    end
    --render.glEnd()
end



function script.Draw3D(dt)  --script.renderTrack()
    if ac.hasTrackSpline() then
        if bAIborders then
            DrawBorders(car.splinePosition)
        end
        if car and bAIideal and #BGas>0 then
            DrawAILine(car.splinePosition)
        end
    end
end



-- function script.windowDynIdeal(dt)
--     ui.beginOutline()
--     if ucTurn.x<=200.0 then
--         --ucTurn.x<brdDist*car.speedKmh/10
--         -- ui.drawSimpleLine(
--         --     vec2(ui.windowWidth()/2,ucTurn.x/200*50),
--         --     vec2(ui.windowWidth()/2,50),
--         --     rgbm.colors.white, 10)
--         ui.drawSimpleLine(
--             vec2(ui.windowWidth()/2,50-ucTurn.x/200*50),
--             vec2(ui.windowWidth()/2,50),
--             rgbm.colors.white, 10)
--     end
--     ui.drawSimpleLine(vec2(ui.windowWidth()/2,80), vec2(ui.windowWidth()/2+ucTurn.y/180*ui.windowWidth()/2, 80), rgbm.colors.white, 10)
--     ui.drawSimpleLine(vec2(ui.windowWidth()/2,60), vec2(ui.windowWidth()/2,100), rgbm.colors.white, 2)
--     --ui.pathArcTo(vec2(ui.windowWidth()/2, ui.windowHeight()/2-1), ui.windowHeight()/2, 0, ucTurn.y, 32 )
--     --if ucTurn.yx<=100.0 then
--         --ucTurn.x<brdDist*car.speedKmh/10
--         --ui.drawSimpleLine(vec2(0,5), vec2(ucTurn.x/100*ui.windowWidth(),5), rgbm.colors.white, 10)
--     --end
--     --ui.endOutline(rgbm.colors.black, 2)
-- end


function script.windowSettings(dt)

    ui.beginOutline()

    if ui.button(textsteer) then
        ToggleSteeringWheel()
    end
    ui.sameLine(0,10)
    if ui.button(textdriver) then
        ToggleDriver()
    end
    ui.sameLine(0,5)
    if ui.checkbox("km's", bKMs) then
        bKMs = not bKMs
        if bKMs then
            writeACConfig(appini, 'CONTROLS', 'KMs', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'KMs', "0")
        end
    end

    ui.sameLine(0,5)
    if ui.checkbox("PoT %", bPoT) then
        bPoT = not bPoT
        if bPoT then
            writeACConfig(appini, 'CONTROLS', 'PoT', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'PoT', "0")
        end
    end

    ui.sameLine(0,5)
    if ui.checkbox("next/prev  ", bSections)
    then
        bSections = not bSections
        if bSections then
            writeACConfig(appini, 'CONTROLS', 'Sections', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'Sections', "0")
        end
    end

    ui.sameLine(0,5)
    if ui.checkbox("buttons", bButtons)
    then
        bButtons = not bButtons
        if bButtons then
            writeACConfig(appini, 'CONTROLS', 'Buttons', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'Buttons', "0")
        end
    end

    ui.sameLine(0,5)
    if ui.checkbox("buttonReload", bButtonReload)
    then
        bButtonReload = not bButtonReload
        if bButtonReload then
            writeACConfig(appini, 'CONTROLS', 'ButtonReload', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'ButtonReload', "0")
        end
    end

    if #BGas==0 or BBrake==0 or ac.getPatchVersionCode()<3044 then
        ui.newLine(0)
        ui.sameLine(320)
        ui.setCursorY(ui.getCursorY()-ac.getUI().uiScale*10)
        ui.bulletText("could not open ai line, CSP 0.2.3 needed!\n"..
                      "dynamic AI line not available")
    end

    ui.setNextItemWidth(50)
    if ui.checkbox("background      ", bBackground) then
        bBackground = not bBackground
        if bBackground then
            writeACConfig(appini, 'CONTROLS', 'BACKGROUND', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'BACKGROUND', "0")
        end
    end

    ui.sameLine(0,0)
    ui.setNextItemWidth(250)
    fntSize, changed = ui.slider('##Font size:', fntSize, 6, 64, "Font size: %d" % fntSize, 1)
    if changed then
        fntSize = math.floor(fntSize)
        fntSizeSmall = math.floor(0.666*fntSize)
        writeACConfig(appini, 'USERSETTINGS', 'FONTSIZE', fntSize)
    end

    ui.sameLine(0,40)
    ui.colorButton('Current Section color', editcolor, ui.ColorPickerFlags.PickerHueBar)
    if editcolor ~= rgbCurrentSection then
        rgbCurrentSection = editcolor:clone()
        writeACConfig(appini, 'USERSETTINGS', 'SECTIONCOLOR', rgbCurrentSection)
    end

    ui.sameLine(0,40)
    ui.colorButton('Border color', editcolor2, ui.ColorPickerFlags.PickerHueBar)
    if editcolor2 ~= rgbBorder then
        rgbBorder = editcolor2:clone()
        writeACConfig(appini, 'USERSETTINGS', 'BORDERCOLOR', rgbBorder)
    end

    ui.sameLine(0,20)
    -- ui.setCursorX(150)
    -- ui.setCursorY(20)
    if physics.allowed() then
        ui.bulletText('extPhys on.')
    else
        ui.bulletText('extPhys OFF!\nNo Jumping!')
    end



    ui.setNextItemWidth(450)
    jumpdist, changed = ui.slider('##jumpdist', jumpdist, 0, math.max(400, math.floor(sim.trackLengthM/2)), "jumpdist: %d meter" % jumpdist, 1)
    if changed then
        jumpdist = math.floor(jumpdist)
        writeACConfig(appini, 'USERSETTINGS', 'JUMPDIST', jumpdist)
    end

    if ui.checkbox("borders", bAIborders) then
        bAIborders = not bAIborders
        if bAIborders then
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "0")
        end
    end


    ui.sameLine(0,20)
    ui.setNextItemWidth(80)
    partlen, changed = ui.slider('##part len', partlen, 1, 32, 'part len: %dm' % partlen, 1 )
    if changed then
        partlen = math.floor(partlen)
        -- no!1!11!
        -- borderDist = brdDist/sim.trackLengthM   --- those meters above in percent of track
        writeACConfig(appini, 'USERSETTINGS', 'BORDER_DISTANCE', partlen)
        -- CreateBorders()
    end


    ui.sameLine(245,0)
    border_renderlength, changed = ui.slider('##border parts to draw', border_renderlength, 2, math.max(10, #BLeft), "border parts to draw: %d" % border_renderlength, 2)
    if changed then
        border_renderlength = math.floor(border_renderlength)
        writeACConfig(appini, 'USERSETTINGS', 'BORDER_RENDERLENGTH', border_renderlength)
    end



    if #BGas>0 and #BBrake>0 and ac.getPatchVersionCode()>=3044 then

        ui.sameLine(0,20)
        if ui.checkbox("ideal single color", bAImonocolor) then
            bAImonocolor = not bAImonocolor
            if bAImonocolor then
                writeACConfig(appini, 'CONTROLS', 'AIMONOCOLOR', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIMONOCOLOR', "0")
            end
        end
        if bAImonocolor then
            ui.sameLine(0,20)
            ui.colorButton('Single Color for AI line:', editcolor3, ui.ColorPickerFlags.PickerHueBar)
            if editcolor3 ~= rgbSingleColor then
                rgbSingleColor = editcolor3:clone()
                writeACConfig(appini, 'USERSETTINGS', 'AISINGLECOLOR', rgbSingleColor)
            end
        end

        -- editF = ui.slider('##Finish', editF, 0.0, 1.0, 'Finish: %.8f', 1 )
        if ui.checkbox("ideal", bAIideal) then
            bAIideal = not bAIideal
            if bAIideal then
                writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "0")
            end
        end
        ui.sameLine(0,5)
        if ui.checkbox("green", bAIonlyWhenNotGreen) then
            bAIonlyWhenNotGreen = not bAIonlyWhenNotGreen
            if bAIonlyWhenNotGreen then
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTGREEN', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTGREEN', "0")
            end
        end
        ui.sameLine(0,5)
        if ui.checkbox("yellow", bAIonlyWhenNotYellow) then
            bAIonlyWhenNotYellow = not bAIonlyWhenNotYellow
            if bAIonlyWhenNotYellow then
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTYELLOW', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTYELLOW', "0")
            end
        end
        ui.sameLine(245,0)
        ai_renderlength, changed = ui.slider('##ideal parts to draw', ai_renderlength, 2, math.max(10, #BLeft), "ideal parts to draw: %d" % ai_renderlength, 2)
        if changed then
            ai_renderlength = math.floor(ai_renderlength)
            writeACConfig(appini, 'USERSETTINGS', 'AI_RENDERLENGTH', ai_renderlength)
        end

        ui.sameLine(0,20)
        ui.setNextItemWidth(150)
        CUSTOM_MULT, changed = ui.slider('##AI offset', CUSTOM_MULT, 0.5, 5.0 , "AI offset: %.2f" % CUSTOM_MULT, 1)
        if changed then
            CUSTOM_MULT = math.round(CUSTOM_MULT, 2)
            writeACConfig(appini, 'USERSETTINGS', 'CUSTOM_MULT', CUSTOM_MULT)
        end


    end

    ui.setNextItemWidth(100)
    leadinCount, changed = ui.slider('##lead in', leadinCount, 1, 100, "lead in: %d" % leadinCount, 1)
    if changed then
        writeACConfig(appini, 'USERSETTINGS', 'LEADINCOUNT', leadinCount)
    end
    ui.sameLine(0,20)
    ui.setNextItemWidth(150)
    glowmult, changed = ui.slider('##border/ideal glow', glowmult, 1, 300, "border/ideal glow: %d" % glowmult, 2)
    if changed then
        --glowmult = glowmult
        writeACConfig(appini, 'USERSETTINGS', 'GLOWMULT', glowmult)
    end

    if #BGas>0 and #BBrake>0 and ac.getPatchVersionCode()>=3044 then
        ui.sameLine(0,20)
        ui.setNextItemWidth(160)
        idealTexture, changed = ui.slider('##ideal graphic', idealTexture, 1, #TexturesAILine, "ideal graphic: %d" % idealTexture, 1)
        if changed then
            idealTexture = math.floor(idealTexture)
            texAIline = TexturesAILine[idealTexture]
            -- ac.debug("texture", texAIline)
            writeACConfig(appini, 'USERSETTINGS', 'IDEALTEXTURE', idealTexture)
        end

        ui.sameLine(0,20)
        ui.setNextItemWidth(50)
        local selected = math.floor (AIskipVar/4)
        local valid = {4,8,12,16,20,24}
        ui.combo("skip", selected, function ()
            -- for k,v in pairs(Sects) do
            for i,v in pairs(valid) do
                if ui.selectable(tostring(i), v == selected) then
                    -- JumpSection(Sects[i][1])
                    AIskipVar = i*4
                    writeACConfig(appini, 'CONTROLS', 'SKIPAIPARTS', AIskipVar)
                end
        end end)
    end


    ui.text('ideal:')
    ui.sameLine(80)
    joystickbuttonideal:control(vec2(80, 0))
    if physics.allowed() then
    ui.sameLine(180)
    ui.text('stepback:')
    ui.sameLine(230)
    joystickbuttonstepback:control(vec2(80, 0))
    ui.sameLine(330)
    ui.text('stepforw:')
    ui.sameLine(380)
    joystickbuttonstepforw:control(vec2(80, 0))
    ui.sameLine(0,0)
    ui.text('reset:')
    ui.sameLine(0,0)
    joystickbuttonreset:control(vec2(80, 0))
    else
    ui.sameLine(200)
    end
    ui.text('ai bords:')
    ui.sameLine(0,10)
    joystickbuttonAI:control(vec2(80, 0))

    if physics.allowed() then
    ui.sameLine(180)
    ui.text('sectPrev:')
    ui.sameLine(230)
    joystickbuttonsectPrev:control(vec2(80, 0))
    ui.sameLine(330)
    ui.text('sectNext:')
    ui.sameLine(380)
    joystickbuttonsectNext:control(vec2(80, 0))
    end

    --ui.newLine()
    ui.text('MEM:')
    ui.sameLine(80)
    joystickbuttonMEM:control(vec2(80, 0))
    ui.sameLine(165)
    ui.text('jump-MEM:')
    ui.sameLine(230)
    joystickbuttonJUMPMEM:control(vec2(80, 0))
    ui.sameLine(330)
    ui.text('AIoffset-')
    ui.sameLine(380)
    joystickbuttonAIoffsetDN:control(vec2(80, 0))
    ui.sameLine(0,10)
    ui.text('AIoffset+')
    ui.sameLine(0,10)
    joystickbuttonAIoffsetUP:control(vec2(80, 0))



    --ui.endOutline(rgbm(64,64,64), 0.25)
    ui.endOutline(rgbm(0.5,0.5,0.5,1), 1)
    --ui.endOutline(rgbm.colors.gray, 1000)
end

------------------------------------------------------------------------



local tooltimer = 0.0
local tooltimer5 = 1.0
local cnti = 1
local tooltimer2 = 0.1
local sesstimeleft = sim.sessionTimeLeft+0.002


function script.update(dt)


    -- ac.debug("car.ffbMultiplier", car.ffbMultiplier)
    if ffbTimer>0.0 then
        ffbTimer=ffbTimer-dt
        if ffbTimer<=0.0 then
            ac.setFFBMultiplier(lastFFB)
            lastFFB = 0.0
        end
    end

    if tooltimer2>0.0 then
        tooltimer2=tooltimer2-dt
        if tooltimer2<=0.0 then
            tooltimer2=0.1
            CheckCurrentSection()
        end
    end

    -- if sim.isWindowForeground and physics.isAvailable and Car.lapTimeMs>10.0 then
    --     CheckForStalledAI()
    -- end


    if sim.sessionTimeLeft > sesstimeleft then
        sesstimeleft = sim.sessionTimeLeft+0.002
    end

    if physics.allowed() then
        if second>0.0 then
            pushCar(dt)
            second = second - dt
        end
    end

    if keydelay>0.0 then
        keydelay = keydelay - dt
        return
    end

    if physics.allowed() then
        if keydelay<=0.0 and not sim.isReplayActive and not sim.isPaused then
            if joystickbuttonreset:down() then
                Reset()
                second = secondadd
                keydelay = 0.188
            end
            if joystickbuttonstepback:down() then
                SetBack()
                second = secondadd
                keydelay = 0.188
            end
            if joystickbuttonstepforw:down() then
                SetForw()
                second = secondadd
                keydelay = 0.188
            end
            if joystickbuttonsectPrev:down() then
                if prevSect~=nil then
                    JumpSection(prevSect[1])
                    second = secondadd
                    keydelay = 0.188
                end
            end
            if joystickbuttonsectNext:down() then
                if nextSect~=nil then
                    JumpSection(nextSect[1])
                    second = secondadd
                    keydelay = 0.188
                end
            end
        end
    end


    if joystickbuttonMEM:down() then
        local pos=car.position
        local dir=car.look
        writeACConfig(appini, 'MEM', 'POS', pos)
        writeACConfig(appini, 'MEM', 'DIR', dir)
        ui.toast(ui.Icons.Clipboard, 'Saved position.')
        keydelay = 0.188
    end
    if joystickbuttonJUMPMEM:down() then
        local pos=car.position
        local dir=car.look
        local s = readACConfig(appini, 'MEM', 'POS', '0,0,0')
        local t = readACConfig(appini, 'MEM', 'DIR', '0,0,0')
        local ss = s:split(',')
        local tt = t:split(',')
        pos = vec3(tonumber(ss[1]), tonumber(ss[2]), tonumber(ss[3]))
        dir = vec3(tonumber(tt[1]), tonumber(tt[2]), tonumber(tt[3]))
        physics.setCarPosition(0, pos, dir)
        keydelay = 0.188
    end

    if joystickbuttonAIoffsetUP:down() then
        if CUSTOM_MULT<5.0 then
        CUSTOM_MULT = CUSTOM_MULT + 0.01
        keydelay = 0.088
        end
    end
    if joystickbuttonAIoffsetDN:down() then
        if CUSTOM_MULT>0.5 then
        CUSTOM_MULT = CUSTOM_MULT - 0.01
        keydelay = 0.088
        end
    end


    if joystickbuttonAI:down() then
        bAIborders = not bAIborders
        if bAIborders then
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "0")
        end
        keydelay = 0.188
    end
    if joystickbuttonideal:down() then
        bAIideal = not bAIideal
        keydelay = 0.188
        if bAIideal then
            writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "0")
        end
    end
end


---------------------------------------------------------------------------------------------
local axisX  = vec3(1, 0, 0)
local axisZ  = vec3(0, 1, 0)
local axisY  = vec3(0, 0, 1)
local axisXm  = vec3(-1, 0, 0)
local axisZm  = vec3(0, -1, 0)
local axisYm  = vec3(0, 0, -1)

local function JumpPosition(p1)
    if car ~= nil then
        -- set new car position
        --physics.setCarPosition(0, p1, axisX)
        physics.setCarPosition(0, p1, axisYm)
    end
end

local function laptime(timestamp)
    if (timestamp==nil or timestamp < 0) then
        return "--.---"
    elseif timestamp==0.0 then
        return "0:00.000"
    end

    --local function pad(n, z) z = z || 2; return ('00' + n).slice(-z); end
    local milliseconds = timestamp % 1000
    timestamp = (timestamp - milliseconds) / 1000
    local seconds = timestamp % 60
    timestamp = (timestamp - seconds) / 60
    local minutes = timestamp % 60
    local hours = (timestamp - minutes) / 60
    --local ms = tostring(milliseconds):pad(3, "0", -1)
    local ms = string.format("%03d", milliseconds)
    local ss = tostring(seconds):pad(2, "0", -1)
    local hh = tostring(hours):pad(2, "0", -1)
    if (hours > 0) then
        local mm = tostring(minutes):pad(1, "0", -1)
        return hh..":"..mm..":"..ss.."."..ms
    elseif (minutes > 0) then
        local mm = tostring(minutes):pad(1, "0", -1)
        return mm..":"..ss.."."..ms
    else
        local mm = tostring(minutes):pad(1, "0", -1)
        return mm..":"..ss.."."..ms
    end
end



--local acstate = ac.StateUi --@class ac.StateUi
--local acstate = ac.getUI()

function script.windowMain(dt)
    --ac.debug('dc', ac.StateUi)
    -- ac.debug('dc', acstate.metricsRenderCommands)
    -- ac.debug('vts', acstate.metricsRenderVertices)

    if bBackground then
        ui.drawRectFilled(vec2(0,0), vec2(ui.windowSize().x, ui.windowSize().y), rgbm(0,0,0,0.25))
    end

    --------------- section stuff
    ui.newLine()
    if ac.hasTrackSpline() then

        --ui.beginOutline()


        -- km info Text
        --ui.sameLine(ui.windowSize().x/4,0)
        ui.setCursor(vec2(20,30+fntSize))
        if bKMs or bPoT then
            -- km info Text + spline pos
            local s = ""
            if bKMs then
                if sim.trackLengthM>2000 then
                    s=math.round(car.splinePosition*sim.trackLengthM/1000, 1)..'km'
                else
                    s=math.floor(car.splinePosition*sim.trackLengthM        )..'m'
                end
            end
            if bPoT then
                s=s .. "  " .. string.format("%.4f", car.splinePosition)
                --s=laptime(car.lapTimeMs)
            end

            -- ui.pushACFont("seiko")

            --ac.perfBegin("dwriteDrawText")
            -- local start = os.preciseClock()
            ui.beginGroup()
            local uisize = ui.measureDWriteText(s, fntSizeSmall*0.8)
            --ui.dwriteDrawText(s, fntSizeSmall*0.8, vec2(40,40), rgbm.colors.white)
            DrawTextWithShadows(s, fntSizeSmall*0.8, ui.Alignment.Start, vec2(20,40+fntSize), vec2(uisize.x + fntSize/10,fntSizeSmall), false, rgbSections)
            --DrawTextACWithShadows(s, fntSizeSmall*2.8, vec2(20,40+fntSize), vec2(uisize.x + fntSize/10,fntSizeSmall), rgbSections)
            ui.endGroup()

            -- local time1 = (os.preciseClock()-start)*1000
            -- ac.debug("dwrite", time1)
            -- if time1>0.1 then
            --     ac.debug("dwrite_peak", time1)
            -- end
            -- ui.popACFont()

            -- copy PoT number value
            if ui.itemHovered() then
                if tooltimer>0.0 then
                    tooltimer=tooltimer-dt
                end
                if tooltimer>0.0 then
                    ui.tooltip(function () ui.text('click to copy PoT') end )
                end
            else
                tooltimer = 1.0
            end
            if ui.itemClicked() then
                ac.setClipboadText(tostring(math.round(car.splinePosition,8)))
                ui.toast(ui.Icons.Clipboard, tostring(math.round(car.splinePosition,8)) .. ' copied!')
            end
        end

        if #Sects>0 then
            -- prev section Text
            if bSections and prevSect~=nil then
                ui.sameLine(40,0)
                DrawTextWithShadows(prevSect[0], fntSizeSmall, ui.Alignment.Start, vec2(10+fntSize*0.8,30), vec2(ui.windowSize().x/2,fntSize), false, rgbSections)
            end

            -- current section Text
            ui.sameLine(1,0)
            if currSect>-1 then
                if bSections then
                    DrawTextWithShadows(Sects[currSect][0], fntSize, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,fntSize*2), false, rgbCurrentSection)
                else
                    DrawTextWithShadows(Sects[currSect][0], fntSize, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,fntSize*2), false, rgbCurrentSection)
                end
            else
                DrawTextWithShadows(" "      , fntSize, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,fntSize*2), false, rgbCurrentSection)
            end

            -- next section Text
            if bSections then
                if nextSect~=nil then
                    local uisize = ui.measureDWriteText(nextSect[0], fntSizeSmall)
                    DrawTextWithShadows(nextSect[0], fntSizeSmall, ui.Alignment.End, vec2(ui.availableSpaceX()-uisize.x,30), vec2(uisize.x+1,fntSize), false, rgbSections)
                end
                ui.newLine()
            end
            ui.newLine()
        end

        if physics.allowed() and not ac.isInReplayMode() and bButtons then

            DrawTextWithShadows('<', fntSize, ui.Alignment.Start, vec2(10,30), vec2(fntSize*1,fntSize*1), false, rgbSections)
            ui.sameLine(0)
            ui.setCursorX(0)
            -- small jump prev section btn
            if ui.invisibleButton('<', vec2(fntSize*2,fntSize*1.2)) then
            --if ui.button('<', vec2(fntSize*1.2,fntSize*1.2)) then
                if #Sects>0 then
                    if prevSect~=nil then
                        JumpSection(prevSect[1])
                        second = secondadd
                    end
                else
                    SetBack()
                    second = secondadd
                end
            end

            -- small jump next section btn
            DrawTextWithShadows('>', fntSize, ui.Alignment.End, vec2(ui.availableSpaceX()-fntSize*0.25,30), vec2(fntSize*1,fntSize*1), false, rgbSections)
            ui.sameLine(ui.windowSize().x-fntSize*3)
            if ui.invisibleButton('>', vec2(fntSize*2,fntSize*1.2)) then
            --if ui.button('>', vec2(fntSize*1.2,fntSize*1.2)) then
                if #Sects>0 then
                    if nextSect~=nil then
                        JumpSection(nextSect[1])
                        second = secondadd
                    end
                else
                    SetForw()
                    second = secondadd
                end
            end

            --ui.endOutline(rgbm.colors.black, 0.5)

            if #Sects>0 then
                ui.setCursor(vec2(ui.availableSpaceX()-5,40+fntSize))
                ui.setNextItemWidth(20)
                -- Sects = { ["Sector1"]="T1", ["Sector2"]="T2" }
                local selected = Sects[1][0]
                ui.combo("", selected, function ()
                    for i,v in pairs(Sects) do
                        if ui.selectable(v[0], v[0] == selected) then
                            JumpSection(Sects[i][1])
                        end
                    end end)
            end

        else
            -- ui.endOutline(rgbm.colors.black, 1)
            ui.setCursorY(ui.getCursorY()-fntSize*1.9)
        end
    end


    ui.newLine()
    --ui.newLine()
    --ui.newLine()

    if physics.allowed() and bButtons and ac.hasTrackSpline() then
        if #Sects==0 then
            ui.newLine()
        end
        if ui.button('Jump\nBack') then
            SetBack()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Jump\nForw') then
            SetForw()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Reset') then
            Reset()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Jump\nPits') then
            SetPits()
        end
        ui.sameLine(0,10)
    end

    if bButtonReload then
        ui.setCursorX(ui.windowWidth()-100)
        if ui.button("reload\nsections.ini") then
            LoadSectionsIni(sectINI)
        end
    end

    ui.newLine()

    local pos=car.position
    local dir=car.look
    if ui.button('MEM') then
        writeACConfig(appini, 'MEM', 'POS', pos)
        writeACConfig(appini, 'MEM', 'DIR', dir)
        ui.toast(ui.Icons.Clipboard, 'Saved position.')
    end
    ui.sameLine()
    if ui.button('jump MEM') then
        local s = readACConfig(appini, 'MEM', 'POS', '0,0,0')
        local t = readACConfig(appini, 'MEM', 'DIR', '0,0,0')
        local ss = s:split(',')
        local tt = t:split(',')
        pos = vec3(tonumber(ss[1]), tonumber(ss[2]), tonumber(ss[3]))
        dir = vec3(tonumber(tt[1]), tonumber(tt[2]), tonumber(tt[3]))
        physics.setCarPosition(0, pos, dir)
    end
    -- ui.sameLine()
    -- if ui.button('jump ORIGIN') then
    --     pos = vec3(0, 0, 0)
    --     dir = vec3(0, 0, 1)
    --     ac.setCurrentCamera(ac.CameraMode.Free)
    --     ac.setCameraPosition(pos)
    --     ac.setCameraDirection(dir)
    -- end

end

if ac.hasTrackSpline() then
    sectINI = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackFullID("\\") .. "\\" .. "data\\sections.ini"
    LoadSectionsIni(sectINI)
end
CreateBorders()

