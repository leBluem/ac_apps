-- JumpAIline by leBluem
--v1.9 - 11 july 2024
-- fixed prev/next sections display
--
--v1.8 - 3 july 2024
-- fixed bugs
--
--v1.7 - 2 july 2024
-- fixed silly "#" mistakes
--
--v1.6 - 1 july 2024
-- dynamic ideal line now also working with CSP 0.2.3
-- added drawing ideal/border a bit backwards too
-- removed ffb thing as it would reset your ffb to 0 in some cases
--
--v1.5 - 25 june 2024
-- fixed last fix not fixing what it should have fixed
--
--v1.4 - 21 june 2024
-- border/ideal being available too in all other modes than practice/hotlap
--
--v1.3 - 12 june 2024
-- added AI line rendering with dynamic yellow/red parts, 4 different ideal graphics available
-- reload button for "sections.ini"
-- added dropdown for Section-names
-- added PointOfTrack (PoT) display to km's, click to copy value
-- added fontsize/color/glow mult/buttons as options
--
--v1.2 - 30 april 2024
-- fixed folder missing for the app in ..ac\apps\lua\
-- FFB is turned off when jumping
--
--v1.1 - 28 april 2024
-- AI borders are projected to ground
-- added control mapping for ai borders, rendered length has a slider now
-- made km/sections optional
--
--v1.0 - 26 april 2024
-- initial version

local trackMeshes --@ac.SceneReference
local carMeshes --@ac.SceneReference
trackMeshes = ac.findNodes('trackRoot:yes'):findMeshes("?")
carMeshes = ac.findNodes('carsRoot:yes'):findMeshes("?")

ac.setWindowTitle('main', tostring(#trackMeshes).." track  /  " ..tostring(#carMeshes).." car objs" ..
  " - JumpAILine v1.9")

-- --   clone meshes test not working :(  -- --
-- local carMeshes ---@ac.SceneReference
-- local newMesh ---@ac.SceneReference
-- carMeshes = ac.findNodes('carsRoot:yes'):findMeshes("estprelude_doorglass_L")
-- if carMeshes then
--     local vertices = carMeshes:getVertices() -- getVertices()
--     --local indices = carMeshes:getVertices():
--     ac.debug("vertices", vertices)
--     if vertices then
--         newMesh = carMeshes:clone() -- :createMesh("newglass", carMeshes:materialName(1), vertices, , true, true )
--         if newMesh then
--             ac.debug("newMesh", newMesh)
--             newMesh:setPosition(newMesh:getPosition() + axisZ*0.5 )  --alterVertices()
--         end
--     end
-- end




local BLeft={}
local BRight={}
local BDir={}
local BIdealL={}
local BIdealR={}
local BGas={}
local BBrake={}
local Sects = {}




-- local aiFolder = ac.getFolder(ac.FolderID.CurrentTrackLayout)..'\\ai\\'
local aiFolder = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackFullID("\\") .. "\\ai\\"
local dataFolder = ac.getFolder(ac.FolderID.CurrentTrackLayout)..'\\data\\'
local splineFilename = aiFolder..'fast_lane.ai'
--splineFilename = dataFolder..'ideal_line.ai'





-- -- local AISpline = require('AISpline')
-- -- local spline = nil ---@type AISpline
-- -- if io.fileExists(splineFilename) then
-- --     spline = AISpline(splineFilename)
-- --     ac.debug('#spline.points', #spline.points)
-- -- end

local function ReadAILINE()
    local f = io.open(splineFilename, 'rb')
    if not f then
        ac.debug("could not open 'fast_lane.ai'", splineFilename)
    else
        -- ac.perfBegin('load fast_lane')
        local pos
        local content = f:read("a")
        local header, detailCount, u1, u2 = 0, 0, 0, 0

        -- 4 floats -- header, detailCount, u1, u2
        header, pos = string.unpack("=I4", content, pos)
        detailCount, pos = string.unpack("=I4", content, pos)
        _, pos = string.unpack("=I4", content, pos)
        _, pos = string.unpack("=I4", content, pos)

        local x,y,z,dist,id=0.0,0.0,0.0,0.0,0
        for i = 1, detailCount do
            -- 4 floats, one integer
            x,    pos = string.unpack("=f", content, pos)
            y,    pos = string.unpack("=f", content, pos)
            z,    pos = string.unpack("=f", content, pos)
            dist, pos = string.unpack("=f", content, pos)
            id,   pos = string.unpack("=I4", content, pos)
        end

        BGas = table.new(detailCount,0)
        BBrake = table.new(detailCount,0)
        -- ac.debug("detailCount", detailCount)
        local gas, brake = 1.0, 1.0
        for i = 1, detailCount do
            -- 18 floats
            _,    pos = string.unpack("=f", content, pos)  -- speed         float()
            _,    pos = string.unpack("=f", content, pos)  -- gas           float()
            gas,  pos = string.unpack("=f", content, pos)  -- brake         float()
            brake,pos = string.unpack("=f", content, pos)  -- obsoleteLatG  float()
            _,    pos = string.unpack("=f", content, pos)  -- radius        float()
            _,    pos = string.unpack("=f", content, pos)  -- sideLeft      float()
            _,    pos = string.unpack("=f", content, pos)  -- sideRight     float()
            _,    pos = string.unpack("=f", content, pos)  -- camber        float()
            _,    pos = string.unpack("=f", content, pos)  -- direction     float()
            _,    pos = string.unpack("=f", content, pos)  -- normal        vec3x()
            _,    pos = string.unpack("=f", content, pos)  -- normal        vec3y()
            _,    pos = string.unpack("=f", content, pos)  -- normal        vec3z()
            _,    pos = string.unpack("=f", content, pos)  -- length        float()
            _,    pos = string.unpack("=f", content, pos)  -- forwardVector vec3x()
            _,    pos = string.unpack("=f", content, pos)  -- forwardVector vec3y()
            _,    pos = string.unpack("=f", content, pos)  -- forwardVector vec3z()
            _,    pos = string.unpack("=f", content, pos)  -- tag           float()
            _,    pos = string.unpack("=f", content, pos)  -- grade         float()
            BGas[i] = gas
            BBrake[i] = brake
        end
        f:close()
        -- ac.perfEnd('load fast_lane')
    end
end
if ac.getPatchVersionCode()>=3044 then
    ReadAILINE()
end



local sim = ac.getSim()
local car = ac.getCar(0)
local carp = ac.getCarPhysics(0)
local carNode = ac.findNodes('carRoot:0')
local carstw = carNode:findNodes('STEER_HR')
carMeshes = carstw:findMeshes('?')



local pushForce = 150
local second = 0.0
local secondadd = 0.25
local gapdefault = 0.3
local currSect = 0
local prevSect = nil
local nextSect = nil
local keydelay = 0.0


local function readACConfig(ini, sec, key, def)
    local inifile = ac.INIConfig.load(ini)
    return inifile:get(sec, key, def)
end
local function writeACConfig(ini, sec, key, val)
    local inifile = ac.INIConfig.load(ini)
    inifile:set(sec, key, val)
    inifile:save(ini)
end

local sTrack = string.lower( ac.getTrackID() )
local sCar = string.lower( ac.getCarID(0) )
local sLayout = string.lower( ac.getTrackLayout() )
local sectINI = ""
local appini = 'apps/lua/JumpAILine/JumpAILine.ini'
local vidini = ac.getFolder('ac.FolderID.Cfg')..'/video.ini'
local acini = ac.getFolder('ac.FolderID.Root')..'/system/cfg/assetto_corsa.ini'

local WheelHidden = tonumber( readACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '0') )
local DriverHidden = tonumber( readACConfig(acini, 'DRIVER', 'HIDE', '0') )

local fntSize = 18
local fntSizeSmall = 12
fntSize = readACConfig(appini, 'USERSETTINGS', 'FONTSIZE', 18)
fntSizeSmall = math.floor(0.666*fntSize)

local TexturesAILine = {}
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/content/texture/ideal_line.png'                   )
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_mono.png'          )
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_mono_slim.png'     )
table.insert(TexturesAILine, ac.getFolder(ac.FolderID.Root)..'/apps/lua/JumpAILine/ideal_line_mono_slim_tiny.png')
local idealTexture = math.floor(tonumber( readACConfig(appini, 'USERSETTINGS', 'IDEALTEXTURE', 1) ))
local texAIline = TexturesAILine[idealTexture]
local rendertex = render.glTexture(texAIline)
local idealscale = 1
local bDrawWalls = false -- true





local glowmult   = tonumber( readACConfig(appini, 'USERSETTINGS', 'GLOWMULT', 10) )
local jumpdist   = tonumber( readACConfig(appini, 'USERSETTINGS', 'JUMPDIST', 50) )
-- rendered IdealLine parts
local ai_renderlength = tonumber( readACConfig(appini, 'USERSETTINGS', 'AI_RENDERLENGTH', 50) )
-- rendered Border parts
local border_renderlength = tonumber( readACConfig(appini, 'USERSETTINGS', 'BORDER_RENDERLENGTH', 50) )
-- part length in meters
local partlen = math.floor ( readACConfig(appini, 'USERSETTINGS', 'BORDER_DISTANCE', 1) )
local brdDist = 1.5525 --math.floor ( readACConfig(appini, 'USERSETTINGS', 'BORDER_DISTANCE', 1) )
-- percent of spline length
local borderDist = brdDist/sim.trackLengthM   --- those meters above in percent of track
-- draw AI line and borders a bit behind the car
local leadinCount = tonumber( readACConfig(appini, 'USERSETTINGS', 'LEADINCOUNT', 0) )


local joystickbuttonideal    = ac.ControlButton('__APP_JumpAILINE_ideal')
local joystickbuttonreset    = ac.ControlButton('__APP_JumpAILINE_reset')
local joystickbuttonstepback = ac.ControlButton('__APP_JumpAILINE_stepback')
local joystickbuttonstepforw = ac.ControlButton('__APP_JumpAILINE_stepforw')
local joystickbuttonsectPrev = ac.ControlButton('__APP_JumpAILINE_sectPrev')
local joystickbuttonsectNext = ac.ControlButton('__APP_JumpAILINE_sectNext')
local joystickbuttonAI       = ac.ControlButton('__APP_JumpAILINE_AI')
local bBackground       = true --$boolean
if readACConfig(appini, 'CONTROLS', 'BACKGROUND', "0") == "0" then bBackground = false end
local bKMs       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'KMs', "0") == "1" then bKMs = true end
local bPoT       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'PoT', "0") == "1" then bPoT = true end
local bSections       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'Sections', "1") == "1" then bSections = true end
local bButtons       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'Buttons', "1") == "1" then bButtons = true end
local bAIborders       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIBORDERS', "0") == "1" then bAIborders = true end
local bAIideal       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIIDEAL', "0") == "1" then bAIideal = true end
local bAIonlyWhenNotGreen       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIWHENNOTGREEN', "1") == "1" then bAIonlyWhenNotGreen = true end
local bAIonlyWhenNotYellow       = false --$boolean
if readACConfig(appini, 'CONTROLS', 'AIWHENNOTYELLOW', "1") == "1" then bAIonlyWhenNotYellow = true end



local rgbSections = rgbm.colors.white
local rgbCurrentSection --@rgbm
local editcolor --@rgbm
local scol = readACConfig(appini, 'USERSETTINGS', "SECTIONCOLOR", "0.5,1,0.5,1")
if scol~="" then
    local col = string.split(scol,',')
    rgbCurrentSection = rgbm(tonumber(col[1]), tonumber(col[2]), tonumber(col[3]), 1)
    editcolor = rgbCurrentSection:clone()
end


local textsteer = ''
local textdriver = ''
local p1 = vec3(0,0,0)
local p2 = vec3(0,0,0)
local p3 = vec3(0,0,0)
local dist = 0.0
local cSpline = 0.0





local first = true
local function LoadSectionsIni(sectINI)
-- [SECTION_0]
-- IN=0.152
-- OUT=0.190
-- TEXT=T1
    table.clear(Sects)
    if not io.fileExists(sectINI) then
        ac.debug('sectINI not found:', sectINI)
        if first then
            first=false
        else
            ui.toast(ui.Icons.AppWindow, 'sections.ini not found:'..sectINI)
        end
    else
        local i = 0
        local sectName = "SECTION_"..i
        local sectText = readACConfig(sectINI, sectName, "TEXT", "")
        while sectText ~= "" do
            local sectIN = tonumber ( readACConfig(sectINI, sectName, "IN", "-1") )
            local sectOUT = tonumber ( readACConfig(sectINI, sectName, "OUT", "-1") )
            if sectIN>-1 and sectOUT>-1 then
                table.insert(Sects, i, {[0]=sectText, [1]=sectIN, [2]=sectOUT})
            end
            i=i+1
            sectName = "SECTION_"..i
            sectText = readACConfig(sectINI, sectName, "TEXT", "")
        end
        -- make sure its sorted
        table.sort(Sects, function (a, b) return a[1] < b[1] end)
        if first then
            first=false
        else
            ui.toast(ui.Icons.AppWindow, 'sections.ini Loaded!')
        end
    end
end


local function CheckIfInsideINOUT(pin, pout, splinepos)
    if pout<pin then
        -- from end of track, wrapping over to start of track/next lap
        if splinepos>pin then
            return true
        elseif splinepos<pout then
            return true
        end
    else
        -- normal section has to be inside those two bounds
        if splinepos>=pin and splinepos<pout then
            return true
        end
    end
    return false
end

local function CheckCurrentSection()
    if car ~= nil then
        local cSpline = car.splinePosition
        local lastS = -1
        currSect = -1
        prevSect = nil
        nextSect = nil
        for k,v in pairs(Sects) do
            if CheckIfInsideINOUT(v[1], v[2], cSpline) then
                if k+1<=#Sects then
                    nextSect = Sects[k+1]
                else
                    nextSect = Sects[0]
                end
                currSect = k
                break
            end
            if cSpline<v[1] and cSpline<v[2] then
                break
            end
            lastS = k
        end
        if currSect>=0 then
            if currSect-1>-1 then
                prevSect = Sects[currSect-1]
            else
                prevSect = Sects[#Sects]
            end
            if currSect+1>#Sects then
                nextSect = Sects[0]
            else
                nextSect = Sects[currSect+1]
            end
        else
            if lastS==-1 then
                prevSect = Sects[#Sects]
            else
                prevSect = Sects[lastS]
            end
            if lastS+1<=#Sects then
                nextSect=Sects[lastS+1]
            else
                nextSect=Sects[0]
            end
        end
    end
end





local function SetBack()
  if car ~= nil then
    cSpline = car.splinePosition
    p1 = ac.trackProgressToWorldCoordinate(cSpline)
    p3 = p1
    p2 = p3
    dist = 0.0
    while dist<=jumpdist and dist<sim.trackLengthM do
      cSpline = cSpline - 0.0001
      if cSpline<0.0 then
        cSpline = cSpline + 1.0
      end
      p3 = p2
      p2 = ac.trackProgressToWorldCoordinate(cSpline)
      dist = p1:distance(p2)
    end
    if cSpline>0.0 then
        physics.setCarPosition(0, p2, vec3(p2.x-p3.x,p2.y-p3.y,p2.z-p3.z))
        --physics.setCarPosition(0, pos, vec3(1,0,0))
    end
  end
end


local function SetForw()
  if car ~= nil then
    cSpline = car.splinePosition --# -0.001
    if cSpline<0.0 then
      cSpline=0.999
    end
    p1 = ac.trackProgressToWorldCoordinate(cSpline)
    p3 = p1
    p2 = p3
    dist = 0.0
    while dist<=jumpdist and dist<sim.trackLengthM do
      cSpline = cSpline + 0.0001
      if cSpline>1.0 then
        cSpline = 0.0
      end
      p3 = p2
      p2 = ac.trackProgressToWorldCoordinate(cSpline)
      dist = p1:distance(p2)
    end
    if cSpline>0.0 then
        physics.setCarPosition(0, p2, vec3(p3.x-p2.x,p3.y-p2.y,p3.z-p2.z))
        --physics.setCarPosition(0, pos, vec3(1,0,0))
    end
  end
end

local function Reset()
    ac.resetCar()
end

local function SetPits()
    physics.teleportCarTo(0, ac.SpawnSet.Pits)
end


local function settexts()
  if WheelHidden==1 then
    textsteer = 'Show\nstwheel'
  else
    textsteer = 'Hide\nstwheel'
  end
  if DriverHidden==1 then
    textdriver = 'Show\ndriver'
  else
    textdriver = 'Hide\ndriver'
  end
end
settexts()


local function ToggleSteeringWheel()
  if carMeshes~=nil then
    if WheelHidden==0 then
      WheelHidden = 1
      carMeshes:setVisible(false)
      writeACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '1')
    else
      WheelHidden = 0
      carMeshes:setVisible(true)
      writeACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '0')
    end
  end
  settexts()
end

local function ToggleDriver()
  if car.isDriverVisible then
    DriverHidden = 1
    ac.setDriverVisible(0, false)
    writeACConfig(acini, 'DRIVER', 'HIDE', '1')
  else
    DriverHidden = 0
    ac.setDriverVisible(0, true)
    writeACConfig(acini, 'DRIVER', 'HIDE', '0')
  end
  settexts()
end

function CheckForStalledAI()
    if physics.allowed() then
        for i=2, sim.carsCount do
            local carl = ac.getCar(i)
            if carl and
               carl.isAIControlled and
               not carl.isInPit and
               not carl.isInPitlane and
               carl.speedKmh<5
            then
                --if sim.physicsLate>10 then
                physics.teleportCarTo(i, ac.SpawnSet.Pits)
            end
        end
    end
end



---------------------------------------------------------------------------------------------

local function DrawTextWithShadows(s, fntsize, algn, xy1, xy2, wrap, col)
    local xy3 = xy1
    local xy4 = xy2
    xy3.x=xy3.x-2
    xy3.y=xy3.y-2
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy3, xy4, wrap, rgbm.colors.black )
    xy3.x=xy3.x-1
    xy3.y=xy3.y-1
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy3, xy4, wrap, rgbm.colors.black )
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy1, xy2, wrap, col )
end



local function JumpSection(cSpline)
    if car ~= nil then
        local p1 = ac.trackProgressToWorldCoordinate(cSpline)
        local p3 = p1
        local p2 = p3
        local dist = 0.0
        local cSpline2 = cSpline

        while dist<=1 and dist<sim.trackLengthM do
            cSpline2 = cSpline2 + 0.001
            if cSpline2>1.0 then
                cSpline2 = 0.0
            end
            p3 = p2
            p2 = ac.trackProgressToWorldCoordinate(cSpline2)
            dist = p1:distance(p2)
        end

        if dist>0.0 then
            -- set new car position
            local direction = vec3(p3.x-p2.x,p3.y-p2.y,p3.z-p2.z)
            physics.setCarPosition(0, p2, direction)
        end
    end
end




local function pushCar(dt)
    local passivePush = pushForce * car.mass * dt * 100 * car.gas
    --ac.debug("passivePush", passivePush)
    physics.addForce(0, vec3(0, 0, 0), true, vec3(0, 0, passivePush), true)
end








local vUp = vec3(0, 1, 0)
local vDown = vec3(0, -1, 0)

local function snapToTrackSurface(pos, gap)
    local p = pos
    local v1 = vec3()
    physics.raycastTrack(v1:set(0, 10, 0):add(p), vDown, 20, p) --, v1)
    p.y = p.y + (gap or 0.3)
end

local function CreateBorders()
    if car ~= nil and borderDist>0.0 and ac.hasTrackSpline() then
        local carState = ac.getCar(0)
        BLeft={}
        BRight={}
        BDir={}
        BIdealL={}
        BIdealR={}

        local cSpline2 = 0
        local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
        local side = ac.getTrackAISplineSides(cSpline2)
        cSpline2 = borderDist
        local p2 = ac.trackProgressToWorldCoordinate(cSpline2)
        local c = 1
        local lastdir = -1080.0
        while cSpline2<=1.0 do
            if c==1 then
                side = vec2(side.y, side.x)
                c=c+1
            end
            --dist = p1:distance(p2)
            --dist>=1.0 and
            --if p1~=p2 and p2.x~=0 and p2.y~=0 and p2.z~=0 then
            local dir = -math.deg( math.atan2(p1.z-p2.z, p1.x-p2.x) )
            local roll = -math.deg( math.atan2(p1.x-p2.x, p1.z-p2.z) )
            local xL = p1.x + math.cos((dir + 90) * math.pi / 180) * side.x
            local yL = p1.z - math.sin((dir + 90) * math.pi / 180) * side.x
            local xR = p1.x + math.cos((dir - 90) * math.pi / 180) * side.y
            local yR = p1.z - math.sin((dir - 90) * math.pi / 180) * side.y
            local zL = p1.y+0.5
            local zR = p1.y+0.5
            local p4 = vec3(xL, zL, yL)
            local p5 = vec3(xR, zR, yR)

            snapToTrackSurface(p4, gapdefault)
            snapToTrackSurface(p5, gapdefault)
            snapToTrackSurface(p1, 0.05)

            table.insert(BLeft, p4)
            table.insert(BRight, p5)
            --table.insert(BDir, dir)
            if lastdir~=-1080.0 then
                table.insert(BDir, math.rad((dir+lastdir)/2))
            end
            lastdir = dir

            local v1 = vec3(p1.x + math.cos((dir + 90) * math.pi / 180)*idealscale, p1.y, p1.z - math.sin((dir + 90) * math.pi / 180)*idealscale)
            local v2 = vec3(p1.x + math.cos((dir - 90) * math.pi / 180)*idealscale, p1.y, p1.z - math.sin((dir - 90) * math.pi / 180)*idealscale)
            snapToTrackSurface(v1, 0.05)
            snapToTrackSurface(v2, 0.05)
            table.insert(BIdealL, v1)
            table.insert(BIdealR, v2)

            p1:copyTo(p2)
            cSpline2 = cSpline2 + borderDist
            p1 = ac.trackProgressToWorldCoordinate(cSpline2)
            side = ac.getTrackAISplineSides(cSpline2)
        end -- while

        -- must interpolate first bc might be a strange distance from last
        BLeft   [1] = vec3((BLeft  [2].x+BLeft  [#BLeft  ].x)/2, (BLeft  [2].y+BLeft  [#BLeft  ].y)/2, (BLeft  [2].z+BLeft  [#BLeft  ].z)/2)
        BRight  [1] = vec3((BRight [2].x+BRight [#BRight ].x)/2, (BRight [2].y+BRight [#BRight ].y)/2, (BRight [2].z+BRight [#BRight ].z)/2)
        BIdealL [1] = vec3((BIdealL [2].x+BIdealL [#BIdealL ].x)/2, (BIdealL [2].y+BIdealL [#BIdealL ].y)/2, (BIdealL [2].z+BIdealL [#BIdealL ].z)/2)
        BIdealR [1] = vec3((BIdealR [2].x+BIdealR [#BIdealR ].x)/2, (BIdealR [2].y+BIdealR [#BIdealR ].y)/2, (BIdealR [2].z+BIdealR [#BIdealR ].z)/2)

    end -- if car ~= nil
end

local function DrawBorders(cSpline)
    if #BLeft>0 then
        local stepswanted = border_renderlength -- 50 --math.floor(#BLeft)
        --local stepswanted = math.floor(#BLeft / 2)
        local currID = math.floor(cSpline * #BLeft) - 1 - leadinCount
        currID = currID - currID % partlen
        local nextID = currID + partlen
        local stepsdone = 0
        while stepsdone<stepswanted do
            --ac.debug(stepsdone.."stepsdone", stepsdone)
            if currID>#BLeft then
                currID = 1
                nextID = partlen
            end
            if nextID>#BLeft then
                nextID = nextID - #BLeft
                -- ac.debug("currID", currID)
                -- ac.debug("nextID", nextID)
            end
            if BLeft[nextID] and BLeft [currID] and currID>0 and nextID>0 and currID<#BLeft and nextID<#BLeft then
                if bDrawWalls then
                    render.debugPlane(vec3((BLeft [currID]+BLeft [nextID])/2),
                                vec3(
                                    -math.sin(BDir[currID]),
                                    0,
                                    -math.cos(BDir[currID])
                                ),
                                rgbm.colors.red*glowmult/4, 3)
                    render.debugPlane(vec3((BRight [currID]+BRight [nextID])/2),
                                vec3(
                                    math.sin(BDir[currID]),
                                    0,
                                    math.cos(BDir[currID])
                                ),
                                rgbm.colors.red*glowmult/4, 3)
                else
                    render.debugLine(BLeft [currID], BLeft [nextID], rgbm.colors.red*glowmult/4)
                    render.debugLine(BRight[currID], BRight[nextID], rgbm.colors.red*glowmult/4)
                    -- render.debugCross(BLeft [currID], 1, rgbm.colors.red)
                    -- render.debugCross(BRight[currID], 1, rgbm.colors.red)
                end
            end

            stepsdone = stepsdone + partlen
            currID = currID + partlen
            nextID = currID + partlen
        end
    end
end




local function DrawAILine(cSpline)
    -- if spline then
    if car and #BGas>0 and #BBrake>0 then
        local stepswanted = ai_renderlength
        local currID = math.floor(cSpline * #BLeft) + 1 - leadinCount
        currID = currID - ((currID % 4))
        local nextID = currID + 1
        -- local currIDSP = math.floor(cSpline * #spline.points) + 1
        local currIDSP = math.floor(cSpline * #BGas)+1
        currIDSP = currIDSP - ((currIDSP % 4))
        local nextIDSP = currIDSP + 1
        local stepsdone = 0

        -- if currIDSP<#spline.payloads and currIDSP>1 then
        --     local speeddiff = car.speedKmh - spline.payloads[currIDSP].speed
        --     ac.debug("speed__diff", speeddiff)
        --     -- ac.debug("speed_curr", car.speedKmh)
        --     -- ac.debug("tag_should", spline.payloads[currID].tag)
        --     -- ac.debug("car.splinePosition"               , car.splinePosition)
        --     -- ac.debug("brake", spline.payloads[currIDSP].brake)
        --     -- ac.debug("gas", spline.payloads[currIDSP].gas)
        --     -- ac.debug("grade", spline.payloads[currIDSP].grade*100)
        --     -- ac.debug("obsoleteLatG", spline.payloads[currIDSP].obsoleteLatG)
        --     ac.debug("speed", spline.payloads[currIDSP].speed)
        --     -- ac.debug("normal", spline.payloads[currIDSP].normal)
        --     -- ac.debug("gas*speed", spline.payloads[currIDSP].gas*spline.payloads[currIDSP].speed)
        --     -- ac.debug("camber", spline.payloads[currIDSP].camber)
        -- end
        -- ac.debug("len ailine", #BBrake)
        -- ac.debug("len borders", #BLeft)
        -- ac.debug("brdDist*car.speedKmh/1000", brdDist) -- *car.speedKmh/5)

        local ucTurn = ac.getTrackUpcomingTurn(0)
        render.setBlendMode(4)
        -- ac.debug("ucTurn.y angle", ucTurn.y)
        -- ac.debug("ucTurn.x dist ", ucTurn.x)
        -- ac.debug("gas", spline.payloads[currIDSP].gas)
        -- ac.debug("brake", spline.payloads[currIDSP].brake)


        while stepsdone<stepswanted do
            if currIDSP==0 then
                currIDSP = 1
                nextIDSP = 4
            end
            if currIDSP>#BGas then
                currIDSP = currIDSP - #BGas
                nextIDSP = currIDSP+4
                if nextIDSP>#BGas then
                    nextIDSP = nextIDSP - #BGas
                end
            end
            if currID==0 then
                currID = 1
                nextID = 4
            end
            if currID>#BLeft then
                currID = currID - #BLeft
                nextID = currID+4
                if nextID>#BLeft then
                    nextID = nextID - #BLeft
                end
            end
            if stepsdone>2 then
                local rgb = 1
                local color = rgbm(0,rgb,0,glowmult/4)
                if    (math.abs(ucTurn.y)>=40
                        and ucTurn.x<brdDist*car.speedKmh/10
                        and BGas[currIDSP]<=0.1)

                        or BBrake[currIDSP]>=0.001
                    --     and spline.payloads[currIDSP].gas<=0.1)
                    --  or spline.payloads[currIDSP].brake>=0.001
                then
                    color = rgbm(rgb,0,0,glowmult/4)
                    render.glSetColor(color)
                    render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
                elseif ((math.abs(ucTurn.y)>=25 and ucTurn.x<brdDist*car.speedKmh/5) or
                    (BGas[currIDSP]<=0.0) ) and
                    not (BGas[currIDSP]==0.0 and
                    BBrake[currIDSP]==0.0)
                    -- (spline.payloads[currIDSP].gas<=0.0) ) and
                    --    not (spline.payloads[currIDSP].gas==0.0 and
                    --         spline.payloads[currIDSP].brake==0.0)
                then
                    if bAIonlyWhenNotYellow then
                        color = rgbm(rgb,rgb,0,glowmult/4)
                        render.glSetColor(color)
                        render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
                    end
                elseif bAIonlyWhenNotGreen then
                    color = rgbm(0,rgb,0,glowmult/4)
                    render.glSetColor(color)
                    render.quad(BIdealL[currID], BIdealR[currID], BIdealR[nextID], BIdealL[nextID], color, texAIline)
                end

                --render.glBegin(render.GLPrimitiveType.Quads)
                --render.quad(v1, v2, v3, v4, color, rendertex)
                --render.glEnd()
            end
            stepsdone = stepsdone + 4
            currIDSP = currIDSP + 1
            nextIDSP = currIDSP + 1
            currID = currID + 4
            nextID = currID + 4
        end
        --render.glEnd()
    end
end



function script.Draw3D(dt)  --script.renderTrack()
    if ac.hasTrackSpline() then
        if bAIborders then
            DrawBorders(car.splinePosition)
        end
        if bAIideal then
            DrawAILine(car.splinePosition)
        end
    end
end


function script.windowSettings(dt)

    ui.beginOutline()
    if ui.button(textsteer) then
        ToggleSteeringWheel()
    end
    ui.sameLine(0,10)
    if ui.button(textdriver) then
        ToggleDriver()
    end
    ui.sameLine(0,5)
    if ui.checkbox("km's", bKMs) then
        bKMs = not bKMs
        if bKMs then
            writeACConfig(appini, 'CONTROLS', 'KMs', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'KMs', "0")
        end
    end
    ui.sameLine(0,5)
    if ui.checkbox("PoT %", bPoT) then
        bPoT = not bPoT
        if bPoT then
            writeACConfig(appini, 'CONTROLS', 'PoT', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'PoT', "0")
        end
    end
    ui.sameLine(0,5)
    if ui.checkbox("next/prev  ", bSections)
    then
        bSections = not bSections
        if bSections then
            writeACConfig(appini, 'CONTROLS', 'Sections', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'Sections', "0")
        end
    end
    ui.sameLine(0,5)
    if ui.checkbox("buttons", bButtons)
    then
        bButtons = not bButtons
        if bButtons then
            writeACConfig(appini, 'CONTROLS', 'Buttons', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'Buttons', "0")
        end
    end
    ui.sameLine(0,10)
    if physics.allowed() then
        ui.bulletText('extPhysics enabled')
    else
        ui.bulletText('no extPhysics avail')
    end
    if #BGas==0 or BBrake==0 or ac.getPatchVersionCode()<3044 then
        ui.newLine(0)
        ui.sameLine(320)
        ui.setCursorY(ui.getCursorY()-ac.getUI().uiScale*10)
        ui.bulletText("could not open ai line, CSP 0.2.3 needed!\n"..
                      "dynamic AI line not available")
    end

    ui.setNextItemWidth(50)
    if ui.checkbox("background      ", bBackground) then
        bBackground = not bBackground
        if bBackground then
            writeACConfig(appini, 'CONTROLS', 'BACKGROUND', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'BACKGROUND', "0")
        end
    end

    ui.sameLine(0,0)
    ui.setNextItemWidth(250)
    fntSize, changed = ui.slider('##Font size:', fntSize, 6, 64, "Font size: %d" % fntSize, 1)
    if changed then
        fntSize = math.floor(fntSize)
        fntSizeSmall = math.floor(0.666*fntSize)
        writeACConfig(appini, 'USERSETTINGS', 'FONTSIZE', fntSize)
    end
    ui.sameLine(0,40)
    --ui.newLine()
    ui.colorButton('Current Section color', editcolor, ui.ColorPickerFlags.PickerHueBar)
    if editcolor ~= rgbCurrentSection then
        rgbCurrentSection = editcolor:clone()
        writeACConfig(appini, 'USERSETTINGS', 'SECTIONCOLOR', rgbCurrentSection)
    end

    ui.setNextItemWidth(450)
    jumpdist, changed = ui.slider('##jumpdist', jumpdist, 0, math.max(400, math.floor(sim.trackLengthM/2)), "jumpdist: %d meter" % jumpdist, 1)
    if changed then
        jumpdist = math.floor(jumpdist)
        writeACConfig(appini, 'USERSETTINGS', 'JUMPDIST', jumpdist)
    end

    if ui.checkbox("borders", bAIborders) then
        bAIborders = not bAIborders
        if bAIborders then
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "0")
        end
    end


    ui.sameLine(0,20)
    ui.setNextItemWidth(80)
    partlen, changed = ui.slider('##part len', partlen, 1, 32, 'part len: %dm' % partlen, 1 )
    if changed then
        partlen = math.floor(partlen)
        -- no!1!11!
        -- borderDist = brdDist/sim.trackLengthM   --- those meters above in percent of track
        writeACConfig(appini, 'USERSETTINGS', 'BORDER_DISTANCE', partlen)
        -- CreateBorders()
    end


    ui.sameLine(245,0)
    border_renderlength, changed = ui.slider('##border parts to draw', border_renderlength, 2, math.max(10, #BLeft), "border parts to draw: %d" % border_renderlength, 2)
    if changed then
        border_renderlength = math.floor(border_renderlength)
        writeACConfig(appini, 'USERSETTINGS', 'BORDER_RENDERLENGTH', border_renderlength)
    end



    if #BGas>0 and #BBrake>0 and ac.getPatchVersionCode()>=3044 then

        -- editF = ui.slider('##Finish', editF, 0.0, 1.0, 'Finish: %.8f', 1 )
        if ui.checkbox("ideal", bAIideal) then
            bAIideal = not bAIideal
            if bAIideal then
                writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "0")
            end
        end
        ui.sameLine(0,5)
        if ui.checkbox("green", bAIonlyWhenNotGreen) then
            bAIonlyWhenNotGreen = not bAIonlyWhenNotGreen
            if bAIonlyWhenNotGreen then
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTGREEN', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTGREEN', "0")
            end
        end
        ui.sameLine(0,5)
        if ui.checkbox("yellow", bAIonlyWhenNotYellow) then
            bAIonlyWhenNotYellow = not bAIonlyWhenNotYellow
            if bAIonlyWhenNotYellow then
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTYELLOW', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIWHENNOTYELLOW', "0")
            end
        end
        ui.sameLine(245,0)
        ai_renderlength, changed = ui.slider('##ideal parts to draw', ai_renderlength, 2, math.max(10, #BLeft), "ideal parts to draw: %d" % ai_renderlength, 2)
        if changed then
            ai_renderlength = math.floor(ai_renderlength)
            writeACConfig(appini, 'USERSETTINGS', 'AI_RENDERLENGTH', ai_renderlength)
        end
    end

    ui.setNextItemWidth(100)
    leadinCount, changed = ui.slider('##lead in', leadinCount, 1, 100, "lead in: %d" % leadinCount, 1)
    if changed then
        writeACConfig(appini, 'USERSETTINGS', 'LEADINCOUNT', leadinCount)
    end
    ui.sameLine(0,20)
    ui.setNextItemWidth(150)
    glowmult, changed = ui.slider('##border/ideal glow', glowmult, 1, 500, "border/ideal glow: %d" % glowmult, 1)
    if changed then
        --glowmult = glowmult
        writeACConfig(appini, 'USERSETTINGS', 'GLOWMULT', glowmult)
    end

    if #BGas>0 and #BBrake>0 and ac.getPatchVersionCode()>=3044 then
        ui.sameLine(0,20)
        ui.setNextItemWidth(100)
            idealTexture, changed = ui.slider('##ideal graphic', idealTexture, 1, 4, "ideal graphic: %d" % idealTexture, 1)
        if changed then
            --glowmult = glowmult
            idealTexture = math.floor(idealTexture)
            texAIline = TexturesAILine[idealTexture]
            -- ac.debug("texture", texAIline)
            writeACConfig(appini, 'USERSETTINGS', 'IDEALTEXTURE', idealTexture)
        end
    end

    --if physics.allowed() then

    ui.text('ideal:')
    ui.sameLine(80)
    joystickbuttonideal:control(vec2(90, 0))
    if physics.allowed() then
    ui.sameLine(180)
    ui.text('stepback:')
    ui.sameLine(230)
    joystickbuttonstepback:control(vec2(90, 0))
    ui.sameLine(330)
    ui.text('stepforw:')
    ui.sameLine(380)
    joystickbuttonstepforw:control(vec2(90, 0))
    ui.sameLine(0,0)
    ui.text('reset:')
    ui.sameLine(0,0)
    joystickbuttonreset:control(vec2(90, 0))
    else
    ui.sameLine(200)
    end
    ui.text('ai bords:')
    ui.sameLine(0,10)
    joystickbuttonAI:control(vec2(90, 0))

    if physics.allowed() then
    ui.sameLine(180)
    ui.text('sectPrev:')
    ui.sameLine(230)
    joystickbuttonsectPrev:control(vec2(90, 0))
    ui.sameLine(330)
    ui.text('sectNext:')
    ui.sameLine(380)
    joystickbuttonsectNext:control(vec2(90, 0))
    end
    ui.endOutline(rgbm.colors.black, 0.25)
end

------------------------------------------------------------------------



local tooltimer = 0.0
local tooltimer5 = 1.0
local cnti = 1
local tooltimer2 = 0.1



function script.update(dt)
    if tooltimer2>0.0 then
        tooltimer2=tooltimer2-dt
        if tooltimer2<=0.0 then
            tooltimer2=0.1
            CheckCurrentSection()
        end
    end

    if sim.isWindowForeground and physics.isAvailable and Car.lapTimeMs>10.0 then
        CheckForStalledAI()
    end


    if keydelay>0.0 then
        keydelay = keydelay - dt
        return
    end
    if physics.allowed() then
        if second>0.0 then
            pushCar(dt)
            second = second - dt
            -- ac.debug('time', second)
        end
        if keydelay<=0.0 then
            if joystickbuttonreset:down() and not sim.isReplayActive and not sim.isPaused then
                Reset()
                second = secondadd
                keydelay = 0.188
            end
            if joystickbuttonstepback:down() and not sim.isReplayActive and not sim.isPaused then
                SetBack()
                second = secondadd
                keydelay = 0.188
            end
            if joystickbuttonstepforw:down() and not sim.isReplayActive and not sim.isPaused then
                SetForw()
                second = secondadd
                keydelay = 0.188
            end
            if joystickbuttonsectPrev:down() and not sim.isReplayActive and not sim.isPaused then
                if prevSect~=nil then
                    JumpSection(prevSect[1])
                    second = secondadd
                    keydelay = 0.188
                end
            end
            if joystickbuttonsectNext:down() and not sim.isReplayActive and not sim.isPaused then
                if nextSect~=nil then
                    JumpSection(nextSect[1])
                    second = secondadd
                    keydelay = 0.188
                end
            end
        end
    end
    if joystickbuttonAI:down() and not sim.isPaused then
        bAIborders = not bAIborders
        if bAIborders then
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "0")
        end
        keydelay = 0.188
    end
    if joystickbuttonideal:down() and not sim.isPaused then
        bAIideal = not bAIideal
        keydelay = 0.188
        if bAIideal then
            writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'AIIDEAL', "0")
        end
    end
end


---------------------------------------------------------------------------------------------
local axisX  = vec3(1, 0, 0)
local axisZ  = vec3(0, 1, 0)
local axisY  = vec3(0, 0, 1)
local axisXm  = vec3(-1, 0, 0)
local axisZm  = vec3(0, -1, 0)
local axisYm  = vec3(0, 0, -1)

local function JumpPosition(p1)
    if car ~= nil then
        -- set new car position
        --physics.setCarPosition(0, p1, axisX)
        physics.setCarPosition(0, p1, axisYm)
    end
end


function script.windowMain(dt)
    if bBackground then
        ui.drawRectFilled(vec2(0,0), vec2(ui.windowSize().x, ui.windowSize().y), rgbm(0,0,0,0.25))
    end

    --------------- section stuff
    ui.newLine()
    if ac.hasTrackSpline() then

        --ui.beginOutline()


        -- km info Text
        --ui.sameLine(ui.windowSize().x/4,0)
        ui.setCursor(vec2(20,30+fntSize))
        if bKMs or bPoT then
            -- km info Text + spline pos
            local s = ""
            if bKMs then
                if sim.trackLengthM>2000 then
                    s=math.round(car.splinePosition*sim.trackLengthM/1000, 1)..'km'
                else
                    s=math.floor(car.splinePosition*sim.trackLengthM        )..'m'
                end
            end
            if bPoT then
                s=s .. "  " .. string.format("%.4f", car.splinePosition)
            end
            ui.beginGroup()
            local uisize = ui.measureDWriteText(s, fntSizeSmall*0.8)
            DrawTextWithShadows(s, fntSizeSmall*0.8, ui.Alignment.Start, vec2(20,40+fntSize), vec2(uisize.x + fntSize/10,fntSizeSmall), false, rgbSections)
            ui.endGroup()
            -- copy PoT number value
            if ui.itemHovered() then
                if tooltimer>0.0 then
                    tooltimer=tooltimer-dt
                end
                if tooltimer>0.0 then
                    ui.tooltip(function () ui.text('click to copy PoT') end )
                end
            else
                tooltimer = 1.0
            end
            if ui.itemClicked() then
                ac.setClipboadText(tostring(math.round(car.splinePosition,8)))
                ui.toast(ui.Icons.Clipboard, tostring(math.round(car.splinePosition,8)) .. ' copied!')
            end
        end

        if #Sects>0 then
            -- prev section Text
            if bSections and prevSect~=nil then
                ui.sameLine(40,0)
                DrawTextWithShadows(prevSect[0], fntSizeSmall, ui.Alignment.Start, vec2(10+fntSize*0.8,30), vec2(ui.windowSize().x/2,fntSize), false, rgbSections)
            end

            -- current section Text
            ui.sameLine(1,0)
            if currSect>-1 then
                if bSections then
                    DrawTextWithShadows(Sects[currSect][0], fntSize, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,fntSize*2), false, rgbCurrentSection)
                else
                    DrawTextWithShadows(Sects[currSect][0], fntSize, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,fntSize*2), false, rgbCurrentSection)
                end
            else
                DrawTextWithShadows(" "      , fntSize, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,fntSize*2), false, rgbCurrentSection)
            end

            -- next section Text
            if bSections then
                if nextSect~=nil then
                    local uisize = ui.measureDWriteText(nextSect[0], fntSizeSmall)
                    DrawTextWithShadows(nextSect[0], fntSizeSmall, ui.Alignment.End, vec2(ui.availableSpaceX()-uisize.x,30), vec2(uisize.x+1,fntSize), false, rgbSections)
                end
                ui.newLine()
            end
            ui.newLine()
        end

        if physics.allowed() and not ac.isInReplayMode() and bButtons then

            DrawTextWithShadows('<', fntSize, ui.Alignment.Start, vec2(10,30), vec2(fntSize*1,fntSize*1), false, rgbSections)
            ui.sameLine(0)
            ui.setCursorX(0)
            -- small jump prev section btn
            if ui.invisibleButton('<', vec2(fntSize*2,fntSize*1.2)) then
            --if ui.button('<', vec2(fntSize*1.2,fntSize*1.2)) then
                if #Sects>0 then
                    if prevSect~=nil then
                        JumpSection(prevSect[1])
                    end
                else
                    SetBack()
                    second = secondadd
                end
            end

            -- small jump next section btn
            DrawTextWithShadows('>', fntSize, ui.Alignment.End, vec2(ui.availableSpaceX()-fntSize*0.25,30), vec2(fntSize*1,fntSize*1), false, rgbSections)
            ui.sameLine(ui.windowSize().x-fntSize*3)
            if ui.invisibleButton('>', vec2(fntSize*2,fntSize*1.2)) then
            --if ui.button('>', vec2(fntSize*1.2,fntSize*1.2)) then
                if #Sects>0 then
                    if nextSect~=nil then
                        JumpSection(nextSect[1])
                    end
                else
                    SetForw()
                    second = secondadd
                end
            end

            --ui.endOutline(rgbm.colors.black, 0.5)

            if #Sects>0 then
                ui.setCursor(vec2(ui.availableSpaceX()-5,40+fntSize))
                ui.setNextItemWidth(20)
                -- Sects = { ["Sector1"]="T1", ["Sector2"]="T2" }
                local selected = Sects[1][0]
                ui.combo("", selected, function ()
                    for i,v in pairs(Sects) do
                        if ui.selectable(v[0], v[0] == selected) then
                            JumpSection(Sects[i][1])
                        end
                    end end)
            end

        else
            -- ui.endOutline(rgbm.colors.black, 1)
            ui.setCursorY(ui.getCursorY()-fntSize*1.9)
        end
    end


    ui.newLine()
    ui.newLine()
    ui.newLine()

    if physics.allowed() and bButtons and ac.hasTrackSpline() then
        if ui.button('Jump\nBack') then
            SetBack()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Jump\nForw') then
            SetForw()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Reset') then
            Reset()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Jump\nPits') then
            SetPits()
        end
        ui.sameLine(0,10)
    end

    ui.setCursorX(ui.windowWidth()-100)
    if ui.button("reload\nsections.ini") then
        LoadSectionsIni(sectINI)
    end

    -- ui.newLine()
    -- if ui.button('jump pX') then
    --     --JumpPosition( vec3(
    --     ac.setCurrentCamera(ac.CameraMode.Free)
    --     ac.setCameraPosition( vec3(
    --     --  0, 0, 0
    --     --  -3019.7, 5.01, 1784.67
    --     --  -3487.41, 155.55, -2181.86
    --     291.44754, 412.13687, 1633.87
    --     --  66.09, 16.17, 1394.58
    --     ))
    -- end

end



if ac.hasTrackSpline() then
    sectINI = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackFullID("\\") .. "\\" .. "data\\sections.ini"
    LoadSectionsIni(sectINI)
end
CreateBorders()
