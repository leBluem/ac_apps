local function readACConfig(ini, sec, key, def)
  local inifile = ac.INIConfig.load(ini)
  return inifile:get(sec, key, def)
end
local function writeACConfig(ini, sec, key, val)
  local inifile = ac.INIConfig.load(ini)
  inifile:set(sec, key, val)
  inifile:save(ini)
end

require("math")

local sim = ac.getSim()
local carp = ac.getCarPhysics(0)
local car  = ac.getCar(0)
-- physics.setCarAutopilot(false)
--physics.setsimulationspeed


local carNode = ac.findNodes('carRoot:0')
local carstw = carNode:findNodes('STEER_HR')
local carMeshes = carstw:findMeshes('?')
local scene = ac.findNodes('sceneRoot:yes')

local pushForce = 150
local second = 0.0
local secondadd = 0.25
local pressed = false

local timerlast = 0.0
local timer = 0.0

local basenode  --@ac.SceneReference
basenode = ac.findNodes('sceneRoot:yes')


--------------------------------------
local Gatekn51   = "contrail.kn5"
local Gatekn52   = "contrail2.kn5"
-- local GateStartL = basenode:loadKN5(Gatekn51)
-- local GateStartR = basenode:loadKN5(Gatekn52)
--basenode:findMeshes("Contrail0"):setVisible(true):setTransparent(true):setMaterialProperty('ksEmissive', rgb.colors.red*500)
-- --basenode:findMeshes("Contrail0"):setVisible(true):setTransparent(true):setMaterialProperty('ksEmissive', rgb.colors.red*5)
--------------------------------------

local axisX  = vec3(1, 0, 0)
local axisZ  = vec3(0, 1, 0)
local axisY  = vec3(0, 0, 1)


local doTime = false

--------------------------------------------------------------------------------------------------------------------------------

local sect = {}
local sects = {}
local currSect = 0
local lastSect = 0
local prevSect = nil
local nextSect = nil


local function LoadSectionsIni(sectINI)
-- [SECTION_0]
-- IN=0.152
-- OUT=0.190
-- TEXT=T1
    if not io.fileExists(sectINI) then
        ac.debug('sectINI', sectINI)
        sects = {}
    else
        local i = 0
        local sectName = "SECTION_"..i
        local sectText = readACConfig(sectINI, sectName, "TEXT", "")
        while sectText ~= "" do
            local sectIN = tonumber ( readACConfig(sectINI, sectName, "IN", "-1") )
            local sectOUT = tonumber ( readACConfig(sectINI, sectName, "OUT", "-1") )
            if sectIN>-1 and sectOUT>-1 then
                table.insert(sects, i, {[0]=sectText, [1]=sectIN, [2]=sectOUT})
            end
            i=i+1
            sectName = "SECTION_"..i
            sectText = readACConfig(sectINI, sectName, "TEXT", "")
        end
    end
end


local function CheckIfInsideINOUT(pin, pout, splinepos)
    if pout<pin then
        -- from end of track, wrapping over to start of track/next lap
        if splinepos>pin then
            return true
        elseif splinepos<pout then
            return true
        end
    else
        -- normal section has to be inside those two bounds
        if splinepos>pin and splinepos<pout then
            return true
        end
    end
    return false
end

local function CheckCurrentSection()
    if car ~= nil then
        local cSpline = car.splinePosition
        local lastS = 0
        currSect = -1
        prevSect = nil
        nextSect = nil
        for k,v in pairs(sects) do
            -- if k<10 then
            --     ac.debug("00"..k,v[1] .. ' ' .. v[0])
            -- else
            --     ac.debug("0"..k,v[1] .. ' ' .. v[0])
            -- end
            --if cSpline>=v[1] and cSpline<v[2] then
            if CheckIfInsideINOUT(v[1], v[2], cSpline) then
                if k<#sects then
                    nextSect = sects[k+1]
                else
                    nextSect = sects[0]
                end
                currSect = k
            end
            if v[1]>cSpline and v[2]>cSpline then
                if k<#sects then
                    nextSect = sects[k]
                else
                    nextSect = sects[0]
                end
                lastS = k
                break
            end
        end

        if currSect>=0 then
            if currSect-1>-1 then
                prevSect = sects[currSect-1]
            else
                prevSect = sects[#sects]
            end
            if currSect+1>#sects then
                nextSect = sects[0]
            else
                nextSect = sects[currSect+1]
            end
        else
            if lastS-1>-1 then
                prevSect = sects[lastS-1]
            else
                prevSect = sects[#sects]
            end
            if lastS+1==#sects then
                nextSect = sects[0]
            else
                nextSect = sects[lastS]
            end
        end

        -- ac.debug("01", sects[0][1])
        -- ac.debug("02", sects[0][2])
        -- ac.debug("10last", lastS)
        -- ac.debug("11prevSect", prevSect)
        -- ac.debug("12currSect", currSect)
        -- ac.debug("13nextSect", nextSect)
    end
end


if ac.hasTrackSpline() then
    local sectINI = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackID() .. "\\" .. "data\\sections.ini"
    local layout = ac.getTrackLayout()
    if layout ~= "" then
        sectINI = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackID() .. "\\" .. layout .. "\\" .. "data\\sections.ini"
    end
    LoadSectionsIni(sectINI)
end



--------------------------------------------------------------------------------------------------------------------------------



local appini = 'apps/lua/JumpAILine/JumpAILine.ini'
local vidini = ac.getFolder('ac.FolderID.Cfg')..'/video.ini'
local acini = ac.getFolder('ac.FolderID.Root')..'/system/cfg/assetto_corsa.ini'

local WheelHidden = tonumber( readACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '0') )
local DriverHidden = tonumber( readACConfig(acini, 'DRIVER', 'HIDE', '0') )

local jumpdist   = 0 --$number
local jumpRef    = refnumber(jumpdist)
local jumpdist   = tonumber( readACConfig(appini, 'USERSETTINGS', 'JUMPDIST', 100) )
--ac.debug('jumpdist', jumpdist)

local fogDensity = 0 --$number
local fogDensRef = refnumber(fogDensity)
fogDensity = tonumber( readACConfig(appini, 'USERSETTINGS', 'FOGDENSITY', 0) )




-- local joystickid                = -1 --$number
-- local joystickidRef             = refnumber(joystickid)
-- joystickid                = tonumber( readACConfig(appini, 'CONTROLS', 'JOYID', -1) )

-- local joystickbuttonreset       = -1 --$number
-- local joystickbuttonresetRef    = refnumber(joystickbuttonreset)
-- joystickbuttonreset       = tonumber( readACConfig(appini, 'CONTROLS', 'RESET', -1) )

-- local joystickbuttonstepback    = -1 --$number
-- local joystickbuttonstepbackRef = refnumber(joystickbuttonstepback)
-- joystickbuttonstepback    = tonumber( readACConfig(appini, 'CONTROLS', 'STEPBACK', -1) )

-- local joystickbuttonstepforw    = -1 --$number
-- local joystickbuttonstepforwRef = refnumber(joystickbuttonstepforw)
-- joystickbuttonstepforw    = tonumber( readACConfig(appini, 'CONTROLS', 'STEPFORW', -1) )

-- local joystickbtnSectPrev       = -1 --$number
-- local joystickbtnSectPrevRef    = refnumber(joystickbtnSectPrev)
-- joystickbtnSectPrev             = tonumber( readACConfig(appini, 'CONTROLS', 'SECTBACK', -1) )

-- local joystickbtnSectNext       = -1 --$number
-- local joystickbtnSectNextRef    = refnumber(joystickbtnSectNext)
-- joystickbtnSectNext             = tonumber( readACConfig(appini, 'CONTROLS', 'SECTFORW', -1) )

local joystickbuttonreset    = ac.ControlButton('__APP_JumpAILINE_reset')
local joystickbuttonstepback = ac.ControlButton('__APP_JumpAILINE_stepback')
local joystickbuttonstepforw = ac.ControlButton('__APP_JumpAILINE_stepforw')
local joystickbuttonsectPrev    = ac.ControlButton('__APP_JumpAILINE_sectPrev')
local joystickbuttonsectNext    = ac.ControlButton('__APP_JumpAILINE_sectNext')



local bBackground       = true --$boolean
if readACConfig(appini, 'CONTROLS', 'BACKGROUND', "1") == "1" then
    bBackground = true
else
    bBackground = false
end
local bAIborders       = true --$boolean
if readACConfig(appini, 'CONTROLS', 'AIBORDERS', "1") == "1" then
    bAIborders = true
else
    bAIborders = false
end



---- from YokaiHUD
-- Convert a timestamp into racing format, like "1:42.556"
-- Probably not very efficent doing tostring and padding etc
local function laptime(timestamp)
    if (timestamp==nil or timestamp < 1) then
        return "--.---"
    end
    --local function pad(n, z) z = z || 2; return ('00' + n).slice(-z); end
    local milliseconds = timestamp % 1000
    timestamp = (timestamp - milliseconds) / 1000
    local seconds = timestamp % 60
    timestamp = (timestamp - seconds) / 60
    local minutes = timestamp % 60
    local hours = (timestamp - minutes) / 60
    --local ms = tostring(milliseconds):pad(3, "0", -1)
    local ms = string.format("%03d", milliseconds)
    local ss = tostring(seconds):pad(2, "0", -1)
    local hh = tostring(hours):pad(2, "0", -1)
    if (hours > 0) then
        local mm = tostring(minutes):pad(1, "0", -1)
        return hh..":"..mm..":"..ss.."."..ms
    elseif (minutes > 0) then
        local mm = tostring(minutes):pad(1, "0", -1)
        return mm..":"..ss.."."..ms
    else
        local mm = tostring(minutes):pad(1, "0", -1)
        return ss.."."..ms
    end
end

local function delta(timestamp)
    if (timestamp==nil) then
        return "--:--.---"
    end
    local milliseconds = timestamp % 1000
    timestamp = (timestamp - milliseconds) / 1000
    local seconds = timestamp % 60
    timestamp = (timestamp - seconds) / 60
    local minutes = timestamp % 60
    local hours = (timestamp - minutes) / 60
    local ms = tostring(milliseconds):pad(3, "0", -1)
    local ss = tostring(seconds):pad(1, "0", -1)
    local mm = tostring(minutes):pad(1, "0", -1)
    local hh = tostring(hours):pad(1, "0", -1)
    if (timestamp > 0) then
        return "-" .. ss .."."..ms
    else
        return "+" .. ss .."."..ms
    end
end




local textsteer = ''
local textdriver = ''
local p1 = vec3(0,0,0)
local p2 = vec3(0,0,0)
local p3 = vec3(0,0,0)
local dist = 0.0
local cSpline = 0.0






local function pushCar(dt)
    local passivePush = pushForce * car.mass * dt * 100 * car.gas
    --ac.debug("passivePush", passivePush)
    physics.addForce(0, vec3(0, 0, 0), true, vec3(0, 0, passivePush), true)
end



local function SetBack()
  if car ~= nil then
    cSpline = car.splinePosition
    p1 = ac.trackProgressToWorldCoordinate(cSpline)
    p3 = p1
    p2 = p3
    dist = 0.0
    while dist<=jumpdist and dist<sim.trackLengthM do
      cSpline = cSpline - 0.001
      if cSpline<0.0 then
        cSpline = cSpline + 1.0
      end
      p3 = p2
      p2 = ac.trackProgressToWorldCoordinate(cSpline)
      dist = p1:distance(p2)
    end
    if cSpline>0.0 then
      --ac.debug("dist", dist)
      --ac.debug("cSpline", cSpline)
      physics.setCarPosition(0, p2, vec3(p2.x-p3.x,p2.y-p3.y,p2.z-p3.z))
      --physics.setCarPosition(0, pos, vec3(1,0,0))
      second = secondadd
    end
  end
end


local function SetForw()
  if car ~= nil then
    cSpline = car.splinePosition --# -0.001
    if cSpline<0.0 then
      cSpline=0.999
    end
    p1 = ac.trackProgressToWorldCoordinate(cSpline)
    p3 = p1
    p2 = p3
    dist = 0.0
    while dist<=jumpdist and dist<sim.trackLengthM do
      cSpline = cSpline + 0.001
      if cSpline>1.0 then
        cSpline = 0.0
      end
      p3 = p2
      p2 = ac.trackProgressToWorldCoordinate(cSpline)
      dist = p1:distance(p2)
    end
    if cSpline>0.0 then
      --ac.debug("dist", dist)
      --ac.debug("cSpline", cSpline)
      physics.setCarPosition(0, p2, vec3(p3.x-p2.x,p3.y-p2.y,p3.z-p2.z))
      --physics.setCarPosition(0, pos, vec3(1,0,0))
      second = secondadd
    end
  end
end


local function Reset()
  ac.resetCar()
  --local cstate = ac.getCarState(1)
  --ac.debug('cstate.awdFrontShare 1', cstate.awdFrontShare)
  --cstate.awdFrontShare = 0.3
  --ac.debug('cstate.awdFrontShare 2', cstate.awdFrontShare)

  --local basenode  --@ac.SceneReference
  --basenode = ac.findNodes('trackRoot:yes')
  --basenode:loadKN5()
end

local function SetPits()
  physics.teleportCarTo(0, ac.SpawnSet.Pits)
end


local function settexts()
  if WheelHidden==1 then
    textsteer = 'Show\nstwheel'
  else
    textsteer = 'Hide\nstwheel'
  end
  if DriverHidden==1 then
    textdriver = 'Show\ndriver'
  else
    textdriver = 'Hide\ndriver'
  end
end
settexts()


local function ToggleSteeringWheel()
  if carMeshes~=nil then
    if WheelHidden==0 then
      WheelHidden = 1
      carMeshes:setVisible(false)
      writeACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '1')
    else
      WheelHidden = 0
      carMeshes:setVisible(true)
      writeACConfig(vidini, 'ASSETTOCORSA', 'HIDE_STEER', '0')
    end
  end
  settexts()
end

local function ToggleDriver()
  --local scene = ac.SceneTweaks()
  -- scene.forceHeadlights=true
  --ac.configureSceneTweaks().forceHeadlights=ac.SceneTweakFlag.ForceOff

  if car.isDriverVisible then
    DriverHidden = 1
    ac.setDriverVisible(0, false)
    writeACConfig(acini, 'DRIVER', 'HIDE', '1')
    --car.isAIControlled = false
    --physics.setCarAutopilot(false, false)
  else
    DriverHidden = 0
    ac.setDriverVisible(0, true)
    writeACConfig(acini, 'DRIVER', 'HIDE', '0')
    --car.isAIControlled = true
    --physics.setCarAutopilot(true, false)
  end
  settexts()
end

function CheckForStalledAI()
    for i=1, sim.carsCount - 1 do
        local carl = ac.getCar(i)
        if carl.isAIControlled and not carl.isInPit and not carl.isInPitlane then
            if carl.speedKmh<5 then
                --if sim.physicsLate>10 then
                if physics.allowed() then
                  physics.teleportCarTo(i, ac.SpawnSet.Pits)
                end
            end
        end
    end
end




local lastcSpline = 0.0
local brdDist = 2.0                           --- meters
local borderDist = brdDist/sim.trackLengthM   --- those meters in percent of track
local BLeft={}
local BRight={}
local tmp_rgbm2 = rgbm(0,25,0,1)


local carroll = math.atan2(car.side.y, car.up.y) -- * cfg.ROLL_LOCK
local pitch = math.asin(car.look.y)              -- * cfg.PITCH_LOCK
local lastp4 = vec3(0,0,0)
local lastp5 = vec3(0,0,0)

local function SetGatePosts(cSpline)
    -- ac.debug("came", "d")
    -- ac.debug("car", car)
    -- ac.debug("BLeft", BLeft)
    if car~=nil and BLeft~=nil then
        if #BLeft>0 then
            local currID = math.floor(cSpline * #BLeft)
            GateStartR:setPosition( BLeft[currID] )
            GateStartL:setPosition( BRight[currID] )
            -- lastp4:set(p4)
            -- lastp5:set(p5)
        end
    end
end

local function JumpSection(cSpline)
    if car ~= nil then
        local p1 = ac.trackProgressToWorldCoordinate(cSpline)
        local p3 = p1
        local p2 = p3
        local dist = 0.0
        local ldist = 0.0
        local cSpline2 = cSpline

        while ldist==dist and dist<=10 and dist<sim.trackLengthM do
            cSpline2 = cSpline2 + 0.001
            if cSpline2>1.0 then
                cSpline2 = 0.0
            end
            p3 = p2
            p2 = ac.trackProgressToWorldCoordinate(cSpline2)
            ldist = dist
            dist = p1:distance(p2)
        end

        if dist>0.0 then
            -- set new car position
            local direction = vec3(p3.x-p2.x,p3.y-p2.y,p3.z-p2.z)
            physics.setCarPosition(0, p2, direction)

            -- add some pushing force
            second = secondadd
            timer = 0.0

            --------------------------------------
            -- SetGatePosts(cSpline2)
            --------------------------------------
        end
    end
end

local function DrawBorders(cSpline)
    if #BLeft>0 then
        local stepswanted = 50 --math.floor(#BLeft)
        --local stepswanted = math.floor(#BLeft / 2)
        local currID = math.floor(cSpline * #BLeft)
        local nextID = currID + 1
        local stepsdone = 0
        while stepsdone<stepswanted do
            --ac.debug(stepsdone.."stepsdone", stepsdone)
            if currID>=#BLeft then
                currID = 1
                nextID = 2
            end
            render.debugLine(BLeft [currID], BLeft [nextID], rgbm.colors.red*1.0)
            render.debugLine(BRight[currID], BRight[nextID], rgbm.colors.red*1.0)
            -- render.debugCross(BLeft [k], 1, rgbm.colors.red*1000)
            -- render.debugCross(BRight[k], 1, rgbm.colors.red*1000)
            stepsdone = stepsdone + 1
            currID = currID + 1
            nextID = currID + 1
        end
    end
end

local function CreateBorders()
    if car ~= nil then
        local carState = ac.getCar(0)
        local p1 = ac.trackProgressToWorldCoordinate(0.0)
        local p2 = p1
        local p3 = p2
        local dist = 0.0
        local cSpline2 = borderDist
        local c=1
        dist=0
        BLeft={}
        BRight={}

        while cSpline2<1.0 do
            p3 = p2
            p2 = ac.trackProgressToWorldCoordinate(cSpline2)
            cSpline2 = cSpline2 + borderDist*1
            if cSpline2>1.0 then
                cSpline2=1.0
            end
            if p2~=p3 and p3.x~=0 and p3.y~=0 and p3.z~=0 then
                dist = p2:distance(p3)
                local dir = math.deg( math.atan2(p2.z-p3.z, p2.x-p3.x)  )
                if dir>360 then
                    dir = dir-360
                end
                local side = ac.getTrackAISplineSides(cSpline2)
                local xL = p2.x + math.cos((dir - 90) * math.pi / 180) * side.x
                local yL = p2.z + math.sin((dir - 90) * math.pi / 180) * side.x
                local xR = p2.x + math.cos((dir + 90) * math.pi / 180) * side.y
                local yR = p2.z + math.sin((dir + 90) * math.pi / 180) * side.y
                local zL = p2.y+0.5
                local zR = p2.y+0.5
                local p4 = vec3(xL, zL, yL)
                local p5 = vec3(xR, zR, yR)
                table.insert(BLeft, p4)
                table.insert(BRight, p5)
                c = c+1
            end
        end
    end
end


local mesh = ac.emptySceneReference()
local rgbgreen = rgbm(0.3,1,0.3,1)
local rgbwhite = rgbm(1,1,1,1)
local lastButtonText = " "

local trackroot = ac.findNodes('trackRoot:yes')
--local trackMeshes --@ac.SceneReference
local trackMeshes --@ac.SceneReference --= trackroot:findMeshes("?")
trackMeshes = trackroot:findMeshes("?")

local carroot = ac.findNodes('carsRoot:yes')
--local trackMeshes --@ac.SceneReference
local carMeshes --@ac.SceneReference --= trackroot:findMeshes("?")
carMeshes = carroot:findMeshes("?")

-- function script.clicked( ... )
--     -- body
--     ui.WindowFlags = ui.WindowFlags or not ui.WindowFlags.NoBackground
-- end

-- local xmesh = ac.findNodes('sceneRoot:yes'):findMeshes("Driver_Body2_SUB0")
-- ac.debug("xmesh1", tostring(#xmesh))

--------------------------------------
-- SetGatePosts(car.splinePosition)
--------------------------------------

CreateBorders()

function Draw3D(dt)  --script.renderTrack()
    if bAIborders and ac.hasTrackSpline() then
        DrawBorders(car.splinePosition)
    end
end





--require "..\\winapi\\winapi"
-- local user32 = ffi.load("c:\\windows\\system32\\user32.dll")
-- ffi.cdef[[
--      int FindWindow(string classname, string winname)
--      int SendMessage(int handle, int msg, int wparam, int lparam);
-- ]]
-- -- FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassname As String, ByVal lpWindowName As String) As Long
-- -- Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" _
-- -- (ByVal hWnd As Long,
-- -- ByVal wMsg As Long,
-- -- ByVal wParam As Long,
-- -- ByVal lParam As Long)
-- -- As Long

-- -- void lj_overrideLapTime(int time);
-- -- void lj_setGripMultiplier(float multiplier);
-- -- void lj_setNoclip(bool active);
-- -- double lj_getGearRatio(int gear);
-- -- void lj_setGearRatio(int gear, double ratio);
-- -- void lj_resetGearRatios();

-- local done = false
-- local acHwnd = FindWindow("Assetto Corsa", nil)
-- local HWND_BROADCAST = 65535 -- FFFF
-- local WM_KEYUP = 257 -- 0101
-- local WM_CHAR = 258 -- 0102
-- HWND_BROADCAST

-- SendMessage(acHwnd, WM_CHAR, 0x03, 0)

local done=false
Sim = ac.getSim()

---------------------------------------------------------------------------------------------
function script.windowSettings(dt)
    if ui.button(textsteer) then
        ToggleSteeringWheel()
    end
    ui.sameLine(0,10)
    if ui.button(textdriver) then
        ToggleDriver()
    end

    if physics.allowed() then
        ui.bulletText('extPhysics enabled')
    else
        ui.bulletText('no extPhysics avail')
    end

    if ac.hasTrackSpline() then
        ui.sameLine(130,30)
        if ui.checkbox("ai", bAIborders) then
            bAIborders = not bAIborders
            if bAIborders then
                writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "1")
            else
                writeACConfig(appini, 'CONTROLS', 'AIBORDERS', "0")
            end
        end
    end
    ui.sameLine(170,30)
    if ui.checkbox("background      "..tostring(#trackMeshes).."/" ..tostring(#carMeshes).." track/car objs", bBackground) then
        bBackground = not bBackground
        if bBackground then
            writeACConfig(appini, 'CONTROLS', 'BACKGROUND', "1")
        else
            writeACConfig(appini, 'CONTROLS', 'BACKGROUND', "0")
        end
    end

    if physics.allowed() then
        if ui.slider('jump distance', jumpRef, 0, math.min(2000, math.floor(sim.trackLengthM/2)), jumpdist) then
            jumpRef.value = math.floor(jumpRef.value)
            jumpdist = jumpRef.value
            writeACConfig(appini, 'USERSETTINGS', 'JUMPDIST', jumpdist)
        end
    end
    -- ui.newLine(1)
    -- for j = 0,3 do
    --     for b = 0,64 do
    --         if ac.isJoystickButtonPressed(j,b) then
    --             lastButtonText = "lastpressed: JoyDevice "..tostring(j).." -- btnID "..tostring(b)
    --         end
    --     end
    -- end
    --ui.sameLine(ui.windowSize().x/6, 50)
    --ui.dwriteTextAligned(lastButtonText, 14, ui.Alignment.Start,vec2(0,80), vec2(0,20), false, rgbwhite)

    if physics.allowed() then
        ui.text('reset:')
        ui.sameLine(50)
        joystickbuttonreset:control(vec2(90, 0))
        ui.sameLine(150)
        ui.text('stepback:')
        ui.sameLine(200)
        joystickbuttonstepback:control(vec2(90, 0))
        ui.sameLine(300)
        ui.text('stepforw:')
        ui.sameLine(350)
        joystickbuttonstepforw:control(vec2(90, 0))
        ui.newLine(1)
        ui.sameLine(150)
        ui.text('sectPrev:')
        ui.sameLine(200)
        joystickbuttonsectPrev:control(vec2(90, 0))
        ui.sameLine(300)
        ui.text('sectNext:')
        ui.sameLine(350)
        joystickbuttonsectNext:control(vec2(90, 0))
    end
end
---------------------------------------------------------------------------------------------

function script.update(dt)
    if joystickbuttonreset:down() and not sim.isReplayActive and not sim.isPaused then
        Reset()
        second = secondadd
    end
    if joystickbuttonstepback:down() and not sim.isReplayActive and not sim.isPaused then
        SetBack()
        second = secondadd
    end
    if joystickbuttonstepforw:down() and not sim.isReplayActive and not sim.isPaused then
        SetForw()
        second = secondadd
    end
    if joystickbuttonsectPrev:down() and not sim.isReplayActive and not sim.isPaused then
        if prevSect~=nil then
            JumpSection(prevSect[1])
            second = secondadd
        end
    end
    if joystickbuttonsectNext:down() and not sim.isReplayActive and not sim.isPaused then
        if nextSect~=nil then
            JumpSection(nextSect[1])
            second = secondadd
        end
        second = secondadd
    end
end

---------------------------------------------------------------------------------------------

function script.windowMain(dt)

    --------------- testing pitch --------------
    --ui.sameLine(-1,0)
    -- local carroll = math.atan2(car.side.y, car.up.y) -- * cfg.ROLL_LOCK
    -- local pitch = math.asin(car.look.y)              -- * cfg.PITCH_LOCK
    -- --ui.bulletText('roll'..tostring(carroll))
    -- ui.bulletText('pitch  '..tostring(math.round(pitch,3))..'  /  '..tostring(math.round(math.deg(pitch),1))..'°')

    --CheckForStalledAI()
    -- if Sim.isWindowForeground and done==false  then --and Car.lapTimeMs>0.0 then
    --     --winapi.send_to_window (winapi.VK_CTRL.."C")
    --     --winapi.send_to_window (winapi.VK_CTRL)
    --     --SendMessage(acHwnd, WM_CHAR, 0x03, 0)
    --     os.execute("p:/Steam/steamapps/common/assettocorsa/extension/lua/new-modes/license-test/Ctrl_c.exe")
    --     --ac.debug("done","1")
    --     done=true
    -- end


    if bBackground then
        ui.drawRectFilled(vec2(0,0), vec2(ui.windowSize().x, ui.windowSize().y), rgbm(0,0,0,0.5))
    end

    -- ai borders stuff
    -- if bAIborders and ac.hasTrackSpline() then
    --     local cSpl = car.splinePosition
    --     if math.abs(cSpl - lastcSpline) > borderDist*5 then
    --         lastcSpline = cSpl
    --         if lastcSpline > cSpl then
    --             lastcSpline = 1.0
    --         else
    --             lastcSpline = cSpl
    --         end
    --         --SetGatePosts(cSpl)
    --     end
    -- end

    -- section stuff
    --if false then
    if #sects>0 and ac.hasTrackSpline() then
        CheckCurrentSection()
        -- km info
        ui.sameLine(ui.windowSize().x/4,0)
        if sim.trackLengthM>2000 then
            ui.dwriteTextAligned( tostring(math.round(car.splinePosition*sim.trackLengthM/1000, 1))..'km', 12, ui.Alignment.Center, vec2(ui.windowSize().x/2,0), vec2(ui.windowSize().x/2,15), false, rgbwhite)
        else
            ui.dwriteTextAligned( tostring(math.floor(car.splinePosition*sim.trackLengthM        ))..'m' , 12, ui.Alignment.Center, vec2(ui.windowSize().x/2,0), vec2(ui.windowSize().x/2,15), false, rgbwhite)
        end
        -- prev section
        ui.sameLine(40,0)
        if prevSect~=nil then
            ui.dwriteTextAligned(prevSect[0], 10, ui.Alignment.Start, vec2(20,40), vec2(ui.windowSize().x/2,20), false, rgbwhite)
        end
        -- current section
        ui.sameLine(1,0)
        if currSect>-1 then
            ui.dwriteTextAligned(sects[currSect][0], 16, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,50), false, rgbgreen)
        else
            --ui.dwriteTextAligned("--noname--"      , 16, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,50), false, rgbgreen)
            ui.dwriteTextAligned("-"      , 16, ui.Alignment.Center, vec2(0,40), vec2(ui.windowSize().x,50), false, rgbgreen)
        end
        -- next section
        ui.sameLine(ui.windowSize().x/3,0)
        if nextSect~=nil then
            ui.dwriteTextAligned(nextSect[0], 10, ui.Alignment.End, vec2(ui.windowSize().x/2,40), vec2(ui.windowSize().x/2,20), false, rgbwhite)
        end

        if physics.allowed() then
            ui.sameLine(-1,0)
            -- small jump prev section btn
            if bBackground then
                if ui.button('  <') then
                --if ui.invisibleButton('  <', vec2(20,20)) then
                    if prevSect~=nil then
                        JumpSection(prevSect[1])
                    end
                end
            else
                ui.setCursorX(13)
                ui.setCursorY(35)
                ui.dwriteTextAligned('<', 16, ui.Alignment.Start, ui.Alignment.Center, vec2(20,20), false, rgbwhite)
                ui.setCursorX(13)
                ui.setCursorY(35)
                if ui.invisibleButton('  <', vec2(20,20)) then
                --if ui.invisibleButton('  <', vec2(20,20)) then
                    if prevSect~=nil then
                        JumpSection(prevSect[1])
                    end
                end
            end
            ui.sameLine(0,ui.windowSize().x-70)
            -- small jump next section btn
            if bBackground then
                if ui.button('>') then
                    if nextSect~=nil then
                        JumpSection(nextSect[1])
                    end
                end
            else
                ui.setCursorX(ui.windowSize().x-40)
                ui.setCursorY(35)
                ui.dwriteTextAligned('>', 16, ui.Alignment.End, ui.Alignment.Center, vec2(20,20), false, rgbwhite)
                ui.setCursorX(ui.windowSize().x-40)
                ui.setCursorY(35)
                if ui.invisibleButton('>', vec2(20,20)) then
                    if nextSect~=nil then
                        JumpSection(nextSect[1])
                    end
                end
            end
        end
        ui.setCursorY(80)
    else
        ui.setCursorY(30)
    end



    if second>0.0 then
        pushCar(dt)
        second = second - dt
        -- ac.debug('time', second)
    end



    if physics.allowed() then
        if ac.hasTrackSpline() then
        if ui.button('Jump\nBack') then
            SetBack()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Jump\nForw') then
            SetForw()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Reset') then
            Reset()
            second = secondadd
        end
        ui.sameLine(0,10)
        if ui.button('Jump\nPits') then
            SetPits()
        end
        end
        ui.sameLine(0,10)
    end


    -- ui.newLine(1)
    -- ui.bulletText(tostring(car.lastSplits))
    -- ui.bulletText(tostring(ac.getCar(1).lastSplits))

    if doTime then
        timer = timer + dt
        ui.setCursorX(20)
        ui.setCursorY(15)

        -- ui.dwriteTextAligned("\n"..delta(timer    *1000).."\n"..delta(timerlast*1000),
        --   12, ui.Alignment.Start, vec2(20,25), vec2(ui.windowSize().x,60), false, rgbwhite)

        --ui.dwriteTextAligned(  delta(timer), 10, ui.Alignment.Start, vec2(20,40), vec2(ui.windowSize().x/2,80), false, rgbwhite)
        --ui.dwriteTextAligned(, 10, ui.Alignment.Start, vec2(20,20), vec2(ui.windowSize().x/2,40), false, rgbwhite)

        ui.pushACFont("seiko_7segs")
        -- ui.acText("\n"..delta(timer    *1000).."\n"..delta(timerlast*1000), vec2(), 10, rgbm.colors.white, 0, true)
        --ui.acText("\n"..laptime(timer    *1000).."\n"..laptime(timerlast*1000), vec2(18,32), 0, rgbm.colors.white, 0, true)
        ui.acText("\n"..laptime(timer    *1000).."\n"..
                        laptime(timerlast*1000).."  ",
                        --tostring(math.round(car.splinePosition,8))
                        vec2(8,16), 0, rgbm.colors.white, 0, true)
        ui.popACFont()
        --ui.newLine()
    end


end

