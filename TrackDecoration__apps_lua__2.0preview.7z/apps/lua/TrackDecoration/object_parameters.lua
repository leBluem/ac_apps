-- for KN5s from obj folder and sub folders
-- Mass of obj in kg -- also acts as damping multiplier!
-- COG, not vec3, only height above ground is used
-- min. distance to place new objects around, just use diameter

Rigid_Kn5s = {
                      "jump.kn5",                   -- 1
                      "bollard.kn5",                -- 2
                      "cone.kn5",                   -- 3
                      "coneF.kn5",                  -- 4
                      "coneS.kn5",                  -- 5
                      "pole150.kn5",                -- 6
                      "pole100.kn5",                -- 7
                      "tyrewall2x3.kn5",            -- 8
                      "tyrewall2x8.kn5",            -- 9
                      "tyrewall2x8round.kn5",       -- 10
                      "tumbleweed.kn5",             -- 11
                      "brakeLeft.kn5",              -- 12
                      "brakeRight.kn5",             -- 13
                      "corner/cornerRWLeft.kn5",    -- 14
                      "corner/cornerRWRight.kn5",   -- 15
                      "corner/cornerSmall50.kn5",   -- 16
                      "corner/cornerSmall100.kn5",  -- 17
                      "corner/cornerSmall150.kn5",  -- 18
                      "corner/cornerSmall200.kn5",  -- 19
                      "corner/cornerSmall300.kn5",  -- 20
                      "dist50Tall.kn5",             -- 21
                      "dist100Tall.kn5",            -- 22
                      "dist150Tall.kn5",            -- 23
                      "dist200Tall.kn5",            -- 24
                      "dist300Tall.kn5",            -- 25
                      "dist400Tall.kn5",            -- 26
                      "distRome1.kn5",              -- 27
                      "distRome2.kn5",              -- 28
                      "distRome3.kn5",              -- 29
                      "DRS.kn5",                    -- 30
                      "noodle.kn5",                 -- 31
                      "noodle_side.kn5",            -- 32
                      "speed60.kn5",                -- 33
                      "speed60off.kn5",             -- 34
                      "speed80.kn5",                -- 35
                      "speed80off.kn5",             -- 36
             }
Rigid_Mass = {
                       10000,                  -- 1 jump
                       5.0,                    -- 2 bollard
                       5.0 ,                   -- 3 cone
                       5.0 ,                   -- 4 coneF
                       5.0 ,                   -- 5 coneS
                       6.0,                    -- 6 pole150
                       4.0,                    -- 7 pole100
                       600.0,                  -- 8 tyrewall2x3
                       600.0,                  -- 9 tyrewall2x8
                       600.0,                  -- 10 tyrewall2x8round
                       10,                     -- 11 tumbleweed
                       4,                      -- 12 brakeLeft
                       4,                      -- 13 brakeRight
                       4,                      -- 14 corner/cornerRWLeft
                       4,                      -- 15 corner/cornerRWRight
                       4,                      -- 16 corner/cornerSmall50
                       4,                      -- 17 corner/cornerSmall100
                       4,                      -- 18 corner/cornerSmall150
                       4,                      -- 19 corner/cornerSmall200
                       4,                      -- 20 corner/cornerSmall300
                       4,                      -- 21 dist50Tall
                       4,                      -- 22 dist100Tall
                       4,                      -- 23 dist150Tall
                       4,                      -- 24 dist200Tall
                       4,                      -- 25 dist300Tall
                       4,                      -- 26 dist400Tall
                       4,                      -- 27 distRome1
                       4,                      -- 28 distRome2
                       4,                      -- 29 distRome3
                       4,                      -- 30 DRS
                       4,                      -- 31 noodle
                       4,                      -- 32 noodle_side
                       4,                      -- 33 speed60
                       4,                      -- 34 speed60off
                       4,                      -- 35 speed80
                       4,                      -- 36 speed80off
            }
Rigid_COG = {
                       0    ,                  -- 1 jump
                       0.2,                    -- 2 bollard
                       0.1  ,                  -- 3 cone
                       0.1   ,                 -- 4 coneF
                       0.1   ,                 -- 5 coneS
                       0.2,                    -- 6 pole150
                       0.25,                   -- 7 pole100
                       0.25 ,                  -- 8 tyrewall2x3
                       0.25 ,                  -- 9 tyrewall2x8
                       0.25 ,                  -- 10 tyrewall2x8round
                       0.25,                   -- 11 tumbleweed
                       0.25,                   -- 12 brakeLeft
                       0.25,                   -- 13 brakeRight
                       0.25,                   -- 14 corner/cornerRWLeft
                       0.25,                   -- 15 corner/cornerRWRight
                       0.25,                   -- 16 corner/cornerSmall50
                       0.25,                   -- 17 corner/cornerSmall100
                       0.25,                   -- 18 corner/cornerSmall150
                       0.25,                   -- 19 corner/cornerSmall200
                       0.25,                   -- 20 corner/cornerSmall300
                       0.25,                   -- 21 dist50Tall
                       0.25,                   -- 22 dist100Tall
                       0.25,                   -- 23 dist150Tall
                       0.25,                   -- 24 dist200Tall
                       0.25,                   -- 25 dist300Tall
                       0.25,                   -- 26 dist400Tall
                       0.25,                   -- 27 distRome1
                       0.25,                   -- 28 distRome2
                       0.25,                   -- 29 distRome3
                       0.25,                   -- 30 DRS
                       0.25,                   -- 31 noodle
                       0.25,                   -- 32 noodle_side
                       0.25,                   -- 33 speed60
                       0.25,                   -- 34 speed60off
                       0.25,                   -- 35 speed80
                       0.25,                   -- 36 speed80off
             }
Rigid_Dist = {
                       2    ,                  -- 1 jump
                       0.2,                    -- 2 bollard
                       0.5  ,                  -- 3 cone
                       0.5   ,                 -- 4 coneF
                       0.5   ,                 -- 5 coneS
                       0.4,                    -- 6 pole150
                       1.0,                    -- 7 pole100
                       1.0  ,                  -- 8 tyrewall2x3
                       1.0  ,                  -- 9 tyrewall2x8
                       1.0  ,                  -- 10 tyrewall2x8round
                       0.5,                    -- 11 tumbleweed
                       0.25,                   -- 12 brakeLeft
                       0.25,                   -- 13 brakeRight
                       0.25,                   -- 14 corner/cornerRWLeft
                       0.25,                   -- 15 corner/cornerRWRight
                       0.25,                   -- 16 corner/cornerSmall50
                       0.25,                   -- 17 corner/cornerSmall100
                       0.25,                   -- 18 corner/cornerSmall150
                       0.25,                   -- 19 corner/cornerSmall200
                       0.25,                   -- 20 corner/cornerSmall300
                       0.25,                   -- 21 dist50Tall
                       0.25,                   -- 22 dist100Tall
                       0.25,                   -- 23 dist150Tall
                       0.25,                   -- 24 dist200Tall
                       0.25,                   -- 25 dist300Tall
                       0.25,                   -- 26 dist400Tall
                       0.25,                   -- 27 distRome1
                       0.25,                   -- 28 distRome2
                       0.25,                   -- 29 distRome3
                       0.25,                   -- 30 DRS
                       0.25,                   -- 31 noodle
                       0.25,                   -- 32 noodle_side
                       0.25,                   -- 33 speed60
                       0.25,                   -- 34 speed60off
                       0.25,                   -- 35 speed80
                       0.25,                   -- 36 speed80off
             }



-- use forward slashes for "subdir/sub2/sub.kn5"
-- force CAST_SHADOWS for some KN5's
-- if not listed here, no changes to Objects shadow from original KN5 are made
FORCE_CAST_SHADOWS   = {
    ["flagman.kn5"] = true,
    ["RMi/track_tso_pitstand_no.kn5"] = true,
    ["RMi/track_tso_pitstand_nonono.kn5"] = true,
    ["RMi/track_tyrestack.kn5"] = true,
    ["RMi/track_gantry1.kn5"] = true,
    ["RMi/track_sign1.kn5"] = true,
    ["RMi/track_sign2.kn5"] = true,
    ["RMi/track_sign_big.kn5"] = true,
    ["RMi/tso_building_barn1.kn5"] = true,
    ["RMi/tso_building_small_misc1.kn5"] = true,
    ["RMi/tso_building_snack2.kn5"] = true,
    ["RMi/tso_building_tent1.kn5"] = true,
    ["RMi/tso_building_tentsmall2.kn5"] = true,
    ["RMi/tso_marshal_flag.kn5"] = true,
    ["RMi/tso_marshal_hdset.kn5"] = true,
    ["RMi/tso_track_stand.kn5"] = true,
    ["RMi/tso_truck_pit_merch.kn5"] = true,
    ["RMi/vehicles_sprinter.kn5"] = true,
    ["RMi-2/tso_plane_dc3.kn5"] = true,
    ["RMi-2/tso_plane_helicopter1.kn5"] = true,
    ["RMi-2/tso_vehicles_carsc.kn5"] = true,
    ["RMi-2/vehicles_support_fm7.kn5"] = true,
}


-- use forward slashes for "subdir/sub2/sub.kn5"
-- set light parameters for some KN5's
ValidLightMeshes = {
{ ["kn5"]="track_lights_array.kn5"             , ["litmesh"]="lights_tyre-1"            , ["color"] = rgb.colors.white*10, ["range"]= 40, ["spot"]=180, ["dir"]="NORMAL" },
{ ["kn5"]="track_lights_portable.kn5"          , ["litmesh"]="lghts_gen_01-1"           , ["color"] = rgb(1,0.9,0.8)  *10, ["range"]= 40, ["spot"]=180, ["dir"]="NORMAL" },
{ ["kn5"]="coneS.kn5"                          , ["litmesh"]="cone_litS"                , ["color"] = rgb(1,0.5,0.0)  *10, ["range"]=  5, ["spot"]=180, ["dir"]="NORMAL" },
{ ["kn5"]="coneF.kn5"                          , ["litmesh"]="cone_litF"                , ["color"] = rgb(1,0  ,0.0)  *10, ["range"]=  5, ["spot"]=180, ["dir"]="NORMAL" },
{ ["kn5"]="RMi-2/track_lights_portable_fm7.kn5", ["litmesh"]="lightgenerator_light"     , ["color"] = rgb(1,0.9,0.8)  *10, ["range"]= 35, ["spot"]=180, ["dir"]="NORMAL" },
{ ["kn5"]="RMi-2/track_lights_floodlight.kn5"  , ["litmesh"]="track_lights_floodlight-1", ["color"] = rgb(1,0.9,0.8)  *10, ["range"]= 45, ["spot"]=180, ["dir"]="NORMAL" },
{ ["kn5"]="track_lights_BigSingle.kn5"         , ["litmesh"]="lightBigSingle_lit"       , ["color"] = rgb(1,0.9,0.8)  *10, ["range"]= 70, ["spot"]=180, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_BigDouble.kn5"         , ["litmesh"]="lightBigDouble_lit"       , ["color"] = rgb(1,0.9,0.8)  *10, ["range"]= 80, ["spot"]=180, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_StreetSingle.kn5"      , ["litmesh"]="lightStreetSingle_lit"    , ["color"] = rgb(1,1,1)      *10, ["range"]= 40, ["spot"]=180, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_StreetDouble.kn5"      , ["litmesh"]="lightStreetDouble_lit"    , ["color"] = rgb(1,1,1)      *10, ["range"]= 50, ["spot"]=180, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_StreetTriple.kn5"      , ["litmesh"]="lightStreetTriple_lit"    , ["color"] = rgb(1,1,1)      *10, ["range"]= 60, ["spot"]=180, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_OldLanternSingle.kn5"  , ["litmesh"]="lightOldLanternSingle_lit", ["color"] = rgb(1,0.8,0.6)  *7 , ["range"]= 20, ["spot"]=  0, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_OldLanternDouble.kn5"  , ["litmesh"]="lightOldLanternDouble_lit", ["color"] = rgb(1,0.8,0.6)  *7 , ["range"]= 25, ["spot"]=  0, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_OldLanternTriple.kn5"  , ["litmesh"]="lightOldLanternTriple_lit", ["color"] = rgb(1,0.8,0.6)  *7 , ["range"]= 30, ["spot"]=  0, ["dir"]="0,-1,0" },
{ ["kn5"]="track_lights_Flood3x.kn5"           , ["litmesh"]="lightFlood3x_lit"         , ["color"] = rgb(1,1,1)      *10, ["range"]=100, ["spot"]=180, ["dir"]="0,-1,0" },
}

-- same as above - use forward slashes for "subdir/sub2/sub.kn5"
-- Z-axis (up/down) Offset for Objects not at origin
-- if not listed, 0 is default offset for loaded kn5's from "OBJ" folder
ValidKn5sOFFSETS   = {
    ["AC_objs/AC_AB_FINISH_L.kn5"] = 1.0,
    ["AC_objs/AC_AB_FINISH_R.kn5"] = 1.0,
    ["AC_objs/AC_AB_START_L.kn5"] = 1.0,
    ["AC_objs/AC_AB_START_R.kn5"] = 1.0,
    ["AC_objs/AC_TIME_0_L.kn5"] = 1.0,
    ["AC_objs/AC_TIME_0_R.kn5"] = 1.0,
    ["AC_objs/AC_TIME_1_L.kn5"] = 1.0,
    ["AC_objs/AC_TIME_1_R.kn5"] = 1.0,
    ["AC_objs/AC_TIME_2_L.kn5"] = 1.0,
    ["AC_objs/AC_TIME_2_R.kn5"] = 1.0,
    ["AC_objs/AC_HOTLAP_START.kn5"] = 1.0,
    ["AC_objs/AC_PIT.kn5"] = 1.0,
    ["AC_objs/AC_START.kn5"] = 1.0,

    ["flagman.kn5"] = 1.345,
    ["flag1.kn5"] = 1.345,
    ["flag2.kn5"] = 1.345,
    ["flag3.kn5"] = 1.345,
    ["flag4.kn5"] = 1.345,
    ["flag5.kn5"] = 1.345,
    ["flag6.kn5"] = 1.345,
    ["flag7.kn5"] = 1.345,
    ["flag8.kn5"] = 1.345,
    ["flag9.kn5"] = 1.345,
    ["flag10.kn5"] = 1.345,
    ["flag11.kn5"] = 1.345,
    ["flag12.kn5"] = 1.345,
    ["flag13.kn5"] = 1.345,
    ["flag14.kn5"] = 1.345,
    ["flag15.kn5"] = 1.345,
    ["flag16.kn5"] = 1.345,
}

-- objects used for "cones on apexes" -- must have 4 elements!
-- if empty '', no cone will be placed
-- filled dynamically further below
ApexCones = {
'cone.kn5' , -- corner start
'pole100.kn5'  , -- corner apex
'coneS.kn5', -- corner end
'pole150.kn5'    -- intermediate apex
}

