-- TrackDecoration by leBluem
--
-- Compass textures based on BeamNG compass
-- https://beamng.com/threads/compass-heading-indicator.8658/


-- ALL OBJECT PARAMETERS moved to this file:
-- dofile(ac.getFolder('ac.FolderID.ACApps')..'/lua/Trackdecoration/object_parameters.lua')
dofile('p:/Steam/steamapps/common/assettocorsa/apps/lua/Trackdecoration/object_parameters.lua')


------------------------------------------------


local function readACConfig(ini, sec, key, def)
    local inifile = ac.INIConfig.load(ini, ac.INIFormat.Default)
    -- local inifile = ac.INIConfig.load(ini)
    return inifile:get(sec, key, def)
end
local function writeACConfig(ini, sec, key, val)
    local inifile = ac.INIConfig.load(ini, ac.INIFormat.Default)
    -- local inifile = ac.INIConfig.load(ini)
    inifile:setAndSave(sec, key, val)
end

local function isValidFilename(fname)
    local validchars=" !#$%&'()+,-.0123456789;=@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ðÐÊËÈıÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµþÞÚÛÙýÝ¯´­±‗¾¶§÷¸°¨·¹³²■"
    for i=1, #fname do
        if not string.find(validchars, fname[i]) then
            return false
        end
    end
    return true
end

local function get_file_name(file)
    local s = file:match("^.+/(.+)$")
    return s or file
end

local function get_file_name2(file)
    local s = file:match("^.+\\(.+)$")
    return s or file
end


local function math_round(v, dec)
    -- return tonumber(math.floor(v*dec*10))/10.0*dec
    local mult = 10^(dec or 0)
    if v then
        return math.floor(v * mult + 0.5) / mult
    end
end

------------------------------------------------------------------

local dirTrackDeco = ac.getFolder(ac.FolderID.Root) .. "\\apps\\lua\\TrackDecoration\\"
local appopts      = ac.getFolder(ac.FolderID.Root) .. '\\apps\\lua\\TrackDecoration\\options.ini'

local sim = ac.getSim()
local car = ac.getCar(0)
if io.fileExists("skins\\default\\tx1.dds") then

end

-- local carp = ac.getCarPhysics(0)
-- local sCar = string.lower( ac.getCarID(0) )
-- local sTrack = string.lower( ac.getTrackID() )
-- local sLayout = string.lower( ac.getTrackLayout() )

local sesstimeleft = sim.sessionTimeLeft-0.002

local bPaused = false
local currObjkn5          = tonumber(readACConfig(appopts, "options", "currObjkn5", 1))
local currObjkn5sameplace = tonumber(readACConfig(appopts, "options", "currObjkn5sameplace", 1))
local bCamFacing          = readACConfig(appopts, "options", "bCamfacing", 1) == 1
local bAutoLoad           = readACConfig(appopts, "options", "AutoLoad", 1) == 1
local bShowObjectList     = readACConfig(appopts, "options", "ObjectList", 1) == 1
local bAlignToSurface     = readACConfig(appopts, "options", "AlignToSurface", 1) == 1
local bAlignSwitchDir     = 0 -- readACConfig(appopts, "options", "AlignSwitchDir", 1) == 1
local bALLLAYOUTS         = readACConfig(appopts, "options", "ALLLAYOUTS", 0) == 1

local bSelectMode         = false  --readACConfig(appopts, "options", "SelectMode", 1) == 1
local bSelectMode2         = false
-- local bHidden             = false

local bWriteCSPTreeFormat  = readACConfig(appopts, "options", "WriteCSPTreeFormat", 1) == 1
local bCompassDegrees      = readACConfig(appopts, "options", "CompassDegrees", 1) == 1
local bCompassGraphics     = readACConfig(appopts, "options", "CompassGraphics", 1) == 1
local bCompassInverted     = readACConfig(appopts, "options", "CompassInverted", 0) == 1

-- 51/34/10
local Curve_Threshold     = readACConfig(appopts, "options", "Curve_Threshold"   , 51)
local Curve_ThresholdOut  = readACConfig(appopts, "options", "Curve_ThresholdOut", 34)
local Curve_Distance      = readACConfig(appopts, "options", "Curve_Distance", 10)

local fileModelsINIs = {}
local fileCurrID = 1

local function GetFileID(fileCurrS)
    for i=0, #fileModelsINIs do
        if fileModelsINIs[i]==fileCurrS then
            return i
        end
    end
    return 1
end


-- local RigidBodiesList = {}
local PhysicsBodies = {}
local RigidBodies = {}
local iRigidBodyHit = 0
local ObjsHit = {}

local ObjectsList = {}
local Objects = {}
local TabSeen = {}
local ValidKn5sApp = {}




ApexCones[1] = readACConfig(appopts, "APEXCONES", "CORNERSTART", 'cone.kn5')
ApexCones[2] = readACConfig(appopts, "APEXCONES", "CORNERAPEX", 'pole100.kn5')
ApexCones[3] = readACConfig(appopts, "APEXCONES", "CORNEREND", 'coneS.kn5')
ApexCones[4] = readACConfig(appopts, "APEXCONES", "CORNERINTER", 'pole150.kn5')

local function AddSubKn5s(sub)
    local subFiles = io.scanDir(dirTrackDeco.."obj/"..sub.."/", "*")
    for j=1, #subFiles do
        if io.dirExists(dirTrackDeco.."obj/"..sub.."/"..subFiles[j]) then
            AddSubKn5s(sub.."/"..subFiles[j])
        elseif string.lower(subFiles[j]):find(".kn5") then
            table.insert(ValidKn5sApp, sub.."/"..subFiles[j])
        end
    end
end
local function ValidateKN5s()
    local i = 1
    while i<=#ValidKn5sApp do
        if io.dirExists(dirTrackDeco.."obj/"..ValidKn5sApp[i]) or
            not string.lower(ValidKn5sApp[i]):find(".kn5")
        then
            local sub = ValidKn5sApp[i]
            table.remove(ValidKn5sApp, i)
            AddSubKn5s(sub)
        else
            i=i+1
        end
    end
end




local function UpdateFileNames()
    -- read available files

    ValidKn5sApp = io.scanDir(dirTrackDeco.."obj/", "*")
    ValidateKN5s()

    fileModelsINIs = {}
    if bALLLAYOUTS then
        fileModelsINIs = io.scanDir(dirTrackDeco.."dataSections/", ac.getTrackID().."*.ini")
    else
        fileModelsINIs = io.scanDir(dirTrackDeco.."dataSections/", ac.getTrackFullID('_').."*.ini")
    end

    if #fileModelsINIs==0 or not io.fileExists(dirTrackDeco.."dataSections/"..ac.getTrackFullID('_')..".ini") then
        -- add default custom models.ini if not already found
        -- dataSections/trackname_layout.ini
        table.insert(fileModelsINIs, ac.getTrackFullID('_')..".ini")
    end
    fileCurrID = 1
    local fileCurrS = readACConfig(appopts, ac.getTrackFullID('_'), "ACTIVEFILE", fileModelsINIs[fileCurrID])
    fileCurrID = GetFileID(fileCurrS)
end
UpdateFileNames()
-- ac.debug("return", fileCurrID)



-- basenode = ac.findNodes('sceneRoot:yes')
local basenode  ---@ac.SceneReference
basenode = ac.findNodes('staticRoot:yes')

local kn5joinexe = ""
if     io.fileExists(dirTrackDeco .. "kn5join\\kn5join.exe") then
       kn5joinexe = (dirTrackDeco .. "kn5join\\kn5join.exe")
elseif io.fileExists(dirTrackDeco .. "dataSections\\kn5join\\kn5join.exe") then
       kn5joinexe = (dirTrackDeco .. "dataSections\\kn5join\\kn5join.exe")
elseif io.fileExists(dirTrackDeco .. "obj\\kn5join\\kn5join.exe") then
       kn5joinexe = (dirTrackDeco .. "obj\\kn5join\\kn5join.exe")
elseif io.fileExists(dirTrackDeco .. "dataSections\\kn5join.exe") then
       kn5joinexe = (dirTrackDeco .. "dataSections\\kn5join.exe")
elseif io.fileExists(dirTrackDeco .. "obj\\kn5join.exe") then
       kn5joinexe = (dirTrackDeco .. "obj\\kn5join.exe")
elseif io.fileExists(dirTrackDeco .. "kn5join.exe") then
       kn5joinexe = (dirTrackDeco .. "kn5join.exe")
end

local vDown    = vec3(0, -1, 0)
local vUp      = vec3(0, 1, 0)
local vSouth   = vec3(0, 0, 1)
local vNorth   = vec3(0, 0, -1)
local vEast    = vec3(1, 0, 0)
local vWest    = vec3(-1, 0, 0)
local axisX    = vec3(1, 0, 0)
local axisZ    = vec3(0, 1, 0)
local axisY    = vec3(0, 0, 1)

local fntSize = 24

local p1=vec2(10,30)
local p2=vec2(328,328) -- originial size
local camlook = ac.getCameraForward()
local dirCompass = -math.atan2(camlook.z, camlook.x)


local function degressToCompassString(angleDeg)
  local value = math_round(angleDeg / 22.5)
  if value == 0 or value == 16 then
    return 'N'
  elseif value == 1 then
    return 'NNE'
  elseif value == 2 then
    return 'NE'
  elseif value == 3 then
    return 'ENE'
  elseif value == 4 then
    return 'E'
  elseif value == 5 then
    return 'ESE'
  elseif value == 6 then
    return 'SE'
  elseif value == 7 then
    return 'SSE'
  elseif value == 8 then
    return 'S'
  elseif value == 9 then
    return 'SSW'
  elseif value == 10 then
    return 'SW'
  elseif value == 11 then
    return 'WSW'
  elseif value == 12 then
    return 'W'
  elseif value == 13 then
    return 'WNW'
  elseif value == 14 then
    return 'NW'
  elseif value == 15 then
    return 'NNW'
  else
    return '?'
  end
end


local txt = ""

--compass
function script.windowCompass(dt)
    ui.beginOutline()
    local wh = math.min(ui.windowWidth(),ui.windowHeight())
    p2=vec2(wh-30,wh-10)
    camlook = ac.getCameraForward()
    -- var 1
    dirCompass = -math.atan2(camlook.z, camlook.x)
    -- dirCompass = -math.atan2(camlook.x, camlook.z)

    -- var 2
    -- dirCompass = math.rad(ac.getCompassAngle(camlook))

    if bCompassGraphics then
        if bCompassInverted then
            ui.beginRotation()
            ui.drawImage("compass_base.png"  , p1, p2)
            ui.endRotation(math.deg(dirCompass))
            ui.drawImage("compass_needle.png", p1, p2)
        else
            ui.drawImage("compass_base.png"  , p1, p2)
            ui.beginRotation()
            ui.drawImage("compass_needle.png", p1, p2)
            ui.endRotation(math.deg(dirCompass))
        end
    end
    if bCompassDegrees then
        -- dirCompass = dirCompass + math.rad(270)
        -- if dirCompass > math.rad(360) then dirCompass = math.rad(360) - (dirCompass - math.rad(360)) end
        -- if dirCompass < 0 then dirCompass = dirCompass + math.rad(360) end
        dirCompass = math.deg(dirCompass)-90
        if dirCompass<0 then
            dirCompass = -dirCompass
        else
            dirCompass = 360-dirCompass
        end
        txt = string.format('%.1f° %s', dirCompass, degressToCompassString(dirCompass))

        ui.setCursorX(ui.availableSpaceX()/3)
        ui.setCursorY(ui.availableSpaceY()/2.75)
        ui.dwriteTextAligned(txt, 16, ui.Alignment.Center, ui.Alignment.Center, p2/2, true)
        -- ui.text("     " .. math_round(math.deg(dirCompass), 1) .. "°")
    end
    ui.endOutline(rgbm.colors.black, 0.25)
end





local doShowPlacementHelper = false
local doMoveStuff = false
local doRotateStuff = false
local doDuplicate = false

local insideWindow = false
local selectedObj = 1
local keydelay = 0.0
local keydelay2=0.0
local MaxSectID = 0
local cursorpos = vec3(0,0,0)
local cursorposray = vec3(0,0,0)

local TableDir = {}
local TableSlope = {}
local TableIdeal = {}
local TableL = {}
local TableR = {}

local lastpos = vec3(0,1000000,0)
local lastposMove = vec3(0,1000000,0)
local origposMove = vec3(0,1000000,0)

local ObjPreview = nil
local previewLook = vec3(0,0,0)

local objpreview1 = ui.ExtraCanvas(256, 4)
local objpreview2 = ui.ExtraCanvas(256, 4)

local bShowNumbers = false
local objsSelected = 0
local ckbSlow=false
local ckbFast=false

local dirsurf = vec3(0,0,0)
local keepfirstDir = false
local keepfirst = false
local rotZadd = 0.0

local lastReply = ""

local o1 = nil
local o2 = nil
local z1 = 1.0
local z2 = 1.0


local function snapToTrackSurface(pos, gap)
    local p = pos
    local v1 = vec3()
    physics.raycastTrack(v1:set(0, 4, 0):add(vec3(pos.x,pos.y+2.0,pos.z)), vDown, 8, p, dirsurf)
    p.y = p.y + gap
end

local function getPosfromMouse()
    local ray = nil
    ray = render.createMouseRay()
    cursorpos = ray.dir * ray:track() + ray.pos
end




local KN5axis = nil ---@ac.sceneReference

if io.fileExists(ac.getFolder(ac.FolderID.Root)..'/sdk/editor/content/objects3D/axis.kn5') then
    KN5axis = basenode:loadKN5(ac.getFolder(ac.FolderID.Root)..'/sdk/editor/content/objects3D/axis.kn5')
    KN5axis:setVisible(false)
elseif io.fileExists(ac.getFolder(ac.FolderID.Root)..'/content/objects3D/axis.kn5') then
    KN5axis = basenode:loadKN5(ac.getFolder(ac.FolderID.Root)..'/content/objects3D/axis.kn5')
    KN5axis:setVisible(false)
end


local function GetObjectLIGHTMesh(kn5)
    for i=1, #ValidLightMeshes do
        if string.lower(ValidLightMeshes[i]["kn5"]) == string.lower(kn5) then
            return i
        end
    end
    return -1
end

local function GetObjectOFFSET(kn5)
    local OFFSET = 0
    for k, v in pairs(ValidKn5sOFFSETS) do
        if string.lower(k) == string.lower(kn5) then
            OFFSET = v
            break
        end
    end
    return OFFSET
end

local function GetObject_FORCE_CAST_SHADOWS(kn5)
    local FORCE = false
    local VAL = true
    for k, v in pairs(FORCE_CAST_SHADOWS) do
        if string.lower(k) == string.lower(kn5) then
            FORCE = true
            VAL = v
            break
        end
    end
    return FORCE, VAL
end

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

local function GetRIGID_BODY_ID(kn5name)
    for i=1, #Rigid_Kn5s do
        if string.lower(kn5name)==string.lower(Rigid_Kn5s[i]) then
            return i
        end
    end
    return 0
end

local function RigidBodiesRemove(i)
    if RigidBodies and i<=#RigidBodies and i>0 then
    RigidBodies[i]['phy']:dispose()
    -- RigidBodies[i]['vis']:dispose()
    table.remove(RigidBodies, i)
    table.clear(ObjsHit)
    iRigidBodyHit = 0
    end
end

local function RigidBodiesReset()
    for i=1, #RigidBodies do
        RigidBodies[i]['phy']:dispose()
        -- RigidBodies[i]['vis']:dispose()
    end
    table.clear(RigidBodies)
    table.clear(ObjsHit)
    iRigidBodyHit = 0
end

local function ObjectsReset()
    rotZadd=0.0
    RigidBodiesReset()
    for i=1, #Objects do
        if Objects[i]['lit']~=nil then
            Objects[i]['lit']:dispose()
        end
        Objects[i]['vis']:dispose()
    end
    table.clear(TabSeen)
    table.clear(Objects)
    table.clear(ObjectsList)
end

local lp1=tonumber(0)
local lp2=tonumber(0)
local lz1=tonumber(0)
local lz2=tonumber(0)
local _ref = ac.emptySceneReference()
local out = vec3(0,0,0)
local out2 = vec3(0,0,0)

local loaded = {}

local function MakePreviews()
    if ac.getPatchVersionCode()<=2144 then return end


    if lp1~=currObjkn5 or lz1~=z1 then
        lp1 = currObjkn5
        lz1 = z1
        o1 = basenode:loadKN5("obj/"..ValidKn5sApp[currObjkn5])
        if o1 then
            local objOffset = GetObjectOFFSET(ValidKn5sApp[currObjkn5])
            local o1meshes = o1:findMeshes("?")
            o1meshes:setPosition( o1meshes:getPosition() + vUp * objOffset )

            out = vec3(0,0,0)
            local bound
            local min, max = o1meshes:at(1):getLocalAABB()
            -- if o1meshes:class isActive(1) then
            if o1meshes:class(1)==ac.ObjectClass.Mesh then
                bound = o1meshes:boundingSphere(1, out)
                min, max = o1meshes:at(1):getLocalAABB()
            end
            for i = 2, #o1meshes do
                local subM = o1meshes:at(i)
                -- if subM:isActive() then
                if subM:class(i)==ac.ObjectClass.Mesh then
                    local min2, max2 = subM:getLocalAABB()
                    if min2.x<min.x then min.x = min2.x end
                    if min2.y<min.y then min.y = min2.y end
                    if min2.z<min.z then min.z = min2.z end
                    if max2.x>max.x then max.x = max2.x end
                    if max2.y>max.y then max.y = max2.y end
                    if max2.z>max.z then max.z = max2.z end
                    local bound2 = o1meshes:boundingSphere(i, out2)
                    bound = bound + bound2
                    out = out + out2
                    -- ac.debug("aabb min"..i, min2)
                    -- ac.debug("aabb max"..i, max2)
                end
            end

            local width  = math_round(math.abs(min.x) + max.x, 3)*2
            local height = math_round(math.abs(min.y) + max.y, 3)*2
            local depth  = math_round(math.abs(min.z) + max.z, 3)*2

            -- ac.debug("aabb min1", min)
            -- ac.debug("aabb max1", max)
            -- ac.debug("boundingcenter", bound)
            -- ac.debug("boundingsize", out)
            -- ac.debug("X width", tostring(width))
            -- ac.debug("X height", tostring(height))
            -- ac.debug("X depth", tostring(depth))

            local shot = ac.GeometryShot(o1meshes, vec2(256, 256))
            -- shot:setShadersType(render.ShadersType.SampleColor)
            shot:setShadersType(render.ShadersType.Shadows)
            shot:setTransparentPass(true)
            --shot:setClippingPlanes(1, 1000)
            -- shot:setOrthogonalParams(vec2(10, 10), 10)
            --shot:setClippingPlanes(-10, 0)
            local ratio = math.abs(width)/math.abs(height)
            if ratio>1 then
                ratio = (math.abs(height)/math.abs(width))
            end

            if not table.contains(loaded, currObjkn5) then
                -- first time twice to make preview work
                shot:update(--pos
                    vec3(z1/10, (height/2) + z1/5, 2+   (math.abs(min.z)+z1/10)),
                    --look dir
                    vec3(0,-1+ratio/10,-1),
                    --up
                    vec3(0,1,0), 60)
                objpreview1 = ui.ExtraCanvas(256, 4):copyFrom(shot)
            end

            if get_file_name(ValidKn5sApp[currObjkn5])=="aclogo_big.kn5" then
                objOffset=1
            end

            shot:update(--pos
                vec3(z1/10, objOffset + (height*1)/2 + z1/10, 1+(height+width)/2+z1/10),
                --look dir
                vec3(0,-1+ratio,-1),
                --up
                vec3(0,1,0), 60)
            objpreview1 = ui.ExtraCanvas(256, 4):copyFrom(shot)

            shot:dispose()
            o1:dispose()
        end
    end

    if lp2~=currObjkn5sameplace or lz2~=z2 then
        lp2 = currObjkn5sameplace
        lz2 = z2
        if not table.contains(loaded, currObjkn5sameplace) then
            table.insert(loaded, currObjkn5sameplace)
            o2 = basenode:loadKN5("obj/"..ValidKn5sApp[currObjkn5sameplace])
            o2:dispose()
        end

        o2 = basenode:loadKN5("obj/"..ValidKn5sApp[currObjkn5sameplace])
        if o2 then
            local objOffset = GetObjectOFFSET(ValidKn5sApp[currObjkn5])
            local o2meshes = o2:findMeshes("?")
            o2meshes:setPosition( o2meshes:getPosition() + vUp * objOffset)

            local bound
            local min, max = o2meshes:at(1):getLocalAABB()
            if o2meshes:class(1)==ac.ObjectClass.Mesh then
            -- if o2meshes:isActive(1) then
                min, max = o2meshes:at(1):getLocalAABB()
            end
            for i = 2, #o2meshes do
                local subM = o2meshes:at(i)
                if subM:class(i)==ac.ObjectClass.Mesh then
                -- if subM:isActive() then
                    local min2, max2 = subM:getLocalAABB()
                    if min2.x<min.x then min.x = min2.x end
                    if min2.y<min.y then min.y = min2.y end
                    if min2.z<min.z then min.z = min2.z end
                    if max2.x>max.x then max.x = max2.x end
                    if max2.y>max.y then max.y = max2.y end
                    if max2.z>max.z then max.z = max2.z end
                    local bound2 = o2meshes:boundingSphere(i, out2)
                    bound = bound + bound2
                    out = out + out2
                end
            end

            local width  = math_round(math.abs(min.x) + max.x, 3)
            local height = math_round(math.abs(min.y) + max.y + math.abs(min.y), 3)
            local depth  = math_round(math.abs(min.z) + max.z, 3)


            local shot = ac.GeometryShot(o2meshes, vec2(256, 256))
            -- shot:setShadersType(render.ShadersType.SampleColor)
            shot:setShadersType(render.ShadersType.Shadows)
            shot:setTransparentPass(true)

            local ratio = width/height
            if ratio>1 then
                ratio = height/width
            end
            if not table.contains(loaded, currObjkn5) then
                -- first time twice to make preview work
                shot:update(--pos
                    vec3(z2, objOffset + (height*1) + z1/10, 1+(height+width)/2+z1/10),
                    --look dir
                    vec3(0,-1+ratio,-1),
                    --up
                    vec3(0,1,0), 60)
                objpreview2 = ui.ExtraCanvas(256, 4):copyFrom(shot)
            end

            if get_file_name(ValidKn5sApp[currObjkn5sameplace])=="aclogo_big.kn5" then
                objOffset=1
            end

            shot:update(--pos
                vec3(z2/10, objOffset + (height*1)/2 + z2/10, 1+(height+width)/2+z2/10),
                --look dir
                vec3(0,-1+ratio,-1),
                --up
                vec3(0,1,0), 60)
            objpreview2 = ui.ExtraCanvas(256, 4):copyFrom(shot)

            shot:dispose()
            o2:dispose()
        end
    end
end



local function LoadTrackModelsINI(sectINI)
    if not io.fileExists(sectINI) then
        ac.debug('INI not found', sectINI)
        return 0
    else
        local i = 0
        local sectName = "MODEL_"..i
        local sectFILE = readACConfig(sectINI, sectName, "FILE", "")
        while sectFILE~="" and i<500 do
            i=i+1
            sectName = "MODEL_"..i
            sectFILE = readACConfig(sectINI, sectName, "FILE", "")
        end
        return i
    end
end



local function GetNextModelID_from_ModelsINI()
    if ac.getTrackLayout()~="" then
        return LoadTrackModelsINI(ac.getFolder(ac.FolderID.Root) .. "/content/tracks/"..ac.getTrackID().."/models_".. ac.getTrackLayout() .. ".ini")
        -- return LoadTrackModelsINI(ac.getFolder(ac.FolderID.CurrentTrack) .. "/models_".. ac.getTrackLayout() .. ".ini")
    else
        return LoadTrackModelsINI(ac.getFolder(ac.FolderID.Root) .. "/content/tracks/"..ac.getTrackID().."/models.ini")
        -- return LoadTrackModelsINI(ac.getFolder(ac.FolderID.CurrentTrack) .. "/models.ini")
    end
    return 0
end

local function GetKn5IDByName(kn5name)
    for i=1, #ValidKn5sApp do
        if kn5name==ValidKn5sApp[i] then
            return i
        end
    end
    return -1
end


local function StopPlacementHelper()
    -- bSelectMode = false
    -- keydelay = 0.5
    doShowPlacementHelper = false
    doMoveStuff = false
    doRotateStuff = false
    doDuplicate = false
    if KN5axis then
    KN5axis:setVisible(false) end
    if ObjPreview then
        ObjPreview:dispose()
        ObjPreview=nil
    end
end

local function StartPlacementHelper()
    lastReply=""
    -- rotZadd = 0
    keepfirst = false
    doShowPlacementHelper = true
    if KN5axis then
        KN5axis:setVisible(true)
    end
    -- bHidden = true
    -- ac.setWindowOpen("windowTrackDecorationid", false)
end







local function GetSurfaceRot(look)
    local yaw   =  math.atan2(look.x, look.z)
    local pitch = 0 -- -math.sin(look.z)
    local roll  = math.atan2(look.y, look.x)
    return math.deg(yaw), math.deg(pitch), 90-math.deg(roll)
end



-- local function GetRotation(dir, up, trans)
local function GetRotation(dir, up, side)
    -- local dir   = Objects[i]['vis']:getLook()
    -- local up    = Objects[i]['vis']:getUp()
    -- local trans = Objects[i]['vis']:getTransformationRaw():normalize()
    local yaw   = -math.atan2(dir.x, dir.z)
    local pitch = -math.atan2(side.y, up.y)
    -- local pitch = math.atan2(trans.side.y, up.y)
    local roll  =  math.asin(dir.y)
    return math.deg(yaw), math.deg(pitch), math.deg(roll)
end



--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------



local function SetPhysical(meshname, kn5id, visObj, destpos, rot)
    local RID = GetRIGID_BODY_ID(ValidKn5sApp[kn5id])
    ac.debug("RIGID BODY ID", tostring(RID) .. "   " .. ValidKn5sApp[kn5id])
    if visObj and RID > 0 then

        local newPhysics = physics.allowed()
        if newPhysics and ValidKn5sApp[kn5id]=="jump.kn5" then
            -- load object
            local verts = {
                vec3(-186.32, 5.91, 18.63),
                vec3(-188.59, 6.30, 17.70),
                vec3(-187.58, 6.32, 15.43),
                vec3(-186.32, 5.91, 18.63),
                vec3(-187.58, 6.32, 15.43),
                vec3(-184.85, 5.85, 16.58),
            }
            local indices = {
                0, 1, 2, 3, 4, 5
            }
            -- local phyBody =  physics.addTrackSurface(verts, indices, "CONCRETE", nil, rgbm.colors.gray)

            local vertsO = visObj:findMeshes('?'):getVertices()
            local indices0 = visObj:findMeshes('?'):getIndices()
            if vertsO then
                verts = {}
                indices = {}
                for i = 0, vertsO:size()-1 do
                    table.insert(   verts, vertsO.raw[i].pos          )
                    -- table.insert(verts, (vertsO.raw[i].pos + destpos))
                end
                for i = 0, indices0:size()-1 do
                    table.insert(indices, indices0.raw[i])
                end
            end

            -- local phyBody =  physics.addTrackSurface(verts, indices, "CONCRETE", nil, rgbm.colors.gray)

            local mat = mat4x4()
            mat = visObj:getTransformationRaw()
            -- mat = visObj:getWorldTransformationRaw()
            -- mat.look     = visObj:getLook()
            -- -- mat.side     = visObj:getTransformationRaw().side
            -- mat.side     = visObj:getWorldTransformationRaw().side
            -- mat.up       = visObj:getUp()
            -- mat.position = visObj:getPosition()
            local phyBody =  physics.addTrackSurface(
                --  verts, indices, "CONCRETE", mat, rgbm.colors.gray)
                 verts, indices, "ROAD", mat, rgbm.colors.gray)



            -- visObject:rotate(axisZ, math.rad(-dir.x))
            -- visObject:rotate(axisX, math.rad(-dir.z))
            -- visObject:rotate(axisY, math.rad(-dir.y))


            -- phyBody.position(visObj:getPosition())

            table.insert(PhysicsBodies, phyBody)

        else

            -- load object with RigidBody physics
            local dynObject = physics.RigidBody("obj/"..Rigid_Kn5s[RID], Rigid_Mass[RID], vec3(0,Rigid_COG[RID],0), false, false)
            if dynObject then
                -- snapToTrackSurface(pos, 0.001)
                -- visObj:setPosition(pos)
                -- if rot~=nil then
                --     visObj:rotate(axisZ, math.rad(-rot.x))
                --     visObj:rotate(axisX, math.rad(-rot.y))
                --     visObj:rotate(axisY, math.rad(-rot.z))
                -- else
                --     visObj:setRotation(axisZ, -math.atan2(rot.x, rot.z)+math.rad(180) )
                -- end

                dynObject:setTransformationFrom(visObj)
                dynObject:setInWorld(true)
                if Rigid_Mass[RID]<1000 then
                    dynObject:setEnabled(true)
                    dynObject:setDamping(0.001, 0.001*Rigid_Mass[RID] , false)
                    dynObject:setSemiDynamic(true, true)
                else
                    dynObject:setEnabled(false)
                    dynObject:setDamping(10000, 10000, false)
                    dynObject:setSemiDynamic(false, false)
                end
                -- ac.debug("sdfsadf", "adfga")
                -- dyncone:getLastHitIndex()

                table.insert(RigidBodies, {['phy']=dynObject, ['vis']=visObj, ['kn5']="obj/"..Rigid_Kn5s[RID], ['kn5id']=kn5id, ['sele']=false})
                local id = #RigidBodies
                dynObject:onCollision((function ()
                    if  not table.contains(ObjsHit, id) and
                        #RigidBodies>0
                        -- and
                        -- bRunning and
                        --not bRigidBodyHit and
                        --currActiveSection>-1 and
                        --CustomSects[currActiveSection]['conemode']>-1
                    then
                        -- -- reset when cone hit
                        iRigidBodyHit = iRigidBodyHit + 1
                        table.insert(ObjsHit, id)
                        -- sMsg = tostring(#ObjsHit).." Objects hit"
                        -- timerMsg = 2.0
                    end
                end))
                return true
            end
        end
    end
    return false
end



local function AddPreviewObject(pos, kn5id, id, snaptoground)
    ObjPreview = basenode:loadKN5("obj/"..ValidKn5sApp[kn5id])
    if ObjPreview~=nil then
        local force, val = GetObject_FORCE_CAST_SHADOWS(ValidKn5sApp[kn5id])
        if force then
            if val then
            ObjPreview:findMeshes("?"):applyShaderReplacements("CAST_SHADOWS=1")
            else
            ObjPreview:findMeshes("?"):applyShaderReplacements("CAST_SHADOWS=0")
            end
        end
        previewLook = ObjPreview:getLook()
        ObjPreview:setPosition(pos + vUp * GetObjectOFFSET(ValidKn5sApp[kn5id]))

        if KN5axis then
        KN5axis:setVisible(true)
        KN5axis:setPosition(pos)
        end
    end
end



local function AddObject(pos, dir, kn5id, id, snaptoground, dontallowsameplace)
    if kn5id==-1 then return end
    if not io.fileExists(dirTrackDeco.."obj/"..ValidKn5sApp[kn5id]) then
        ac.debug("file not found: "..ValidKn5sApp[kn5id], "in obj/ folder")
        return
    end

    local OFFSET = 0.0
    --OFFSET = GetObjectOFFSET(ValidKn5sApp[kn5id])

    -- distance check to other objs
    if dontallowsameplace then
        if pos and lastpos and lastpos.y~=1000000 and #Objects>0 then
            if lastpos:distance(pos + vUp*OFFSET) < 0.5 then
                -- for i=1, #Objects do
                --     local p1 = Objects[i]['vis']:getPosition()
                --     if math.abs(pos:distance(p1))<=0.5 then
                --         -- doShowPlacementHelper = false
                --         StopPlacmentHelper()
                --         keydelay=0.2
                    -- ac.debug("_____dist ", "out!!!!!!!!!!!!!!!!!!!")
                    return
                --     end
            end
        end
    end

    local visObject = basenode:loadKN5("obj/"..ValidKn5sApp[kn5id])
    if visObject~=nil then
        local meshname = get_file_name(ValidKn5sApp[kn5id])
        meshname = meshname:sub(1, #meshname-4)
        if #visObject:findMeshes("?")>0 then
            meshname = visObject:findMeshes("?"):name(1)
        end

        if  string.find(meshname, "AC_TIME_"     )==1 or
            string.find(meshname, "AC_AB_START_" )==1 or
            string.find(meshname, "AC_AB_FINISH_")==1
        then
        else
            local seen = false
            for i=1, #TabSeen do
                if TabSeen[i]['kn5'] == ValidKn5sApp[kn5id] then
                    seen = true
                    TabSeen[i]['id'] = TabSeen[i]['id']+1
                    meshname = meshname .. "_" .. tostring(TabSeen[i]['id'])
                    break
                end
            end
            if not seen then
                table.insert(TabSeen, { ['kn5']=ValidKn5sApp[kn5id], ['id']=0 } )
                meshname = meshname .. "_0"
            end
        end

        if snaptoground then
            snapToTrackSurface(pos, 0.0)
        end

        -- ['look']
        local baselook = visObject:getLook()
        local baseup = visObject:getUp()
        local mat = visObject:getTransformationRaw()
        visObject:setPosition(pos+vUp*OFFSET)
        lastpos = pos:clone() + vUp*OFFSET

        visObject:rotate(axisZ, math.rad(-dir.x))
        visObject:rotate(axisX, math.rad(-dir.z))
        visObject:rotate(axisY, math.rad(-dir.y))
        visObject:rotate(axisZ, rotZadd)

        local force, val = GetObject_FORCE_CAST_SHADOWS(ValidKn5sApp[kn5id])
        if force then
            if val then
            visObject:findMeshes("?"):applyShaderReplacements("CAST_SHADOWS=1")
            else
            visObject:findMeshes("?"):applyShaderReplacements("CAST_SHADOWS=0")
            end
        end
        -- visObject:findMeshes("?"):applyShaderReplacements("CAST_SHADOWS=1")
        -- visObject:findMeshes("?"):applyShaderReplacements("DOUBLE_FACE_SHADOW_BIASED=1")

        local light = nil
        local litMeshid = GetObjectLIGHTMesh(ValidKn5sApp[kn5id])
        if litMeshid > 0 then
            local m = visObject:findMeshes(ValidLightMeshes[litMeshid]["litmesh"])
            light = ac.LightSource(ac.LightType.Regular)
            light.position = visObject:getPosition() + vUp * m:boundingSphere().y

            -- ["dir"]="0,-1,0"
            light.direction = vDown
            -- light.direction = visObject:getLook()
            if string.upper(ValidLightMeshes[litMeshid]["dir"]) == "NORMAL" then
            light.direction = visObject:getLook()
            else
                local s = string.split(tostring(ValidLightMeshes[litMeshid]["dir"]), ",")
                if s and #s==3 then
                    local v3 = vec3(tonumber(s[1]), tonumber(s[2]), tonumber(s[3]) )
                else
                    light.direction = vDown
                end
            end

            -- ["spot"]=180,
            -- light.spot = 180
            light.spot = ValidLightMeshes[litMeshid]["spot"]
            light.spotSharpness = 0.5
            light.range = ValidLightMeshes[litMeshid]["range"]
            light.shadows = true
            light.fadeAt = 500
            light.fadeSmooth = 30
            light.color = ValidLightMeshes[litMeshid]["color"]
            m:applyShaderReplacements("PROP_...=ksEmissive, " ..
                tostring(ValidLightMeshes[litMeshid]["color"].r*5)..","..
                tostring(ValidLightMeshes[litMeshid]["color"].g*5)..","..
                tostring(ValidLightMeshes[litMeshid]["color"].b*5),
                'ac.IncludeType.Track'
            )
        end

        local physical = false
        if SetPhysical(meshname, kn5id, visObject, pos, dir) then
            physical = true
        end

        table.insert(Objects, {['vis']=visObject,
            ['kn5']=ValidKn5sApp[kn5id], ['kn5id']=kn5id, ['id']=id,
            ['sele']=false, ['lit']=light, ['name']=meshname,
            ['rot']=dir, ['look']=baselook, ['phy']=physical })
        -- ac.debug(id, dir)
        -- table.insert(ObjectsList, {['kn5']=ValidKn5sApp[kn5id], ['pos']=pos, ['dir']=dir, ['kn5id']=kn5id})
    end
end




local function LoadTXT(txtf)
    if not io.fileExists(txtf) then
        lastReply = 'file not found: \n'.. txtf
        ac.debug('TXT not found', txtf)
        return 0
    else
        -- ac.debug("opening ", txtf)
        local f = io.open(txtf, "r")
        if f then
            local content = string.split(f:read("a"), "\n")
            f:close()
            local v3 = vec3(0,0,0)

            -- tree: Beech_11.bin; -49.298,16.268,-93.402;size=1.200;width=1.300
            for i,line in pairs(content) do
                local cols = string.split(line, ";")
                if #cols>1 then

                    -- get kn5 used
                    local valkn5 = ValidKn5sApp[currObjkn5]
                    local valkn5ID = currObjkn5
                    for j=1, #ValidKn5sApp do
                        local txtoname = cols[1]:gsub("tree: ", ""):gsub("tree:", ""):lower():gsub(".bin", "")
                        if string.find(get_file_name(ValidKn5sApp[j]):lower(), txtoname) then
                            valkn5 = get_file_name(ValidKn5sApp[j]):lower()
                            valkn5ID = j
                            break
                        end
                    end

                    -- insert new Obj at coords
                    local sPOS = string.split(tostring(cols[2]),',')
                    if #sPOS==3 then
                        local pos = vec3( tonumber(sPOS[1]:trim()), tonumber(sPOS[2]:trim()), tonumber(sPOS[3]:trim()) )
                        --table.insert(ObjectsList, {['kn5']=ValidKn5sApp[j], ['pos']=pos, ['dir']=nil, ['kn5id']=j})
                        AddObject(pos, v3, valkn5ID, #Objects, false, false)
                    end
                end
            end
        end
    end
end




local function IsBasicCSV(s)
    local valid = tostring("0123456789,.-")
    for i=1, #s do
        if not string.find(valid, s[i]) then
            return false
        end
    end
    return true
end

local function LoadCSV(csvfile)
    if not io.fileExists(csvfile) then
        lastReply = "file not found: \n" .. csvfile
        ac.debug("file not found", csvfile)
    else
        local ghdate = os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(csvfile).lastWriteTime))
        local ghtime = ""

        local f = io.open(csvfile, 'r')
        if not f then
            lastReply = "could not open '.csv'\n" .. csvfile
            ac.debug("could not open '.csv'", csvfile)
            return
        else
            local lines = f:read("a"):split("\n")
            local coord = vec3(0,0,0)
            f:close()

            local colX, colY, colZ = 0,0,0
            local lineid = 0
            local switchY = false

            for i=1, #lines do
                if IsBasicCSV(lines[i]) then
                    local ll = string.split(lines[i], ",")
                    if #ll==3 or #ll==4 then
                        colX, colY, colZ = 1,2,3
                        lineid = 1
                        switchY = true
                        break
                    end
                end

                if  tostring(lines[i]):find("World Pos X") and
                    tostring(lines[i]):find("World Pos Y") and
                    tostring(lines[i]):find("World Pos Z")
                then
                    local cols = lines[i]:split(",")
                    for j=1, #cols do
                        if tostring(cols[j]):find("World Pos X") then colX=j end
                        if tostring(cols[j]):find("World Pos Y") then colY=j end
                        if tostring(cols[j]):find("World Pos Z") then colZ=j end
                    end
                    lineid = i + 2
                    break
                end
            end

            if not (colX>0 and colY>0 and colZ>0) or lineid==0 then
                return
            end

            local valkn5 = ValidKn5sApp[currObjkn5]
            while lineid < #lines do
                if lines[lineid]~="" then
                    local cols = lines[lineid]:split(",")
                    if #cols>=3 then
                        -- ac.debug("lineid", lineid)
                        -- ac.debug("colX", colX)
                        -- ac.debug("cols[colX]", cols[colX]:replace('"','') )
                        -- if true then
                        -- return end
                        local x = cols[colX]:gsub('"','')
                        local y = cols[colY]:gsub('"','')
                        local z = cols[colZ]:gsub('"','')
                        if switchY then
                            z = -z
                        end

                        coord.x=tonumber(x)
                        coord.y=tonumber(y)
                        coord.z=tonumber(z)
                        if bAlignToSurface then
                            snapToTrackSurface(coord, 0.0)
                        end
                        AddObject(coord, vec3(0,0,0), currObjkn5, #Objects+1, false, false)
                    end
                end
                lineid=lineid+1
            end

            return
        end
    end
end


local function LoadCustomModelsINI(sectINI)
    rotZadd=0.0

    if not io.fileExists(sectINI) then
        lastReply = 'INI not found\n' .. sectINI
        ac.debug('INI not found', sectINI)
    else
        local f = io.open(sectINI, 'r')
        if not f then
            lastReply = "could not open \n" .. sectINI
            ac.debug("could not open \n", sectINI)
            return
        else
            ac.perfBegin("Loading INI File")
            local lines = f:read("a"):split("\n")
            f:close()

            lastReply = ""

            -- [MODEL_x]
            -- FILE=.kn5
            -- POSITION=-59.314, 26.241, 572.887
            -- ROTATION=100,0,0
            table.clear(ObjectsList)
            local foundsome = false
            local i = 1
            local sPOS = {""}
            local sROT = {""}
            local pos = vec3(0,0,0)
            local dir = vec3(0,0,0)
            local sectFILE = ""
            while i<#lines do
                sectFILE = ""
                -- line = lines[i]
                -- ac.debug("§came here", lines[i])
                -- ac.debug("§came here2 " .. tostring(string.find(lines[i], "%[MODEL_" )) , " --- " )
                if lines[i] and string.find(lines[i], "^%[MODEL_") then
                    i=i+1
                    if string.split(lines[i], "=")[1] == "FILE" then
                        sectFILE = string.split(lines[i], "=")[2]
                    elseif string.split(lines[i], "=")[1] == "POSITION" then
                        sPOS = string.split(string.split(lines[i], "=")[2],',')
                    elseif string.split(lines[i], "=")[1] == "ROTATION" then
                        sROT = string.split(string.split(lines[i], "=")[2],',')
                    end
                    i=i+1
                    if string.split(lines[i], "=")[1] == "FILE" then
                        sectFILE = string.split(lines[i], "=")[2]
                    elseif string.split(lines[i], "=")[1] == "POSITION" then
                        sPOS = string.split(string.split(lines[i], "=")[2],',')
                    elseif string.split(lines[i], "=")[1] == "ROTATION" then
                        sROT = string.split(string.split(lines[i], "=")[2],',')
                    end
                    i=i+1
                    if string.split(lines[i], "=")[1] == "FILE" then
                        sectFILE = string.split(lines[i], "=")[2]
                    elseif string.split(lines[i], "=")[1] == "POSITION" then
                        sPOS = string.split(string.split(lines[i], "=")[2],',')
                    elseif string.split(lines[i], "=")[1] == "ROTATION" then
                        sROT = string.split(string.split(lines[i], "=")[2],',')
                    end

                    if sectFILE ~= "" and #sPOS>=3 and #sROT>=3 then

                        -- ac.debug(i, sectFILE)
                        if not io.fileExists(dirTrackDeco.."obj/"..sectFILE) then
                            if lastReply=="" then
                                lastReply = "Reading   " .. sectINI .. "\n"
                            end
                            lastReply = lastReply ..lines[i-3].."  --  FILE= not found:   obj/"..sectFILE .."\n"
                            ac.debug("file not found: "..lines[i-3], "obj/"..sectFILE)
                        else
                            pos = vec3( tonumber(sPOS[1]), tonumber(sPOS[2]), tonumber(sPOS[3]) )
                            dir = vec3( math_round(tonumber(sROT[1]),1), math_round(tonumber(sROT[2]),1), math_round(tonumber(sROT[3]),1) )
                            for k,vkn5 in pairs(ValidKn5sApp) do
                                if string.lower(vkn5)==string.lower(sectFILE) then
                                    if not foundsome then foundsome=true end
                                    table.insert(ObjectsList, {['kn5']=sectFILE, ['pos']=pos, ['dir']=dir, ['kn5id']=k})
                                    break
                                end
                            end
                        end
                    end

                end
                i=i+1
            end
            ac.perfEnd("Loading INI File")
            -- writeACConfig("debug.txt", "done", "objs", #ObjectsList)
        end
    end
end




local function SaveCustomModelsINI(inifile, curr)
    -- lastReply = "Folder: " .. io.getParentPath(inifile).."\n"
    lastReply = "File: " .. inifile.."\n"
    local f = io.open(inifile, "w")
    if not f then
        lastReply = lastReply .."\nCould not open\n" .. inifile
    else
        local done = {}
        for i=1, #ValidLightMeshes do
            for j=1, #Objects do
                if ValidLightMeshes[i]["kn5"] == Objects[j]['kn5']
                   and not table.contains(done, ValidLightMeshes[i]["litmesh"])
                then
                    if #done==0 then
                        f:write(";;; !light config not used by TrackDeco app!'\n")
                        f:write(";;; !use this in 'ext_config.ini'!\n\n")
                    end
                    table.insert(done, ValidLightMeshes[i]["litmesh"])

                    -- [MATERIAL_ADJUSTMENT_...]
                    -- KEY_...=ksEmissive
                    -- VALUE_...=10
                    -- VALUE_OFF...=0
                    -- KEY_...=ksAlphaRef
                    -- VALUE_...= -193
                    -- VALUE_OFF...=0
                    -- CONDITION=NIGHT_SMOOTH
                    -- [INCLUDE]
                    -- INCLUDE = common/conditions.ini, common/all_conditions.ini, common/materials_track.ini, common/custom_emissive.ini, common/grass_fx.ini
                    -- [INCLUDE: common/conditions.ini]
                    local color = tostring(ValidLightMeshes[i]["color"])
                    -- ac.debug("color", color)
                    color=string.gsub(color, " ","")
                    color=string.gsub(color, "%(","")
                    color=string.gsub(color, "%)","")

                    f:write("[INCLUDE: common/conditions.ini]\n")
                    f:write("[MATERIAL_ADJUSTMENT_...]\n")
                    f:write("MESHES"        .."="..ValidLightMeshes[i]["litmesh"] .."?\n")
                    f:write("KEY_..."       .."=ksEmissive\n")
                    f:write("VALUE_..."     .."="..color ..", 5\n")
                    f:write("VALUE_OFF_..." .."=0\n")
                    -- f:write("VALUE_..."     .."="..tostring(ValidLightMeshes[i]["color"]):replace("(",""):replace(")","") ..", 5\n")
                    f:write("VALUE_OFF_..." .."=0\n")
                    f:write("KEY_..."       .."=ksAlphaRef\n")
                    f:write("VALUE_..."     .."=-193\n")
                    f:write("VALUE_OFF_..." .."=0\n")
                    f:write("CONDITION=NIGHT_SHARP\n")
                    f:write("[LIGHT_SERIES_...]\n")
                    f:write("MESHES"     .."="..ValidLightMeshes[i]["litmesh"] .."?\n")
                    f:write("DIRECTION"  .."="..ValidLightMeshes[i]["dir"] .."?\n")
                    f:write("SPOT"  .."="..ValidLightMeshes[i]["spot"] .."?\n")
                    -- f:write("DIRECTION"  .."=NORMAL\n")
                    f:write("RANGE"      .."="..ValidLightMeshes[i]["range"] .."\n")
                    f:write("COLOR"      .."="..color.."\n")
                    -- f:write("COLOR"      .."="..tostring(ValidLightMeshes[i]["color"]):replace("(",""):replace(")","") .."\n")
                    f:write("COLOR_OFF=0\n")
                    f:write("FADE_AT=700\n")
                    f:write("CONDITION=NIGHT_SHARP\n")
                    f:write("\n")

                    -- [LIGHT_SERIES_...]
                    -- ACTIVE=1
                    -- MESHES=lit_dbl_sng_down_?,lit_tri_dn_?
                    -- SPOT=170
                    -- SPOT_SHARPNESS=0.25
                    -- RANGE=40
                    -- RANGE_GRADIENT_OFFSET=0.02
                    -- FADE_AT=1000
                    -- FADE_SMOOTH=50
                    -- CLUSTER_THRESHOLD=20
                    -- COLOR=255,183,76,0.05
                    -- COLOR_OFF=0
                    -- CONDITION=NIGHT_SMOOTH
                    -- VOLUMETRIC_LIGHT=1

                end
            end
        end

        if #done>0 then f:write("\n") end

        if #Objects>0 then
            f:write("; all the objects\n\n")
            for i, v in pairs(Objects) do
                -- -- get Position
                local pos = Objects[i]['vis']:getPosition()
                local spos = tostring(math_round(pos.x, 3)) ..", ".. tostring(math_round(pos.y, 3)) ..", ".. tostring(math_round(pos.z, 3))
                -- local rotx, roty, rotz = GetSurfaceRot(
                -- local trans = Objects[i]['vis']:getTransformationRaw().side
                local side = Objects[i]['vis']:getTransformationRaw().side
                local rotx, roty, rotz = GetRotation(
                    Objects[i]['vis']:getLook():normalize(),
                    Objects[i]['vis']:getUp(), -- :normalize(),
                    -- Objects[i]['vis']:getTransformationRaw())
                    side:normalize() )
                    -- math.normalize(Objects[i]['vis']:getTransformationRaw()))
                -- ac.debug("xxx", ac.getPatchVersionCode())
                -- -- CSP v2.1 - 2735  needs negative
                -- -- CSP v2.2 - 2744
                -- -- CSP v2.3 - 3044
                -- -- CSP v2.4 - 3116
                -- -- CSP v2.9 - 3435
                -- -- CSP v2.11 - 3465
                -- -- CSP v2.12 - 3467
                -- -- CSP v3.0-p1 - 3490
                -- if ac.getPatchVersionCode()<3490 then
                --     -- ac.debug("yyy", ac.getPatchVersionCode())
                --     roty = -roty
                -- end
                local srot =
                    tostring(math_round(rotx, 1)) ..', '..
                    tostring(math_round(roty, 1)) ..', '..
                    tostring(math_round(rotz, 1))
                f:write("[MODEL_"..tostring(MaxSectID).."]\n")
                f:write("FILE"     .."="..Objects[i]['kn5'] .."\n")
                f:write("POSITION" .."="..spos .."\n")
                f:write("ROTATION" .."="..srot .."\n")
                if Objects[i]['phy'] then
                    f:write("PHYSICAL".."=".."1")
                else
                    f:write("PHYSICAL".."=".."0")
                end
                f:write("\n")
                MaxSectID=MaxSectID+1
            end
        end
        lastReply = lastReply .."File   : "..get_file_name(inifile).."  --  written Objs: " .. tostring(#Objects) .. "\n"
        f:close()
    end

    if bWriteCSPTreeFormat then

        local inifile2 = string.lower(inifile):gsub(".ini", "_tree.txt")
        local f2 = io.open(inifile2, "w")
        if not f2 then
            lastReply = lastReply .. "\nCould not open\n" .. inifile2
        else
            for i, v in pairs(Objects) do
                -- local dir = Objects[i]['vis']:getLook()
                -- local up =  Objects[i]['vis']:getUp()
                -- local dirx = -math.deg(math.atan2(dir.x, dir.z))
                -- local dirz = math.deg(math.atan2(up.x, up.y))
                -- local diry = math.deg(math.atan2(up.y, up.z))-90
                -- local sdir = tostring(math_round(dirx , 1)) ..", ".. tostring(math_round(diry , 1)) ..", ".. tostring(math_round(dirz , 1))
                local pos = Objects[i]['vis']:getPosition()
                local spos = tostring(math_round(pos.x, 3)) ..",".. tostring(math_round(pos.y, 3)) ..",".. tostring(math_round(pos.z, 3))
                local meshname = string.gsub(get_file_name(Objects[i]['kn5']), ".kn5", "")
                -- tree: Bush.bin; -22.852,12.179,-85.545; size=0.250; width=1.200
                f2:write("tree: "..meshname..".bin; "..spos .."; size=1.0; width=1.0\n")
            end
            lastReply = lastReply .."external File   : "..get_file_name(inifile2).."  --  written Objs: " .. tostring(#Objects) .. "\n"
            f2:close()
        end
    end

end






local function CreateBorders()
    table.clear(TableSlope)
    table.clear(TableDir)
    table.clear(TableIdeal)
    table.clear(TableL)
    table.clear(TableR)
    local cSpline2 = 1.0 - 1/sim.trackLengthM
    local p2 = ac.trackProgressToWorldCoordinate(cSpline2)
    cSpline2 = 0.0
    local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    local side = ac.getTrackAISplineSides(cSpline2)
    local c=0
    while cSpline2 < 1.0 do
        table.insert(TableIdeal, p1)
        local dir = -math.atan2(p1.z-p2.z, p1.x-p2.x)
        table.insert(TableDir, math.deg(dir-math.pi/2))

        -- interpolate ?
        -- table.insert(TableDir, (math.deg(dir-math.pi/2)*3+lastdir)/4)

        local vL = vec3(p1.x + math.cos(dir + math.pi/2)*side.x, p1.y, p1.z - math.sin(dir + math.pi/2)*side.x*1.1)
        local vR = vec3(p1.x + math.cos(dir - math.pi/2)*side.y, p1.y, p1.z - math.sin(dir - math.pi/2)*side.y*1.1)

        table.insert(TableL, vL)
        table.insert(TableR, vR)

        local slope = -math.deg( math.atan2(p1.z-p2.z, p1.x-p2.x) )
        table.insert(TableSlope, math.rad(slope)/math.pi)

        c=c+1
        p1:copyTo(p2)
        cSpline2 = cSpline2 + 1/sim.trackLengthM
        p1 = ac.trackProgressToWorldCoordinate(cSpline2)
        side = ac.getTrackAISplineSides(cSpline2)
    end -- while
end


-- 51/34
local function AddConesOnCorners()
    local min = 1000
    local max = -1000
    local dcnt = 0
    local count = 0
    local diff = 0
    local diffpm = 0
    local prevdiffpm = 0
    local prevdiff = 0
    local prevdiff2 = 0
    local idIn=-1
    local idOut=-1
    -- local prev = TableIdeal[#TableDir]
    local prevAng = TableDir[#TableDir]
    local i=1
    local diffAcc=1
    local lastIn = -100000
    local lastOut = -100000
    local lastApex = -100000
    while i < #TableDir do
        -- diff = math.deg(math.abs(math.abs(TableDir[i])-math.abs(prevAng)))
        -- diffpm = TableDir[i]-prevAng

        diffpm = math.max(-90, math.min(90, math.deg(TableDir[i]-prevAng)))
        if (TableDir[i]>0 and prevAng<0) then
            diffpm = math.max(-90, math.min(90, math.deg(prevAng           + TableDir[i])))
        elseif (TableDir[i]<0 and prevAng>0) then
            diffpm = math.max(-90, math.min(90, math.deg(TableDir[i]       + prevAng)))
        else
            if prevAng>TableDir[i] then
                diffpm = math.max(-90, math.min(90, math.deg(prevAng        - TableDir[i])))
            else
                diffpm = math.max(-90, math.min(90, math.deg(TableDir[i]    - prevAng)))
            end
        end
        diff   = math.abs(diffpm)
        prevAng = TableDir[i]

        -- ac.debug(tostring(i), diff)
        -- ac.debug("diff "..i, diffpm)


        if min > TableDir[i] then min = TableDir[i] end
        if max < TableDir[i] then max = TableDir[i] end

        if  i >= lastOut + Curve_Distance
            and diff     > Curve_Threshold
            and prevdiff > Curve_Threshold
        then
            -- corner start
            if idIn==-1 then
                idIn=i
            end
            dcnt=dcnt+1
        end

        if  idIn~=-1 and idIn<=#TableL
            and i-idIn>=Curve_Distance
            and dcnt>Curve_Distance
            and
            ((  diff     < prevdiff
                and
                diff     < Curve_ThresholdOut)
            or
            (   (diffpm>=0.0 and prevdiffpm<0.0)
                or
                (diffpm<0.0 and prevdiffpm>=0.0)
            ))
        then
            --this "i" is the apex, but first use remembered corner start idIn

            if (idIn>Curve_Distance and
                ((diffpm>=0.0 and prevdiffpm<0.0)
                or
                (diffpm<0.0 and prevdiffpm>=0.0))
            ) then
                -- intermediate apex if idIn too far away
                local itmp = idIn + math.ceil((i-idIn)/3*2)
                if TableDir[itmp]<0 then
                    AddObject(TableL[itmp], vec3(0,0,0), GetKn5IDByName(ApexCones[4]), count, true, true )
                    lastApex=i
                else
                    AddObject(TableR[itmp], vec3(0,0,0), GetKn5IDByName(ApexCones[4]), count, true, true )
                    lastApex=i
                end
            end


            if idIn>lastOut+Curve_Distance then
                --corner start
                if TableDir[idIn]>0 then
                    AddObject(TableL[idIn], vec3(0,0,0), GetKn5IDByName(ApexCones[1]), count, true, true )
                    lastIn=idIn
                else
                    AddObject(TableR[idIn], vec3(0,0,0), GetKn5IDByName(ApexCones[1]), count, true, true )
                    lastIn=idIn
                end
            else
                --corner apex
                if diffpm>0 then
                    AddObject(TableL[idIn], vec3(0,0,0), GetKn5IDByName(ApexCones[2]), count, true, true )
                    lastApex = idIn
                    -- lastIn=i
                else
                    AddObject(TableR[idIn], vec3(0,0,0), GetKn5IDByName(ApexCones[2]), count, true, true )
                    lastApex = idIn
                    -- lastIn=i
                end
            end

            --corner apex
            if TableDir[i]<0 then
                AddObject(TableL[i], vec3(0,0,0), GetKn5IDByName(ApexCones[2]), count, true, true )
                lastApex = i
            else
                AddObject(TableR[i], vec3(0,0,0), GetKn5IDByName(ApexCones[2]), count, true, true )
                lastApex = i
            end

            -- i = math.floor(i + i-idIn)
            -- i = math.floor(i + (i-idIn)/2)
            i = math.ceil(i+Curve_Distance)
            if i>#TableDir then break end
            -- prevdiff = math.abs(TableDir[i]-TableDir[i-1    ])

            --corner end
            if TableDir[i]>0 then
                AddObject(TableL[i], vec3(0,0,0), GetKn5IDByName(ApexCones[3]), count, true, true )
                lastOut = i
            else
                AddObject(TableR[i], vec3(0,0,0), GetKn5IDByName(ApexCones[3]), count, true, true )
                lastOut = i
            end

            i = math.ceil(i+Curve_Distance)
            if i>#TableDir then break end

            dcnt = 0
            idIn=-1
            count = count + 1
        end

        prevdiff = diff
        prevdiffpm = diffpm
        i=i+1
    end
    -- ac.debug("min", min)
    -- ac.debug("max", max)
end










local function ApplyRotation(Object)
    -- reset to original direction
    Object['vis']:setOrientation(Object['look'])
    -- apply rotation for all axis
    Object['vis']:rotate( axisZ, -math.rad(Object['rot'].x))
    Object['vis']:rotate( axisY, -math.rad(Object['rot'].y))
    Object['vis']:rotate( axisX, -math.rad(Object['rot'].z))
end



local function SeleRot(axis, rad)
    local num = 0
    for i=1, #Objects do
        if Objects[i]['sele']==true then
            num=num+1
            -- Objects[i]['vis']:rotate(axis, deg)
            local r = Objects[i]['rot']
            if axis==axisZ then r.x = r.x+math.deg(rad) end
            if axis==axisX then r.z = r.z+math.deg(rad) end
            if axis==axisY then r.y = r.y+math.deg(rad) end
            Objects[i]['rot']:set(r)
            ApplyRotation(Objects[i])
            if KN5axis then
            KN5axis:setVisible(true)
            KN5axis:setPosition(Objects[i]['vis']:getPosition())
            KN5axis:setOrientation(Objects[i]['vis']:getLook(), Objects[i]['vis']:getUp())
            end
            if Objects[i]['lit']~=nil then
                Objects[i]['lit'].direction = Objects[i]['vis']:getLook()
            end
        end
    end
    keydelay2=0.1
    if num==0 then
        ui.toast(ui.Icons.AppWindow, "Nothing selected!")
    end
end

local function SeleMove(axis, amount)
    local num = 0
    for i=1, #Objects do
        if Objects[i]['sele']==true then
            num=num+1
            Objects[i]['vis']:setPosition(Objects[i]['vis']:getPosition()+axis*amount)
            if Objects[i]['lit']~=nil then
                local litMesh = GetObjectLIGHTMesh(Objects[i]['kn5id'])
                if litMesh~=nil then
                    Objects[i]['lit'].position = Objects[i]['lit'].position + axis*amount
                end
            end
        end
    end
    keydelay2=0.1
    if num==0 then
        ui.toast(ui.Icons.AppWindow, "Nothing selected!")
    end
end

local function SeleMoveCursor(vdiff)
    local num = 0
    for i=1, #Objects do
        if Objects[i]['sele']==true then
            -- here only position, rotation in mouse event ...
            num=num+1
            OFFSET = GetObjectOFFSET(Objects[i]['kn5'])

            Objects[i]['vis']:setPosition(Objects[i]['vis']:getPosition() + vdiff + vUp*OFFSET)

            if Objects[i]['lit']~=nil then
                local litMesh = GetObjectLIGHTMesh(Objects[i]['kn5id'])
                if litMesh~=nil then
                    Objects[i]['lit'].position = Objects[i]['lit'].position + vdiff + vUp*OFFSET
                end
            end
        end
    end

    keydelay2=0.1
    if num==0 then
        ui.toast(ui.Icons.AppWindow, "Nothing selected!")
    end
end













local function SeleClear()
    for i=1, #Objects do
        Objects[i]['sele']=false
    end
    if KN5axis then KN5axis:setVisible(false) end
    objsSelected = 0
end

local function RenameObjects(kn5)
    -- check if rename is needed
    for j=1, #TabSeen do
        if TabSeen[j]['kn5'] == kn5 then
            TabSeen[j]['id'] = TabSeen[j]['id']-1
            local c=0
            for k=1, #Objects do
                if TabSeen[j]['kn5'] == Objects[k]["kn5"] then
                    local meshname = Objects[k]['vis']:findMeshes("?"):name(1)
                    Objects[k]['name'] = meshname .. "_" .. tostring(c)
                    c=c+1
                end
            end
            break
        end
    end
end

local function SeleDele()
    local i = 1
    while i<=#Objects do
        if Objects[i]['sele'] then
            if Objects[i]['lit'] ~= nil then
                Objects[i]['lit']:dispose()
            end
            Objects[i]["vis"]:dispose()
            local origname = Objects[i]["kn5"]
            table.remove(Objects, i)
            if #Objects>0 then
                RenameObjects(origname)
            end
        else
            i=i+1
        end
    end
    objsSelected = 0
end

local function SeleDeleDups()
    local i = 1
    local num = 1
    while i<=#Objects do
        if Objects[i]['sele'] then
            if Objects[i]['lit'] ~= nil then
                Objects[i]['lit']:dispose()
            end
            Objects[i]["vis"]:dispose()
            table.remove(Objects, i)
            num = num + 1
        else
            i=i+1
        end
    end
    objsSelected = 0
end


local function SeleSnapToGround()
    local origC = #Objects
    for i=1, origC do
        if Objects[i]['sele'] then
            local p1 = Objects[i]['vis']:getPosition()
            -- if math.abs(pos:distance(p1))<=0.5 then
            local dir = Objects[i]['vis']:getLook()
            local up =  Objects[i]['vis']:getUp()
            local offset = GetObjectOFFSET(Objects[i]['kn5'])
            local dirx = -math.deg(math.atan2(dir.x, dir.z))
            local dirz = math.deg(math.atan2(up.x, up.y))
            local diry = math.deg(math.atan2(up.y, up.z))-90

            snapToTrackSurface(p1, 0)
            local yaw, pitch, roll = GetSurfaceRot(dirsurf)
            -- ac.debug("X1yaw", yaw)
            -- ac.debug("X2pitch", pitch)
            -- ac.debug("X3roll", roll)

            -- Objects[i]['vis']:setOrientation(previewLook)
            -- ObjPreview:rotate(axisZ, (math.rad(yaw) + rotZadd) )

            Objects[i]['vis']:setPosition(p1 + vUp * offset)
            if bAlignToSurface then
                ObjPreview = basenode:loadKN5("obj/"..Objects[i]['kn5'])
                if ObjPreview~=nil then
                    previewLook = ObjPreview:getLook()
                    ObjPreview:dispose()
                else
                    ac.debug("not loaded", "---")
                end
                Objects[i]['vis']:setOrientation(previewLook)
                Objects[i]['vis']:rotate(axisZ, (math.rad(yaw)) )
                if bAlignToSurface then
                    Objects[i]['vis']:rotate(axisX, math.rad(roll))
                    Objects[i]['vis']:rotate(axisY, math.rad(pitch))
                end
                -- ObjPreview:rotate(axisZ, (rotZadd) )
                -- Objects[i]['vis']:setRotation(axisZ, math.rad(yaw))
                -- Objects[i]['vis']:setRotation(axisX, math.rad(roll))
                -- Objects[i]['vis']:setRotation(axisY, math.rad(pitch))
            end

            -- Objects[i]['vis']:rotate(axisZ, (math.rad(yaw)) )
            -- if bAlignToSurface then
            --     Objects[i]['vis']:rotate(axisX, math.rad(roll))
            --     Objects[i]['vis']:rotate(axisY, math.rad(pitch))
            -- end

        end
    end
end


local function SeleDup()
    local origC = #Objects
    for i=1, origC do
        if Objects[i]['sele'] then
            local dir = Objects[i]['vis']:getLook()
            local up =  Objects[i]['vis']:getUp()
            local dirx = -math.deg(math.atan2(dir.x, dir.z))
            local dirz = math.deg(math.atan2(up.x, up.y))
            local diry = math.deg(math.atan2(up.y, up.z))-90
            AddObject(Objects[i]['vis']:getPosition(),
                      vec3(dirx, dirz, diry),
                      GetKn5IDByName(Objects[i]['kn5']), #Objects+1, false, false)
            Objects[i]['sele'] = false
        end
    end
    for i=origC+1, #Objects do
        Objects[i]['sele'] = true
    end
    objsSelected = #Objects - origC
end

local function SeleAll()
    local axSet = false
    for i=1, #Objects do
        Objects[i]['sele']=true
        -- Objects[i]['vis']:findMeshes("?"):setOutline(rgbm.colors.white*2)
        -- if not axSet then
        --     axSet = true
        --     if KN5axis then
        --     KN5axis:setVisible(true)
        --     -- KN5axis:setPosition(Objects[i]['vis']:getPosition())
        --     -- KN5axis:setOrientation(Objects[i]['vis']:getLook(), Objects[i]['vis']:getUp())
        --     -- KN5axis:setTransformationFrom(Objects[i]['vis'])
        --     end
        -- end
    end
    objsSelected = #Objects
end

local function SeleSelection()
    local axSet = false
    for i=1, #Objects do
        if Objects[i]['sele'] then
            if not axSet then
                axSet = true
                -- if KN5axis then
                -- KN5axis:setVisible(true)
                -- KN5axis:setPosition(Objects[i]['vis']:getPosition())
                -- -- KN5axis:setOrientation(Objects[i]['vis']:getLook(), Objects[i]['vis']:getUp())
                -- -- setTransformationFrom(Objects[i]['vis'])
                -- end
            end
            objsSelected = objsSelected + 1
            selectedObj = i
            -- Objects[i]['vis']:findMeshes("?"):setOutline(rgbm.colors.white*2)
            -- ac.debug(i.." sele", tostring(Objects[i]['sele']) .. " - " .. "ON")
        else
            -- Objects[i]['vis']:findMeshes("?"):setOutline(rgbm.colors.black*0.1)
            -- Objects[i]['vis']:findMeshes("?"):setOutline(nil)
            -- Objects[j]['vis']:findMeshes("?"):setOutline(rgb.colors.clear)
            -- ac.debug(i.." sele", tostring(Objects[i]['sele']) .. " - " .. "OFF")
        end
    end
end

local function SeleGetNum()
    objsSelected=0
    for i=1, #Objects do
        if Objects[i]['sele'] then
            objsSelected = objsSelected + 1
            selectedObj = i
        end
    end
end

local function SeleGetCenter()
    local axSet = false
    local snum = 0
    local vsum = vec3(0,0,0)
    for i=1, #Objects do
        if Objects[i]['sele'] then
            vsum = vsum + Objects[i]['vis']:getPosition()
            snum = snum + 1
        end
    end
    return vsum:div(vec3(snum,snum,snum))
end




local function ObjectsLoadFromList()
    ac.perfBegin("Loading Objects")
    rotZadd=0.0
    for i=1, #ObjectsList do
        AddObject( ObjectsList[i]['pos'], ObjectsList[i]['dir'], ObjectsList[i]['kn5id'], i, false, false)
        -- if i%100 == 0 then
        --     writeACConfig(dirTrackDeco.."debug.txt", "done", "curr", i)
        -- end
    end
    ac.perfEnd("Loading Objects")
end




local lastHeight = 200



-- apexCones
function script.ApexObjectSelect()
    ui.combo("corner start", ApexCones[1], function ()
        if ui.selectable("--none--", ApexCones[1]=="--none--") then
            ApexCones[1]="--none--"
            writeACConfig(appopts, "APEXCONES", "CORNERSTART", "--none--")
        end
        for i,v in pairs(ValidKn5sApp) do
            if ui.selectable(ValidKn5sApp[i], ValidKn5sApp[i] == ApexCones[1]) then
                ApexCones[1] = ValidKn5sApp[i]
                writeACConfig(appopts, "APEXCONES", "CORNERSTART", ValidKn5sApp[i])
            end
        end
        end  )
    ui.combo("corner apex", ApexCones[2], function ()
        if ui.selectable("--none--", ApexCones[2]=="--none--") then
            ApexCones[2]="--none--"
            writeACConfig(appopts, "APEXCONES", "CORNERAPEX", "--none--")
        end
        for i,v in pairs(ValidKn5sApp) do
            if ui.selectable(ValidKn5sApp[i], ValidKn5sApp[i] == ApexCones[2]) then
                ApexCones[2] = ValidKn5sApp[i]
                writeACConfig(appopts, "APEXCONES", "CORNERAPEX", ValidKn5sApp[i])
            end
        end
        end  )
    ui.combo("corner end", ApexCones[3], function ()
        if ui.selectable("--none--", ApexCones[3]=="--none--") then
            ApexCones[3]="--none--"
            writeACConfig(appopts, "APEXCONES", "CORNEREND", "--none--")
        end
        for i,v in pairs(ValidKn5sApp) do
            if ui.selectable(ValidKn5sApp[i], ValidKn5sApp[i] == ApexCones[3]) then
                ApexCones[3] = ValidKn5sApp[i]
                writeACConfig(appopts, "APEXCONES", "CORNEREND", ValidKn5sApp[i])
            end
        end
        end  )
    ui.combo("more apex ", ApexCones[4], function ()
        if ui.selectable("--none--", ApexCones[4]=="--none--") then
            ApexCones[4]="--none--"
            writeACConfig(appopts, "APEXCONES", "CORNEREND", "--none--")
        end
        for i,v in pairs(ValidKn5sApp) do
            if ui.selectable(ValidKn5sApp[i], ValidKn5sApp[i] == ApexCones[4]) then
                ApexCones[4] = ValidKn5sApp[i]
                writeACConfig(appopts, "APEXCONES", "CORNEREND", ValidKn5sApp[i])
            end
        end
        end  )

-- 'cone.kn5' , -- corner start
-- 'pole100.kn5'  , -- corner apex
-- 'coneS.kn5', -- corner end
-- 'pole150.kn5'    -- intermediate apex

end




function ShowMainWindow(dt)

    if keydelay2>=0.0 then keydelay2=keydelay2-dt end -- else keydelay2=0.2 end

    ui.beginGroup()
    ui.beginOutline()

    -- ui.pushFont(ui.Font.Title)
    -- editname = ui.inputText("Name (keep short)", editname, ui.InputTextFlags.None, vec2(150, 38))
    -- if ui.itemHovered() then insideWindow=true end
    -- ui.sameLine(0,10)

    -- local id = math.floor(car.splinePosition*#TableDir)
    -- if id>2 and id<=#TableDir then
    --     local diff = math.deg(TableDir[id]-TableDir[id-1])
    --     -- --   local diff = math.deg(TableDir[id])
    --     --   ui.text("dircurr   ".. tostring(TableDir[id]))
    --     --   ui.text("id   ".. tostring(id))
    --     --ui.text("diff   ".. tostring(diff))
    --     -- ui.text("tabDIR  ".. tostring(math_round(TableDir[id], 3)))
    --     --   -- ac.debug("slope  ", math.abs(TableSlope[id]))
    --     --   -- ac.debug("diff   ", diff)
    -- end

    ui.text(tostring(#ObjectsList).." object(s) in:   ..apps/lua/TrackDecoration/dataSections/..")
    -- ui.text(tostring(#ObjectsList).." objects in: 'apps/lua/TrackDecoration/dataSections/" .. io.getFileName(fileModelsINIs[fileCurrID]) .. "'")

    local selectedF = fileCurrID
    -- ui.setNextItemWidth(ui.availableSpaceX()-210)
    ui.setNextItemWidth(300)
    ui.combo("###AvailableCfgs", get_file_name(fileModelsINIs[selectedF]):gsub(".ini",""):gsub(".INI",""):gsub(".Ini",""), function ()
        for i,v in pairs(fileModelsINIs) do
            if ui.selectable(get_file_name(v):gsub(".ini",""):gsub(".INI",""):gsub(".Ini",""), i == selectedF) then
                lastReply = ""
                fileCurrID = i
                writeACConfig(appopts, ac.getTrackFullID('_'), "ACTIVEFILE", fileModelsINIs[fileCurrID])
                -- GetFileID()
                ObjectsReset()
                LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
                if bAutoLoad then
                    ObjectsLoadFromList()
                end
            end
        end
        end  )


    ui.sameLine(0,10)
    -- if ui.modernButton("###reload", 24, ui.ButtonFlags.None, ui.Icons.Restart) then
    if ui.button("r", 24, ui.ButtonFlags.None, ui.Icons.Restart) then
        UpdateFileNames()
        LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
        if bAutoLoad then
            ObjectsReset()
            ObjectsLoadFromList()
        end
        return    ---true
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("reload available files") end ) end


    ui.sameLine(0,10)
    if ui.button("+") then
    --if ui.modernButton("###filePlus", 24, nil, ui.Icons.Plus) then
        lastReply = ""
        ui.modalPrompt(
            "Filename needed",
            "add this to '"..  ac.getTrackFullID('_') .."_' ..." ,
            tostring(car:driverName()), function (inp)
                if not isValidFilename(inp) then
                    -- ui.modalPopup("Error", "Filename contains illegal characters. Please try again...",nil)
                    lastReply = "Filename contained illegal characters. Please try again..."
                elseif io.fileExists(dirTrackDeco.."dataSections/"..ac.getTrackFullID('_').."_" .. inp.. ".ini") then
                    lastReply = "File already exists. Please try again..."
                else
                    -- ui.modalPopup("Error", "Filename contains illegal characters. Please try again...",nil)
                    -- []
                    writeACConfig(dirTrackDeco.."dataSections/"..ac.getTrackFullID('_').."_" .. inp.. ".ini",
                        "ABOUT", "AUTHOR", car:driverName())
                    writeACConfig(dirTrackDeco.."dataSections/"..ac.getTrackFullID('_').."_" .. inp.. ".ini",
                        "ABOUT", "NAME", inp)
                    writeACConfig(appopts, ac.getTrackFullID('_'), "ACTIVEFILE",
                                                                 ac.getTrackFullID('_').."_" .. inp.. ".ini")
                    ObjectsReset()
                    UpdateFileNames()
                    LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
                    -- if bAutoLoad then
                    --     ObjectsLoadFromList()
                    -- end
                end
        end)
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("add new empty file") end ) end


    ui.sameLine(0,10)
    local flag = 0
    if (string.lower(fileModelsINIs[fileCurrID]) == string.lower(ac.getTrackFullID('_')..".ini") ) then
        flag=ui.ButtonFlags.Disabled
    end
    if ui.button("-") then
    -- if ui.modernButton("###fileminus", 24, flag, ui.Icons.Minus) then
        lastReply = ""
        ui.modalDialog("Confirm", function ()
            ui.text("Really delete  '"..  fileModelsINIs[fileCurrID] .."' ?")
            if ui.modernButton('OK', vec2(ui.availableSpaceX() / 2 - 4, 40), ui.ButtonFlags.Confirm, ui.Icons.Confirm)
                or ui.keyPressed(ui.Key.Enter)
            then
                -- remove file
                if not io.deleteFile(dirTrackDeco..'dataSections/'..fileModelsINIs[fileCurrID]) then
                    lastReply = "Could not delete '" .. dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID] .. "'"
                end
                -- ac.debug("del", dirTrackDeco .. 'dataSections/'.. fileModelsINIs[fileCurrID])
                writeACConfig(appopts, ac.getTrackFullID('_'), "ACTIVEFILE", fileModelsINIs[fileCurrID])
                ObjectsReset()
                UpdateFileNames()
                LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
                if bAutoLoad then
                    ObjectsLoadFromList()
                end
                return true
            end
            ui.sameLine(0, 8)
            return ui.modernButton('Cancel', vec2(-0.1, 40), ui.ButtonFlags.Cancel, ui.Icons.Cancel)
        end, true)
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("remove current file and all objects") end ) end

    ui.sameLine(0,10)
    if ui.checkbox("all", bALLLAYOUTS) then
        bALLLAYOUTS = not bALLLAYOUTS
        writeACConfig(appopts, ac.getTrackFullID('_'), "ALLLAYOUTS", bALLLAYOUTS)
        ObjectsReset()
        UpdateFileNames()
        LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
        if bAutoLoad then
            ObjectsLoadFromList()
        end
        return true
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("show all files for this track, not only for current layout") end ) end


    -- ui.sameLine(0,200)
    if ui.button('SAVE') then
        StopPlacementHelper()
        table.clear(ObjectsList)
        for i=1, #Objects do
            -- table.insert(RigidBodiesList, {['kn5']=Objects[i]['kn5'  ], ['pos']=Objects[i]['vis'  ]:getPosition(), ['dir']=Objects[i]['vis'  ]:getLook(), ['kn5id']=k})
            table.insert(ObjectsList, {
                ['kn5'  ]=Objects[i]['kn5'  ],
                ['pos'  ]=Objects[i]['vis'  ]:getPosition(),
                ['dir'  ]=Objects[i]['vis'  ]:getLook(),
                ['kn5id']=Objects[i]['kn5id']
                }
            )
        end
        -- ac.debug("ObjectsList", #ObjectsList)
        MaxSectID = GetNextModelID_from_ModelsINI()
        lastReply = ""
        SaveCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID], -1)
        --doShowPlacementHelper = false
        return
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("save all objects, no matter if selected or not\nwill overwrite existing without asking") end ) end


    ui.sameLine(0,10)
    if ui.button('(re)load') then
        StopPlacementHelper()
        bSelectMode = false
        bSelectMode2 = false
        ObjectsReset()
        LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
        ObjectsLoadFromList()
        SeleGetNum()
        lastReply = ""
        return
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("removes all current objects, loads selected file") end ) end

    ui.sameLine(0,10)
    if ui.button("F") then os.showInExplorer(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID]) end
    -- if ui.iconButton(ui.Icons.Folder) then os.showInExplorer(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID]) end
    if ui.itemHovered() then ui.tooltip(function () ui.text("open folder") end ) end

    ui.sameLine(0,10)
    if ui.button("E") then os.openTextFile(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID], 1) end
    -- if ui.iconButton(ui.Icons.Edit) then os.openTextFile(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID], 1) end
    if ui.itemHovered() then ui.tooltip(function () ui.text("open in Editor") end ) end

    ui.sameLine(0,10)
    if ui.checkbox('AutoLoad', bAutoLoad) then
        bAutoLoad=not bAutoLoad
        writeACConfig(appopts, "options", "AutoLoad", bAutoLoad)
    end
    if ui.itemHovered() then ui.tooltip(function () ui.text("for next session, or when switching files") end ) end

    ui.sameLine(0,10)
    if ui.button("make kn5") then
        lastReply = ""
        if io.fileExists(kn5joinexe) and io.fileExists(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID]) then

            local kn5File = dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID]:lower():gsub(".ini",".kn5")
            local kn5joinLOG = string.gsub(kn5joinexe, ".exe", "_log.txt")
            if io.fileExists(kn5joinLOG) then
                local f = io.open(kn5joinLOG, "w")
                if f then
                    f:write("")
                    f:close()
                end
            end

            local olddate = tonumber(0)
            if io.fileExists(kn5File) then
                -- ac.debug("date 1 before lastWriteTime",  os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(kn5File).lastWriteTime)))
                -- ac.debug("date 1 before lastAccessTime",  os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(kn5File).lastAccessTime)))
                -- ac.debug("date 1 before creationTime",  os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(kn5File).creationTime)))
                olddate = io.getAttributes(kn5File).lastWriteTime
            end

            -- variant A
            -- os.execute('type NUL && '..'"'..kn5joinexe .. '" -x "' .. dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID] .. '"', -1, false)
            os.execute('type NUL && '..'"'..kn5joinexe .. '" -x "' .. dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID] .. '"', -1, true)

            -- variant B ---- why the heck this wont work?
            -- os.runConsoleProcess({
            --     -- filename = kn5joinexe,
            --     filename = kn5joinexe,
            --     arguments = {'-x '..dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID]},
            --     rawArguments = true,
            --     -- arguments = {'-x', dirTrackDeco .. 'dataSections/'..tostring(fileModelsINIs[fileCurrID]) },
            --     workingDirectory = io.getParentPath(kn5joinexe),
            -- }, function (err, data)
            --     lastReply = 'Exit code: '..tostring(err)..'\nStdOut:\n'..data.stdout
            -- end)

            if io.fileExists(kn5File) then
                local newdate = io.getAttributes(kn5File).lastWriteTime
                -- ac.debug("date 2 after lastWriteTime",  os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(kn5File).lastWriteTime)))
                -- ac.debug("date 2 after lastAccessTime",  os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(kn5File).lastAccessTime)))
                -- ac.debug("date 2 after creationTime",  os.date("%A, %m %B %Y %H:%M",tonumber(io.getAttributes(kn5File).creationTime)))
                if newdate > olddate then
                    ui.toast(ui.Icons.AppWindow, "KN5 written!  -  " .. kn5File)
                else
                    ui.toast(ui.Icons.AppWindow, "Old file not overwritten.")
                    lastReply = "Old file not overwritten."
                end
            end


            -- if io.fileExists(kn5File) and io.fileExists(kn5joinLOG) then
            if io.fileExists(kn5joinLOG) then
                local f = io.open(kn5joinLOG, "r")
                if f then
                    lastReply = lastReply .. "\n" .. f:read("a")
                    f:close()
                end
            else
                kn5joinLOG = ac.getFolder(ac.FolderID.Root) .."/".. get_file_name2(kn5joinLOG)
                -- ac.debug("kn5joinLOG2", kn5joinLOG)
                if io.fileExists(kn5joinLOG) then
                    local f = io.open(kn5joinLOG, "r")
                    if f then
                        lastReply = lastReply .. "\n" .. f:read("a")
                        f:close()
                    end
                end
            end

        else
            ui.toast(ui.Icons.AppWindow, "kn5Join.exe or ini not found!")
        end
    end

    if ui.itemHovered() then
        if kn5joinexe~="" then
            ui.tooltip(function () ui.text("found "..kn5joinexe) end )
        else
            ui.tooltip(function () ui.text("kn5Join not found, put into TrackDecoration\\ or obj\\ folder!") end )
        end
    end

    ui.sameLine()
    if ui.button("open txt/csv") then
        os.openFileDialog({
            title = 'Open',
            defaultFolder = dirTrackDeco .. 'dataSections/',
            fileTypes = {
                {
                name = 'tree.txt/.csv files',
                mask = '*.txt; *.csv'
                }
            },
        }, function (err, filename)
            if not err and filename then
                if filename:lower():endsWith('.csv') then
                    LoadCSV(filename)
                else
                    LoadTXT(filename)
                end
            end
        end)
    end

    ui.newLine(0)
    ui.setNextItemWidth(200)
    local Threshold=math.floor(Curve_Threshold)
    local changed, changed2, changed3 = false, false, false
    Threshold, changed = ui.slider("Curve_Threshold", Threshold, 0, 90, "%.0f" , 1)
    if changed then
        Curve_Threshold = math.floor(Threshold)
        writeACConfig(appopts, "options", "Curve_Threshold", Curve_Threshold)
        ObjectsReset()
        AddConesOnCorners()
        -- 51/34
    end
    ui.sameLine(0,10) ui.text('<< change will remove')
    ui.setNextItemWidth(200)
    local ThresholdOut=math.floor(Curve_ThresholdOut)
    ThresholdOut, changed2 = ui.slider("Curve_ThresholdOut", ThresholdOut, 0, 90, "%.0f", 1)
    if changed2 then
        Curve_ThresholdOut = math.floor(ThresholdOut)
        writeACConfig(appopts, "options", "Curve_ThresholdOut", Curve_ThresholdOut)
        ObjectsReset()
        AddConesOnCorners()
    end
    ui.sameLine(0,10) ui.text('<< all other objects')
    ui.setNextItemWidth(200)
    local Distance=math.floor(Curve_Distance)
    Distance, changed3 = ui.slider("cone distance  <<", Distance, 2, 50, "%.0f", 1)
    if changed3 then
        Curve_Distance = math.floor(Distance)
        writeACConfig(appopts, "options", "Curve_Distance", Curve_Distance)
        ObjectsReset()
        AddConesOnCorners()
    end
    if not (doShowPlacementHelper or bSelectMode or bSelectMode2) then
        ui.sameLine(0,30)
        if ui.button("cones on apexes") then
            AddConesOnCorners()
        end
        ui.sameLine(0,10)
        if ui.button("> set apex objs") then
            -- ApexObjectSelect
            ac.setWindowOpen("ApexObjectSelectid", true)
        end
    else
        -- ui.newLine(0)
    end


    -- improvised "STOP" green color text button
    ui.pushFont(ui.Font.Title)
    if doShowPlacementHelper or bSelectMode or bSelectMode2 then
        -- bSelectMode
        local dx1 = ui.availableSpaceX()-80
        local dy1 = ui.getCursorY()
        ui.sameLine(dx1)
        --ui.setCursorY(ui.getCursorY()-20)
        if ui.button("          ") then
            StopPlacementHelper()
            bSelectMode = false
            bSelectMode2 = false
        end
        if ui.itemHovered() then insideWindow=true end
        ui.sameLine(dx1+10)
        ui.dwriteText("stop", fntSize, rgbm.colors.green*5)
        ui.setCursorY(dy1)
    end

    ui.newLine(-10)
    ui.pushFont(ui.Font.Main)
    ui.text("Objects:\n" .. #Objects .."  ("..tostring(objsSelected)..")")

    ui.pushFont(ui.Font.Small)
    ui.sameLine(0)
    if ui.checkbox('angle', bCamFacing) then
        bCamFacing=not bCamFacing
        writeACConfig(appopts, "options", "bCamfacing", bCamFacing)
    end
    ui.pushFont(ui.Font.Title)
    if ui.itemHovered() then
        ui.tooltip(function () ui.text("insert Objects facing the camera, or with same angle") end ) end

    ui.pushFont(ui.Font.Small)
    ui.sameLine(0)
    if ui.checkbox('align', bAlignToSurface) then
        bAlignToSurface=not bAlignToSurface
        writeACConfig(appopts, "options", "AlignToSurface", bAlignToSurface)
    end
    ui.pushFont(ui.Font.Title)
    if ui.itemHovered() then
        ui.tooltip(function () ui.text("align object angle to surface underneath") end ) end

    -- ui.sameLine(0)
    -- ui.pushFont(ui.Font.Small)
    -- if ui.checkbox('<>', bAlignSwitchDir) then
    --     bAlignSwitchDir=not bAlignSwitchDir
    --     writeACConfig(appopts, "options", "AlignSwitchDir", bAlignSwitchDir)
    -- end
    -- ui.pushFont(ui.Font.Title)
    -- if ui.itemHovered() then
    --     ui.tooltip(function () ui.text("Switch object direction") end ) end

    ui.sameLine(0,10)
    -- ui.setNextItemWidth(150)
    -- ui.setNextItemWidth(ui.availableSpaceX()-130)
    ui.setNextItemWidth(ui.availableSpaceX()-180)
    local selected = currObjkn5
    ui.combo("##validKN5s"..#ValidKn5sApp, ValidKn5sApp[currObjkn5]:gsub(".kn5",""):gsub(".KN5",""):gsub(".Kn5",""), ui.ComboFlags.HeightLarge, function ()
        for i,v in pairs(ValidKn5sApp) do
            if ui.selectable(v:gsub(".kn5",""):gsub(".KN5",""):gsub(".Kn5",""), i == selected) then
                currObjkn5 = i
                writeACConfig(appopts, "options", "currObjkn5", currObjkn5)
                MakePreviews()
                StartPlacementHelper()
                -- doShowPlacementHelper = true
                -- keepfirst = false
                -- diradd = 0.0
            end
            if i == selected then
                ui.setItemDefaultFocus()
            end
            if ui.itemHovered() then
                currObjkn5 = i
                writeACConfig(appopts, "options", "currObjkn5", currObjkn5)
                MakePreviews()
            end
        end
        --
    end)

    if ui.itemHovered() then
    ui.tooltip(function () ui.text("Selecting here will activate placement mode") end ) end

    ui.sameLine() if ui.button("↑##objprev") then currObjkn5=math.max(1, currObjkn5-1)             MakePreviews() writeACConfig(appopts, "options", "currObjkn5", currObjkn5) end
    ui.sameLine() if ui.button("↓##objnext") then currObjkn5=math.min(#ValidKn5sApp, currObjkn5+1) MakePreviews() writeACConfig(appopts, "options", "currObjkn5", currObjkn5) end

    ui.pushFont(ui.Font.Small)
    ui.sameLine() ui.text(tostring(currObjkn5) .. " / ".. tostring(#ValidKn5sApp))
    ui.pushFont(ui.Font.Title)

    ui.sameLine(0,10)
    local dxADD = ui.getCursorX()

    if ui.button("add >") then
        SeleClear()
        StartPlacementHelper()
    end
    ui.pushFont(ui.Font.Main)




    --- next line



    -- ui.newLine(0)
    if bShowObjectList then
        if ui.button("^") then
        -- if ui.iconButton(ui.Icons.UpAlt) then
            bShowObjectList=false
            -- ac.debug("bShowObjectList", bShowObjectList)
            writeACConfig(appopts, "options", "ObjectList", bShowObjectList)
            SeleClear()
        end
    else
        if ui.button("v") then
        -- if ui.iconButton(ui.Icons.DownAlt) then
            bShowObjectList=true
            -- ac.debug("bShowObjectList", bShowObjectList)
            writeACConfig(appopts, "options", "ObjectList", bShowObjectList)
        end end

    ui.sameLine(0,20)

    if #Objects > 0 then
        ui.sameLine(0,20)
        ui.pushFont(ui.Font.Main)
        if ui.button("Remove all") then
            ui.modalDialog("Confirm", function ()
                -- ui.slider('##offset', _cloneOffset, -20, 20, 'Offset: %.1f m')
                ui.newLine()
                -- ui.offsetCursorY(4)
                ui.text("Really remove all objects?")
                if ui.modernButton('OK', vec2(ui.availableSpaceX() / 2 - 4, 40), ui.ButtonFlags.Confirm, ui.Icons.Confirm)
                    or ui.keyPressed(ui.Key.Enter)
                then
                    lastReply=""
                    -- remove all button
                    StopPlacementHelper()
                    bSelectMode = false
                    bSelectMode2 = false
                    ObjectsReset()
                    LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
                    return true
                end
                ui.sameLine(0, 8)
                return ui.modernButton('Cancel', vec2(-0.1, 40), ui.ButtonFlags.Cancel, ui.Icons.Cancel)
            end, true)
        end

        ui.sameLine(150)
        if ui.checkbox("#", bShowNumbers) then
            -- show id checkbox
            bShowNumbers = not bShowNumbers
        end
        ui.pushFont(ui.Font.Title)
        if ui.itemHovered() then ui.tooltip(function () ui.text("show ID above Object") end ) end
    end

    ui.pushFont(ui.Font.Small)
    ui.sameLine(220)
    -- ui.sameLine(0,20)
    -- ui.setNextItemWidth(150)
    -- ui.setNextItemWidth(ui.availableSpaceX()-130)
    ui.setNextItemWidth(ui.availableSpaceX()-180)
    local selected2 = currObjkn5sameplace
    ui.combo("##add inplace combo", ValidKn5sApp[currObjkn5sameplace]:gsub(".kn5",""):gsub(".KN5",""):gsub(".Kn5",""), ui.ComboFlags.HeightLarge, function ()
        for i,v in pairs(ValidKn5sApp) do
            if ui.selectable(v:gsub(".kn5",""):gsub(".KN5",""):gsub(".Kn5",""), i == selected2) then
                currObjkn5sameplace = i
                writeACConfig(appopts, "options", "currObjkn5sameplace", currObjkn5sameplace )
                MakePreviews()
            end
            if i == selected2 then
                ui.setItemDefaultFocus()
            end
            if ui.itemHovered() then
                currObjkn5sameplace = i
                writeACConfig(appopts, "options", "currObjkn5sameplace", currObjkn5sameplace )
                MakePreviews()
            end
        end
        -- ui.setScrollHereY(currObjkn5sameplace/#ValidKn5sApp)
    end)
    -- ui.setScrollHereY(currObjkn5sameplace/#ValidKn5sApp)
    -- ui.setItemDefaultFocus()

    ui.sameLine() if ui.button("↑##objprevsameplace") then currObjkn5sameplace=math.max(1, currObjkn5sameplace-1)             MakePreviews() writeACConfig(appopts, "options", "currObjkn5sameplace", currObjkn5sameplace ) end
    ui.sameLine() if ui.button("↓##objnextsameplace") then currObjkn5sameplace=math.min(#ValidKn5sApp, currObjkn5sameplace+1) MakePreviews() writeACConfig(appopts, "options", "currObjkn5sameplace", currObjkn5sameplace ) end
    ui.pushFont(ui.Font.Small)
    ui.sameLine() ui.text(tostring(currObjkn5sameplace))
    ui.pushFont(ui.Font.Main)



    ui.sameLine(dxADD-20)
    -- ui.sameLine(0,35)
    ui.pushFont(ui.Font.Main)
    if ui.button("add >##inplace button") then -- add inplace
        for j=1, #Objects do
            if Objects[j]['sele'] then
                selectedObj = j
            end
        end
        if selectedObj>0 and selectedObj<=#Objects then
            AddObject(Objects[selectedObj]['vis']:getPosition(), ObjectsList[selectedObj]['dir'], currObjkn5sameplace, #Objects+1, false, false)
            Objects[#Objects]['sele']=true
            selectedObj = #Objects
            -- keydelay=0.2
            keydelay=0.35
            lastReply=""
            StopPlacementHelper()
            bSelectMode = false
            bSelectMode2 = false
            return
        else
        end
    end
    if ui.itemHovered() then
    ui.tooltip(function () ui.text(" at same position of last selected") end ) end



    -- local dx = 250
    -- -- local dx = ui.getCursorX()+20
    -- -- local dy = ui.getCursorY() + fntSize
    -- local dy = ui.getCursorY() -- - fntSize*2

    local listwidth = ui.windowWidth() -30
    -- if lastReply=="" then

    ui.pushFont(ui.Font.Main)
    if #Objects>0 and lastReply=="" and bShowObjectList then




        -------- next line



        -- ui.text("┌")  -- -- ui.text("↱") corner arrow
        if ui.button("┌") then end
        if ui.itemHovered() then
            ui.tooltip(function () ui.text("left   click - select all\nright click - clear selection") end )
        end
        if ui.itemClicked(ui.MouseButton.Left) then SeleAll() end
        if ui.itemClicked(ui.MouseButton.Right) then SeleClear() end

        ui.sameLine()
        ui.pushFont(ui.Font.Small)
        if ui.checkbox("-###slow", ckbSlow) then ckbSlow = not ckbSlow end
        ui.pushFont(ui.Font.Main)
        if ui.itemHovered() then ui.tooltip(function () ui.text("slow") end ) end
        ui.sameLine()
        ui.pushFont(ui.Font.Small)
        if ui.checkbox("Ξ###fast", ckbFast) then ckbFast=not ckbFast end
        ui.pushFont(ui.Font.Main)
        if ui.itemHovered() then ui.tooltip(function () ui.text("fast") end ) end


        ui.pushFont(ui.Font.Main)
        ui.sameLine()
        --ui.pushButtonRepeat()
        local am = 0.1
        local deg = 5
        if ac.isKeyDown(ui.KeyIndex.Shift) or ckbSlow then
            am=am/10
            deg=deg/10
        end
        if ac.isKeyDown(ui.KeyIndex.Control) or ckbFast then
            am=am*5
            deg=deg*5
        end

        if ui.button("-rZ")   and keydelay2<=0.0 then SeleRot(axisZ, math.rad(deg)) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleRot(axisZ, math.rad(deg)) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("rotate -") end ) end
        ui.sameLine()
        if ui.button("rZ+")   and keydelay2<=0.0 then SeleRot(axisZ, math.rad(-deg)) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleRot(axisZ, math.rad(-deg)) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("rotate +") end ) end
        ui.sameLine(0,10)
        if ui.button("-rY")   and keydelay2<=0.0 then SeleRot(axisY, math.rad(deg)) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleRot(axisY, math.rad(deg)) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("pitch -") end ) end
        ui.sameLine()
        if ui.button("rY+")   and keydelay2<=0.0 then SeleRot(axisY, math.rad(-deg)) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleRot(axisY, math.rad(-deg)) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("pitch +") end ) end
        ui.sameLine(0,10)
        if ui.button("-rX")   and keydelay2<=0.0 then SeleRot(axisX, math.rad(deg)) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleRot(axisX, math.rad(deg)) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("roll -") end ) end
        ui.sameLine()
        if ui.button("rX+")   and keydelay2<=0.0 then SeleRot(axisX, math.rad(-deg)) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleRot(axisX, math.rad(-deg)) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("roll +") end ) end
        ui.sameLine(0,20)
        if ui.button("-z")    and keydelay2<=0.0 then SeleMove(-vUp, am) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleMove(-vUp, am) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("down") end ) end
        ui.sameLine()
        if ui.button("z+")    and keydelay2<=0.0 then SeleMove( vUp, am) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleMove( vUp, am) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("up") end ) end
        ui.sameLine(0,10)
        if ui.button("-y")    and keydelay2<=0.0 then SeleMove(-vEast, am) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleMove(-vEast, am) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("backward") end ) end
        ui.sameLine()
        if ui.button("y+")    and keydelay2<=0.0 then SeleMove( vEast, am) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleMove( vEast, am) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("forward") end ) end
        ui.sameLine(0,10)
        if ui.button("-x")    and keydelay2<=0.0 then SeleMove(-vSouth, am) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleMove(-vSouth, am) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("left") end ) end
        ui.sameLine()
        if ui.button("x+")    and keydelay2<=0.0 then SeleMove( vSouth, am) end
        if ui.itemActive()    and keydelay2<=0.0 then SeleMove( vSouth, am) end
        if ui.itemHovered() then ui.tooltip(function () ui.text("right") end ) end




        -------- next line





        -- ui.text("┌")  -- -- ui.text("↱") corner arrow
        if ui.button("┌") then end
        if ui.itemHovered() then
            ui.tooltip(function () ui.text("left   click - select all\nright click - clear selection") end )
        end
        if ui.itemClicked(ui.MouseButton.Left) then SeleAll() end
        if ui.itemClicked(ui.MouseButton.Right) then SeleClear() end

        -- ui.sameLine(0,20)
        -- ui.text("selected ")
        ui.sameLine()
        if ui.button("delete") then
            SeleGetNum()
            if objsSelected>1 then
                ui.modalDialog("Confirm", function ()
                    -- ui.slider('##offset', _cloneOffset, -20, 20, 'Offset: %.1f m')
                    ui.newLine()
                    -- ui.offsetCursorY(4)
                    ui.text("Really remove selected objects?")
                    if ui.modernButton('OK', vec2(ui.availableSpaceX() / 2 - 4, 40), ui.ButtonFlags.Confirm, ui.Icons.Confirm)
                        or ui.keyPressed(ui.Key.Enter)
                    then
                        lastReply=""
                        -- remove all button
                        SeleDele()
                        return true
                    end
                    ui.sameLine(0, 8)
                    return ui.modernButton('Cancel', vec2(-0.1, 40), ui.ButtonFlags.Cancel, ui.Icons.Cancel)
                end, true)
            else
                SeleDele()
            end
        end

        ui.sameLine(0,30)
        local flag2 = bSelectMode2 and ui.ButtonFlags.Active
        -- local flag2 = ui.ButtonFlags.Active
        if ui.button("select", flag2) then
            bSelectMode2 = not bSelectMode2
            keydelay=0.0
            -- SeleClear()
        end
        if ui.itemHovered() then ui.tooltip(function () ui.text("LEFT Mouse select + move!") end ) end

        ui.sameLine(0,10)
        local flag3 = bSelectMode and ui.ButtonFlags.Active
        -- local flag2 = ui.ButtonFlags.Active
        if ui.button("select/move", flag3) then
            bSelectMode = not bSelectMode
            keydelay=0.0
            -- SeleClear()
            -- if bSelectMode then
            --     bHidden = true
            --     ac.setWindowOpen("windowTrackDecorationid", false)
            -- end
        end
        if ui.itemHovered() then ui.tooltip(function () ui.text("LEFT Mouse select + move!") end ) end


        ui.sameLine(0,10)
        if ui.button("rotate") then
            SeleGetNum()
            if objsSelected>0 then
                -- lastReply=""
                -- diradd = 0
                -- doShowPlacementHelper = true
                StartPlacementHelper()
                doRotateStuff = true
            else
                ui.toast(ui.Icons.AppWindow, "Nothing selected!")
            end
        end

        ui.sameLine(0,10)
        if ui.button("move/rotate") then
            SeleGetNum()
            if objsSelected>0 then
                -- lastReply=""
                -- diradd = 0
                -- doShowPlacementHelper = true
                StartPlacementHelper()
                doMoveStuff = true
                lastposMove = SeleGetCenter()
                origposMove = lastposMove:clone()
            else
                ui.toast(ui.Icons.AppWindow, "Nothing selected!")
            end
        end

        ui.sameLine(0,10)
        if ui.button("duplicate") then
            SeleGetNum()
            if objsSelected>0 then
                -- lastReply=""
                -- diradd = 0
                -- doShowPlacementHelper = true
                SeleDup()
                StartPlacementHelper()
                doMoveStuff = true
                doDuplicate = true
                lastposMove = SeleGetCenter()
                origposMove = lastposMove:clone()
            else
                ui.toast(ui.Icons.AppWindow, "Nothing selected!")
            end
        end


        ui.sameLine(0,10)
        if ui.button("snap down") then
            SeleGetNum()
            if objsSelected>0 then
                -- lastReply=""
                -- diradd = 0
                -- doShowPlacementHelper = true
                SeleSnapToGround()
            else
                ui.toast(ui.Icons.AppWindow, "Nothing selected!")
            end
        end





        -------- next line






        -- listwidth = ui.windowWidth()/2
        ui.childWindow('scrolling', vec2(listwidth, ui.availableSpace().y),
        -- list of Objects and del/go buttons / Object names
        function ()
            for i=1, #Objects do
                if ui.checkbox(tostring(i), Objects[i]['sele']==true) then
                    Objects[i]['sele']=not Objects[i]['sele']
                    objsSelected = 0
                    selectedObj = -1
                    SeleSelection()
                    -- return
                end
                ui.sameLine()
                if ui.button("del###"..i) then
                    local kn5 = Objects[i]["kn5"]
                    if Objects[i]['lit'] ~= nil then
                        Objects[i]['lit']:dispose()
                    end
                    Objects[i]["vis"]:dispose()
                    table.remove(Objects, i)
                    RenameObjects(kn5)
                    -- table.remove(ObjectsList, i)
                    objsSelected = 0
                    selectedObj = -1
                    SeleSelection()
                    return
                end
                ui.sameLine()
                if ui.button("go### "..i) then
                    if sim.freeCameraAllowed then
                        local dir = Objects[i]["vis"]:getLook()
                        local pos = Objects[i]["vis"]:getPosition() + dir*3 + vUp
                        dir.x=-dir.x
                        dir.y=-0.25
                        dir.z=-dir.z
                        ac.setCurrentCamera(ac.CameraMode.Free)
                        ac.setCameraPosition(pos)
                        ac.setCameraDirection(dir)
                    else
                        ui.toast(ui.Icons.AppWindow, "AC/System/Allow FreeCam not enabled!")
                    end
                end

                ui.sameLine()
                ui.text('phy'..' = '..tostring(Objects[i]['phy']) )
                -- if ui.checkbox('physical###'..i, Objects[i]['phy']) then
                --     Objects[i]['phy'] = not Objects[i]['phy']
                --     -- todo remove rigidbody
                --     if Objects[i]['phy'] then

                --     else
                --         RigidBodiesRemove(i)
                --     end
                -- end

                ui.sameLine()
                ui.text(Objects[i]['kn5'])
                ui.sameLine()
                ui.text( " -> " .. Objects[i]['name'])
            end
        end) -- Object list childwin

    elseif lastReply~="" then

        -- KN5Join output
        local uiy = ui.getCursorY()
        -- ui.setCursor(vec2(ui.windowWidth()-100, ui.getCursorY()))
        -- if ui.button("CLEAR LOG") then lastReply="" end
        ui.setCursor(vec2(ui.windowWidth()-90, uiy))
        if ui.button("CLEAR LOG") then lastReply="" end
        ui.newLine()
        ui.setCursor(vec2(ui.windowWidth()-90, uiy+25))
        if ui.button("copy+clear") then
            ac.setClipboardText(lastReply)
            ui.toast(ui.Icons.AppWindow, "Copied to Clipboard!")
            lastReply = ""
        end

        ui.setCursor(vec2(20, uiy))
        ui.childWindow('scrolling', vec2(listwidth-100, ui.availableSpace().y),
        -- list of Objects and del/go buttons / Object names
        function ()
            ui.textWrapped(lastReply)
            -- ui.sameLine(ui.windowWidth()-100)
        end) -- Object list childwin
        -- ui.newLine()
        -- ui.sameLine(0,20)
        -- ui.textWrapped("lastReply\nfgsdfghgsg")

    end

    ui.endOutline(rgbm(0,0,0,0.5), 1)
    ui.endGroup()
    if ui.itemClicked() then StopPlacementHelper() bSelectMode = false end
    if ui.itemClicked(ui.MouseButton.Right) then StopPlacementHelper() bSelectMode = false end



    -- ignore previews in older CSP versions
    if ac.getPatchVersionCode()>2144 then

        -- mini object preview1
        ui.setCursorX(480)
        ui.setCursorY(30)
        if objpreview1~=nil and not doShowPlacementHelper then
            ui.drawRectFilled(              ui.getCursor(), ui.getCursor()+vec2(128,128), rgbm.colors.white-0.25)
            -- ui.drawRectFilled(              ui.getCursor(), ui.getCursor()+vec2(128,128), rgbm.colors.white)
            -- ui.drawImage(objpreview1, ui.getCursor(), ui.getCursor()+vec2(128,128))
            ui.iconButton(objpreview1, vec2(128,128), 0, false, ui.ButtonFlags.Disabled)
            local mw = ui.mouseWheel()
            if ui.itemHovered() and mw~=0 then
                z1=z1-mw/1.0
                MakePreviews()
            end
        end

        -- mini object preview2
        ui.setCursorY(30)
        ui.setCursorX(480+130)
        if objpreview2~=nil and not doShowPlacementHelper then
            ui.drawRectFilled(              ui.getCursor(), ui.getCursor()+vec2(128,128), rgbm.colors.white-0.25)
            -- ui.drawImage(objpreview2, ui.getCursor(), ui.getCursor()+vec2(128,128))
            ui.iconButton(objpreview2, vec2(128,128), 0, false, ui.ButtonFlags.Disabled)
            local mw = ui.mouseWheel()
            if ui.itemHovered() and mw~=0 then
                z2=z2-mw/1.0
                MakePreviews()
            end
        end
    end



    -- mouse scroll to rotate objects on track
    -- preview Object on track rotated somewhere else
    if doMoveStuff or doRotateStuff or doShowPlacementHelper then

        local mw_deg = ui.mouseWheel()  -- // * 5
        if not ui.windowHovered(ui.HoveredFlags.RootWindow) and mw_deg ~= 0 then
            if ac.isKeyDown(ui.KeyIndex.Shift) or ckbSlow then
                mw_deg=mw_deg/10
            end
            if ac.isKeyDown(ui.KeyIndex.Control) or ckbFast then
                mw_deg=mw_deg*5
            end
            rotZadd = rotZadd + math.rad( mw_deg )
                -- rotZadd = rotZadd + math.rad(  math.max(5,math.min(1,math.floor(mw*5)))   )
                -- preview Object rotated somewhere else

            if doMoveStuff or doRotateStuff then
                -- rotate selected objects
                for i=1, #Objects do
                    if Objects[i]['sele']==true then
                        Objects[i]['vis']:rotate(axisZ, math.rad(mw_deg))
                    end
                end
            end

        end

    end

end







local doubleclicktimer = 0.0
local acuistate = nil

local _l_manual_pos = vec2(0,0)
local _l_manual_padding = vec2(0,0)
local _l_manual_dim = vec2(1280,512)
local _l_color_bg = rgbm(0,0,0,0.35)

function script.windowTrackDecoration(dt)
    insideWindow = ui.windowHovered()
    if insideWindow then keydelay=0.2 end  -- to prevent adding objs when clicking on "STOP"
    ShowMainWindow(dt)

    -- if doShowPlacementHelper then
    --     ui.setNextWindowSize(vec2(250,500 ))
    --     ShowMainWindow(dt)
    -- else
    --     ui.setNextWindowSize(vec2(250,200 ))
    --     ShowMainWindow(dt)
    -- end
    -- _l_manual_padding.x = 0 --sim.windowWidth/2 - 1280/2*UIScale
    -- _l_manual_padding.y = 0 --sim.windowWidth/2 - 1280/2*UIScale
    -- _l_manual_pos = ui.windowPos()
    -- _l_manual_dim.x = ui.windowWidth()-30
    -- _l_manual_dim.y = ui.windowHeight()-40
    -- local flag = 0  -- bit.bor(ui.WindowFlags.NoBackground)
    -- -- ui.beginOutline()


    -- if doShowPlacementHelper or bSelectMode then
    --     -- if not bHidden then
    --     --     bHidden = true
    --     --     ac.setWindowOpen("windowTrackDecorationid", false)
    --     -- end
    -- else

    --     if not bPaused then
    --         -- if bHidden then
    --         --     bHidden = false
    --         --     ac.setWindowOpen("windowTrackDecorationid", true)
    --         --     ac.debug("KACKACKACKAKCKAC", "kkkkkkkkkkkkkkkkkkkkkkkk")
    --         -- end
    --     end
    --         lastHeight = ui.windowHeight()
    --         ShowMainWindow(dt)
    --         _l_manual_dim.y=lastHeight

    --         --ui.windowHeight
    --         -- ac.setWindowOpen("windowTrackDecorationid", true)
    --         --ui.setNextWindowSize(vec2(250, lastHeight))
    --         --ui.childWindow("TrackDeco", _l_manual_dim, false, flag, function() ShowMainWindow(dt) end)
    --         -- ui.childWindow("TrackDeco", _l_manual_dim, true, flag, function() ShowMainWindow(dt) end)
    --         -- ui.toolWindow("TrackDeco", _l_manual_pos, _l_manual_dim, true, function() ShowMainWindow(dt) end)
    --         -- ui.transparentWindow(
    --         --         "TrackDeco",
    --         --         _l_manual_pos, _l_manual_dim, true, true,
    --         --         function() ShowMainWindow(dt) end
    --         --     )

    -- end
    -- -- ui.endOutline(rgbm(0,0,0,0.5), 1)

end




-- -- Compass settings
function script.windowCompassSettings(dt)
    ui.beginOutline()
    if ui.checkbox("Degrees", bCompassDegrees) then
        bCompassDegrees = not bCompassDegrees
        writeACConfig(appopts, "options", "CompassDegrees", bCompassDegrees)
    end
    if ui.checkbox("Graphics", bCompassGraphics) then
        bCompassGraphics = not bCompassGraphics
        writeACConfig(appopts, "options", "CompassGraphics", bCompassGraphics)
    end
    if ui.checkbox("Inverted", bCompassInverted) then
        bCompassInverted = not bCompassInverted
        writeACConfig(appopts, "options", "CompassInverted", bCompassInverted)
    end
    ui.endOutline(rgbm.colors.black, 1)
end


-- -- TrackDeco settings
function script.windowTrackDecoSettings(dt)
    ui.beginOutline()
    if ui.checkbox("Write CSP 'tree.txt' format too", bWriteCSPTreeFormat) then
        bWriteCSPTreeFormat = not bWriteCSPTreeFormat
        writeACConfig(appopts, "options", "WriteCSPTreeFormat", bWriteCSPTreeFormat)
    end
    ui.endOutline(rgbm.colors.black, 1)
end


-- -- draw messages on screen
-- function UICallback()
-- end





-- -- main script update
function script.update(dt)

    -- reset on session restart
    if sim.sessionTimeLeft > sesstimeleft  then
        sesstimeleft = sim.sessionTimeLeft-0.002
        if bAutoLoad then
            ObjectsReset()
            LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
            ObjectsLoadFromList()
            SeleGetNum()
            lastReply = ""
        end
        return
    end

    -- slowly spin aclogo(s)
    if #Objects>0 then
        for i=1, #Objects do
            if get_file_name(Objects[i]['kn5'])=='aclogo_big.kn5' then
                -- Objects[i]['vis']:rotate(axisZ, -math.rad(0.5))
                Objects[i]['vis']:rotate(axisZ, -0.005)
            end
        end
    end

    -- dont do heavy stuff all the time
    --if keydelay>0.0 then keydelay=keydelay-dt end
    if doShowPlacementHelper or bSelectMode or bSelectMode2 then
       if keydelay>0.0 then keydelay=keydelay-dt end
    end


    -- select w left mouse button
    -- if bSelectMode and not doShowPlacementHelper and keydelay<=0.0 then
    if ((bSelectMode and not doShowPlacementHelper) or bSelectMode2) and keydelay<=0.0 then

        if doubleclicktimer>0.0 then
            doubleclicktimer = doubleclicktimer - dt
        end

        if ac.isKeyDown(ac.KeyIndex.RightButton) then
            if doubleclicktimer<=0.0 then
                doubleclicktimer = 2.0
            else
                if doubleclicktimer>0.0 and doubleclicktimer<1.0 then
                    bSelectMode = false
                    bSelectMode2 = false
                    doubleclicktimer = 0.0
                    return
                end
            end
        end

        getPosfromMouse()

        if ac.isKeyDown(ac.KeyIndex.LeftButton) then

            local ray = render.createMouseRay()
            local ref = ac.emptySceneReference()
            local res = basenode:raycast(ray, ref)
            if res ~= -1 then
                cursorpos = ray.dir * ray:track() + ray.pos
                cursorposray = ray.dir * ray:track() + ray.pos
            else
                cursorpos = nil
            end

            if res ~= -1 then
                local mind = 999999.0
                local mindID = -1
                for i=1, #Objects do
                    local dist = Objects[i]['vis']:getPosition():distance(cursorpos + vUp*0.1)
                    if dist<mind then
                        mind=dist
                        mindID=i
                    end
                end
                if  mindID> -1
                    and
                    mind  <  5
                    -- math.abs(mind-res)<2
                    -- and
                    --ac.getCameraPosition():distance(Objects[mindID]['vis']:getPosition()) < res+5
                then
                --if mindID>-1 and mind<2 then
                    if bSelectMode then
                        SeleClear()
                    end
                    Objects[mindID]['sele']=true
                    SeleGetNum()

                    -- SeleSelection()
                    -- lastReply=""
                    -- diradd = 0
                    -- doShowPlacementHelper = true
                    -- lastposMove = SeleGetCenter()
                    -- origposMove = lastposMove:clone()

                    -- ac.setWindowOpen("windowTrackDecorationid", true)
                    if bSelectMode then
                        doMoveStuff = true
                        lastposMove = Objects[mindID]['vis']:getPosition()
                        origposMove = lastposMove:clone()
                        StartPlacementHelper()
                    end
                    -- keydelay = 0.5
                    keydelay = 0.25
                    -- break
                    return

                end
            end
        end
    end

    if doShowPlacementHelper and keydelay<=0.0 then
        if --ui.isKeyPressed(ui.KeyIndex.Escape) or
           ac.isKeyDown(ac.KeyIndex.RightButton)
        then
            if doMoveStuff or doRotateStuff then
                -- undo stuff after duplication
                local diff = origposMove - cursorpos
                for i=1, #Objects do
                    if Objects[i]['sele']==true then
                        Objects[i]['vis']:rotate(axisZ, -rotZadd )
                    end
                end
                if doMoveStuff then
                    SeleMoveCursor(diff)
                end
                if doDuplicate then
                    SeleDeleDups()
                end
            end
            -- stop doing stuff
            StopPlacementHelper()
            if bSelectMode then SeleClear() end
            -- if not bPaused and bHidden then
            --     bHidden = false
            --     ac.setWindowOpen("windowTrackDecorationid", true)
            -- end
            return
        end
    end

    if acuistate == nil then
        if ac.getUI() then
            acuistate = ac.getUI()
        end
    end

    if acuistate and (doMoveStuff or doRotateStuff or doShowPlacementHelper) then
        local mw_deg = acuistate.mouseWheel   -- * 5
        if mw_deg~=0 then
            if ac.isKeyDown(ui.KeyIndex.Shift) or ckbSlow then
                mw_deg=mw_deg/10
            end
            if ac.isKeyDown(ui.KeyIndex.Control) or ckbFast then
                mw_deg=mw_deg*5
            end
            rotZadd = rotZadd + math.rad(mw_deg*5)
            -- preview Object rotated somewhere else
            if doMoveStuff or doRotateStuff then
                -- rotate selected objects
                for i=1, #Objects do
                    if Objects[i]['sele']==true then
                        Objects[i]['vis']:rotate(axisZ, math.rad(mw_deg*5))
                    end
                end
            end
        end
    end



    if doShowPlacementHelper and not insideWindow then
        getPosfromMouse()
        if keydelay<=0.0 and
           ac.isKeyDown(ac.KeyIndex.LeftButton) and
           cursorpos ~= nil
        then

            if doMoveStuff or doRotateStuff then

                -- left mouse clicked after duplicate or move finished
                -- everything can stay as is
                StopPlacementHelper()
                if bSelectMode then SeleClear() end
                -- if not bPaused and bHidden then
                --     bHidden = false
                --     ac.setWindowOpen("windowTrackDecorationid", true)
                --     ac.debug("eeeeeeeee", "kkkkkkkkkkkkkkkkkkkkkkkk")
                -- end
                cursorpos = nil
                keydelay = 0.35

            else

                -- left mouse clicked
                -- add 1 new object
                local objnum = #Objects+1

                -- copy orientation from surface normal
                local yaw, pitch, roll = GetSurfaceRot(dirsurf)
                if bAlignToSurface then
                else
                    local camlook = ac.getCameraForward()
                    local angleCursor = math.deg(math.atan2(cursorpos.z-sim.cameraPosition.z, cursorpos.x-sim.cameraPosition.x) + math.rad(90) )
                    local angleCamera = math.deg(math.atan2(camlook.z, camlook.x) + math.rad(90))
                    if bCamFacing then
                        yaw = (angleCamera-(angleCamera-angleCursor)) --  + math.deg(-rotZadd)
                    else
                        yaw = angleCamera                             --  + math.deg(-rotZadd)
                    end
                    pitch = 0 -- objdir.y
                    roll  = 0 -- objdir.z
                    -- rotZadd = 0.0
                end
                -- if bAlignSwitchDir then
                --     yaw=-yaw
                --     roll=-roll
                -- end
                snapToTrackSurface(cursorpos, 0)
                local newrot = vec3(-math.deg(math.rad(yaw) ),
                -- local newrot = vec3(-math.deg(math.rad(yaw) + rotZadd),
                                    -math.deg(math.rad(pitch)),
                                    -math.deg(math.rad(roll)) )
                AddObject(cursorpos + vUp * GetObjectOFFSET(ValidKn5sApp[currObjkn5]), newrot, currObjkn5, objnum, false, true)

                --SeleClear()
                if Objects[objnum] then
                Objects[objnum]['sele']=true
                end
                SeleGetNum()
                -- keydelay=0.2
                keydelay=0.35
            end
        end
    end
end





-- [RENDER_CALLBACKS]
-- TRANSPARENT = Draw3D

-- drawing/updating stuff on track
function Draw3D(dt)

    if #RigidBodies>0 then
        -- update/sync RigidBodies and their visible objects
        for i=1, #RigidBodies do
            RigidBodies[i]['vis']:setTransformationFrom(RigidBodies[i]['phy'])
            -- show debug names/numbers
            if bShowNumbers then
                local currPos = ac.getCameraPosition()
                local pos = RigidBodies[i]['vis']:getPosition()
                local d = currPos:distance(pos)
                local sz = math.min(3, math.max(1*fntSize/22,100/d))
                if d<400 then
                    render.debugText(pos+vUp*2, tostring(i), rgbm.colors.white, sz, render.FontAlign.Center)
                end
            end
        end
    end


    -- show arrow above selected objects
    for i=1, #Objects do
        if Objects[i]['sele'] then
            local currPos = ac.getCameraPosition()
            local d=currPos:distance(Objects[i]['vis']:getPosition())
            if d<400 then
                render.debugArrow(Objects[i]['vis']:getPosition()+vUp*3, Objects[i]['vis']:getPosition()+vUp*1, 0.15, rgbm.colors.white*2)
            end
        end
    end

    -- show object numbers / Names above nearby objects
    if bShowNumbers then
        render.setBlendMode(4)
        render.setDepthMode(4)
        local currPos = ac.getCameraPosition()
        for i=1, #Objects do
            local d=currPos:distance(Objects[i]['vis']:getPosition())
            if d<400 then
                local sz = math.min(2, math.max(1*fntSize/22,100/d))
                render.debugText(Objects[i]['vis']:getPosition()+vUp*1,
                    Objects[i]['name'], rgbm.colors.white*2, sz, render.FontAlign.Center)
            end
        end
    end


    -- show msg to exit select mode
    if bSelectMode and not insideWindow and not doShowPlacementHelper and keydelay<=0.0 and cursorpos~=nil then
    -- if bSelectMode and keydelay<=0.0 then
        local s = "left click: select\nhold right mouse: stop"
        -- "right mouse: stop\n" .. tostring(math_round(math.deg(diradd)).."°" ),
        -- if objsSelected>0 then s=s.."\n"..tostring(objsSelected) end
        render.debugText( cursorpos+vUp*2, s, rgbm.colors.lime, 1.25, render.FontAlign.Center)
        render.debugArrow(cursorpos+vUp*1, cursorpos, 0.25, rgbm.colors.lime*2)
        -- render.debugText( cursorposray+vUp*2, s, rgbm.colors.lime, 1.2, render.FontAlign.Center)
        -- render.debugArrow(cursorposray+vUp*2, cursorposray, 0.25, rgbm.colors.lime*2)
    end


    -- create/move around preview object or selected objects
    if doShowPlacementHelper and not insideWindow then

        if doMoveStuff or doDuplicate then

            -- move around X selected objects
            local vdiff = cursorpos - lastposMove
            SeleMoveCursor(vdiff)
            lastposMove = cursorpos

        elseif not doRotateStuff then

            -- move around one preview object
            snapToTrackSurface(cursorpos, 0.0)

            local yaw, pitch, roll = GetSurfaceRot(dirsurf)
            if bAlignToSurface then
            else
                local camlook = ac.getCameraForward()
                local angleCursor = math.deg(math.atan2(cursorpos.z-sim.cameraPosition.z, cursorpos.x-sim.cameraPosition.x) + math.rad(90) )
                local angleCamera = math.deg(math.atan2(camlook.z, camlook.x) + math.rad(90))
                if bCamFacing then
                    yaw = (angleCamera-(angleCamera-angleCursor)) -- + math.deg(-rotZadd)
                else
                    yaw = angleCamera   -- + math.deg(-rotZadd)
                end
                pitch = 0 -- objdir.y
                roll  = 0 -- objdir.z
            end
            --if bAlignSwitchDir then
                -- rotZadd=-rotZadd
                --yaw=-yaw
                --roll=-roll
            --end

            if KN5axis then
                KN5axis:setPosition(cursorpos)
                KN5axis:setOrientation(previewLook)
                KN5axis:rotate(axisZ, (math.rad(yaw) ) )
                if bAlignToSurface then
                    KN5axis:rotate(axisX, math.rad(roll))
                    KN5axis:rotate(axisY, math.rad(pitch))
                end
                KN5axis:rotate(axisZ, (rotZadd) )
            end

            if ObjPreview==nil then
                AddPreviewObject(cursorpos, currObjkn5, 0, true)
            end
            if ObjPreview then
                -- copy orientation from surface normal
                ObjPreview:setPosition(cursorpos + vUp * GetObjectOFFSET(ValidKn5sApp[currObjkn5]))
                ObjPreview:setOrientation(previewLook)
                -- ObjPreview:rotate(axisZ, (math.rad(yaw) + rotZadd) )
                ObjPreview:rotate(    axisZ, (math.rad(yaw)) )
                -- ObjPreview:rotate(    axisZ, (math.rad(yaw) + (rotZadd)) )
                if bAlignToSurface then
                    ObjPreview:rotate(axisX, math.rad(roll))
                    ObjPreview:rotate(axisY, math.rad(pitch))
                end
                ObjPreview:rotate(    axisZ, (rotZadd) )
            end
        end

        render.setBlendMode(4)
        render.setDepthMode(4)
        local s = "right click: stop"
        -- "right mouse: stop\n" .. tostring(math_round(math.deg(diradd)).."°" ),
        if objsSelected>0 then s=s.."\n"..tostring(objsSelected) end
        render.debugText(cursorpos+vUp*1, s, rgbm.colors.lime*2, 1.5, render.FontAlign.Center)
    end

    -- show msg to exit select mode
    if (bSelectMode or bSelectMode2) and not insideWindow and not doShowPlacementHelper and keydelay<=0.0 and cursorpos~=nil then
    -- if bSelectMode and keydelay<=0.0 then
        render.setBlendMode(4)
        render.setDepthMode(4)
        local s = "left click: select\nhold right mouse: stop"
        render.debugText( cursorpos+vUp*2, s, rgbm.colors.lime, 1.25, render.FontAlign.Center)
        render.debugArrow(cursorpos+vUp*1, cursorpos, 0.25, rgbm.colors.lime*2)
    end

end




function FnMainClose()
    SeleClear()
end



-- ac.debug("ac.getPatchVersionCode()", ac.getPatchVersionCode())

-- -- onExclusiveHUD - when game is paused/in main menu
if ac.getPatchVersionCode()>=2651 then
ui.onExclusiveHUD(function (mode)
    if mode == 'pause' then
        if not bPaused then
            bPaused = true
            if doShowPlacementHelper or bSelectMode or bSelectMode2 then
                bSelectMode = false
                bSelectMode2 = false
                StopPlacementHelper()
            end
            -- bSelectMode = false
            -- doShowPlacementHelper = false
            -- if ac.isWindowOpen("windowTrackDecorationid") then
            -- if true then
            --     if not bHidden then
            --         bHidden = true
            --         ac.setWindowOpen("windowTrackDecorationid", false)
            --     end
            -- end
        end
    else
        if bPaused then
            -- if bHidden then
            --     bHidden=false
            --     ac.setWindowOpen("windowTrackDecorationid", true)
            -- end
            bPaused = false
        end
    end
    return false
end)
end




---- running all this on script start

MaxSectID = GetNextModelID_from_ModelsINI()
if ac.hasTrackSpline() then
    CreateBorders()
end

if io.fileExists(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID]) then
    LoadCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID])
    if bAutoLoad then
        ObjectsLoadFromList()

        -- -- HC test, saves immediately after loading first time
        -- if true then
        --     ac.debug("MaxSectID", MaxSectID)
        --     SaveCustomModelsINI(dirTrackDeco .. 'dataSections/'..fileModelsINIs[fileCurrID], -1)
        -- end

    end
    -- -- for debugging
    -- AddConesOnCorners()

end



currObjkn5          = math.min(tonumber(currObjkn5), #ValidKn5sApp)
currObjkn5sameplace = math.min(tonumber(currObjkn5sameplace), #ValidKn5sApp)
if currObjkn5>0 then
    MakePreviews()
end

