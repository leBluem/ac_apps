TrackDecoration by leBluem
Place Objects on track, auto loading next session.
Full description: https://www.overtake.gg/downloads/trackdecoration.76979/


TrackDecoration Objects Pack1 by RMi - v0.85
  85 objects for TD app,
  readme included
  unpack to "...apps\Lua\"!
  https://sharemods.com/lu7uckrv5qnl/TrackDecoration_Objects_Pack1_by_RMi_-_v0.85.7z.html
  https://www.mediafire.com/file/eomlk4ashi6r47u/TrackDecoration_Objects_Pack1_by_RMi_-_v0.85.7z/file

TrackDecoration Objects Pack2 by RMi - v0.85
  47 objects for TD app,
  readme included
  unpack to "...apps\Lua\"!
  https://sharemods.com/6qfz8fr8fe4h/TrackDecoration_Objects_Pack2_by_RMi_-_v0.85.7z.html
  https://www.mediafire.com/file/vdid5mady4npkaf/TrackDecoration_Objects_Pack2_by_RMi_-_v0.85.7z/file


try this in the Future:
https://www.gtplanet.net/forum/search/4096614/?q=TrackDecoration+Objects&t=post&c[thread]=307899



v1.1 changelog
-fixed not unloading objects for preview
-added filesize after filename
v1.2 changelog
-changed filesize to objects in current file
-small ui changes
v1.3 changelog
-selected objects are highlighted
-added AC_PIT/AC_START/AC_TIME/AC_AB_TIME... dummies (obj\AC_objs\ folder)
--lets you easily build a new layout with new spawn points/more pits
-added button to run "kn5Join" to create the KN5 from the app
--for that put "kn5Join" folder into TrackDecoration\ or TrackDecoration\obj\ folder!
-new icon
v1.3.1 changelog
-added preview-names
v1.3.2 changelog
-kn5Join now included and runs fully in the background
v1.3.3 changelog
-added for selected:
--delete / duplicate / move/rotate via mousewheel
-CSP version 0.2.0 is enough to run
-fixed error when /content/objects3D/axis.kn5 is missing
v1.4 changelog
--fixed kn5Join not finding objects directory
v1.5 changelog
--fixes for mini preview:
---better camera position
---now also showing transparent objects
---random crash when fast scrolling through objects
v1.5.1 quickfix1 changelog
    Now app should work with CSP 0.2.0 as advertised.
v1.5.1 quickfix2 changelog
    -must confirm deletion of more than 1 object
    -object-list can be hidden
    -rotate only button, so you dont mess up original position
    -changed preview-cam pos again
v1.5.2 changelog
--fixed kn5join not working
--fixed object numbers when deleteing some
v1.5.3 changelog
--final fix for running kn5join
v1.6 changelog
--all folders inside "obj" will be scanned for kn5's
--mainwindow now hidden when placing/moving objects
--added multiple file support
--added select/move with left mouse button
---this mode eats half your fps
---holding right mouse will exit
--added option to align objects to surface
--- it has an extra switch for flipping direction of object
--fixed other small issues
--loading lots of objects now almost instant
--added dialog to select object for "Cones on apexes"
v1.6.1
--added light definitions for RMi Objects Pack 2
--fixed adding more than one object in same place, while holding left mouse button
--fixed TD app-window always showing up next session
--removed all app hiding stuff
--improved performance when using "select/move"
--set "select/move" select distance to 5 meters, before nearest object would be picked, no matter how far away from cursor
--added option to load cfg from different layout on same track
--added reload for available files
--now includes a TrackDeco config for Nordschleife "..._leBluem_cones.ini"
---134 manually placed cones in strategic places, took me ~half an hour :)
v1.6.2
--fixed rotation with mouse spazzing out
v1.6.3
--fixed duplicating stuff
--rotation now also reacts to "slow/fast" movement checkboxes
--or holding Shift/Ctrl
v1.6.4
--added another button for only just selecting objects
--added AC_AUDIO/AC_REVERB dummy as objects
(for "data\audio_sources.ini" those could have any name too)
--fixed compass not being round
--select button now does not remove selection from already selected
v1.6.5
--fixed reloading files/obj folder
--fixed some localized textures of some objects
--fixed rotating w mouse when "switch direction" was on
--added 60/80 speed limit signs, added 50m/150m tall corner markers
v1.7
--fixed lights not turning on, also removing lights now turns them off
--fixed textures for brakeLeft/brakeRight.kn5
--current object is now selected when opening combobox
--added "snap down" button for selected objects
--added 9 lights
--added some more parameters for lights on top of source file
v1.8
--fixed KN5Join renaming objects
--added 17 objects in "obj/corner/" folder
v1.9
--finally fixed saving/loading rotated objects
--compatible with CSP 0.1.77, no need for a stripped down version
v1.9.1
--fixed aligned object placement
v2.0
--fixed non-aligned placement again
--added Rigid-Body Physics to all objects defined in "TrackDecoration\object_parameters.lua"
