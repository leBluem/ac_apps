v4.3 - custom by leBluem
-based on v4.1
-added IMO temps, added carcass temps when car has this
-slip from 0-200%, in yellow until 100%, then in red

v4.4
-fixed gears above 8
