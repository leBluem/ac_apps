-- CustomLicenseTest by leBluem
-- v0.6 - 14 feb 2025
-- -fixed delta after new record
-- -fixed timer still running when game is paused
-- -fixed low fps with sector editor on
-- -fixed not saving options
-- -moved messages away from the timing window, to be printed on screen only, which can be made much smaller now
-- -moved away images into their own folder
-- -added current estimated medal graphics near delta
-- v0.5 - 24 jan 2025
-- v0.4 - 24 oct 2024
-- v0.3 - 14 sept 2024
-- v0.2 - 30 july 2024
-- v0.1 - 17 may 2024
-- v0.0 - 1 may 2024  -- initial version

local function readACConfig(ini, sec, key, def)
    local inifile = ac.INIConfig.load(ini, ac.INIFormat.Default)
    return inifile:get(sec, key, def)
end
local function writeACConfig(ini, sec, key, val)
    local inifile = ac.INIConfig.load(ini)
    inifile:setAndSave(sec, key, val)
end

local appopts = 'apps/lua/CustomLicenseTest/options.ini'
local alsomovecar   = readACConfig(appopts, "options", "alwaysmovecar", false) --@bool
local ailevel       = readACConfig(appopts, "options", "ailevel"      , 100.0) --@float
local aiagg         = readACConfig(appopts, "options", "aiaggression" , 100.0) --@float
local aimedaloffset = readACConfig(appopts, "options", "aimedaloffset", 0.025) --@float
local bShowDelta    = readACConfig(appopts, "options", "bShowDelta"    , true) --@bool
local bShowMedals   = readACConfig(appopts, "options", "bShowMedals"  , true) --@bool
local bAudio        = readACConfig(appopts, "options", "bAudio"      , false) --@bool
local bAutoRestart  = readACConfig(appopts, "options", "bAutoRestart", false) --@bool
local bControls     = readACConfig(appopts, "options", "bControls", true) --@bool
local ailevelother  = readACConfig(appopts, "options", "ailevelother"      , 100.0) --@float
local aiaggother    = readACConfig(appopts, "options", "aiaggressionother" , 100.0) --@float

if physics.allowed() then
physics.setAILevel(0,ailevel/100.0)
physics.setAIAggression(0,aiagg/100.0)
end

local sim = ac.getSim()
local car = ac.getCar(0)
-- local carp = ac.getCarPhysics(0)
local sCar = string.lower( ac.getCarID(0) )
local sTrack = string.lower( ac.getTrackID() )
local sLayout = string.lower( ac.getTrackLayout() )


local carname = ac.getCarName(0, true)
if carname then
    local i=carname:find("’")
    if i and i>0 and i>carname:len()-5 then
        carname=carname:sub(1,i-1)
    end
end

-- basenode = ac.findNodes('sceneRoot:yes')
local basenode  --@ac.SceneReference
basenode = ac.findNodes('staticRoot:yes')
local aclogo          = basenode:loadKN5("vis/aclogo.kn5")
local GateSF          = basenode:loadKN5("vis/sfgate.kn5")
local GateConeStartL  = basenode:loadKN5("vis/coneS.kn5")
local GateConeStartR  = basenode:loadKN5("vis/coneS.kn5")
local GateConeFinishL = basenode:loadKN5("vis/coneF.kn5")
local GateConeFinishR = basenode:loadKN5("vis/coneF.kn5")
local GateSFmesh = GateSF:findMeshes("sfflag?")

aclogo:findMeshes("acglass"):setVisible(false)
GateSF:setVisible(false)
GateConeStartL:setVisible(false)
GateConeStartR:setVisible(false)
GateConeFinishL:setVisible(false)
GateConeFinishR:setVisible(false)


-- basenode:loadKN5Async(
--     "coneS.kn5",
--     function(err, loaded)
            --MESHES=cone_bodyS
basenode:applyShaderReplacements([[
[SHADER_REPLACEMENT_...]
MESHES=cone_litS?, cone_litF?
PROP_...=ksAmbient, 0.18
PROP_...=ksDiffuse, 0.10
PROP_...=ksEmissive, 50,30,10
]]
-- [SHADER_REPLACEMENT_...]
-- MESHES=sfflag?
-- PROP_...=ksEmissive, 5,3,1
    ,ac.IncludeType.Track)
--         else
--             ac.debug("Error:", err)
--         end
--     end
-- )

-- ac.debug("meshfound", GateSF:findMeshes("sfflag?"):setMaterialProperty('ksEmissive', rgbm(1,1,1,1000)))

-- basenode:applyShaderReplacements([[
-- [CONDITION_...]
-- NAME=BLINK1CLT
-- INPUT=ONE
-- FLASHING_FREQUENCY=5
-- FLASHING_SMOOTHNESS=0.4

-- [CONDITION_...]
-- NAME=BLINK2CLT
-- INPUT=ONE
-- FLASHING_FREQUENCY=4.5
-- FLASHING_SMOOTHNESS=0.4

-- [CONDITION_...]
-- NAME=BLINK3CLT
-- INPUT=ONE
-- FLASHING_FREQUENCY=5.5
-- FLASHING_SMOOTHNESS=0.4

-- [CONDITION_...]
-- NAME=BLINK4CLT
-- INPUT=ONE
-- FLASHING_FREQUENCY=4.75
-- FLASHING_SMOOTHNESS=0.4

-- [CustomEmissive]
-- ACTIVE = 1
-- Materials = dyn_cone_uk_large1
-- Resolution = 1536, 512
-- SHADER=ksPerPixelMultiMap_emissive
-- ;;; Start = "543, 22", Size = "157, 168"
-- @ = CustomEmissive_Circle, Channel = 0, Start = "520, 260", Size = "200", Exponent=2
-- @ = CustomEmissive_Circle, Channel = 1, Start = "780, 260", Size = "200", Exponent=2
-- @ = CustomEmissive_Circle, Channel = 2, Start = "520, 0", Size = "200", Exponent=2
-- @ = CustomEmissive_Circle, Channel = 3, Start = "780, 0", Size = "200", Exponent=2

-- [MATERIAL_ADJUSTMENT_...]
-- MATERIALS = dyn_cone_uk_large1
-- KEY_... = ksEmissive
-- VALUE_... = 100
-- KEY_... = ksAlphaRef
-- VALUE_... = -193
-- CONDITION = BLINK1CLT

-- [MATERIAL_ADJUSTMENT_...]
-- MATERIALS = dyn_cone_uk_large1
-- KEY_... = ksEmissive1
-- VALUE_... = 100
-- KEY_... = ksAlphaRef
-- VALUE_... = -193
-- CONDITION = BLINK2CLT

-- [MATERIAL_ADJUSTMENT_...]
-- MATERIALS = dyn_cone_uk_large1
-- KEY_... = ksEmissive2
-- VALUE_... = 100
-- KEY_... = ksAlphaRef
-- VALUE_... = -193
-- CONDITION = BLINK3CLT

-- [MATERIAL_ADJUSTMENT_...]
-- MATERIALS = dyn_cone_uk_large1
-- KEY_... = ksEmissive3
-- VALUE_... = 100
-- KEY_... = ksAlphaRef
-- VALUE_... = -193
-- CONDITION = BLINK4CLT
-- ]], ac.IncludeType.Track)

local imgupdate = 0.0
local currSplinePos = 0.0
local bABtrack = false
-- local lastCamera = -1 --@ac.CameraMode


------ for real --------------------
local afterRace = -1.0
---- for debug testing aclogo ------
--local afterRace = 50.0
------------------------------------

local metersToRewind = 200  -- 5 for testing
local previewMapLeadinMeters = 100
local previewMapLeadinMetersDefault = 100

local png_size = 513
local mapZoomed = ui.ExtraCanvas(png_size, 4)
local mapOverlay = ui.ExtraCanvas(png_size, 4)

local png_mapoffset = 20
local previewSize = png_size
local previewOffX = previewSize + 128
local previewOffY = 150


local brdDist = 1.0                           --- meters
local borderDist = brdDist/sim.trackLengthM   --- those  m above in percent of track


local fntSize = 24
local fntSizeSmall = 20

local colInactive = rgbm(0.4,0.4,0.4,0.5)
local colInactive2 = rgbm(0.25,0.25,0.25,0.1)
local colInactive3 = rgbm(0.75,0.75,0.75,0.5)
local colBG = rgbm(0,0,0,0.075)
local colBGdelta = rgbm(1,0,0.5,0.1)
local colBGdeltagreen = rgbm(0.25,1,0.25,0.1)

local partoffset = 1
local partoffsetadd = 1

local pushForce = 150
local pushsecondstoadd = 0.25
local pushseconds = 0.0 -- used as counter
local ffbTimer = 0.0
local lastFFB = 1




local Beep          = ui.MediaPlayer(ac.getFolder(ac.FolderID.Root).."/apps/lua/CustomLicenseTest/sounds/beep.mp3")
local BeepFL        = ui.MediaPlayer(ac.getFolder(ac.FolderID.Root).."/apps/lua/CustomLicenseTest/sounds/beep_fastestLap.mp3")
local BeepFS        = ui.MediaPlayer(ac.getFolder(ac.FolderID.Root).."/apps/lua/CustomLicenseTest/sounds/beep_fastestSector.mp3")
local BeepCountdown = ui.MediaPlayer(ac.getFolder(ac.FolderID.Root).."/apps/lua/CustomLicenseTest/sounds/countdown.mp3")

--local Beep = ac.AudioEvent.fromFile('sounds/beep.mp3')

Beep:setVolume(ac.getAudioVolume(ac.AudioChannel.Main)*0.5)
BeepFL:setVolume(ac.getAudioVolume(ac.AudioChannel.Main)*0.5)
BeepFS:setVolume(ac.getAudioVolume(ac.AudioChannel.Main)*0.5)
BeepCountdown:setVolume(ac.getAudioVolume(ac.AudioChannel.Main)*0.5)



local dirdataPB = ac.getFolder(ac.FolderID.Root)       .. "\\apps\\lua\\CustomLicenseTest\\dataPB\\"
local dirdataSections = ac.getFolder(ac.FolderID.Root) .. "\\apps\\lua\\CustomLicenseTest\\dataSections\\"
local dirdataMedals = ac.getFolder(ac.FolderID.Root)    .. "\\apps\\lua\\CustomLicenseTest\\dataMedals\\"


--local mappng = ac.getFolder(ac.FolderID.Root) .. "\\content\\tracks\\" .. ac.getTrackFullID('\\') .. "\\map.png"
local sectionNamesINI = ac.getFolder(ac.FolderID.Root)    .. "\\content\\tracks\\" .. ac.getTrackFullID('\\') .. "\\data\\sections.ini"

local brdimg = ac.getFolder(ac.FolderID.ACApps)           .. "/lua/CustomLicenseTest/vis/border.png"
--local bandageIcon = ac.getFolder(ac.FolderID.Root)      .. "/content/gui/sessionRanking/currentLapBg.png"
local bandageIcon = ac.getFolder(ac.FolderID.ACApps)      .. "/lua/CustomLicenseTest/vis/currentLapBg.png"

local bronzeIcon = ac.getFolder(ac.FolderID.ACApps)       .. "/lua/CustomLicenseTest/vis/bronze.png"
local silverIcon = ac.getFolder(ac.FolderID.ACApps)       .. "/lua/CustomLicenseTest/vis/silver.png"
local goldIcon = ac.getFolder(ac.FolderID.ACApps)         .. "/lua/CustomLicenseTest/vis/gold.png"
local pepegaIcon = ac.getFolder(ac.FolderID.ACApps)       .. "/lua/CustomLicenseTest/vis/wheel.png"
local goldsilverbronze = ac.getFolder(ac.FolderID.ACApps) .. "/lua/CustomLicenseTest/vis/goldsliverbronze.png"

local exitpng = ac.getFolder(ac.FolderID.Root)            .. "/content/gui/endRace/exit_icon_OFF.png"
local restartpng = ac.getFolder(ac.FolderID.Root)         .. "/content/gui/endRace/restart_icon_OFF.png"
local nextpng = ac.getFolder(ac.FolderID.Root)            .. "/content/gui/raceControl/right_icon_OFF.png"
local prevpng = ac.getFolder(ac.FolderID.Root)            .. "/content/gui/raceControl/left_icon_OFF.png"
local nopng = ac.getFolder(ac.FolderID.Root)              .. "/content/gui/raceControl/session_0_OFF.png"
local countdownImg = ac.getFolder(ac.FolderID.ACApps)     .. "/lua/CustomLicenseTest/vis/countdown-stripes.png"

local basecolors = {
    ["white"]=rgbm.colors.white,
    ["black"]=rgbm.colors.black,
    ["blue"]=rgbm.colors.blue,
    ["red"]=rgbm.colors.red,
    ["green"]=rgbm.colors.green,
    ["aqua"]=rgbm.colors.aqua,
    ["transparent"] = rgbm(0, 0, 0, 0),
    ["silver"] = rgbm(0.75, 0.75, 0.75, 1),
    ["gray"] = rgbm(0.5, 0.5, 0.5, 1),
    ["maroon"] = rgbm(0.5, 0, 0, 1),
    ["purple"] = rgbm(0.5, 0, 0.5, 1),
    ["fuchsia"] = rgbm(1, 0, 1, 1),
    ["lime"] = rgbm(0, 1, 0, 1),
    ["olive"] = rgbm(0.5, 0.5, 0, 1),
    ["yellow"] = rgbm(1, 1, 0, 1),
    ["orange"] = rgbm(1, 0.5, 0, 1),
    ["navy"] = rgbm(0, 0, 0.5, 1),
    ["teal"] = rgbm(0, 0.5, 0.5, 1),
    ["cyan"] = rgbm(0, 0.5, 1, 1),
}

local isInside = false -- CheckIfInsideINOUT(CustomSects[currCustomSect][1], CustomSects[currCustomSect][2], currSplinePos)

local bRunning = false
local sMsg = ""
local Countdown = -1.0
local CountdownDone = false
local afterCountdown = -1.0
local sectorLength = 0.0
local alphaup =false
local autoalpha = 1.0
local AIturnedOff = false

-- local splittime = 0.0
local currentDeltaTime = 0.0
local rgbwhite = rgbm(1,1,1,1)


local timercurr = -1.0
local timerlast = -1.0
local timerlastlast = -1.0
local timerMsg = 0.0

local filesSects = {}
local filesMedals = {}
local CustomSects = {}
local MedalSects = {}
local RecordSects = {}
local SectionNames = {}
local AboutSect = {}
local recordTrackSects = {}

local timeData = {}
local timeDataRecord = {}

local BIdeal={}
local BLeft={}
local BRight={}
local BLeftleft={}
local BRightright={}
local BRoll={}
local BDir={}
local BDirdir={}
local BPartIdeal={}
local BPartL={}
local BPartR={}
local BCenter={}

local lastCarPos = vec3(0,0,0)
local currPos = vec3(0,0,0)
local axisX  = vec3(1, 0, 0)
local axisZ  = vec3(0, 1, 0)
local axisY  = vec3(0, 0, 1)
-- local axisXm  = vec3(-1, 0, 0)
-- local axisZm  = vec3(0, -1, 0)
-- local axisYm  = vec3(0, 0, -1)

local doTime = false
local doTimeAI = false
local doEdit = false

local editS = 0.0 --$number
local editF = 1.0 --$number
local editSL = 0.0 --$number
local editFL = 1.0 --$number
local editname = ""
local editdesc = ""
local editinfo = ""
local editcolor = rgbm.colors.white
local editrollingS = 1
local editrollingF = 1

local currentFileID = 1
local INIrecords = ""
local record = 0.0 --@number?
local defsection = ""
local defmedal = ""
local medalExtid = ""
local currActiveSection = -1
local currSelectedSection = -1
local lastSelectedSection = -2

local borderAdd = 1.0/sim.trackLengthM -- one meter

local crossedIN = false
local crossedOUT = false
-- local splineposlast = 0.0



local function CheckIfInsideINOUTsimple(pin, pout, splinepos)
    -------------oldversion----------------
    if pout<=pin or pout-pin==1.0 then
        -- from end of track, wrapping over to start of track/next lap
        if splinepos>=pin then return true
        elseif splinepos<=pout-borderDist then return true end
    else
        -- normal section has to be inside those two bounds
        if splinepos<=pout-borderDist then return true end
    end
    return false
end


local function CheckIfInsideINOUT(pin, pout, splinepos)
    if pout<pin then
        -- from end of track, wrapping over to start of track/next lap
        if splinepos>pin then
            return true
        elseif splinepos<pout then
            return true
        end
    else
        -- normal section has to be inside those two bounds
        if splinepos>=pin and splinepos<pout then
            return true
        end
    end
    return false
end




local function GetMetersToSplinePoint(cSplineFr, cSplineTo)
    local p = ac.trackProgressToWorldCoordinate(cSplineFr)
    local pL = p
    if cSplineFr==1.0 then cSplineFr=0.0 end
    local cCurr = cSplineFr + borderAdd
    local cMax = cSplineTo
    local dist = 0.0
    if cSplineFr>cSplineTo then
        cMax=1.0
    end
    while cCurr<cMax do
        p = ac.trackProgressToWorldCoordinate(cCurr)
        dist = dist + p:distance(pL)
        pL = p
        cCurr = cCurr + borderAdd
    end
    if cSplineFr>cSplineTo then
        cCurr=0
        while cCurr<=cSplineTo do
            p = ac.trackProgressToWorldCoordinate(cCurr)
            dist = dist + p:distance(pL)
            pL = p
            cCurr = cCurr + borderAdd
        end
    end
    return dist
end




local function SetGatePostsS(cSpline)
    if car~=nil and BLeft~=nil then
        if #BLeft>0 then
            if cSpline<0.0 then cSpline = 1.0 + cSpline end
            if cSpline>1.0 then cSpline = 2.0 - cSpline end
            local currID = math.round(cSpline * #BLeft)
            if currID>0 and currID<#BDir and currID<#BLeft then
                -- ac.debug("currIDx", currID)
                -- ac.debug("currID0", "-")
                GateSF:setVisible(true        ):setPosition(BCenter[currID]):setRotation(axisX, BRoll[currID]):setRotation(axisZ, BDir[currID])
                GateConeStartL:setVisible(true):setPosition( BLeft[currID]):setRotation(axisZ, BDir[currID])
                GateConeStartR:setVisible(true):setPosition( BRight[currID]):setRotation(axisZ, BDir[currID])
            else
                -- ac.debug("currIDx", "-")
                -- ac.debug("currID0", currID)
                GateSF:setVisible(true        ):setPosition(BCenter[#BCenter]):setRotation(axisX, BRoll[#BCenter]):setRotation(axisZ, BDir[#BCenter])
                GateConeStartL:setVisible(true):setPosition( BLeft [#BCenter]):setRotation(axisZ, BDir [#BCenter])
                GateConeStartR:setVisible(true):setPosition( BRight[#BCenter]):setRotation(axisZ, BDir [#BCenter])
            end
        end
    end
end

local function SetGatePostsF(cSpline)
    if BLeft~=nil then
        if #BLeft>0 then
            --ac.debug('cames',1)
            if cSpline<0.0 then cSpline = 1.0 + cSpline end
            if cSpline>1.0 then cSpline = 2.0 - cSpline end
            local currID = math.floor(cSpline * #BLeft)
            if currID>0 and currID<#BDir and currID<#BLeft then
                GateSF:setVisible(true        ):setPosition(BCenter[currID]):setRotation(axisX, BRoll[currID]):setRotation(axisZ, BDir[currID])
                GateConeFinishL:setVisible(true):setPosition( BLeft[currID] ):setRotation(axisZ, BDir[currID])
                GateConeFinishR:setVisible(true):setPosition( BRight[currID]):setRotation(axisZ, BDir[currID])
            else
                GateSF:setVisible(true        ):setPosition(BCenter[#BCenter]):setRotation(axisX, BRoll[#BCenter]):setRotation(axisZ, BDir[#BCenter])
                GateConeFinishL:setVisible(true):setPosition( BLeft [#BLeft ]):setRotation(axisZ, BDir[#BLeft ])
                GateConeFinishR:setVisible(true):setPosition( BRight[#BRight]):setRotation(axisZ, BDir[#BRight])
            end
        end
    end
end



local function JumpToSplinePoint(cSpline)
    if cSpline<0.0 then cSpline = 1.0 + cSpline end
    if cSpline>1.0 then cSpline = 2.0 - cSpline end
    local currID = math.floor(cSpline * #BLeft)
    local p1 = ac.trackProgressToWorldCoordinate(cSpline)
    local p2 = vec3(0,0,0)
    if cSpline + 1.0/sim.trackLengthM > 1.0 then
        p2 = ac.trackProgressToWorldCoordinate(          1.0/sim.trackLengthM)
    else
        p2 = ac.trackProgressToWorldCoordinate(cSpline + 1.0/sim.trackLengthM)
    end
    ffbTimer = 0.25
    lastFFB = car.ffbMultiplier
    ac.setFFBMultiplier(0)
    -- set new car position
    local direction = vec3(p1.x-p2.x,p1.y-p2.y,p1.z-p2.z)
    physics.setCarPosition(0, p1, direction)
    if currID>#BDir then
        currID=1
    end
    if currID>0 and currID<#BDir and currID<#BLeft then
    GateSF:setVisible(true)
          :setPosition(BCenter[currID])
          :setRotation(axisX, BRoll[currID])
          :setRotation(axisZ, BDir[currID])
        else
            GateSF:setVisible(true)
                  :setPosition(BCenter[1])
                  :setRotation(axisX, BRoll[1])
                  :setRotation(axisZ, BDir[1])
    end
    -- if bRunning then
    -- else
    -- GateSF:setVisible(false)
    -- GateConeStartL:setVisible(false)
    -- GateConeStartR:setVisible(false)
    -- end

    -- GateStartL:setPosition( BLeft[currID] - axisZ * gap):setRotation(axisZ, BDir[currID])
    --physics.setCarPosition(0, p1, BDir[currID])
end



local function CrossedFinishSector(carID, timer)
    crossedOUT = true
    isInside = false
    -- bRunning = false
    -- HandleSplinePos(CustomSects[currCustomSect][2])
end


local function CrossedStartSector(carID, timer)
    -- if CustomSects[currCustomSect][7]==0 then
    -- end
    isInside = true
    bRunning = true
    Countdown = -1.0
    afterCountdown = 1.0
    timercurr = 0.0
    crossedIN = true
    SetGatePostsF(CustomSects[currActiveSection][2])

    -- set Finish callback
    --ac.debug("waiting for end", CustomSects[currCustomSect][2])
    -- ac.onTrackPointCrossed(0, CustomSects[currCustomSect][2], CrossedFinishSector)
end



local function LoadMedalsIni(sectINI)
    -- [SECTOR_0]
    -- gold=106000
    -- silver=107000
    -- bronze=108000
    --ac.debug('medalsINI', sectINI)
    for i,v in pairs(CustomSects) do
        MedalSects[i][0] = -1
        MedalSects[i][1] = -1
        MedalSects[i][2] = -1
    end
    -- ac.debug('medalsINI', sectINI)
    if not io.fileExists(sectINI) then
        ac.debug('medalsINI not found', sectINI:lower():replace((ac.getFolder(ac.FolderID.Root).."\\apps\\lua\\customLicensetest\\"):lower(),''))
    else
        -- ac.debug('medalsINI not found', "false")
        for i,v in pairs(CustomSects) do
            local sectName = "SECTOR_"..tostring(i-1)
            local gold   = tonumber( readACConfig(sectINI, sectName, "gold"  , "-1") )
            local silver = tonumber( readACConfig(sectINI, sectName, "silver", "-1") )
            local bronze = tonumber( readACConfig(sectINI, sectName, "bronze", "-1") )
            if gold > 1.0 and silver>1.0 and bronze>1.0 then
                MedalSects[i][0] = gold
                MedalSects[i][1] = silver
                MedalSects[i][2] = bronze
            end
            --ac.debug("MedalSects"..i, MedalSects[i])
        end
    end
end

local function LoadCustomSectionsIni(sectINI)
    -- [ABOUT]
    -- author=leBluem
    -- name=Nordschleife GT7 license tests
    -- version=0.1
    -- description=
    -- [SECTOR_0]
    -- text=Sector 1
    -- in=0.20
    -- out=0.25
    -- color=white
    -- desc=desc
    -- info=info
    table.clear(CustomSects)
    table.clear(MedalSects)
    table.clear(AboutSect)
    table.clear(RecordSects)

    local s = ac.getTrackName()
    if s=="" then s=ac.getTrackID() end
    local a=""  --   tostring(car:driverName())
    local n=""  --   s .. " generic Sector Challenge"
    local v=""  --   "1.0"
    local d=""  --   "auto generated"
    if not io.fileExists(sectINI) then
        ac.debug('sectINI not found', sectINI:lower():replace((ac.getFolder(ac.FolderID.Root).."\\apps\\lua\\customLicensetest\\"):lower(),''))
        table.insert(AboutSect, {[0]=a, [1]=n, [2]=v, [3]=d})
    else
        a=tostring(readACConfig(sectINI, "ABOUT", "author", ""))
        n=tostring(readACConfig(sectINI, "ABOUT", "name", ""))
        v=tostring(readACConfig(sectINI, "ABOUT", "version", ""))
        d=tostring(readACConfig(sectINI, "ABOUT", "description", ""))
        table.insert(AboutSect, {[0]=a, [1]=n, [2]=v, [3]=d})
        local i = 0
        local sectName = "SECTOR_"..i
        local sectText = readACConfig(sectINI, sectName, "name", "")
        --while sectText ~= "" do
        while i<100 do
            if sectText ~= "" then
                local sectIN = tonumber ( readACConfig(sectINI, sectName, "in", "-1") )
                local sectOUT = tonumber ( readACConfig(sectINI, sectName, "out", "-1") )
                local desc = tostring ( readACConfig(sectINI, sectName, "description", "") )
                local info = tostring ( readACConfig(sectINI, sectName, "info", "") )
                local colorS = tostring ( readACConfig(sectINI, sectName, "color", "white") ):lower():replace(' ', '')
                local rollingS = tonumber ( readACConfig(sectINI, sectName, "rollingstart", 1) )
                local rollingF = tonumber ( readACConfig(sectINI, sectName, "rollingfinish", 1) )
                local color = rgbm.colors.white
                if string.match(stringify(basecolors), colorS) ~= nil then
                    color = basecolors[colorS]
                elseif string.match(stringify(colorS), ',') ~= nil then
                    local col = string.split(colorS,',')
                    color = rgbm(tonumber(col[1]/255), tonumber(col[2]/255), tonumber(col[3]/255), 1)
                end
                if sectIN>-1 and sectOUT>-1 then
                    if sectIN==1.0 then sectIN=0.0 end
                    table.insert(CustomSects, {[0]=sectText, [1]=sectIN, [2]=sectOUT, [3]=desc, [4]=info, [5]=color, [6]=rollingS, [7]=rollingF})
                    table.insert(MedalSects, {[0]=-1.0, [1]=-1.0, [2]=-1.0})
                    local rec = tonumber ( readACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..(i), "TIME", "-1") )
                    table.insert(RecordSects, rec)
                end
            end
            i=i+1
            sectName = "SECTOR_"..i
            sectText = readACConfig(sectINI, sectName, "name", "")
        end
    end
end




local function LoadSectionFile()
    LoadCustomSectionsIni(filesSects[currentFileID])
    LoadMedalsIni(filesMedals[currentFileID])
    -- ac.debug("filesSects", #filesSects)
    -- ac.debug("filesMedals", #filesMedals)
    -- ac.debug("INI records Section", recordTrackSects[currentFileID]..'SECTOR_'..currHoverSect-1)
    -- ac.debug('INIrecords', INIrecords)
    -- ac.debug('#CustomSects', #CustomSects)
    -- ac.debug('#MedalSects', #MedalSects)
    -- ac.debug("#filesSects", #filesSects)
    -- ac.debug("f1", dirdataSections..filesSects[currentFileID])
    -- ac.debug("f2", filesMedals[currentFileID])
    -- ac.debug("currentFileID", currentFileID)
    -- ac.debug("record", record)
    -- ac.debug("currCustomSect", currCustomSect)
end


local function LoadFilenames()
    table.clear(filesSects)
    --table.clear(RecordSects)
    table.clear(filesMedals)
    table.clear(recordTrackSects)
    if ac.hasTrackSpline() then
        if not io.dirExists(dirdataPB)       then io.createDir(dirdataPB) end
        if not io.dirExists(dirdataSections) then io.createDir(dirdataSections) end
        if not io.dirExists(dirdataMedals)   then io.createDir(dirdataMedals) end
        INIrecords  = dirdataPB..sCar..".ini"
        if sLayout == "" then
            defsection  = sTrack
            defmedal    = sTrack .. "_" .. sCar
            filesSects = io.scanDir(dirdataSections, sTrack.."*.ini")
        else
            defsection  = sTrack .. "_" .. sLayout
            defmedal    = sTrack .. "_" .. sLayout .. "_" .. sCar
            filesSects = io.scanDir(dirdataSections, sTrack.."_"..sLayout.."*.ini")
        end

        if string.match(stringify(filesSects), defsection..'.ini') == nil then
            table.insert(filesSects, 1, defsection..'.ini')
            table.insert(RecordSects, -1)
        end

        dirdataSections = string.lower(dirdataSections)
        dirdataMedals = string.lower(dirdataMedals)

        if #filesSects>0 then
            for i, v in pairs(filesSects) do
                filesSects[i] = string.lower(filesSects[i])

                medalExtid = string.replace(filesSects[i], dirdataSections, dirdataMedals)
                medalExtid = string.replace(medalExtid, '.ini', '')
                medalExtid = string.replace(medalExtid, string.lower(ac.getTrackFullID('_')), '')
                medalExtid = string.replace(medalExtid, '_','')

                local medalExtid_short = "_"
                if medalExtid~="" then
                    medalExtid_short = "_" .. medalExtid .. "_"
                    medalExtid = (dirdataMedals..defmedal):replace(defmedal,'') .. defsection..'_' ..medalExtid.. '_'..sCar..'.ini'
                else
                    medalExtid = (dirdataMedals..defmedal):replace(defmedal,'') .. defsection..'_'..sCar..'.ini'
                end
                filesSects[i] = dirdataSections .. filesSects[i]
                local recordTrackSection = ""
                if sLayout == "" then
                    recordTrackSection = sTrack              ..medalExtid_short
                else
                    recordTrackSection = sTrack.."_"..sLayout..medalExtid_short
                end
                table.insert(filesMedals, medalExtid)
                table.insert(recordTrackSects, recordTrackSection)
            end
            LoadSectionFile()
        end
    end
end


local function JumpCustomSection(cSpline)
    if car ~= nil then
        local p1 = ac.trackProgressToWorldCoordinate(cSpline)
        local p3 = p1
        local p2 = p3
        local dist = 0.0
        local cSpline2 = cSpline

        -- writeACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currCustomSect-1, "TIME", tostring(math.round(record,3)))
        -- writeACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currCustomSect-1, "DATA", s)
        --if record<=0.0 and timerlastlast<=0.0 then
            record     = tonumber ( readACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currActiveSection-1, "TIME", "-1.0") )
            table.clear(timeDataRecord)

            --local data --@serializable table
            local data = readACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currActiveSection-1, "DATA", "")
            -- timeDataRecord = JSON.parse(data)
            local s=data:replace('{{',''):replace('}}','')
            s=data:replace('{{',''):replace('}}','')
            local ss = string.split(s,'},{')
            if #ss>2 then
                for i,sss in pairs(ss) do
                    local ssss = string.split(sss,',')
                    table.insert(timeDataRecord, i, {[0]=tonumber(ssss[1]), [1]=tonumber(ssss[2])})
                end
            end
        --end


        -- ac.debug("readcount", readcount)
        -- ac.debug("readcount str1", recordTrackSects[currentFileID])
        -- ac.debug("readcount str2", 'SECTOR_'..currCustomSect-1)
        -- ac.debug("record", record)
        -- ac.debug("timeDataRecord", #timeDataRecord)



        sectorLength = math.round(GetMetersToSplinePoint(CustomSects[currActiveSection][1], CustomSects[currActiveSection][2]))
        physics.setCarAutopilot(false, false)

        if sim.cameraMode == ac.CameraMode.Track then
            --ac.setCurrentCamera(lastCamera)
        end

        -- wind back spline pos some meters for the car
        local windbackdist = 5
        if CustomSects[currActiveSection][6]==1 then
            windbackdist = metersToRewind
        end
        if bABtrack and CustomSects[currActiveSection][1] < 1/sim.trackLengthM then
            windbackdist = 1
            cSpline2 = 0.0
        end
        --ac.debug("windbackdist", windbackdist)
        cSpline2 = cSpline
        if windbackdist>0 then
            while dist<=windbackdist and dist<sim.trackLengthM do
                cSpline2 = cSpline2 - 1/sim.trackLengthM
                if cSpline2<0.0 then
                    if bABtrack then
                        cSpline2 = 0.0
                        dist=windbackdist*2
                        p3 = ac.trackProgressToWorldCoordinate(1/sim.trackLengthM)
                        --p3 = p2
                        break
                    else
                        cSpline2 = 1.0
                    end
                end
                p3 = p2
                p2 = ac.trackProgressToWorldCoordinate(cSpline2)
                dist = p1:distance(p2)
            end
            -- set new car position
            if dist>0.0 then
                --ac.debug("set ", windbackdist)
                ffbTimer = 0.25
                lastFFB = car.ffbMultiplier
                ac.setFFBMultiplier(0)

                lastCarPos = currPos --  p2
                splineposlast=cSpline2
                crossedIN = false
                crossedOUT = false
                local direction = vec3(p2.x-p3.x,p2.y-p3.y,p2.z-p3.z)
                physics.setCarPosition(0, p2, direction)

                if CustomSects[currActiveSection][6]==1 then
                    pushseconds = pushsecondstoadd*1.5
                end

            end
        end

        p3 = p1
        p2 = p3
        cSpline2 = cSpline
        dist = 0.0
        -- wind 1m back for gate posts
        while dist<=1.0 and dist<sim.trackLengthM do
            cSpline2 = cSpline2 - 1/sim.trackLengthM
            if cSpline2<0.0 then
                cSpline2 = 1.0
            end
            p3 = p2
            p2 = ac.trackProgressToWorldCoordinate(cSpline2)
            dist = dist + p1:distance(p2)
        end

        if dist>0.0 then
            SetGatePostsS(CustomSects[currActiveSection][1])
            SetGatePostsF(CustomSects[currActiveSection][2])
            -- local id = currCustomSect + 3
            -- if id>#BCenter then id=1 end
            -- GateSF:setPosition(BCenter[id]):setRotation(axisZ, BDir[currCustomSect])
            local id = math.floor(CustomSects[currActiveSection][1]*#BIdeal) + 1
            if id>#BIdeal then id=1 end
            if id==0 then id=1 end
            GateSF:setVisible(true)
            GateSF:setPosition(BCenter[id]):setRotation(axisX, BRoll[id]):setRotation(axisZ, BDir[id])
            --SetGatePosts(cSpline2+borderDist*2)
        end


        if CustomSects[currActiveSection][6]==1 then
            -- rolling start
            Countdown = -1.0
            CountdownDone = false
        else
            -- standing start
            timercurr = 0.0
            bRunning = true
            Countdown = 3.0
            CountdownDone = false
            if bAudio then BeepCountdown:play() end
        end
        if currActiveSection>-1 then
            doTime = true
            timercurr = 0.0
            timerlast = -1.0
            bRunning = false
            table.clear(timeData)
        end
        -- CountdownDone=false
        -- Countdown=-1

        AIturnedOff = true
        if CustomSects[currActiveSection][6]==1 or doTimeAI then
            physics.setCarAutopilot(true, false)
            AIturnedOff = false
        end
        isInside = false

        -- set Start callback
        -- ac.debug("waiting for start", CustomSects[currCustomSect][1])
        -- ac.onTrackPointCrossed(0, CustomSects[currCustomSect][1], CrossedStartSector)

    end
end

local function HandleSplinePos(dt)
    -- local currSplinePos = car.splinePosition
    -- isInside = CheckIfInsideINOUT(CustomSects[currCustomSect][1], CustomSects[currCustomSect][2], currSplinePos)

    if isInside and not crossedIN then   --  not bRunning then
        CrossedStartSector()

    -- elseif not crossedOUT and not isInside then
    --     CrossedFinishSector()

    elseif not crossedOUT and isInside then
        timercurr = timercurr + dt
        timerMsg = 2.0
        Countdown = -1.0
        sMsg = ""
        if not bRunning then
            bRunning = true
        end
        if car.isAIControlled and not AIturnedOff then
            if not doTimeAI then
                AIturnedOff = true
                physics.setCarAutopilot(false, false)
            end
            --sMsg = "AI disabled :=)"
            --sMsg = "Go!"
        end
        if car.speedKmh<=1.0 then
            -- reset when too slow
            sMsg = "You got too slow!"
            timerMsg = 2.0
            JumpCustomSection(CustomSects[currActiveSection][1])

        elseif car.wheelsOutside>2 then
            -- reset when cutting track
            sMsg = "You cut the track!"
            timerMsg = 2.0
            JumpCustomSection(CustomSects[currActiveSection][1])

        -- elseif car.collidedWith(0) then
        --     -- reset when cutting track
        --     sMsg = "Collision detected!"
        --     timerMsg = 2.0
        --     JumpCustomSection(CustomSects[currCustomSect][1])
        end

        -- ac.debug("eeeeekkkkkk", #timeDataRecord)
        -- ac.debug("eeeeekkkkkk2", #timeData)

        currPos = ac.trackProgressToWorldCoordinate(currSplinePos)
        if lastCarPos:distance(currPos)>=10.0 then
            lastCarPos = currPos
            if currSplinePos<=CustomSects[currActiveSection][2] then
                table.insert(timeData, {[0]=math.round(currSplinePos,6), [1]=math.round(timercurr,3)})
            end

            -- split time calc
            local spid = 1
            while spid<#timeDataRecord do
                if timeDataRecord[spid][0]>currSplinePos then break end
                spid=spid+1
            end
            if spid<#timeDataRecord then
                if spid>1 then
                    -- Interpolation
                    local bestLapDeltaPos  = timeDataRecord[spid][0] - timeDataRecord[spid-1][0]
                    local bestLapDeltaTime = timeDataRecord[spid][1] - timeDataRecord[spid-1][1]
                    local currentDeltaPos  = currSplinePos - timeDataRecord[spid-1][0]
                    local currentDT = currentDeltaPos*bestLapDeltaTime/bestLapDeltaPos
                    currentDeltaTime = (timercurr - timeDataRecord[spid-1][1] - currentDT)
                end
                -- simple, not displayed/active
                -- splittime = timercurr - timeDataRecord[spid][1]
            end
        end

    elseif bRunning then -- and not inside

        if timerlast<=0.0 and timercurr~=0.0 then

            -- section timer done
            if bAudio then Beep:play() end

            timerlast = timercurr
            timerlastlast = timercurr
            crossedOUT = true
            isInside = false
            --CrossedFinishSector()

            if doTimeAI then
                -- save ai time

                local offset =1.0
                if CustomSects[currActiveSection][2]>CustomSects[currActiveSection][1] then
                    offset = timercurr * aimedaloffset
                end
                writeACConfig(filesMedals[currentFileID], 'SECTOR_'..tostring(currActiveSection-1), "gold"  , tostring(math.round(timercurr-offset,3)))
                writeACConfig(filesMedals[currentFileID], 'SECTOR_'..tostring(currActiveSection-1), "silver", tostring(math.round(timercurr,3)))
                writeACConfig(filesMedals[currentFileID], 'SECTOR_'..tostring(currActiveSection-1), "bronze", tostring(math.round(timercurr+offset*2,3)))
                MedalSects[currActiveSection][0] = timercurr-offset
                MedalSects[currActiveSection][1] = timercurr
                MedalSects[currActiveSection][2] = timercurr+offset*2

                -- goto next not medal'ed section
                for i,v in pairs(CustomSects) do
                    if i>currActiveSection and MedalSects[i][0]<=0.0 then
                        doTimeAI = true
                        doTime = true
                        currActiveSection = i
                        timerlast = -1.0
                        timerlastlast = -1.0
                        --- do next undone Medal
                        JumpCustomSection(CustomSects[currActiveSection][1])
                        return
                    end
                end

                -- reset to overview menu
                --ac.setCurrentCamera(lastCamera)
                doTimeAI = false
                doTime = false
                currActiveSection = -1
                timerlastlast = -1.0

                --LoadSectionFile()
                --LoadMedalsIni(filesMedals[currentFileID])
                -- LoadCustomSectionsIni(filesSects[currentFileID])
                ---LoadFilenames()

                ac.setWindowOpen("main", true)
                ac.setWindowOpen("WinTiming", false)
                ac.setWindowOpen("WinEdit", false)


            elseif doTime then

                -- sector finished by player --

                if timercurr>1.0 and (timercurr<record or record <= 0.0) then
                    -- save player record
                    local recordlast = record
                    record = timercurr
                    if timeData[#timeData][0]~=CustomSects[currActiveSection][1] then
                        table.insert(timeData, {[0]=math.round(CustomSects[currActiveSection][1],6), [1]=math.round(record,3)})
                    end
                    --timeDataRecord = timeData

                    local s = stringify(timeData, true, 100000)
                    ---- :replace('{{','[('):replace('}}',')]'):replace('},{','), (')
                    writeACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currActiveSection-1, "TIME", tostring(math.round(record,3)))
                    writeACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currActiveSection-1, "DATA", s)
                    -- make sure new record is read
                    -- record=-1
                    -- timerlastlast=-1

                    sMsg = "New Record!"
                    if     record<=MedalSects[currActiveSection][0]  then
                        if (recordlast>MedalSects[currActiveSection][0] or recordlast<=0.0 ) then
                            sMsg = sMsg .. " You got the Gold Medal!"
                        else
                            sMsg = sMsg .. " And still Gold!"
                        end
                    elseif record<=MedalSects[currActiveSection][1] then
                        if (recordlast>MedalSects[currActiveSection][1] or recordlast<=0.0 ) then
                            sMsg = sMsg .. " You got the Silver Medal!"
                        else
                            sMsg = sMsg .. " But still Silver!"
                        end
                    elseif record<=MedalSects[currActiveSection][2] then
                        if (recordlast>MedalSects[currActiveSection][2] or recordlast<=0.0) then
                            sMsg = sMsg .. " You got the Bronze Medal!"
                        else
                            sMsg = sMsg .. " But still Bronze!"
                        end
                    end

                    -- LoadCustomSectionsIni(filesSects[currentFileID])
                    -- LoadMedalsIni(filesMedals[currentFileID])
                    --LoadSectionFile()
                    --LoadMedalsIni(filesMedals[currentFileID])
                    LoadFilenames()
                    if bAudio then BeepFL:play() end

                else
                    sMsg = "Finished"
                    if     timercurr<=MedalSects[currActiveSection][0]  then
                        sMsg = sMsg .. " with Gold Time again."
                    elseif timercurr<=MedalSects[currActiveSection][1] then
                        sMsg = sMsg .. " with Silver Time again."
                    elseif timercurr<=MedalSects[currActiveSection][2] then
                        sMsg = sMsg .. " with Bronze Time again."
                    else
                        sMsg = sMsg.."."
                    end
                end

                aclogo:setVisible(true):setRotation(axisZ, math.rad(0))
                aclogo:findMeshes("acglass"):setMaterialProperty('ksEmissive', rgb.colors.white*0.6)
                aclogo:findMeshes("acglass"):setVisible(true)
                if     timercurr <= MedalSects[currActiveSection][0] then
                    aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {255,203,104} ):setMaterialProperty('ksEmissive', rgb(1,0.8,0.5)*0.35)
                elseif timercurr <= MedalSects[currActiveSection][1] then
                    aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {214,219,224} ):setMaterialProperty('ksEmissive', rgb(0.9,0.91,0.95)*0.25)
                elseif timercurr <= MedalSects[currActiveSection][2] then
                    aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {225,153,106} ):setMaterialProperty('ksEmissive', rgb(0.85,0.6,0.4)*0.25)
                else
                    aclogo:findMeshes("acglass"):setVisible(false)
                    aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {128,128,128} )
                end

                doTimeAI = false
                doTime = false
                timerMsg = 5.0
                afterRace = 5.0

                ffbTimer = 0.25
                lastFFB = car.ffbMultiplier
                ac.setFFBMultiplier(0)
                physics.setCarAutopilot(true, false)

                -- auto restart when timerMsg < 0.0 further above
                -- JumpCustomSection(CustomSects[currCustomSect][1])
            end
        end
    end
    -- CustomSects([0]=sectText, [1]=sectIN, [2]=sectOUT
    -- MedalSects[0]=gold, [1]=silver, [2]=bronze)
end






ui.setAsynchronousImagesLoading(false)


local function UpdateOverlayMap()
    mapOverlay:update(function (dt)
        if partoffset>1 and partoffset<=#BPartL then
            -- small ai line
            -- ui.drawLine(
            --     vec2(BPartIdeal[partoffset  ].x, BPartIdeal[partoffset  ].y),
            --     vec2(BPartIdeal[partoffset-1].x, BPartIdeal[partoffset-1].y),
            --     rgbm(1,0.1,0.1,10), 5)

            -- draw wide over the track
            ui.drawQuadFilled(
                vec2(BPartL[partoffset  ].x, BPartL[partoffset  ].y),
                vec2(BPartR[partoffset  ].x, BPartR[partoffset  ].y),
                vec2(BPartR[partoffset-1].x, BPartR[partoffset-1].y),
                vec2(BPartL[partoffset-1].x, BPartL[partoffset-1].y),
                rgbm(1,0.5,0.5,0.65))
        end
    end)
    partoffset = partoffset+1
    if partoffset>#BPartIdeal then
        partoffset = 1
    end
end



local function MakeTrackPreviewImage()
    partoffset = 1
    mapOverlay:clear(rgbm.colors.transparent)
    mapZoomed
        :clear(colInactive2)
        :update(function (dt)

        sectorLength = math.round(GetMetersToSplinePoint(CustomSects[currSelectedSection][1], CustomSects[currSelectedSection][2]))

        -- ac.perfBegin("createPreview")
        --ac.debug("calulating length", "...")
        --ac.debug("calulating length result", sectorLength)

        BPartL = {}
        BPartR = {}
        BPartIdeal = {}

        if math.abs(CustomSects[currSelectedSection][2]-1) == CustomSects[currSelectedSection][1] then previewMapLeadinMeters=1 else previewMapLeadinMeters=previewMapLeadinMetersDefault end
        if bABtrack then
            previewMapLeadinMeters = 1
        end
        local ist, iend = math.floor(CustomSects[currSelectedSection][1]*#BIdeal), math.floor(CustomSects[currSelectedSection][2]*#BIdeal)
        local irun = math.floor(math.abs(iend-ist) + previewMapLeadinMeters/sim.trackLengthM*#BIdeal*2)
        if iend < ist then
            irun = math.floor(iend + (#BIdeal - ist) + previewMapLeadinMeters/sim.trackLengthM*#BIdeal*2)
        end
        if irun > #BIdeal then
            irun = #BIdeal
        end
        local icurr = math.floor(ist - previewMapLeadinMeters/sim.trackLengthM*#BIdeal)
        if icurr<0 then icurr = #BIdeal+icurr end
        if icurr==0 then icurr = #BIdeal end
        if icurr>=#BIdeal-1 then icurr = 1 end

        local minx, miny, maxx, maxy = 10000000,10000000,-10000000,-10000000
        local ic = 1
        while ic<=irun do
            if minx> BIdeal[icurr].x then minx= BIdeal[icurr].x end
            if maxx< BIdeal[icurr].x then maxx= BIdeal[icurr].x end
            if miny>-BIdeal[icurr].z then miny=-BIdeal[icurr].z end
            if maxy<-BIdeal[icurr].z then maxy=-BIdeal[icurr].z end
            ic=ic+1
            icurr=icurr+1
            if icurr>#BIdeal then icurr = 1 end
        end

        --- borrowed from "create_png" (map_display app by 'Never Eat Yellow Snow' APPS)
        local spreadx = math.max(maxx-minx, 100)
        local spready = math.max(maxy-miny, 100)
        local width  = png_size - png_mapoffset*2
        local height = png_size - png_mapoffset*2
        local mapscale = math.min((width - png_mapoffset) / spreadx, (height - png_mapoffset) / spready)
        local ocenterx = 0.5*(minx+maxx)
        local ocentery = 0.5*(miny+maxy)
        local loffset = 1.0
        local roffset = 1.0

        if true then
            -- set scaled values
            local coordsRL = vec2(0,0)
            local coordsLL = vec2(0,0)
            local coordsAI   = vec2(0,0)
            local coordsAIL  = vec2(0,0)
            local stDone = false
            local fiDone = false

            if math.abs(CustomSects[currSelectedSection][2]-1) == CustomSects[currSelectedSection][1] then previewMapLeadinMeters=1 else previewMapLeadinMeters=previewMapLeadinMetersDefault end
            if bABtrack then
                previewMapLeadinMeters = 1
            end
            ist, iend = math.floor(CustomSects[currSelectedSection][1]*#BIdeal), math.floor(CustomSects[currSelectedSection][2]*#BIdeal)
            irun = math.floor(math.abs(iend-ist) + previewMapLeadinMeters*2)
            if iend < ist then
                irun = math.floor(iend + (#BIdeal - ist) + previewMapLeadinMeters*2)
            end
            if irun > #BIdeal then
                irun = #BIdeal
            end
            icurr = math.floor(ist - previewMapLeadinMeters/sim.trackLengthM*#BIdeal)
            if icurr<0 then icurr = #BIdeal+icurr end
            if icurr==0 then icurr = #BIdeal end
            if icurr>=#BIdeal-1 then icurr = 1 end
            ic=1

            -- grid
            local igrid = 1
            local igride = png_size+1
            local iadd = math.max(8, math.floor( (128*mapscale) + ((128*mapscale) % 8) ))
            partoffsetadd = math.floor(math.max(1, ((128*1/mapscale) - (128*1/mapscale) % 32)/50))
            --ac.debug("partoffsetadd", partoffsetadd)
            ui.drawQuadFilled(
                vec2(0, 0),
                vec2(0, png_size),
                vec2(png_size, png_size),
                vec2(png_size, 0),
                colInactive)

            -- ac.debug("iadd", math.floor(math.fmod(png_size,iadd)/2) )
            igrid = math.floor(math.fmod(png_size,iadd)/2)
            while igrid<igride do
                ui.drawSimpleLine(vec2(1,igrid), vec2(png_size,igrid), colInactive, 1)
                ui.drawSimpleLine(vec2(igrid,1), vec2(igrid,png_size), colInactive, 1)
                igrid=igrid+iadd
            end

            while ic<=irun do
                local pl = BIdeal[icurr]
                local x = png_mapoffset + width/2  - (ocenterx - pl.x) * mapscale + math.cos((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale
                local y = png_mapoffset + height/2 + (ocentery + pl.z) * mapscale + math.sin((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale

                loffset = math.min(50, BLeftleft[icurr]        * math.max(1,1/mapscale/2) )
                roffset = math.min(50, BRightright[icurr]      * math.max(1,1/mapscale/2) )

                if ic>=previewMapLeadinMeters and not stDone then
                    loffset = loffset + 20
                    roffset = roffset + 20
                end
                if ic>=irun-previewMapLeadinMeters+1 and not fiDone then
                    loffset = loffset + 20
                    roffset = roffset + 20
                end

                x = png_mapoffset + width/2  - (ocenterx - pl.x) * mapscale + math.cos((-BDirdir[icurr] - 90) * math.pi / 180) * mapscale * loffset
                y = png_mapoffset + height/2 + (ocentery + pl.z) * mapscale + math.sin((-BDirdir[icurr] - 90) * math.pi / 180) * mapscale * loffset
                local coordsL    = vec2(x, y)
                x = png_mapoffset + width/2  - (ocenterx - pl.x) * mapscale + math.cos((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale * roffset
                y = png_mapoffset + height/2 + (ocentery + pl.z) * mapscale + math.sin((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale * roffset
                local coordsR    = vec2(x, y)
                coordsAI   = vec2(png_mapoffset + width/2  - (ocenterx - pl.x) * mapscale + math.cos((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale,
                                  png_mapoffset + height/2 + (ocentery + pl.z) * mapscale + math.sin((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale)

                if ic>=previewMapLeadinMeters and ic<=irun-previewMapLeadinMeters+partoffsetadd then
                    if ic>=previewMapLeadinMeters-partoffsetadd and not stDone then
                        stDone=true
                    end
                    if ic>=irun+previewMapLeadinMeters and not fiDone then
                        fiDone=true
                    end
                    if ic>partoffsetadd then
                    ui.drawQuadFilled(
                        vec2(coordsL.x , coordsL.y),
                        vec2(coordsR.x , coordsR.y),
                        vec2(coordsRL.x, coordsRL.y),
                        vec2(coordsLL.x, coordsLL.y),
                        rgbm.colors.white)
                    end
                    x = png_mapoffset + width/2  - (ocenterx - pl.x) * mapscale + math.cos((-BDirdir[icurr] - 90) * math.pi / 180) * mapscale * (loffset+20)
                    y = png_mapoffset + height/2 + (ocentery + pl.z) * mapscale + math.sin((-BDirdir[icurr] - 90) * math.pi / 180) * mapscale * (loffset+20)
                    table.insert(BPartL, vec2(x, y))
                    x = png_mapoffset + width/2  - (ocenterx - pl.x) * mapscale + math.cos((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale * (roffset+20)
                    y = png_mapoffset + height/2 + (ocentery + pl.z) * mapscale + math.sin((-BDirdir[icurr] + 90) * math.pi / 180) * mapscale * (roffset+20)
                    table.insert(BPartR, vec2(x, y))
                    table.insert(BPartIdeal, coordsAI)
                else
                    if ic>=irun-previewMapLeadinMeters-1 and not fiDone then
                        fiDone=true
                    end
                    if ic>1 then
                        if ic>previewMapLeadinMeters and ic<=irun-previewMapLeadinMeters+partoffsetadd*2 then
                            ui.drawQuadFilled(
                                vec2(coordsL.x , coordsL.y),
                                vec2(coordsR.x , coordsR.y),
                                vec2(coordsRL.x, coordsRL.y),
                                vec2(coordsLL.x, coordsLL.y),
                                rgbm.colors.white)
                        else
                            ui.drawQuadFilled(
                                vec2(coordsL.x , coordsL.y),
                                vec2(coordsR.x , coordsR.y),
                                vec2(coordsRL.x, coordsRL.y),
                                vec2(coordsLL.x, coordsLL.y),
                                rgbm.colors.gray)
                        end
                    end
                end

                ic=ic+math.max(1,partoffsetadd)
                icurr=icurr+math.max(1,partoffsetadd)
                if icurr>#BIdeal then
                    if bABtrack then
                        break
                    end
                    icurr = 1
                end

                coordsR:copyTo(coordsRL)
                coordsL:copyTo(coordsLL)
                coordsAI:copyTo(coordsAIL)

            end -- while end
        end
        --ac.perfEnd("createPreview")

    end) -- ExtraCanvas end
end




--------------------------------------------------------------------------------------------------------------------------------






---- from YokaiHUD
-- Convert a timestamp into racing format, like "1:42.556"
-- Probably not very efficent doing tostring and padding etc
local function laptime(timestamp)
    if (timestamp==nil or timestamp < 0) then
        return "--.---"
    elseif timestamp==0.0 then
        return "0:00.000"
    end

    --local function pad(n, z) z = z || 2; return ('00' + n).slice(-z); end
    local milliseconds = timestamp % 1000
    timestamp = (timestamp - milliseconds) / 1000
    local seconds = timestamp % 60
    timestamp = (timestamp - seconds) / 60
    local minutes = timestamp % 60
    local hours = (timestamp - minutes) / 60
    --local ms = tostring(milliseconds):pad(3, "0", -1)
    local ms = string.format("%03d", milliseconds)
    local ss = tostring(seconds):pad(2, "0", -1)
    local hh = tostring(hours):pad(2, "0", -1)
    if (hours > 0) then
        local mm = tostring(minutes):pad(1, "0", -1)
        return hh..":"..mm..":"..ss.."."..ms
    elseif (minutes > 0) then
        local mm = tostring(minutes):pad(1, "0", -1)
        return mm..":"..ss.."."..ms
    else
        local mm = tostring(minutes):pad(1, "0", -1)
        return mm..":"..ss.."."..ms
    end
end

local function delta(timestamp)
    if (timestamp==nil) then
        return "--.---"
    end
    return string.format("%+.3f", timestamp/1000.0)
end





local vUp = vec3(0, 1, 0)
local vDown = vec3(0, -1, 0)
local v1 = vec3()


local function snapToTrackSurface(pos, gap)
    local p = pos
    local v1 = vec3()
    physics.raycastTrack(v1:set(0, 10, 0):add(vec3(pos.x,pos.y+2.0,pos.z)), vDown, 20, p, vUp)
    p.y = p.y + gap
end




local function CreateBorders()
    if car ~= nil then
        BIdeal={}
        BLeftleft={}
        BRightright={}
        BLeft={}
        BRight={}
        BDir={}
        BRoll={}
        BDirdir={}
        BCenter={}
        local cSpline2 = 0
        local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
        local pE = ac.trackProgressToWorldCoordinate(1.0)
        bABtrack = p1:distance(pE) > 10
        local side = ac.getTrackAISplineSides(cSpline2)
        cSpline2 = brdDist/sim.trackLengthM
        local p2 = ac.trackProgressToWorldCoordinate(cSpline2)
        local c = 1
        while cSpline2 < 1.0 - brdDist/sim.trackLengthM do
            if c==1 then
                side = vec2(side.y, side.x)
                c=c+1
            end
            --dist = p1:distance(p2)
            --dist>=1.0 and
            --if p1~=p2 and p2.x~=0 and p2.y~=0 and p2.z~=0 then
            local dir = -math.deg( math.atan2(p1.z-p2.z, p1.x-p2.x) )
            local roll = -math.deg( math.atan2(p1.x-p2.x, p1.z-p2.z) )
            local xL = p1.x + math.cos((dir + 90) * math.pi / 180) * side.x*0.95
            local yL = p1.z - math.sin((dir + 90) * math.pi / 180) * side.x*0.95
            local xR = p1.x + math.cos((dir - 90) * math.pi / 180) * side.y*0.95
            local yR = p1.z - math.sin((dir - 90) * math.pi / 180) * side.y*0.95
            local zL = p1.y+0.5
            local zR = p1.y+0.5
            local p4 = vec3(xL, zL, yL)
            local p5 = vec3(xR, zR, yR)

            snapToTrackSurface(p4, -0.005)
            snapToTrackSurface(p5, -0.005)
            snapToTrackSurface(p1, 0.05)

            table.insert(BIdeal, p1)
            table.insert(BLeft, p4)
            table.insert(BRight, p5)
            table.insert(BLeftleft, side.x)
            table.insert(BRightright, side.y)
            table.insert(BDir, math.rad(dir-90))
            table.insert(BRoll, math.rad(roll-90))
            table.insert(BDirdir, dir)
            table.insert(BCenter, vec3((p4.x + p5.x)/2,(p4.y + p5.y)/2+0.1,(p4.z + p5.z)/2))

            p1:copyTo(p2)
            cSpline2 = cSpline2 + brdDist/sim.trackLengthM
            p1 = ac.trackProgressToWorldCoordinate(cSpline2)
            side = ac.getTrackAISplineSides(cSpline2)
        end -- while

        -- must interpolate first bc might be a strange distance from last
        BIdeal [1] = vec3((BIdeal [2].x+BIdeal [#BIdeal ].x)/2, (BIdeal [2].y+BIdeal [#BIdeal ].y)/2, (BIdeal [2].z+BIdeal [#BIdeal ].z)/2)
        BLeft  [1] = vec3((BLeft  [2].x+BLeft  [#BLeft  ].x)/2, (BLeft  [2].y+BLeft  [#BLeft  ].y)/2, (BLeft  [2].z+BLeft  [#BLeft  ].z)/2)
        BRight [1] = vec3((BRight [2].x+BRight [#BRight ].x)/2, (BRight [2].y+BRight [#BRight ].y)/2, (BRight [2].z+BRight [#BRight ].z)/2)
        BCenter[1] = vec3((BCenter[2].x+BCenter[#BCenter].x)/2, (BCenter[2].y+BCenter[#BCenter].y)/2, (BCenter[2].z+BCenter[#BCenter].z)/2)
    end
end





---------------------------------------------------------------------------------------------
local function DrawTextWithShadows(s, fntsize, algn, xy1, xy2, wrap, col)
    ui.setCursorX(0)
    ui.setCursorY(0)
    local xy3 = xy1
    local xy4 = xy2
    xy3.x=xy3.x-2
    xy3.y=xy3.y-2
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy3, xy4, wrap, rgbm.colors.black )
    xy3.x=xy3.x-1
    xy3.y=xy3.y-1
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy3, xy4, wrap, rgbm.colors.black )
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.dwriteTextAligned( s, fntsize, algn, xy1, xy2, wrap, col )
end
local function DrawTextACWithShadows(s, fntsize, xy1, xy2, col)
    ui.setCursorX(0)
    ui.setCursorY(0)
    local xy3 = xy1
    local xy4 = xy2
    xy3.x=xy3.x-2
    xy3.y=xy3.y-2
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.acText(s, vec2(math.floor(fntsize/2),fntsize), 0, rgbm.colors.black, 0, true)
    xy3.x=xy3.x-1
    xy3.y=xy3.y-1
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.acText(s, vec2(math.floor(fntsize/2),fntsize), 0, rgbm.colors.black, 0, true)
    ui.setCursorX(xy1.x)
    ui.setCursorY(xy1.y)
    ui.acText(s, vec2(math.floor(fntsize/2),fntsize), 0, col, 0, true)
    -- ui.dwriteTextAligned( s, fntsize, algn, xy1, xy2, wrap, col )
end






local function LoadSectionsIni(sectINI)
    -- [SECTION_0]
    -- IN=0.152
    -- OUT=0.190
    -- TEXT=T1
    SectionNames = {}
    if not io.fileExists(sectINI) then
        ac.debug('"sections.ini" not found:', sectINI:lower():replace((ac.getFolder(ac.FolderID.Root) ):lower(),''))
    else
        -- local i = 0
        -- local sectName = "SECTION_"..i
        -- local sectText = readACConfig(sectINI, sectName, "TEXT", "")
        -- while sectText ~= "" do
        --     local sectIN = tonumber ( readACConfig(sectINI, sectName, "IN", "-1") )
        --     local sectOUT = tonumber ( readACConfig(sectINI, sectName, "OUT", "-1") )
        --     if sectIN>-1 and sectOUT>-1 then
        --         table.insert(SectionNames, i, {[0]=sectText, [1]=sectIN, [2]=sectOUT})
        --     end
        --     i=i+1
        --     sectName = "SECTION_"..i
        --     sectText = readACConfig(sectINI, sectName, "TEXT", "")
        -- end

        local i = 0
        local j = 0
        local sectName = "SECTION_"..i
        local sectText = readACConfig(sectINI, sectName, "TEXT", "")
        local lastsectText = ""
        while sectText ~= "" do
            local sectIN = tonumber ( readACConfig(sectINI, sectName, "IN", "-1") )
            local sectOUT = tonumber ( readACConfig(sectINI, sectName, "OUT", "-1") )
            if sectIN>-1 and sectOUT>-1 then
                --ac.debug('a ' .. j, sectText)
                if lastsectText == sectText then
                    SectionNames[j-1][2] = sectOUT
                else
                    if j>0 and SectionNames[0][0] == sectText then
                        SectionNames[0][1] = sectIN
                    else
                        table.insert(SectionNames, j, {[0]=sectText, [1]=sectIN, [2]=sectOUT})
                        j=j+1
                        lastsectText = sectText
                    end
                end
            end
            i=i+1
            sectName = "SECTION_"..i
            sectText = readACConfig(sectINI, sectName, "TEXT", "")
        end

        -- make sure its sorted
        table.sort(SectionNames, function (a, b) return a[1] < b[1] end)
    end
end


local function GetSectionNamesFromTo(pin, pout)
    local ssd = ""
    local ssi = ""
    local c = 0
    if #SectionNames>0 then
        for j,v in pairs(SectionNames) do
            if CheckIfInsideINOUT(pin, pout, SectionNames[j][1]) or
               CheckIfInsideINOUT(pin, pout, SectionNames[j][2])
            -- if CheckIfInsideINOUTsimple(pin, pout, SectionNames[j][1]) or
            --    CheckIfInsideINOUTsimple(pin, pout, SectionNames[j][2])
            then
                c=c+1
                local sss = SectionNames[j][0]
                if ssi~="" then
                    ssi = ssi .. " " .. sss
                else
                    ssi = sss
                end
            end
        end
        ssd=c.." corners"
    else
        ssi="info"..(1)
        ssd="descr"..(1)
    end
    return ssd, ssi
end




local function iniManualSave(inifile)
    local f = io.open(inifile, "w")
    if f then
        f:write("[ABOUT]".."\n")
        f:write("author".."="..AboutSect[1][0].."\n")
        f:write("name".."="..AboutSect[1][1].."\n")
        f:write("version".."="..AboutSect[1][2].."\n")
        f:write("description".."="..AboutSect[1][3].."\n\n")
        for i, v in pairs(CustomSects) do
            local colorS = tostring(CustomSects[i][5]):replace("(rgb=(",""):replace("), mult=1)", "")
            local col = string.split(colorS,',')
            colorS = tostring(math.floor(col[1]*255)) .. ', ' ..
                     tostring(math.floor(col[2]*255)) .. ', ' ..
                     tostring(math.floor(col[3]*255))
            f:write("[SECTOR_"..(i-1).."]".."\n")
            -- [0]=editname, [1]=editS, [2]=editF,
            -- [3]=editdesc, [4]=editinfo, [5]=editcolor, [6]=editrollingS, [7]=editrollingF
            f:write("name"         .."="..CustomSects[i][0].."\n")
            f:write("in"           .."="..math.round(CustomSects[i][1], 6).."\n")
            f:write("out"          .."="..math.round(CustomSects[i][2], 6).."\n")
            f:write("description"  .."="..CustomSects[i][3].."\n")
            f:write("info"         .."="..CustomSects[i][4].."\n")
            f:write("color"        .."="..colorS.."\n")
            f:write("rollingstart" .."="..CustomSects[i][6].."\n")
            f:write("rollingfinish".."="..CustomSects[i][7].."\n\n")
        end
        f:close()
    end
end

function CreateRandomSections()
    local parts = 2
    if sim.trackLengthM>20000 then
        parts=12
    elseif sim.trackLengthM>15000 then
        parts=10
    elseif sim.trackLengthM>10000 then
        parts=8
    elseif sim.trackLengthM>5000 then
        parts=5
    elseif sim.trackLengthM>2500 then
        parts=4
    elseif sim.trackLengthM>1500 then
        parts=3
    end

    local s = ac.getTrackName()
    if s=="" then s=ac.getTrackID() end
    local drivername = ac.getCar(0):driverName()
    local drivernameshort = string.sub( drivername, 1, 3)

    local c = 1
    local lastnewini = filesSects[1]:replace('.ini', '')..'_'..drivernameshort
    local newini = lastnewini
    while io.fileExists(newini..'.ini') do
        newini = lastnewini..c..'.ini'
        c=c+1
    end

    AboutSect[1][0] = drivername
    AboutSect[1][1] = s .. " random Sector Challenge"..c
    AboutSect[1][2] = "1.0"
    AboutSect[1][3] = "auto generated"
    table.clear(CustomSects)
    table.clear(MedalSects)
    table.clear(RecordSects)
    table.insert(filesSects, #filesSects+1, newini..'.ini')

    local i=0
    local ssd = ""
    local ssi = ""
    local rndOffset = math.random(0,10000)/10000.0
    local pin  = rndOffset
    local pout = pin+1/parts
    while i<parts do
        ssd, ssi = GetSectionNamesFromTo(pin, pout)
        editname    = "Sector"..(i+1)
        editS       = math.round(pin,8)
        editF       = math.round(pout,8)
        editdesc    = ssd
        editinfo    = ssi
        editcolor   = rgbm.colors.white
        editrollingS = math.random( 2 )-1
        editrollingF = math.random( 2 )-1
        table.insert(CustomSects, {[0]=editname, [1]=editS, [2]=editF, [3]=editdesc, [4]=editinfo, [5]=editcolor, [6]=editrollingS, [7]=editrollingF})
        table.insert(MedalSects, {[0]=-1.0, [1]=-1.0, [2]=-1.0})
        table.insert(RecordSects, -1.0)
        i=i+1
        pin  = pout
        pout = pin+1/parts
        if pout>1.0 then pout = math.abs(1-pout) end
    end
    currentFileID = #filesSects
    iniManualSave(filesSects[currentFileID])
    LoadFilenames()
    currSelectedSection=1
end

function CreateGenericSections()
    local parts = 1
    if sim.trackLengthM>20000 then
        parts=10
    elseif sim.trackLengthM>15000 then
        parts=8
    elseif sim.trackLengthM>10000 then
        parts=6
    elseif sim.trackLengthM>5000 then
        parts=4
    elseif sim.trackLengthM>2500 then
        parts=3
    elseif sim.trackLengthM>1500 then
        parts=2
    end
    local s = ac.getTrackName()
    if s=="" then s=ac.getTrackID() end

    local drivername = ac.getCar(0):driverName()
    AboutSect[1][0] = drivername
    AboutSect[1][1] = s .. " generic Sector Challenge"
    AboutSect[1][2] = "1.0"
    AboutSect[1][3] = "auto generated"
    table.clear(CustomSects)

    local i=0
    local ssd = ""
    local ssi = ""
    while i<parts do
        local pin  = math.round(i    /parts, 6)
        local pout = math.round((i+1)/parts, 6)
        ssd, ssi = GetSectionNamesFromTo(pin, pout)
        editname    = "Sector"..(i+1)
        editS        = math.round(pin,6)
        editF        = math.round(pout,6)
        editrollingS = 1
        editrollingF = 1
        editdesc     = ssd
        editinfo     = ssi
        editcolor    = rgbm.colors.white
        table.insert(CustomSects, {[0]=editname, [1]=editS, [2]=editF, [3]=editdesc, [4]=editinfo, [5]=editcolor, [6]=editrollingS, [7]=editrollingF})
        table.insert(MedalSects, {[0]=-1.0, [1]=-1.0, [2]=-1.0})
        table.insert(RecordSects, -1.0)
        i=i+1
    end
    iniManualSave(filesSects[1])
    LoadFilenames()
    currSelectedSection=1
end











local function exitChallengeMode()
    ac.debug("undef break", "--")
    BeepCountdown:pause():setCurrentTime(0)
    currSelectedSection = currActiveSection
    currActiveSection = -1
    doTime=false
    doTimeAI=false
    bRunning=false
    ac.setWindowOpen("main", true)
    ac.setWindowOpen("WinEdit", false)
    ac.setWindowOpen("WinTiming", false)
    if car.speedKmh>1.0 then
        ffbTimer = 0.25
        lastFFB = car.ffbMultiplier
        ac.setFFBMultiplier(0)
        JumpToSplinePoint(car.splinePosition)
        physics.setCarAutopilot(false, false)
    end
end



---------------------------------------------------------------
-- local UIScale = 1/ac.getUI().uiScale  -- * Sim.windowHeight/1080
local UIScale = ac.getUI().uiScale  -- * Sim.windowHeight/1080


local function drawControls()
    --- control icons
    --- prev section challenge
    if currActiveSection>1 then
        if ui.iconButton( prevpng, vec2(40*UIScale,40*UIScale)) then
            --Countdown = -1.0
            timerlastlast = -1.0
            currActiveSection = currActiveSection - 1
            JumpCustomSection(CustomSects[currActiveSection][1])
        end
    else
        ui.iconButton( nopng, vec2(40*UIScale,40*UIScale))
    end
    ui.sameLine()
    --- next section challenge
    if currActiveSection < #CustomSects then
        if ui.iconButton( nextpng, vec2(40*UIScale,40*UIScale)) then
            --Countdown = -1.0
            timerlastlast = -1.0
            currActiveSection = currActiveSection + 1
            JumpCustomSection(CustomSects[currActiveSection][1])
        end
    else
        ui.iconButton( nopng, vec2(40*UIScale,40*UIScale))
    end

    ui.sameLine()
    --- restart this section challenge
    if ui.iconButton( restartpng, vec2(40*UIScale,40*UIScale)) then
        JumpCustomSection(CustomSects[currActiveSection][1])
    end
    ui.sameLine()
    --- exit this section challenge
    if ui.iconButton( exitpng, vec2(40*UIScale,40*UIScale)) then
        exitChallengeMode()
    end
end


local function getAngle(deg)
    return (deg / 360 * 2 * math.pi) - math.pi / 2
end
local function scale(val)
    return UIScale*val
end
local function scaledVec2(valueX, valueY)
    return vec2(UIScale * valueX, UIScale * valueY)
end
local function inSine(t, b, c, d)
    return -c * math.cos(t / d * (math.pi / 2)) + c + b
end
local function outSine(t, b, c, d)
    return c * math.sin(t / d * (math.pi / 2)) + b
end
local function outInSine(t, b, c, d)
    if t < d / 2 then
        return outSine(t * 2, b, c / 2, d)
    else
        return inSine((t * 2) - d, b + c / 2, c / 2, d)
    end
end

local centery = -1
local centerx = -1


local function drawMessages()
    local w = sim.windowWidth/2
    local bX2 = sim.windowWidth/2 - w
    local bY2 = 70/2*UIScale + fntSize/2
    local w2 = sim.windowWidth/2 - 1280/2*UIScale
    local wd = fntSize*5
    if centery == -1 then
        -- centerx = ac.getUI().windowSize.x / 2
        -- centery = ac.getUI().windowSize.y / 2
        centerx = sim.windowWidth/2 *1/UIScale
        centery = sim.windowHeight/2 *1/UIScale
        -- textToWrite = math.floor(SIM.timeToSessionStart / 1000) + 1
    end

    ui.beginOutline()

    ui.setCursorX(bX2-100*UIScale)
    ui.setCursorY(0)
    if doTimeAI then
        --DrawTextACWithShadows("please wait while getting medal times"   , 32*UIScale, vec2(ui.windowSize().x/2-UIScale*220, bY2*3.5), rgbm(1,1,1,1))
        DrawTextWithShadows("please wait while getting medal times"   , fntSize*1.25*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*3.2), vec2(ui.windowSize().x/2,fntSize*2*UIScale), false, rgbm(1,1,1,1))
    else
        if sMsg~="" then
            if sMsg~="You got too slow!" and sMsg~="You cut the track!" then
                ui.pushDWriteFont('MyTimingFont:\\fonts')
                ui.drawRectFilled(vec2(ui.windowSize().x/2-wd, bY2*2.4), vec2(ui.windowSize().x/2+wd, bY2*2.4+fntSize*1.5), colBG, 8, ui.CornerFlags.All)
                ui.dwriteDrawTextClipped(laptime(timerlastlast*1000), fntSize*UIScale, vec2(ui.windowSize().x/2-wd, bY2*2.4), vec2(ui.windowSize().x/2+wd,bY2*2.4+fntSize*1.5), ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))
                ui.popDWriteFont()
                --DrawTextWithShadows(       laptime(timercurr*1000), fntSize*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*2.4), vec2(ui.windowSize().x/2,fntSize*1.6), false, rgbm(1,1,1,1))
            else
                -- sMsg = "You got too slow!"
                -- sMsg = "You cut the track!"
            end
            DrawTextWithShadows(sMsg      , fntSize*3*UIScale, ui.Alignment.Center, vec2(centerx/2, 0), vec2(centerx,centery), false, rgbm(1,1,1,1))
            --DrawTextWithShadows(sMsg    , fntSize*1.25*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*1.5), vec2(ui.windowSize().x/2,fntSize*2*UIScale), false, rgbm(1,1,1,1))
            -- DrawTextWithShadows("last: " ..laptime(timerlastlast*1000)      )
        end
    end

    if alphaup then
        autoalpha = autoalpha + 0.025
        if autoalpha>=1.0 then
            autoalpha=1.0
            alphaup=false
        end
    else
        autoalpha = autoalpha - 0.025
        if autoalpha<=0.1 then
            autoalpha=0.1
            alphaup=true
        end
    end

    GateSFmesh:setMaterialProperty('ksEmissive', rgb((0.5-autoalpha)*20,(0.5-autoalpha)*20,0.5))

    if car.isAIControlled then
        ui.endOutline(rgbm(0,0,0,0.5), 0.5)
        --DrawTextACWithShadows("auto control - Get Ready !!!"   , 32*UIScale, vec2(ui.windowSize().x/2-UIScale*220, bY2*3.5), rgbm(1,1,1,1))
        --DrawTextWithShadows("AUTO DRIVE"      , fntSize*1.25*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*3.0), vec2(ui.windowSize().x/2,fntSize*2*UIScale), false, rgbm(1,1,1,1))
        DrawTextWithShadows("AUTO DRIVE"      , fntSize*1.25*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*4.1), vec2(ui.windowSize().x/2,fntSize*2*UIScale), false, rgbm(1,1,1,autoalpha))
        ui.beginOutline()
    end



    -- countdown / START
    if math.floor(Countdown)>=0 then
        ui.pushDWriteFont('Arkitech:\\fonts')
        DrawTextWithShadows(math.floor(Countdown+1), fntSize*3, ui.Alignment.Center,
          vec2(centerx-fntSize*1.5, centery-fntSize*1.5),
          vec2(fntSize*3, fntSize*3),
        --   vec2(centerx+100-fntSize*5.75, centery+100-fntSize*5.75),
        --   vec2(fntSize*3, fntSize*3),
          false, rgbm(1,1,1,1))
        ui.popDWriteFont()

        ------  countdown ARC
        ui.setCursor(  vec2(centerx-100*UIScale, centery-100*UIScale))
        ui.image(countdownImg, vec2(200*UIScale,         200*UIScale), rgbm.colors.white)

        local count = math.abs(math.ceil(Countdown) - Countdown)
        local easeInValue  = inSine   (count * 1000, 0, 1, 1000)
        local easeOutValue = 360 - easeInValue   --0 --outInSine(count * 1000, 0, 0.5, 1000)
        ui.pathArcTo(vec2(centerx, centery),
            100*UIScale,
            getAngle(0),
            getAngle(360 - 360 * (((easeInValue - 0.5) / 0.5 * 1)))
            , 80)
        -- if count > 0.5 then
        --     ui.pathArcTo(vec2(centerx-100, centery-100),
        --         UIScale*100,
        --         getAngle(0),
        --         getAngle(360 - 360 * (((easeInValue - 0.5) / 0.5 * 1)))
        --         , 80)
        -- else
        --     ui.pathArcTo(vec2(centerx-100, centery-100),
        --         UIScale*100,
        --         getAngle(360 - 360 * easeOutValue / 0.5 * 1),
        --         getAngle(360)
        --         , 80)
        -- end
        ui.pathStroke(rgbm.colors.white, false, scale(12))

    else
        if afterCountdown>0.0 then
            ui.pushDWriteFont('Arkitech:\\fonts')
            DrawTextWithShadows("START",           fntSize*3*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*5.5), vec2(ui.windowSize().x/2,fntSize*6*UIScale), false, rgbm(1,1,1,1))
            ui.popDWriteFont()
        end
    end

    ui.endOutline(rgbm(0,0,0,0.5), 0.5)

end

local function drawGoldSilverBronze()
    if currActiveSection<0 or #MedalSects==0 then return end
    UIScale = ac.getUI().uiScale

    local w = 1280/2 *UIScale
    local bX2 = sim.windowWidth/2 - w
    local bY2 = 70/2*UIScale + fntSize/2
    local w2 = sim.windowWidth/2 - 1280/2*UIScale
    local wd = fntSize*5

    if bShowMedals then
        ui.drawImage(goldsilverbronze, vec2(bX2-UIScale*50,5), vec2(bX2+w*2,512*UIScale*0.65))
    end
    if timercurr<=0.0 then
        if doTimeAI then
        else
            ui.drawImage(bandageIcon  , vec2(50, bY2*2.25), vec2(bX2 + w*2-UIScale*200, bY2*2.9 + fntSize*2))
        end
    end

    ui.beginOutline()

    --ui.begin
    --- current sector timer and delta ---
    if timercurr>0.0 then
        --if doTimeAI or doTime then
        --if doTimeAI or doTime or (bRunning and timerlastlast>0.0) then
        if (doTimeAI or doTime) and bRunning then

            ui.pushDWriteFont('MyTimingFont:\\fonts')
            --ui.drawRectFilled(vec2(bX2+w-UIScale*120, bY2*2.4), vec2(bX2+w+UIScale*120,bY2*2.4+fntSize*1.5), colBG, 8, ui.CornerFlags.All)
            ui.drawRectFilled(                                                 vec2(ui.windowSize().x/2-wd-UIScale*10, bY2*2.4), vec2(ui.windowSize().x/2+wd+UIScale*10, bY2*2.4+fntSize*1.5), colBG, 8, ui.CornerFlags.All)
            ui.dwriteDrawTextClipped(laptime(timercurr*1000), fntSize*UIScale, vec2(ui.windowSize().x/2-wd-UIScale*10, bY2*2.4), vec2(ui.windowSize().x/2+wd+UIScale*10, bY2*2.4+fntSize*1.5), ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))
            --DrawTextWithShadows(       laptime(timercurr*1000), fntSize*UIScale, ui.Alignment.Center, vec2(ui.windowSize().x/4, bY2*2.4), vec2(ui.windowSize().x/2,fntSize*1.6), false, rgbm(1,1,1,1))
            ui.popDWriteFont()

            if timercurr>0.0 then
                if doTimeAI then
                    ui.pushDWriteFont('MyTimingFont:\\fonts')
                    DrawTextWithShadows(
                        CustomSects[currActiveSection][0] .. ",  "..math.floor(sectorLength)..'m',
                        fntSize, ui.Alignment.Center,
                        vec2(sim.windowWidth/4*1/UIScale,8), vec2(sim.windowWidth/2*1/UIScale,fntSize*1.5*UIScale), false, rgbwhite)
                    ui.popDWriteFont()
                else
                     ---   RecordSects[currCustomSect]>0.0 and
                    if car and timeDataRecord~=nil and #timeDataRecord>0 and timercurr>0.0 and bShowDelta then
                        ui.pushDWriteFont('MyFont:\\fonts;Weight=Light')
                        --ui.pushDWriteFont('MyTimingFont:\\fonts')
                        --- delta sector timer ---
                        -- basic
                        -- DrawTextWithShadows(""           ..delta(splittime       *1000) .. "", fntSizeSmall*UIScale, ui.Alignment.Center, vec2(bX2-20*UIScale, bY2*2.0), vec2(ui.windowSize().x,32), false, rgbm(1,1,1,1))
                        -- ui.dwriteDrawTextClipped(delta(splittime*1000), fntSizeSmall*UIScale, vec2(bX2+w*1.4-UIScale*30, bY2*2.4), vec2(bX2+w*1.7-UIScale*30,bY2*2.4+fntSize*1.5), ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))

                        -- interpolated
                        if currentDeltaTime<=0.0 then
                            ui.drawRectFilled(
                                vec2(ui.windowSize().x/2+wd*1.35 , bY2*2.45),
                                vec2(ui.windowSize().x/2+wd*2.4  , bY2*2.4+fntSize*1.4),
                                -- vec2(ui.windowSize().x/2+wd*1.65 , bY2*2.45),
                                -- vec2(ui.windowSize().x/2+wd*2.5,bY2*2.4+fntSize*1.4),
                                colBGdeltagreen, 8, ui.CornerFlags.All)
                        else
                            ui.drawRectFilled(
                                vec2(ui.windowSize().x/2+wd*1.35 , bY2*2.45),
                                vec2(ui.windowSize().x/2+wd*2.4  , bY2*2.4+fntSize*1.4),
                                -- vec2(ui.windowSize().x/2+wd*1.65 , bY2*2.45),
                                -- vec2(ui.windowSize().x/2+wd*2.5,bY2*2.4+fntSize*1.4),
                                colBGdelta, 8, ui.CornerFlags.All)
                        end
                        --DrawTextWithShadows(
                        --    delta(currentDeltaTime*1000), fntSizeSmall*UIScale,
                        --    ui.Alignment.Center, vec2(bX2+w+UIScale*170, bY2*2.45), vec2(UIScale*250,fntSize*1.5), false, rgbm(1,1,1,1))
                        ui.dwriteDrawTextClipped(
                            delta(currentDeltaTime*1000), fntSize*UIScale,
                            vec2(ui.windowSize().x/2+wd*1.35, bY2*2.4 ),
                            vec2(ui.windowSize().x/2+wd*2.4 ,bY2*2.4+fntSize*1.5),
                            -- vec2(ui.windowSize().x/2+wd*1.75, bY2*2.4 ),
                            -- vec2(ui.windowSize().x/2+wd*2.4,bY2*2.4+fntSize*1.5),
                            ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))
                        ui.popDWriteFont()

                        if     record>0 and record+currentDeltaTime <= MedalSects[currActiveSection][0] then
                            ui.drawImage(goldIcon  , vec2(ui.windowSize().x/2+wd*2.6,bY2*2.4+fntSize*1.5-32), vec2(ui.windowSize().x/2+wd*2.6+32,bY2*2.4+fntSize*1.5))
                        elseif record>0 and record+currentDeltaTime <= MedalSects[currActiveSection][1] then
                            ui.drawImage(silverIcon, vec2(ui.windowSize().x/2+wd*2.6,bY2*2.4+fntSize*1.5-32), vec2(ui.windowSize().x/2+wd*2.6+32,bY2*2.4+fntSize*1.5))
                        elseif record>0 and record+currentDeltaTime <= MedalSects[currActiveSection][2] then
                            ui.drawImage(bronzeIcon, vec2(ui.windowSize().x/2+wd*2.6,bY2*2.4+fntSize*1.5-32), vec2(ui.windowSize().x/2+wd*2.6+32,bY2*2.4+fntSize*1.5))
                        elseif record>0 and record+currentDeltaTime<record then
                            ui.drawImage(pepegaIcon, vec2(ui.windowSize().x/2+wd*2.6,bY2*2.4+fntSize*1.5-32), vec2(ui.windowSize().x/2+wd*2.6+32,bY2*2.4+fntSize*1.5))
                        end

                    end
                end
            end
        end
    end


    --ui.pushFont("Segoe UI")
    --ui.pushDWriteFont('MyFont:\\fonts;Weight=Medium')
    ui.pushDWriteFont('MyFont:\\fonts;Weight=Light')
    --ui.pushDWriteFont('MyFont:\\fonts')

    ui.setCursorX(0)
    if bShowMedals then
        DrawTextWithShadows(laptime(MedalSects[currActiveSection][0]*1000) , fntSize*UIScale, ui.Alignment.Start, vec2(bX2+w*0.12-UIScale*30, bY2), vec2(ui.windowSize().x/2,32), false, rgbm(1,1,1,1))
        DrawTextWithShadows(laptime(MedalSects[currActiveSection][1]*1000) , fntSize*UIScale, ui.Alignment.Start, vec2(bX2+w*0.57-UIScale*30, bY2), vec2(ui.windowSize().x/2,32), false, rgbm(1,1,1,1))
        DrawTextWithShadows(laptime(MedalSects[currActiveSection][2]*1000) , fntSize*UIScale, ui.Alignment.Start, vec2(bX2+w*1.03-UIScale*30, bY2), vec2(ui.windowSize().x/2,32), false, rgbm(1,1,1,1))
        DrawTextWithShadows("last: " ..laptime(timerlastlast*1000)         , fntSize*UIScale, ui.Alignment.Start, vec2(bX2+w*1.78-UIScale*30, bY2), vec2(ui.windowSize().x/2,32), false, rgbm(1,1,1,1))
        if record<=0.0 then
            DrawTextWithShadows("PB: --.---"                               , fntSize*UIScale, ui.Alignment.Start, vec2(bX2+w*1.42-UIScale*30, bY2), vec2(ui.windowSize().x/2,32), false, rgbm(1,1,1,1))
        else
            --DrawTextWithShadows("PB: " ..laptime(record*1000)      , fntSizeSmall*UIScale, ui.Alignment.Center, vec2(bX2+120*UIScale, bY2), vec2(ui.windowSize().x,32), false, rgbm(1,1,1,1))
            DrawTextWithShadows("PB: " ..laptime(record*1000)              , fntSize*UIScale, ui.Alignment.Start, vec2(bX2+w*1.42-UIScale*30, bY2), vec2(ui.windowSize().x/2,32), false, rgbm(1,1,1,1))
            if     record>0 and record <= MedalSects[currActiveSection][0] then
                ui.drawImage(goldIcon  , vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            elseif record>0 and record <= MedalSects[currActiveSection][1] then
                ui.drawImage(silverIcon, vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            elseif record>0 and record <= MedalSects[currActiveSection][2] then
                ui.drawImage(bronzeIcon, vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            elseif record>0 then
                ui.drawImage(pepegaIcon, vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            end
        end
        if record>0.0 and bShowMedals then
        else
            if     record>0 and record <= MedalSects[currActiveSection][0] then
                ui.drawImage(goldIcon  , vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            elseif record>0 and record <= MedalSects[currActiveSection][1] then
                ui.drawImage(silverIcon, vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            elseif record>0 and record <= MedalSects[currActiveSection][2] then
                ui.drawImage(bronzeIcon, vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            elseif record>0 then
                ui.drawImage(pepegaIcon, vec2(bX2+w*1.31-UIScale*30, bY2-16*UIScale), vec2(bX2+w*1.31-UIScale*30+64*UIScale, bY2+45*UIScale))
            end
        end
    end

    ---- sector name + info text
    if timercurr<=0.0 then
        if doTimeAI then
            DrawTextWithShadows(
                CustomSects[currActiveSection][0] .. ",  "..math.floor(sectorLength)..'m',
                fntSize, ui.Alignment.Center,
                vec2(sim.windowWidth/4*1/UIScale,8), vec2(sim.windowWidth/2*1/UIScale,fntSize*1.5*UIScale), false, rgbwhite)
        else
            --ui.drawImage(bandageIcon  , vec2(bX2+w/3*1/UIScale, bY2*2.25), vec2(bX2+w*1.75*1/UIScale, bY2*2.25 + fntSize*2))
            DrawTextWithShadows(
                CustomSects[currActiveSection][0],
                fntSize*2, ui.Alignment.Center,
                vec2(fntSize+wd, bY2*2.4),
                vec2(fntSize+wd*2,fntSize*2.5*UIScale),
                false, CustomSects[currActiveSection][5])
            DrawTextWithShadows(
                CustomSects[currActiveSection][3] .. "  -  "..math.floor(sectorLength)..'m',
                fntSize, ui.Alignment.Center,
                vec2(ui.windowSize().x/4, bY2*2.4), vec2(ui.windowSize().x/2,fntSize*1.5*UIScale), false, rgbwhite)
            DrawTextWithShadows(
                CustomSects[currActiveSection][4],
                fntSizeSmall*0.8, ui.Alignment.Center,
                vec2(ui.windowSize().x/4, bY2*2.4), vec2(ui.windowSize().x/2,fntSize*4.00*UIScale), false, rgbwhite)

            -- local s = ""
            -- if CustomSects[currCustomSect][6]==1 then s='Rolling Start' else s='Standing Start' end
            -- if CustomSects[currCustomSect][7]==1 then s=s..'  -  Rolling Finish' else s='  -  Standing Finish' end
            -- DrawTextWithShadows(
            --     s,fntSize*1.35, ui.Alignment.Center,
            --     vec2(ui.windowSize().x/2+w/3, bY2*2.), vec2(ui.windowSize().x/8*UIScale,fntSize*4.00*UIScale), false, rgbwhite)
        end
    end
    ui.popDWriteFont()
    ui.endOutline(rgbm(0,0,0,0.5), 0.5)

end

----------------------------------------------------------------------------------------------------
local ssd, ssi = "", ""

function script.windowEdit()
    ui.beginOutline()
    editname = ui.inputText("Name (keep short)   Font-Color:", editname, ui.InputTextFlags.None, vec2(150, 38))
    ui.sameLine(0,200)
    local srgb = editcolor
    local changed = ui.colorButton('Font-Color', srgb, ui.ColorPickerFlags.PickerHueBar)
    if changed then
        editcolor = srgb
    end
    -- if ui.colorButton(
    --     'Selected Car Color',
    --     self.store.specColor,
    --     ui.ColorPickerFlags.AlphaBar + ui.ColorPickerFlags.AlphaPreview + ui.ColorPickerFlags.PickerHueBar) then
    --    self.store.specColor = self.store.specColor
    -- end

    ui.sameLine(0,50)
    if ui.checkbox("Rolling start", editrollingS==1) then
        if editrollingS==0 then editrollingS = 1 else editrollingS = 0 end
    end
    ui.sameLine(0,20)
    -- if ui.checkbox("Rolling finish          color:", editrollingF==1) then
    --     if editrollingF==0 then editrollingF = 1 else editrollingF = 0 end
    -- end


    ui.sameLine(0,50)
    if ui.button(' \n--SAVE--\n') then
        if currActiveSection>#CustomSects then
            table.insert(CustomSects, {[0]=editname, [1]=editS, [2]=editF, [3]=editdesc, [4]=editinfo, [5]=editcolor, [6]=editrollingS, [7]=editrollingF})
            table.insert(MedalSects, {[0]=-1.0, [1]=-1.0, [2]=-1.0})
            --local rec = tonumber ( readACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..(i), "TIME", "-1") )
            table.insert(RecordSects, -1.0)
        else
            -- CustomSects =  [0]=sectText, [1]=sectIN, [2]=sectOUT, [3]=desc, [4]=info, [5]=color, [6]=rollingS, [7]=rollingF
            CustomSects[currActiveSection][0] = editname
            CustomSects[currActiveSection][1] = editS
            CustomSects[currActiveSection][2] = editF
            CustomSects[currActiveSection][3] = editdesc
            CustomSects[currActiveSection][4] = editinfo
            CustomSects[currActiveSection][5] = editcolor
            CustomSects[currActiveSection][6] = editrollingS
            CustomSects[currActiveSection][7] = editrollingF
        end

        iniManualSave(filesSects[currentFileID])
        currActiveSection=-1
        doEdit=false
        MakeTrackPreviewImage()
        ac.setWindowOpen("main", true)
        ac.setWindowOpen("WinEdit", false)
    end
    ui.sameLine(0,40)
    if ui.button(' \n--close-- \n') then
        currActiveSection=-1
        doEdit=false
        ac.setWindowOpen("main", true)
        ac.setWindowOpen("WinEdit", false)
        return
    end

    editdesc = ui.inputText("Descr", editdesc)
    ui.sameLine(0,10)
    if ui.button("< insert # of corners") then
        local ssd, ssi = GetSectionNamesFromTo(editS, editF)
        if editdesc~="" then
            editdesc = editdesc .. ' ' .. ssd
        else
            editdesc = ssd
        end
    end
    editinfo = ui.inputText("Info", editinfo)
    ui.sameLine(0,10)
    if ui.button("< insert sections") then
        local ssd, ssi = GetSectionNamesFromTo(editS, editF)
        if editinfo~="" then
            editinfo = editinfo..' '..ssi
        else
            editinfo = ssi
        end
    end
    ui.drawSimpleLine(vec2(0,ui.getCursor().y-3), vec2(620, ui.getCursor().y-3), colInactive)

    editS = ui.slider('##Start', editS, 0.0, 1.0, 'Start: %.8f', 1 )
    ui.sameLine(0,20)
    if ui.button('jump to Start') then editSL = -1.0 return end
    ui.sameLine(0,20)
    if ui.button('from prev sect.') then
        local id = currActiveSection-1
        if id<1 then id=#CustomSects end
        editSL = -1.0
        editS = CustomSects[id][2]
    end

    if ui.button('-10 m') then editS = editS - 10*brdDist/sim.trackLengthM end
    ui.sameLine(0,5)
    if ui.button('-'..brdDist..' m') then editS = editS - brdDist/sim.trackLengthM end
    ui.sameLine(0,10)
    ui.dwriteText('on track:  '.. math.round(editS*sim.trackLengthM)..'  m', 16)
    ui.sameLine(360,0)
    if ui.button('+'..brdDist..' m') then editS = editS + brdDist/sim.trackLengthM end
    ui.sameLine(0,5)
    if ui.button('+10 m') then editS = editS + 10/sim.trackLengthM end

    ui.sameLine(0,50)
    if ui.checkbox("always move car", alsomovecar) then
        alsomovecar = not alsomovecar
        writeACConfig(appopts, "options", "alwaysmovecar", alsomovecar)
    end

    editF = ui.slider('##Finish', editF, 0.0, 1.0, 'Finish: %.8f', 1 )
    ui.sameLine(0,20)
    if ui.button('jump to Finish') then editFL = -1.0 end
    ui.sameLine(0,20)
    if ui.button('from next sect.') then
        local id = currActiveSection+1
        if id>#CustomSects then id=1 end
        editFL = -1.0
        editF = CustomSects[id][1]
    end
    if ui.button('-10 m ') then editF = editF - 10/sim.trackLengthM end
    ui.sameLine(0,5)
    if ui.button('-'..brdDist..' m ') then editF = editF - brdDist/sim.trackLengthM end
    ui.sameLine(0,10)
    ui.dwriteText('on track:  '.. math.round(editF*sim.trackLengthM)..'  m', 16)
    ui.sameLine(360,0)
    if ui.button('+'..brdDist..' m ') then editF = editF + brdDist/sim.trackLengthM end
    ui.sameLine(0,5)
    if ui.button('+10 m ') then editF = editF + 10/sim.trackLengthM end

    if editSL~=editS then
        if editS<0.0 then
            editS = 1.0 + editS
        end
        if editS>1.0 then
            editS = 0.0
        end
        SetGatePostsS(editS)
    end

    if editFL~=editF then
        if editF<0.0 then
            editF = 1.0 + editF
        end
        if editF>1.0 then
            editF = 0.0
        end
        SetGatePostsF(editF)
    end

    if editSL~=editS or editFL~=editF then
        sectorLength = math.round(GetMetersToSplinePoint(editS, editF))
        if alsomovecar then
            if editSL~=editS then
                JumpToSplinePoint(editS-3/sim.trackLengthM)
            elseif editFL~=editF then
                JumpToSplinePoint(editF-3/sim.trackLengthM)
            end
        end
        ssd, ssi = GetSectionNamesFromTo(editS, editF)
        editSL=editS
        editFL=editF
    end

    -- ui.dwriteTextWrapped('Sector length: ' ..
    --     math.round(sectorLength)..'  m  -  '..
    --     ssd..' - '..ssi, 16)
    ui.dwriteTextWrapped('Sector length: ' ..
        math.round(editF*sim.trackLengthM-editS*sim.trackLengthM)..'  m  -  '..
        ssd..' - '..ssi, 16)

    ui.endOutline(rgbm(0,0,0,0.5), 1)

end



local aimax = 100
if ac.getPatchVersionCode()>=3116 then
    aimax = 120
end

local function windowOverviewAIonly(dt)
    ui.beginOutline()

    ui.text("physics.allowed(): " .. tostring(physics.allowed()))

    --local sess = ac.getSession(0)
        -- if sess.type ==
        if ac.getPatchVersionCode()>=3116 then
            aimax = 120
        end
        ui.newLine()
        ui.text("other cars AI")
        ui.newLine()
        ui.sameLine(150)
        ui.setNextItemWidth(200)
        ailevelother, changed = ui.slider('##AI level other', ailevelother, 60.0, aimax, 'AI level other: %.1f', 1 )
        if changed then
            -- physics.setAILevel(0,ailevel/100.0)
            -- writeACConfig(appopts, "options", "ailevel", math.round(ailevel,1))
            for i = 1, 108 do
                if ac.getCar(i) and not ac.getCar(i).isRemote then
                    physics.setAILevel(i,ailevelother/100.0)
                    writeACConfig(appopts, "options", "ailevelother", math.round(ailevel,1))
                end
            end
        end
        ui.newLine(0)
        ui.newLine(0)
        ui.newLine(0)
        ui.sameLine(150)
        ui.setNextItemWidth(200)
        ui.setCursorY(ui.getCursor().y-fntSize*1.25)
        aiaggother, changed = ui.slider('##AI aggression other', aiaggother, 0, 100, 'AI aggression other: %.1f', 1 )
        if changed then
            -- physics.setAIAggression(0,aiagg/100.0)
            -- writeACConfig(appopts, "options", "aiaggression", math.round(aiagg,1))
            for i = 1, 108 do
                if ac.getCar(i) and not ac.getCar(i).isRemote then
                    physics.setAIAggression(i,aiaggother/100.0)
                    --ac.debug(i.." aggr done", ac.getCar(i).aiAggression)
                    writeACConfig(appopts, "options", "aiaggressionother", math.round(aiagg,1))
                end
            end
        end
        ui.newLine(0)
        ui.newLine(0)
        ui.newLine(0)

        ui.text("Player car AI")
        ui.sameLine(150)
        ui.setNextItemWidth(200)
        ailevel, changed = ui.slider('##AI level', ailevel, 60.0, aimax, 'AI level: %.1f', 1 )
        if changed then
            physics.setAILevel(0,ailevel/100.0)
            writeACConfig(appopts, "options", "ailevel", math.round(ailevel,1))
        end
        ui.newLine(0)
        ui.newLine(0)
        ui.newLine(0)
        ui.sameLine(150)
        ui.setNextItemWidth(200)
        ui.setCursorY(ui.getCursor().y-fntSize*1.25)
        aiagg, changed = ui.slider('##AI aggression', aiagg, 0, 100, 'AI aggression: %.1f', 1 )
        if changed then
            physics.setAIAggression(0,aiagg/100.0)
            writeACConfig(appopts, "options", "aiaggression", math.round(aiagg,1))
        end
    ui.endOutline(rgbm(0,0,0,1), 2)
end


local function windowOverview(dt)

    ui.beginOutline()

    if #filesSects>0 then
        if currentFileID==0 then
            currentFileID=1
        end
        if currentFileID>1 then
            ui.sameLine(0,0)
            if ui.button(" \n < \n ") then
                currentFileID = currentFileID - 1
                timerlastlast = -1.0
                currSelectedSection = 1
                lastSelectedSection = -1
                LoadSectionFile()
            end
            ui.sameLine(0,5)
        else
            ui.sameLine(0,40)
        end
        if currentFileID<#filesSects then
            if ui.button(" \n > \n ") then
                currentFileID = currentFileID + 1
                timerlastlast = -1.0
                currSelectedSection = 1
                lastSelectedSection = -1
                LoadSectionFile()
            end
        end
        ui.sameLine(100)
        --ui.setNextItem
        ui.labelText("", "Available Challenge Files: "..(currentFileID).." / "..#filesSects)
        --ui.newLine()
        if io.fileExists(filesSects[currentFileID]) then
            if AboutSect[1] then
                ui.sameLine(100)
                ui.setCursorY(ui.getCursorY()+fntSize)
                ui.labelText("",  'from: ' ..AboutSect[1][0]..' ('..AboutSect[1][2]..')')
                ui.sameLine(330)
                --ui.setCursorY(ui.getCursorY()-fntSize)
                --ui.labelText("", AboutSect[1][1] )
                ui.dwriteDrawText(AboutSect[1][1]                            , fntSize         , vec2(330,25), rgbm.colors.white)
                --ui.dwriteDrawText('from: ' ..AboutSect[1][0]..' ('..AboutSect[1][2]..')', fntSizeSmall*0.8, vec2(80,fntSize), rgbm.colors.white)
            end
        else
            CreateGenericSections()
            --ui.dwriteDrawText('...default generic Challenge missing..."'..io.getFileName(filesSects[currentFileID])..'"', fntSize         , vec2(300,5), rgbm.colors.white)
        end

        ui.dwriteDrawText(carname, fntSize         , vec2(330,25+fntSize*1.2), rgbm.colors.white)

        ui.sameLine(ui.windowWidth()-100)
        if ui.button("Exit") then
            ac.setWindowOpen("main", false)
            ac.setWindowOpen("WinTiming", false)
            ac.setWindowOpen("WinEdit", false)
        --     ac.debug("here","herhe")
        --     currHoverSect = 1
        --     currentFileID = -1
        --     currCustomSect = -1
        --     --LoadFilenames()
        --     -- doTime = false
        --     -- doTimeAI = false
        --     -- physics.setCarAutopilot(false, false)
            ac.unloadApp()
        end

    end


    if #CustomSects==0 then
        -- generate generic sectors
        ui.setCursorX(ui.availableSpaceX()-170)
        if ui.button('generate generic sectors\n   - same every time - ') then
            CreateGenericSections()
        end
    end
    ui.endOutline(rgbm(0,0,0,1), 2)

    local t = -1

    ui.sameLine()
    ui.newLine()
    -- draw all available "Sector1"/"IA 10" buttons section name
    if #CustomSects>0 then
        --ui.beginTabBar(AboutSect[1][1])
        --local flag = bit.bor(ui.WindowFlags.fade) -- , ui.WindowFlags.NoBringToFrontOnFocus, ui.WindowFlags.NoFocusOnAppearing)
        ui.childWindow('scrolling', vec2(220, ui.availableSpaceY()),
            function ()
                ui.beginOutline()
                for i,v in pairs(CustomSects) do
                    local s=CustomSects[i][0]
                    if MedalSects[i][0]<=0.0 then
                        -- mark those without medals
                        s=s.." *"
                        if t==-1 then t = i end
                    end

                    ui.beginGroup()
                    ui.newLine(10)
                    if i~=currSelectedSection then
                        ui.drawIcon(brdimg,vec2(5,ui.getCursor().y-fntSize*0.25), vec2(199,ui.getCursor().y+fntSize*1.5), CustomSects[i][5]*0.5)
                    else
                        ui.drawIcon(brdimg,vec2(5,ui.getCursor().y-fntSize*0.25), vec2(199,ui.getCursor().y+fntSize*1.5), CustomSects[i][5])
                    end
                    ui.newLine(0)
                    ui.sameLine(5)
                    ui.setCursorY(ui.getCursor().y-fntSize*0.25)
                    -- sector title name --
                    if i~=currSelectedSection then
                        ui.dwriteTextAligned( s, fntSize*1.2, ui.Alignment.Center, ui.Alignment.Center,
                                        vec2(199,fntSize*1.5), false, CustomSects[i][5]*0.5)
                    else
                        ui.dwriteTextAligned( s, fntSize*1.2, ui.Alignment.Center, ui.Alignment.Center,
                                        vec2(199,fntSize*1.5), false, CustomSects[i][5] )
                    end
                    ui.endGroup()

                    if ui.itemHovered() then
                        if i~=currSelectedSection then
                        ui.drawSimpleLine(
                            vec2(50,ui.getCursor().y),
                            vec2(150,ui.getCursor().y),
                            CustomSects[i][5]*0.5, 2 )
                        else
                        ui.drawSimpleLine(
                            vec2(50,ui.getCursor().y),
                            vec2(150,ui.getCursor().y),
                            CustomSects[i][5], 2 )
                        end
                    end
                    if ui.itemClicked() then
                        currSelectedSection=i -- triggers creating new preview
                    end
                end -- for
                ui.endOutline(rgbm(0,0,0,1), 1)
            end) -- childwin

        --ui.endTabBar()
    end


    -- event challenge details start
    if #CustomSects>0 and currSelectedSection>-1 then
        ui.beginOutline()

        local i = currSelectedSection
        local s=CustomSects[i][0]
        if MedalSects[i][0]<=0.0 then
            -- mark those without medals
            s=s.." *"
        end
        ui.setCursorY(80)
        ui.newLine()
        ui.sameLine(650)
        if ui.button('\n             \n ') then
            currActiveSection = i
            JumpCustomSection(CustomSects[i][1])
        end
        ui.sameLine(660)
        ui.dwriteText("GO", fntSize*1.35, rgbm.colors.green*5)
        -- ui.dwriteText("  GO  ", fntSize*1.5, rgbm.colors.green)

        ui.sameLine(800)
        ui.endOutline(rgbm(0,0,0,1), 2)

        if ui.button('edit\nsection') then
            currActiveSection = i
            editS = CustomSects[currActiveSection][1]
            editF = CustomSects[currActiveSection][2]
            editname = CustomSects[currActiveSection][0]
            editdesc     = CustomSects[currActiveSection][3]
            editinfo     = CustomSects[currActiveSection][4]
            editcolor    = CustomSects[currActiveSection][5]
            editrollingS  = CustomSects[currActiveSection][6]
            editrollingF  = CustomSects[currActiveSection][7]
            if alsomovecar then
                physics.setCarAutopilot(false, false)
                -- JumpToSplinePoint(editS)
                -- JumpToSplinePoint(CustomSects[i][1])
            end
            editSL = -10.000  -- triggers jump
            editFL = editF
            doEdit = true
            return
        end
        ui.sameLine(0,10)
        if ui.button('add\nsection') then
            currActiveSection = #CustomSects + 1
            editS = car.splinePosition
            editF = car.splinePosition + 500/sim.trackLengthM
            -- CustomSects =  [0]=sectText, [1]=sectIN, [2]=sectOUT, [3]=desc, [4]=info, [5]=color, [6]=rollingS, [7]=rollingF
            editname = "Sector" .. currActiveSection
            editdesc     = "desc"
            editinfo     = "info"
            editcolor    = rgbm.colors.white
            editrollingS  = 1
            editrollingF  = 1
            if alsomovecar then
                JumpToSplinePoint(editS)
            end
            physics.setCarAutopilot(false, false)
            doEdit = true
            return
        end
        -- generate random sectors
        ui.sameLine(0,10)
        --ui.setCursorY(80)
        --ui.setCursorX(ui.availableSpaceX()-145)
        if ui.button('new random sectors') then
            CreateRandomSections()
        end


        ui.beginOutline()

        ui.setCursorY(100)
        ui.newLine(0)
        ui.sameLine(250)
        ui.dwriteTextAligned( "Event Details" , fntSizeSmall*0.75, ui.Alignment.Start, ui.Alignment.Center,
            vec2(500,fntSize), false, rgbm.colors.white)
        -- ui.newLine(0)
        -- ui.sameLine(250)
        -- ui.dwriteTextAligned( CustomSects[i][0] , fntSize*2, ui.Alignment.Start, ui.Alignment.Center,
        --                     vec2(500,fntSize*3), false, CustomSects[i][5])
        ui.newLine(0)
        ui.newLine(0)
        ui.sameLine(250)
        --ui.setCursorY(ui.getCursor().y-fntSize*0.5)
        ui.dwriteTextAligned( sectorLength..'m - ' ..CustomSects[i][3], fntSizeSmall, ui.Alignment.Start, ui.Alignment.Center,
                            vec2(500,fntSize), false, rgbm.colors.white)
        --ui.setCursorY(ui.getCursor().y-fntSize*0.75)
        ui.newLine(0)
        ui.sameLine(250)
        local sPB = CustomSects[i][4]
        if CustomSects[i][6]==1 then sPB = sPB .. "\n\nRolling Start" else sPB = sPB .. "\n\nStanding Start" end
        if CustomSects[i][7]==1 then sPB = sPB .. "  -  Rolling Finish" else sPB = sPB .. "  -  Standing Finish" end
        ui.dwriteTextAligned( sPB, fntSizeSmall*0.7, ui.Alignment.Start, ui.Alignment.Center,
                              vec2(500,fntSize*3), false, rgbm.colors.white)

        ui.newLine(0)
        ui.newLine(0)
        ui.newLine(0)
        ui.sameLine(250)
        --ui.setCursorY(ui.getCursor().y-fntSize*0.75)
        --record = tonumber ( readACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currCustomSect-1, "TIME", "-1.0") )

        sPB=""
        if RecordSects[i]>0.0 then
            if     RecordSects[i]<=MedalSects[i][0] then
                --sPB = sPB .. "  -  You got the Gold Medal!"
                sPB =        "√ Bronze: ".. laptime((MedalSects[i][2]*1000))
                sPB = sPB .. "\n√ Silver: ".. laptime((MedalSects[i][1]*1000))
                sPB = sPB .. "\n√ Gold: ".. laptime((MedalSects[i][0]*1000)) .. "\n\n"
            elseif RecordSects[i]<=MedalSects[i][1] then
                --sPB = sPB .. "  -  You got the Silver Medal!"
                sPB =          "√ Bronze: ".. laptime((MedalSects[i][2]*1000))
                sPB = sPB .. "\n√ Silver: ".. laptime((MedalSects[i][1]*1000))
                sPB = sPB .. "\nGold: ".. laptime((MedalSects[i][0]*1000)) .. "\n\n"
            elseif RecordSects[i]<=MedalSects[i][2] then
                --sPB = sPB .. "  -  You got the Bronze Medal!"
                sPB =        "√ Bronze: ".. laptime((MedalSects[i][2]*1000))
                sPB = sPB .. "\nSilver: ".. laptime((MedalSects[i][1]*1000))
                sPB = sPB .. "\nGold: ".. laptime((MedalSects[i][0]*1000)) .. "\n\n"
            else
                sPB =        "Bronze: ".. laptime((MedalSects[i][2]*1000))
                sPB = sPB .. "\nSilver: ".. laptime((MedalSects[i][1]*1000))
                sPB = sPB .. "\nGold: ".. laptime((MedalSects[i][0]*1000)) .. "\n\n"
            end
            sPB = sPB .. 'PersBest: '.. laptime(math.round(RecordSects[i]*1000,3))
        else
            sPB =        "Bronze: ".. laptime((MedalSects[i][2]*1000))
            sPB = sPB .. "\nSilver: ".. laptime((MedalSects[i][1]*1000))
            sPB = sPB .. "\nGold: ".. laptime((MedalSects[i][0]*1000)) .. "\n\n"
            sPB = sPB .. "Not driven yet."
        end
        ui.dwriteTextAligned(sPB, fntSizeSmall*1.25, ui.Alignment.End, ui.Alignment.Center,
                             vec2(250,fntSizeSmall*10), false, rgbm.colors.white)
        ui.endOutline(rgbm(0,0,0,1), 2)

        ui.newLine(0)
        ui.sameLine(350)
        if RecordSects[i]>0.0 then
            if ui.button('clear', vec2(100*UIScale,20*UIScale)) then
                -- RecordSects[currHoverSect]=-1.0
                local ls = currSelectedSection
                writeACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currSelectedSection-1, "TIME", -1)
                writeACConfig(INIrecords, recordTrackSects[currentFileID]..'SECTOR_'..currSelectedSection-1, "DATA", "{}")
                LoadSectionFile()
                currSelectedSection = ls
            end
        end


        ui.beginOutline()

        -- if timerlastlast>0.0 then
        --     ui.sameLine(250)
        --     ui.dwriteTextAligned('Last: '.. laptime(timerlastlast*1000), fntSizeSmall*1, ui.Alignment.End, ui.Alignment.Center,
        --                          vec2(250,fntSizeSmall*21), false, rgbm.colors.white)
        -- end


        -- button to make MedalTimes
        ui.sameLine(275)
        ui.setCursorY(ui.availableSpaceY()+360)
        local btnS = " \nmake new \nmedal times\n "
        if t>-1 or #MedalSects==0 then btnS = " \n* make\nMedal Times\n " end
        if ui.button(btnS) then
            doTimeAI = true
            doTime = true
            if #MedalSects==0 then
                t = 0
            end
            -- lastCamera = sim.cameraMode
            -- --ac.setCurrentCamera(ac.CameraMode.Track)
            if t==-1 then
                --for i, v in pairs(MedalSects) do
                    MedalSects[currSelectedSection][0]=-1
                    MedalSects[currSelectedSection][1]=-1
                    MedalSects[currSelectedSection][2]=-1
                --end
                t = currSelectedSection
                writeACConfig(filesMedals[currentFileID],                                  'SECTOR_'..tostring(currSelectedSection-1), "gold"  , "-1")
                writeACConfig(filesMedals[currentFileID],                                  'SECTOR_'..tostring(currSelectedSection-1), "silver", "-1")
                writeACConfig(filesMedals[currentFileID],                                  'SECTOR_'..tostring(currSelectedSection-1), "bronze", "-1")
                writeACConfig(INIrecords                , recordTrackSects[currentFileID]..'SECTOR_'..tostring(currSelectedSection-1), "TIME", "-1")
                writeACConfig(INIrecords                , recordTrackSects[currentFileID]..'SECTOR_'..tostring(currSelectedSection-1), "DATA", "{}")
            else
                t = currSelectedSection
            end
            currActiveSection = t
            --ac.debug("t", t)
            JumpCustomSection(CustomSects[t][1])
            --physics.setAILevel(0,ailevel/100.0)
            --physics.setAIAggression(0,aiagg/100.0)
            --writeACConfig(appopts, "options", "ailevel"      , ailevel)
            --writeACConfig(appopts, "options", "aiaggression" , aiagg)
            return
        end
        local aimax = 100
        if ac.getPatchVersionCode()>=3116 then
            aimax = 120
        end
        ui.sameLine(0,10)
        ui.setNextItemWidth(200)
        ailevel, changed = ui.slider('##AI level', ailevel, 80.0, aimax, 'AI level: %.1f', 1 )
        if changed then
            physics.setAILevel(0,ailevel/100.0)
            writeACConfig(appopts, "options", "ailevel", math.round(ailevel,1))
        end
        ui.newLine(0)
        ui.sameLine(275+98)
        ui.setNextItemWidth(200)
        ui.setCursorY(ui.getCursor().y-fntSize*1.25)
        aiagg, changed = ui.slider('##AI aggression', aiagg, 0, 100, 'AI aggression: %.1f', 1 )
        if changed then
            physics.setAIAggression(0,aiagg/100.0)
            writeACConfig(appopts, "options", "aiaggression", math.round(aiagg,1))
        end
        ui.newLine(0)
        ui.sameLine(275)
        ui.setNextItemWidth(300)
        ui.setCursorY(ui.getCursorY()+10)
        local aimedaloffsettmp, changed = ui.slider('##time offset', aimedaloffset*100.0, 0.1, 10.0, 'offset from silver: %.1f %%')
        if changed then
            aimedaloffset = aimedaloffsettmp / 100.0
            writeACConfig(appopts, "options", "aimedaloffset", math.round(aimedaloffset,4))
        end
        ui.endOutline(rgbm(0,0,0,1), 2)

        ui.sameLine(0,90)
        if ui.checkbox("Show Medal times", bShowMedals) then
            bShowMedals = not bShowMedals
            writeACConfig(appopts, "options", "bShowMedals", tostring(bShowMedals))
        end
        ui.sameLine(0,20)
        if ui.checkbox("Delta", bShowDelta) then
            bShowDelta = not bShowDelta
            writeACConfig(appopts, "options", "bShowDelta", tostring(bShowDelta))
        end
        ui.sameLine(0,20)
        if ui.checkbox("Controls", bControls) then
            bControls = not bControls
            writeACConfig(appopts, "options", "bControls", tostring(bControls))
        end
        ui.sameLine(0,20)
        if ui.checkbox("Auto restart", bAutoRestart) then
            bAutoRestart = not bAutoRestart
            writeACConfig(appopts, "options", "bAutoRestart", tostring(bAutoRestart))
        end
        ui.sameLine(0,20)
        if ui.checkbox("Sounds", bAudio) then
            bAudio = not bAudio
            writeACConfig(appopts, "options", "bAudio", tostring(bAudio))
        end
    end


    if #CustomSects>0 and currSelectedSection>-1 then
        local i = currSelectedSection
        if RecordSects[i]>0.0 then
        ui.setCursorY(275)
        --ui.sameLine(250)
            if     RecordSects[i]<=MedalSects[i][0] then
                ui.drawImage(goldIcon  , vec2(530-8, ui.getCursor().y+32+fntSizeSmall*5-8), vec2(530+32+32, ui.getCursor().y+32+fntSizeSmall*5+32+28))
            elseif RecordSects[i]<=MedalSects[i][1] then
                ui.drawImage(silverIcon, vec2(530-8, ui.getCursor().y+32+fntSizeSmall*5-8), vec2(530+32+32, ui.getCursor().y+32+fntSizeSmall*5+32+28))
            elseif RecordSects[i]<=MedalSects[i][2] then
                ui.drawImage(bronzeIcon, vec2(530-8, ui.getCursor().y+32+fntSizeSmall*5-8), vec2(530+32+32, ui.getCursor().y+32+fntSizeSmall*5+32+28))
            else
                ui.drawImage(pepegaIcon, vec2(530-8, ui.getCursor().y+32+fntSizeSmall*5-8), vec2(530+32+32, ui.getCursor().y+32+fntSizeSmall*5+32+28))
            end
        end
    end
    -- details end

    if #CustomSects>0 then
        if currSelectedSection~=lastSelectedSection and currSelectedSection>-1 then
            lastSelectedSection = currSelectedSection
            timerlastlast = -1.0
            ac.debug("Custom Sections file", (filesSects[currentFileID]):replace((ac.getFolder(ac.FolderID.Root).."\\apps\\lua\\customLicensetest\\"):lower(),''))
            ac.debug("Medals File", (filesMedals[currentFileID]):replace((ac.getFolder(ac.FolderID.Root).."\\apps\\lua\\customLicensetest\\"):lower(),''))
            ac.debug("Records Car File", string.lower(INIrecords):replace((ac.getFolder(ac.FolderID.Root).."\\apps\\lua\\customlicensetest\\"):lower(),'') )
            ac.debug("Records Car File track-section", recordTrackSects[currentFileID]..'SECTOR_'..currSelectedSection-1)
            MakeTrackPreviewImage()
        end
        if currSelectedSection>-1 then
            if mapOverlay and mapZoomed then
                imgupdate = imgupdate + 1 --dt
                if imgupdate>1 then
                    imgupdate = 0.0
                    if partoffset == 1 then
                        mapOverlay:clear(rgbm.colors.transparent)
                    end
                    UpdateOverlayMap()
                end
                ui.drawIcon(mapZoomed, vec2(previewOffX,previewOffY), vec2(previewOffX+previewSize,previewOffY+previewSize) , rgbm.colors.white) -- ui.ImageFit.Fill)
                ui.drawIcon(mapOverlay, vec2(previewOffX,previewOffY), vec2(previewOffX+previewSize,previewOffY+previewSize) , colInactive*2)
            end
        end
    end
end




---------------------------------------------------------------------------------------------

local function pushCar(dt)
    -- local passivePush = pushForce * car.mass * dt * 100 * car.gas
    -- --ac.debug("passivePush", passivePush)
    -- physics.addForce(0, vec3(0, 0, 0), true, vec3(0, 0, passivePush), true)
    local passivePush = pushForce * car.mass * dt * 100
    --ac.debug("passivePush", passivePush)
    physics.addForce(0, vec3(0, 0, 0), true, vec3(0, 0, passivePush), true)
end



-- local _l_manual_pos = vec2(0,0)
-- local _l_manual_padding = vec2(0,0)
-- local _l_manual_dim = vec2(1280,512)

local sesstimeleft = sim.sessionTimeLeft-0.002

function script.windowMain(dt)
    if car and physics.allowed() and not ac.isInReplayMode() and sim.raceSessionType==ac.SessionType.Race then
        ac.setWindowOpen("main", true)
        ac.setWindowOpen("WinTiming", false)
        ac.setWindowOpen("WinEdit", false)
        windowOverviewAIonly(dt)

    elseif car and physics.allowed() and not ac.isInReplayMode() and sim.raceSessionType==ac.SessionType.Hotlap then
    -- if car and physics.allowed() and not ac.isInReplayMode() and
    --    (sim.raceSessionType==ac.SessionType.Hotlap or sim.raceSessionType==ac.SessionType.Practice)
    -- then
        if ac.hasTrackSpline() then
            if currActiveSection>-1 and not doEdit then
                -- a section is active, do the timing window
                ac.setWindowOpen("main", false)
                ac.setWindowOpen("WinTiming", true)
                --ui.transparentWindow("w time",
                -- ui.toolWindow("Win-Timing",
                --         _l_manual_pos, _l_manual_dim, true, false,
                --         function() windowOverview() end)
            else
                if doEdit then
                    ac.setWindowOpen("main", false)
                    ac.setWindowOpen("WinEdit", true)
                else
                    ac.setWindowOpen("main", true)
                    ac.setWindowOpen("WinTiming", false)
                    ac.setWindowOpen("WinEdit", false)
                    --ac.setWindowBackground("windowMain", rgbm(0,0,0,0.5))
                    -- ac.setWindowSizeConstraints("windowMain", _l_manual_dim, _l_manual_dim)
                    windowOverview()
                    -- ui.toolWindow(
                    --         "CustomLicenseTestOverview",
                    --         _l_manual_pos, _l_manual_dim, true, true,
                    --         function() windowOverview() end)
                end
            end
        end
    else
        --ac.debug("ac.SessionType", sim.raceSessionType)
        ui.beginOutline()
        if not physics.allowed() then
        ui.dwriteDrawText("Extended Physics not enabled!",
                           fntSize*1.5, vec2(20,40), rgbm.colors.white)
        end
        -- if not (sim.raceSessionType==ac.SessionType.Hotlap or sim.raceSessionType==ac.SessionType.Practice) then
        if sim.raceSessionType~=ac.SessionType.Hotlap then
            if ui.button("\n   Restart in Hotlap mode   \n ") then
                local s = "[SESSION_0]\nNAME=Hotlap\nTYPE=4\nDURATION_MINUTES=0\nSPAWN_SET=HOTLAP_START\n"
                ac.restartAssettoCorsa(s)
            end
            ui.dwriteDrawText("CustomLicenseTest can only run in Hotlap Mode!",
            fntSize*1.5, vec2(20,80), rgbm.colors.white)

            ui.sameLine(ui.windowWidth()-100)
            if ui.button("Exit") then
                ac.setWindowOpen("main", false)
                ac.setWindowOpen("WinTiming", false)
                ac.setWindowOpen("WinEdit", false)
                --     ac.debug("here","herhe")
                --     currHoverSect = 1
                --     currentFileID = -1
                --     currCustomSect = -1
                --     --LoadFilenames()
                --     -- doTime = false
                --     -- doTimeAI = false
                --     -- physics.setCarAutopilot(false, false)
                --     ac.unloadApp()
            end
        end
        ui.endOutline(rgbm(0,0,0,1), 2)
    end
end

local bPaused = false

function script.windowTiming(dt)
    -- ac.debug("ui", ui.availableSpace())
    -- draw player timing stuff
    if (doTime or bRunning) and currActiveSection>-1 and #MedalSects>0 then
        if not ac.isInReplayMode() then
            UIScale = ac.getUI().uiScale
            if bControls or timercurr<=0.0 or sMsg~="" then
            drawControls() end
            drawGoldSilverBronze()
        end
    end
end

function UICallback()
    -- draw big messages on screen
    if (doTime or bRunning) and currActiveSection>-1 and #MedalSects>0 then
        drawMessages()
    end
end

-- function script.windowSettings(dt)
-- end

--function Draw3D(dt)  --script.renderTrack()
    -- if bAIborders and ac.hasTrackSpline() then
    --     --DrawBorders(car.splinePosition)
    --     -- DrawStartFinishGates()
    -- end
--end

-- local function fnOpen()
--     if filesSects and #filesSects>0 then
--         currentFileID = 1
--         LoadSectionFile()
--     end
-- end

function script.update(dt)

    -- ac.debug("Countdown", Countdown)

    if car and physics.allowed() and not ac.isInReplayMode() and ac.hasTrackSpline() then
        if currActiveSection>-1 and not doEdit and not bPaused then
            currSplinePos = car.splinePosition
            isInside = CheckIfInsideINOUT(CustomSects[currActiveSection][1], CustomSects[currActiveSection][2], currSplinePos)
            HandleSplinePos(dt)
        end
    end

    if sim.sessionTimeLeft > sesstimeleft and currActiveSection>-1 then
        sesstimeleft = sim.sessionTimeLeft-0.002
        exitChallengeMode()
        return
    end
    if car and car.isInPit and currActiveSection>-1 then
        exitChallengeMode()
        return
    end

    if Countdown>0.0 and not CountdownDone then
        Countdown = Countdown - dt
        if Countdown<=0.0 then
            CountdownDone = true
            afterCountdown = 0.666
        end
    end
    if afterCountdown>0.0 then
        afterCountdown = afterCountdown - dt
        sMsg = ""
    end
    if timerMsg>0.0 then
        timerMsg = timerMsg - dt
        if timerMsg<=0.0 then
            sMsg = ""
        end
    end
    if pushseconds>0.0 then
        pushCar(dt)
        pushseconds = pushseconds - dt
    end
    if ffbTimer>0.0 then
        ffbTimer=ffbTimer-dt
        if ffbTimer<=0.0 then
            ac.setFFBMultiplier(lastFFB)
        end
    end

    if afterRace>0.0 then
        afterRace = afterRace-dt
        if afterRace>0.0 then
            aclogo:setPosition( ac.getCameraPosition() + ac.getCameraForward() * 0.5 )
            aclogo:rotate(axisZ, -0.01)
        else
            aclogo:setVisible(false)
            GateSF:setVisible(false)
            if bAutoRestart and currActiveSection>-1 then
                JumpCustomSection(CustomSects[currActiveSection][1])
            else
                exitChallengeMode()
            end
        end
    end
    -- ac.debug("cameraPosition" , ac.getCameraPosition())
    -- ac.debug("cameraLook" , ac.getCameraForward())
end


ui.onExclusiveHUD(function (mode)
--     --if mode == 'game' then
--     -- @param callback fun(mode: 'menu'|'pause'|'results'|'replay'|'game'): 'debug'|boolean? @Callback function.

    if mode == 'pause' then
        bPaused = true
    else
        bPaused = false
        if not bRunning and not doEdit and mode == 'game' and currActiveSection>0 and #CustomSects>0 then
            if Countdown<=0.0 and not CountdownDone then
                --v=s/t   t=s/v
                local t = GetMetersToSplinePoint(car.splinePosition, CustomSects[currActiveSection][1]) / car.speedMs
                --ac.debug("t", t)
                if t<=3.05 then
                    Countdown = t-0.1
                    -- if not bRunning then timercurr=0.0 end
                    if bAudio then
                    BeepCountdown:play() end
                end
            end
        end
    end
--     if not doEdit and (mode == 'pause' or mode == 'replay')
--        and currActiveSection>-1
--        and (doTime or doTimeAI) and  -- Countdown<0.0 and
--        car and car.splinePosition>=CustomSects[currActiveSection][2]
--     then
--         ac.debug("break here1", "--")
--         --exitChallengeMode()
--         return true
--     end

end)


--         -- if CheckIfInsideINOUT(
--         --     CustomSects[currCustomSect][1],
--         --     CustomSects[currCustomSect][2],
--         --     car.splinePosition)

--         -- if isInside and not bRunning
--         -- then

--         --     -- if CustomSects[currCustomSect][7]==0 then
--         --     -- end

--         --     -- if not bRunning then timercurr=0.0 end
--         --     -- BeepCountdown:play():pause():setCurrentTime(0)
--         --     ac.debug("running", bRunning)
--         --     Countdown = -1.0
--         --     bRunning = true
--         --     afterCountdown = 1.0
--         --     timercurr = 0.0
--         --     if not bRunning then
--         --         local id = math.floor(CustomSects[currCustomSect][2]*#BIdeal)
--         --         if id==0 then id=1 end
--         --         GateSF:setVisible(true):setPosition(BCenter[id]):setRotation(axisX, BRoll[id]):setRotation(axisZ, BDir[id])
--         --     end

--         --     -- -- set Finish callback
--         --     -- ac.onTrackPointCrossed(0, CustomSects[currCustomSect][2], CrossedFinishSector(0, ))

--         --     return false -- dont block, let ac do its thing

--         -- end

--         -- handled by us, block AC ui
--         --return 'debug'
--         --return true
--     end

-- end)




LoadSectionsIni(sectionNamesINI)
CreateBorders()
LoadFilenames()
-- Countdown = 4.0
ac.setWindowOpen("WinTiming", false)
ac.setWindowOpen("WinTiming", false)
ac.setWindowOpen("WinEdit", false)

-- -- dodebug debugegug --- --
if #CustomSects>0 and physics.allowed() then
    currentFileID = 1
    currSelectedSection = 1
    ac.setWindowOpen("main", true)
    -- currCustomSect = 1

    --require("autostart.lua")
    -- currHoverSect = 1
    -- JumpCustomSection(CustomSects[currCustomSect][1])
    -- physics.setCarAutopilot(true, false)
end

--aclogo:setVisible(true):setRotation(axisZ, math.rad(90))
--aclogo:findMeshes("aclogo"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {64,64,64} )
--aclogo:findMeshes("aclogo"):setMaterialTexture('txDiffuse', 'color::#%x%x%x'   % {233,153,106} )
--aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {255,203,104} ):setMaterialProperty('ksEmissive', rgb(1,0.8,0.5)*0.35)
--aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {214,219,224} ):setMaterialProperty('ksEmissive', rgb(0.9,0.91,0.95)*0.25)
--aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {225,153,106} ):setMaterialProperty('ksEmissive', rgb(0.85,0.6,0.4)*0.25)
--aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {64,64,64} )
--aclogo:findMeshes("acchrome"):setMaterialTexture('txDiffuse', 'color::#%x%x%x' % {233,153,106} )
--aclogo:findMeshes("acglass"):setMaterialProperty('ksEmissive', rgb.colors.white*0.6)
--aclogo:findMeshes("acglass"):setMaterialProperty('ksEmissive', rgb(1,1,1)*0.25)
--aclogo:findMeshes("acglass"):setVisible(false)
