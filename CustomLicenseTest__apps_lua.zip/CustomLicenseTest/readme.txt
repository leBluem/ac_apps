1. Install and Run
==================
Only works in Hotlap mode. CSP 0.2.0 or higher needed.
After unpacking into AC folder, ingame goto AC-taskbar and click
"CustomLicenseTest". If you had it open last session, it should also be there
 next session.

2. ABOUT
========
With this lue app you can make your own little test sectors on any
part of a track, and then run Custom Challenges with its own timer.
Somewhat resembling that from GranTurismo.
Unfortunately this works only per car AND track. First default generic
challenge is auto-generated when first on a new track/layout. For any
new car you must generate the medal times yourself. Included some sounds,
anims, logos, ie. custom made AC logo in Gold/Silver/Bronze/bare metal.
One Challenge-Set (IB-7/IA-10) for Nordschleife is included. And only
the "BMZ Z4 GT3" has some medal-times done already.

There is an Overview window, a sector editor and a timing window.
You should only see one at a time.

When a Challenge is running you have 4 buttons on the top left:
-goto previous/next challenge
-restart/exit current challenge
Delta display against your own record.

Recomended CSP new-UI scale: 100%

Note (!!!) that while the timing window is visible,
it will fill up the top half of your screen,
maybe blocking apps behind it.

Uses some fonts and sounds from GT7 HUD. thx @Inori GC.
Thx @Damgam for feedback, @Yokai for some small code parts.




3. FILES USED
=============

example car/track used below:
car    : ks_mazda_mx5_cup
track  : ks_nordschleife
layout : nordschleife
_ext   : _gt7

a. dataSections\
----------------
Challenges/Sections are configured in 2 files in two different
directories in the app directory.

default section file: dataSections\ks_nordschleife_nordschleife.ini
custom section file_: dataSections\ks_nordschleife_nordschleife_gt7.ini

b. dataMedals\
--------------
Medal files

default medal file__: dataMedals\ks_nordschleife_nordschleife_ks_mazda_mx5_cup.ini
custom medal file___: dataMedals\ks_nordschleife_nordschleife_gt7_ks_mazda_mx5_cup.ini

c. dataPB\
----------
Personal Best (PB) times are stored per car in an extra folder, ie:

personal best file__: dataPB\ks_mazda_mx5_cup.ini

Sections in that file store Records and Split-Times in this format:
[track[_layout]_sectorID]{_ext}, ie:

[ks_nordschleife_nordschleife_SECTOR_0]
TIME=...
DATA=...

for the 2nd Challenge file for Nordschleife included:
[ks_nordschleife_nordschleife_gt7_SECTOR_0]


If you would like to donate smth: https://www.patreon.com/leBluem
