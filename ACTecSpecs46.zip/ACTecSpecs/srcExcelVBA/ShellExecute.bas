Attribute VB_Name = "ShellExecute"
Option Explicit

Public tmpFileName As String

#If VBA7 Then
    ' --- API declarations, 64-bit safe ---
    Private Declare PtrSafe Function CloseHandle Lib "kernel32" ( _
        ByVal hObject As LongPtr) As Long

    Private Declare PtrSafe Function GetExitCodeProcess Lib "kernel32" ( _
        ByVal hProcess As LongPtr, _
        lpExitCode As Long) As Long

    Private Declare PtrSafe Function CreateProcessA Lib "kernel32" ( _
        ByVal lpApplicationName As String, _
        ByVal lpCommandLine As String, _
        ByVal lpProcessAttributes As LongPtr, _
        ByVal lpThreadAttributes As LongPtr, _
        ByVal bInheritHandles As Long, _
        ByVal dwCreationFlags As Long, _
        ByVal lpEnvironment As LongPtr, _
        ByVal lpCurrentDirectory As String, _
        lpStartupInfo As STARTUPINFO, _
        lpProcessInformation As PROCESS_INFORMATION) As Long

    Private Declare PtrSafe Function WaitForSingleObject Lib "kernel32" ( _
        ByVal hHandle As LongPtr, _
        ByVal dwMilliseconds As Long) As Long
#Else
    Private Declare Function CloseHandle Lib "kernel32" ( _
        ByVal hObject As Long) As Long

    Private Declare Function GetExitCodeProcess Lib "kernel32" ( _
        ByVal hProcess As Long, _
        lpExitCode As Long) As Long

    Private Declare Function CreateProcessA Lib "kernel32" ( _
        ByVal lpApplicationName As String, _
        ByVal lpCommandLine As String, _
        ByVal lpProcessAttributes As Long, _
        ByVal lpThreadAttributes As Long, _
        ByVal bInheritHandles As Long, _
        ByVal dwCreationFlags As Long, _
        ByVal lpEnvironment As Long, _
        ByVal lpCurrentDirectory As String, _
        lpStartupInfo As STARTUPINFO, _
        lpProcessInformation As PROCESS_INFORMATION) As Long

    Private Declare Function WaitForSingleObject Lib "kernel32" ( _
        ByVal hHandle As Long, _
        ByVal dwMilliseconds As Long) As Long
#End If

' --- Types ---

#If VBA7 Then
    Private Type STARTUPINFO
        cb As Long
        lpReserved As String
        lpDesktop As String
        lpTitle As String
        dwX As Long
        dwY As Long
        dwXSize As Long
        dwYSize As Long
        dwXCountChars As Long
        dwYCountChars As Long
        dwFillAttribute As Long
        dwFlags As Long
        wShowWindow As Integer
        cbReserved2 As Integer
        lpReserved2 As LongPtr
        hStdInput As LongPtr
        hStdOutput As LongPtr
        hStdError As LongPtr
    End Type

    Private Type PROCESS_INFORMATION
        hProcess As LongPtr
        hThread As LongPtr
        dwProcessId As Long
        dwThreadId As Long
    End Type
#Else
    Private Type STARTUPINFO
        cb As Long
        lpReserved As String
        lpDesktop As String
        lpTitle As String
        dwX As Long
        dwY As Long
        dwXSize As Long
        dwYSize As Long
        dwXCountChars As Long
        dwYCountChars As Long
        dwFillAttribute As Long
        dwFlags As Long
        wShowWindow As Integer
        cbReserved2 As Integer
        lpReserved2 As Long
        hStdInput As Long
        hStdOutput As Long
        hStdError As Long
    End Type

    Private Type PROCESS_INFORMATION
        hProcess As Long
        hThread As Long
        dwProcessId As Long
        dwThreadId As Long
    End Type
#End If

Public Const NORMAL_PRIORITY_CLASS As Long = &H20&
Private Const INFINITE As Long = -1&

Public Sub RunEXEAndWaitForClose(ByVal Program As String, ByVal Args As String)
    Dim proc As PROCESS_INFORMATION
    Dim start As STARTUPINFO
    Dim Ret As Long
    Dim cmdline As String

    start.cb = Len(start)

    cmdline = Program & " " & Trim$(Args)

    Ret = CreateProcessA(vbNullString, cmdline, 0&, 0&, 1&, _
                         NORMAL_PRIORITY_CLASS, 0&, vbNullString, start, proc)

    Ret = WaitForSingleObject(proc.hProcess, INFINITE)

    Call GetExitCodeProcess(proc.hProcess, Ret)
    Call CloseHandle(proc.hThread)
    Call CloseHandle(proc.hProcess)
End Sub


