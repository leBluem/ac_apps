original: https://www.racedepartment.com/downloads/g-force-and-tyre-data-app.8348/

Written by J Richter - panarace970@gmail.com

Version 1.0, Dec 2015
Changes in 1.1, January 2016:
- show the tyre usage with 2 decimal points (if below 100.0%)
- allow to configure which parts to display (gforce, tyres, pedals)

How to customize: edit gforce.py and change the following lines
---
# change as desired
fontSize   = 16
opacity    = 0
showHeader = 0

showGForce = 1
showTyres  = 1
showPedals = 1
---

E.g. if you don't want to see the g-force, change it to
showGForce = 0


Update v1.2 - by leBluem aka PleaseStopThis, Jan 2020

added timer for hiding buttons, they re-appear with click on app
exposed some variables to CM app config and changes ingame are saved
added neat little z-force indicator (vertical up/down force)
buttons:
-(from original: -/+ buttons for g-force multiplier):
-button "r" = g-max reset
-button "z0"/"z1"/"z2" = off/inplace/centered
 > display of vertical g-force (z)
 > as smaller extra ball in two variations
-button "c0"/"c1"/"c2" = toggle 3 color schemes
-button "t0"/"t1"/"t2"/"t3" = toggle 4 background images
-buttons "-/+" = app opacity
-buttons "-/+" = app size
buttons on the left side to toggle all modules and values

Update v1.3 - by leBluem, Jan 2020

fixed inconsistency btw CM ui and actual settings
tyre values are colored now, if you choose a color preset
added trailing for geforce, it has a length option (0..400), off by default
added trailing transparency value
Beware! too much trailing length can be taxing on FPS!

Update v1.4 - by leBluem, Jan 2020

added unit-switches for tyre-pressure and temperature (bar/psi and °C/°F)
added smoothing for g-force, 0..20, default=10
raised max trail-length to 1000 (its not that taxing on FPS ;) )

if you update from a previous version, please use "Reset" button in
CM->settings->APPs->"g-force and tyre data app"


Update v1.5 - by leBluem, Jan 2020
-fixed temp-unit save/load
-added option to display only max g-force
-added option for ffb/ffb-max value
-value readings are displayed gradually now



So PanaRace970 urged me to put this out as mine, this is the original:
https://www.racedepartment.com/threads/g-force-and-tyre-data-app.115100/

Update v2.0 - by leBluem, mar 2022
-made gforce display fancier, added unit display in background
 (90% accurate, dont use for serious physics plots, rounding/scaling might be off when scaled up a lot)
-max displayed G saved per car
-ffb text display now independent from the rest
--with new feature "reset on Numpad +/-" you can easily adjust user FFB mult
--off by default: reset max/ffb values on NumPad +/- (actually it resets on user FFB mult change, so dont use it with ie "FFB-Clip" app)
Inspired by this https://www.youtube.com/watch?v=bYp2vvUgEqE
-added traction zones, based on gforce when values go above some threshold
--values are: TyreSlip, Mz, SlipRatio, NDslip, SlipAngle (green, yellow, orange, red, blue)
--arcade mode (moving zones)
--transparency option

v2.1
-fixed scaling issues
-automatic g force scaling, off after you change manually, also on next session with the car
-added ffb/g-force max reset in pits

v2.2
-fixed saving max displayed gforce with fractions
-colored traction zones dont overshoot max gforce

v2.3
-fixed color breaking bug

v2.4
-fixed overshoot, now for real
-text-opacity now also applies to 1/2/3/4g text and circle

v2.5
-fixed y traction circles only updating in one direction

v2.6
-added separate opacity control for bg 1/2/3/4g graphics
-fixed small issue with z-force having its history drawn

v2.7
-added a live history to g-force plot, at 0% opacity by default (only with CSP)
-added Steering angle vs G-Force graph in extra window (with a fake background) + live history (live history only with CSP)
--has same smoothing/trails etc options as g-force plot

-saves 2 transparent images pngs after a session as
  apps\python\GForce\result_gforce.png
  apps\python\GForce\result_steer_gforce.png

-both histories fade to grey slowly (not in the "result...png")

-make "steer_gforce_blanc.png" as big as you want (atm 1024²)
--the app will use that resolution for "result...png"s (all its content will be lost)

-live history uses new csp funtions to create and draw in texture buffers

-used for saving and painting on images: python PIL image library for python3.3 (apps\system\PIL, included https://pypi.org/project/Pillow/2.4.0/)

(install: open archive, go one folder down, unpack the two folders "apps"/"content" into your "assettocorsa" folder, or use jsgme)

Note1: atm maxSteerAngle displayed depends on how big the overall appsize ingame is
Note2: and no, results are not filled with data when the windows are not visible (clicked off in AC-taskbar)
Note3: you should keep "MAX-g" during a session or results will be wonky

v2.8
-added "Reset all when in pits" option in CM, was always on before (not for ingame UI)
-added 3 data-modes / graph types: "Speed vs RPM", "Speed vs Lon. g-force" and "RPM vs Torque/Power"
-2nd graph window has its own options now (history-dotsize will be used in g-force plot too, same for "text on/off" option in g-force window, used for 2nd graph too)
--control for max. displayed value per datamode
-history-dotsize for result PNGs only in first line of 'Gforce.py'
-graphics are drawn also when when app-windows are off
--the app will still "Save 5 PNG images"  (when enabled) and draw in background
--"save pngs now" will add a timestamp ti filenames, so they will be kept (unlike previous results,
they will all be overwritten btw sessions)
--with traction circles enabled you get the 5th result image (4 when off/invisible)
-vanilla AC: no history ingame, so 2nd window is pretty useless,but results will be there, but not the "RPM/Torque/Power" png
(install: open archive, go one folder down, unpack the two folders "apps"/"content" into ac folder)
(after install restart CM to see new options)

v2.9
-out-source'd the 2 graph window into this:
  leB-yatt: https://www.racedepartment.com/downloads/lebluems-yet-another-telemetry-tool-leb_yatt.57941/
-added option for G-ball size
-adjusted shape of traction circles

v3.0
-fix on very first start without settings.ini
-turned off auto-adjusting to max g-force entirely (line 16 userChanged=True)
--default for every new car is in CM options: "*G-Force dafeult max"

v3.1
-fixed saving images

v3.2
-added feature to draw a line from center to current g-force ball
--3 modes: off, diagonal, perpendicular, both
-while at it: adjusted center of 1/2/3 BG-graphics, was off by 2,1 pixel (x/y)
-fixed g-bars filling the whole screen on car impact

v3.3
-fixed centerlines with trails enabled
-separated options into extra window
