Install:
Unpack archive to AC root. Icons included.

All options in ContentManager UI are also available in-game, click the app and some controls appear.
Its quite heavy on performance
 - maybe dont use STEPPING=1, but higher values
 - dont use more than 300 for "back" and "forward" tracking values

v1.1
-fixed flooding log file with vanilla AC (without csp), still showing nothing then

v1.2
-removed importing unneeded/missing library

v1.3
-added "base_altitudes.ini" for vanilla AC, already includes original track heights
-more options, nicer drawing
-more performance with CSP (buffered image)

v1.4
-fixed small drawing issue for line mode
-fixed not saving color mult
-added full map view
-added b/w mode with colormult=0

v1.5
-fixed div by zero error with some bad/fake ai line files, like on EndlessFloor, destroying ui, sorry for that

v1.6
-added option for marker representing the pitch of the car
Cmark = car mark
Tmark = track mark (half transparent)
