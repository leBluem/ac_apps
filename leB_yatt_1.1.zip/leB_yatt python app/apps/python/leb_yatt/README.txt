v0.5 - intitial version after outsourcing from v2.8 of
g-force app https://www.racedepartment.com/downloads/g-force-and-tyre-data-app.49485/update/100870/

-6 data-modes / graph types:
--Steering angle vs lateral g-force
--Speed vs RPM
--Speed vs Lon. g-force
--RPM vs Torque/Power
--lap overview with steering/Throttle/brake/gear/speed vs track progress
--track heat-map view with throttle/brake (left/right)

-modes 5 and 6: there are 3(2) scroll-bars to switch btw older laps
--1st and 2nd will switch btw laps recorded in current session
--3rd scroll-bar loads older laps from previous sessions

-there is an option for saving all laps as images per track+layout/car
! be carefull, this leads to a lot of files saved!
--when "False", then all result images will be overwritten next session (some old laps may still be there)
...apps\python\leb_yatt\laps_images\
--when "True", then completed laps will be saved in this directory:
...apps\python\leb_yatt\laps_images\trackname\layoutname\
--filename will look like this:
  date     time  type car        lap# timeMS.png
  ie:
  23-01-22 19_30 race bmw_z4_gt3 Lap1 30203.png

-also works in replay - if you dont skip around
--also in fast forward, at x2 or x4 is ok, not so well if at x16

-graphics are drawn also when app-windows are off
--the app will still save all laps (when enabled) and draw in background
--"save pngs now" will add a timestamp to filenames

-result image-size is based on "plot_blanc.png" and "steer_gforce_blanc.png"
--for the result-heatmap size see line 6 of 'leb_yatt.py':
--png_size=1240 # (default)

-dotsize for saved result PNGs only in line 4 of 'leb_yatt.py'

-vanilla AC: no history ingame, but results will be saved, but not the "RPM/Torque/Power" png, thats only linear :(

(install: open archive, go one folder down, unpack the two folders "apps"/"content" into ac folder)

v0.6
-fixed spazzing out on end of a-b tracks
-added 6th datamode: aero/suspensions
-switched 5th datamode for heatmap to display speed/lateral g-force (was throttle/brake before, line 7 in .py, set gHeatmapMode=0 to revert back)

v0.7
-fixed values for hybrid/electric cars

v0.8
-final

v0.9
-fixed fullscreen/overlay control
-added SlipAngle vs SlipRatio graph as data mode 7
(replaces messy suspension mode from v0.8, line 30 in code: AEROSUSP_SLIP_MODE=0)

v1.0
-added button for showing overlay control
-added SlipAngle vs SlipRatio graph as data mode 7

v1.1
-fixed on tracks without ai line
