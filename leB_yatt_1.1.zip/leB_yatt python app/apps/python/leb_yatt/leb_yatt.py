# leb_yatt v1.1
# lebluem's yet another telemetry tool

histDotSizePNG  = 1    # not available in ingame ui
png_size        = 1240   # default is 1240

gHeatmapMode    = 1   ### 0=throttle/brakes   1=speed/latg-force
png_mapoffset   = 40
histDotSize     = 4.0    # can be changed in ingame UI
dataTimerUpdate = 0.01   # with csp>=0.1.78 or smth and in replay it will be set to replay frametime

# fadeoutime      = 0.179247   ### ui only, not on result pngs
fadeoutime      = 0.79247   ### ui only, not on result pngs

sCustomFontName = 'Consolas'
#sCustomFontName = 'Arial'
#sCustomFontName = 'Segoe UI'
#sCustomFontName = 'Segoe UI; Weight=Light'
### you can try some others if curious
#sCustomFontName = "Ticking Timebomb BB"      # font might be installed from some other app
#sCustomFontName = "Digital-7"                # font might be installed from some other app
#sCustomFontName = "Strait"                   # font might be installed from some other app
##############################################################
# bSaveAllLaps=True    timestamped laps saved under
# ...apps\python\leb_yatt\laps_images\trackname\layoutname
# bSaveAllLaps=False   all results named the same as last session, saved to
# ...apps\python\leb_yatt\laps_images\



bSaveAllLaps     = False
bClosedTrack = True
laps_images_path = ''
lasttyres = ''
drivername = ''
lastaiid=-1
mapscale = 1.0
box_w=0
box_w2=0
box_h=0
box_h2=0
offset=0
top=0
wsub=-1
hsub=wsub
wmain=-1
hmain=wmain
BBlock=False
flag=True
fullscreenflag=False
bDAMPERsON = True
bSuspensionForceEnabled = True
bShowSuspTravel = True
savedFiles=[]
savedFilesHeat=[]
savedFilesAero=[]
savedFilesSlip=[]
foundFiles=[]
foundFilesHeat=[]
foundFilesAero=[]
foundFilesSlip=[]
LapInvalidated=False
allowedNumberOfTyresOut=2
l_info = 0
Rake = 0.0
pitch = 0.0
roll = 0.0
cgHeight = 0.0
RideHeight=[0.0,0.0]
RideHeightMax=[0.100,0.100]
RideHeightMin=[0.0,0.0]
carCoordinates = [0.0,0.0,0.0]
dampTravel = [0.0,0.0,0.0,0.0]
susForce = [0.0,0.0,0.0,0.0]
suspMaxTravel = [0.0,0.0,0.0,0.0]
suspTravel = [0.0,0.0,0.0,0.0]
StaticDeflection=[0.0,0.0,0.0,0.0]
maxDampTravFRONT =-100000.0
minDampTravFRONT = 100000.0
maxDampTravREAR  =-100000.0
minDampTravREAR  = 100000.0
maxSuspTravFRONT =-100000.0
minSuspTravFRONT = 100000.0
maxSuspTravREAR  =-100000.0
minSuspTravREAR  = 100000.0
maxSuspForceFRONT=-1000000.0
minSuspForceFRONT= 1000000.0
maxSuspForceREAR =-1000000.0
minSuspForceREAR = 1000000.0
baseAEROdens = -1.0
maxDownForce=5000.0
maxDrag=100.0
AEROCDv=0.0
AEROCLf=0.0
AEROCLr=0.0
AERODownforceF=0.0
AERODownforceR=0.0
AERODrag=0.0
turboTorque=0.0
jsonPowerCurveMax=0.0
jsonTorqueCurveMax=0.0
thread = 0
bCPhysCarcassEnabled = False
bNewTyreParams       = False
bCPhysicsActive      = False
bNewTyreParams       = False
PRACTICAL_TEMP_RATIO = -1000.0
ac_Grip     = [0.0,0.0,0.0,0.0]
tempFtemp=[]
tempRtemp=[]
tempFgrip=[]
tempRgrip=[]

import ac, acsys, sys, os, io, platform, traceback, math
import json, time, threading, configparser, struct
import inspect, pickle
# , codecs, pickle, collections, functools
from datetime import datetime

os.environ['PATH'] = os.environ['PATH'] + ";."
if platform.architecture()[0] == "64bit":
  sysdir='apps/python/leb_yatt/DLLs/stdlib64'
else:
  sysdir='apps/python/leb_yatt/DLLs/stdlib'
sys.path.insert(0, sysdir)
import ctypes
from ctypes.wintypes import RECT
from gfsim_info import info

from lebylt_acd import ACD, get_tire_name, get_tire_namelong, get_val_from_lut, get_float, get_tire_id_max, get_tire_name_by_id, get_tire_id
global ACD_FILE

sys.path.insert(0, 'apps/python/system')
# https://pypi.org/project/Pillow/2.4.0/
from PIL import Image, ImageDraw, ImageOps, ImageFont, ImageEnhance

#try:
#  #ac.log(str(vars(ac)))
#  #ac.log(str(inspect.getmembers(ac)))
#  #ac.log(str(inspect.getsource(ac)))
#  # ac.log(str(inspect.getmembers(ac)))
#  # for fname in dir(ac):
#  #   if not '__' in fname:
#  #     f = getattr(ac,fname)
#  #     ac.log(fname) ##+  + ' - ' + str(inspect.getargspec(f)))
#  #     ##ac.log(str(inspect.signature(f)))
#  #     ##ac.log(str(inspect.getcallargs(f())))
#  #     ##ac.log(str(inspect.getargs(f())))
#except:
#  ac.log("leb_yatt error :" + traceback.format_exc())

bCSPActive = False
if 'ext_createRenderTarget' in dir(ac):
  bCSPActive = True
# ac.log('leb_yatt app: bCSPActive=' +str(bCSPActive))

appSettingsPath = "apps\\python\\leb_yatt\\settings\\settings.ini"
appSettingsDefaultsPath = "apps\\python\\leb_yatt\\settings\\settings_defaults.ini"

gScreenW = 1920
gScreenH = 1080
# find Assetto Corsa window and get its width and height to place the Slot editor right.
hWnd = ctypes.windll.user32.FindWindowW(None, "Assetto Corsa")
if hWnd != None:
    rect = RECT() ### ctypes.wintypes.RECT()
    ctypes.windll.user32.GetClientRect(hWnd, ctypes.byref(rect))
    gScreenW = rect.right - rect.left
    gScreenH = rect.bottom - rect.top
# ac.log('leb_yatt: Screen resolution: %ix%i'%(gScreenW, gScreenH))
dblclickTimer = 0.0
dblclickTimerON = False
dblclickCounter = 0

ac_status = -1
ac_session = -1

myImageMap = 0
canvasMap = 0
myImageMapOrig = 0

timerIMG = 0.0
timerIMG2 = 0.0
PNGmultGF = 1.0
PNGmultSF = 1.0
datagf=0
datagfperlap=0
thread = 0
imgsloaded = False
DoResetOnUSERFFBChange = False
ResetOnSessionRestart  = True
g_Reset_When_In_Pits   = True
firstClearDone = False
speedDiv = 1
iCounter = -1

rtIndexSP_orig = -1
rtIndexSP = -1
rtIndexSP_bg = -1
rtIndexSP_bg1 = -1
rtIndexSP_bg2 = -1
rtIndexAS_orig = -1
rtIndexAS = -1
rtIndexAS_bg = -1
rtIndexHeat = -1
rtIndexHeat_orig = -1
rtIndexSF = -1
rtIndexSF2 = -1
rtIndexSF3 = -1
rtIndexSF4 = -1
rtIndex0 = -1
myImageSF=0
myImageSF2=0
myImageSF3=0
myImageSF4=0
canvasSF=0
canvasSF2=0
canvasSF3=0
canvasSF4=0

myImageSP=0
myImageSP_bg=0
myImageSP_bg1=0
myImageSP_bg2=0
canvasSP=0
canvasSP_bg=0
canvasSP_bg1=0
canvasSP_bg2=0

myImageAS=0
myImageAS_bg=0
canvasAS=0
canvasAS_bg=0
canvasAS_bg1=0
canvasAS_bg2=0

# # # # #lastTime = 100000000
# lapData=[]
lapTimes=[]
lapTimesFlags=[]
OverallLaps = 0
lastTime = -1
act_idx2=0
SlipAng_Front=0
SlipAng_Rear=0
ac_TempMult=[0.0,0.0,0.0,0.0]
ac_LocalV=[0.0,0.0,0.0]
maxtemp = 1.0
lastSessonTime=0.0
bRecording    = False
jsonPower=0.0
jsonTorque=0.0
currTime=0
minioffset = 0
minioffset2 = 0
showLabels     = True
showHeader     = False
zForce         = False
centeredZForce = False
bScaleFixed    = True
gforce_fac     = 2
texid          = 2
gColor         = 1
gSizeGforceW   = 100
gSizeGforceH   = 100
histCount      = 0
histVisi       = 0
smoothValue    = 10
gOpacityBG  = 0
gOpacityFG     = 100
gOpacityTx     = 100
ghistT   = 70 # history transparency
f1=0
txcnt=-1
txcnt2=-1

gforcesteer_x_act = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
gforcesteer_y_act = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
###
VisiMult        = 1
dataTimer       = 0.0

speedRange = []
Gears    = []
geardatacount = 0
geardatacountdone = 0

valx=0.0
valy=0.0
valxx=0.0
valyy=0.0
valxxx=0.0
valyyy=0.0
valxxxx=0.0
valyyyy=0.0
lvalx1  =-1.0
lvaly1  =-1.0
lvaly2  =-1.0
lvaly3  =-1.0
lvaly4  =-1.0
lvaly5  =-1.0
lcurrPoT=0.5
lcurrPoT2=0.5
lastLap=-2
lastLap2=-2

#####################################################################
base_gforce_fac          = 2.0
max_gforce_fac = base_gforce_fac
lastCarFFB = 0.0

maxTorque=-1.0
maxPower=0.0
currTorque=0.0
currPower=0.0
MaxPowDiv=0.0
minRPMdisplayed=0

fontSize    = int(float(gSizeGforceW/7.0))
fontSize2   = int(float(gSizeGforceW/12.0))

maxHistCount    = 500
lastXYZ   = [[111.0,111.0,111.0] * maxHistCount for i in range(maxHistCount)]
lastXY    = [[111.0,111.0]       * maxHistCount for i in range(maxHistCount)]

sCar = ""
sTrack = ""
sLayout = ""
globalprefix = ""
sFileAI = ""
currID  = 0
currCar = 0
isInPits = False
bDoneResetInPits = False

appWindowLeB_YATT = 0
appWindowOverlayControls = 0
l_laps2 = 0
l_laps3 = 0
b_gforceDec = 0
b_gforceInc = 0
b_showLabels = 0
b_DataEnabled = 0
b_saveResultsNow = 0
b_reset = 0
b_Control = 0

b_doResetOnFFB = 0
b_smoothValueUp = 0
b_smoothValueDn = 0
b_TrailDn = 0
b_TrailUp = 0
b_TrailSmoothDn = 0
b_TrailSmoothUp = 0
b_texid = 0
b_vertToggle = 0

b_SaveAllLaps = 0
b_FullScreen = 0
b_color = 0

b_transpTxUp = 0
b_transpTxDn = 0
b_transpFGUp = 0
b_transpFGDn = 0
b_transphistUp = 0
b_transphistDn = 0
b_DotSizeDec = 0
b_DotSizeInc = 0

b_subSizeWDec = 0
b_subSizeWInc = 0
b_subSizeHDec = 0
b_subSizeHInc = 0
b_subtranspBGUp = 0
b_subtranspBGDn = 0
b_subSteerMaxUp = 0
b_subSteerMaxDn = 0
b_subdataModeUp = 0
b_subdataModeDn = 0
b_laps1=0
b_laps2=0
b_laps3=0


maxdatamode = 7
gDataMode   = 0 # 0 = Steering vs lat. g-force
                # 1 = speed vs rpm         with gears colored different
                # 2 = speed vs long gforce with gears colored different
                # 3 = rpm vs power
                # 4 = rpm vs throttle
                # 5 = steering/throttle/brake/speed
                # 6 = aero/suspensions
                # 7 = Slip angel/SlipRatio

gSteeringNormalizer = 90
maxSteerReached = 0
gSpeedNormalizer = 300
maxSpeedReached = 0
maxSpeed = 0
maxRPMReached = 0
maxRPM = -1

TempID=0
PressID=0

userChanged=False
bActiveTimer = True
fTimer  = 5.0
fTimer2 = 0.0

texture_dot       = 0
texture_dot2      = 0
texture_circle    = 0

ac_wspeed         = { "FL" : 0.0, "FR" : 0.0, "RL" : 0.0, "RR" : 0.0 }
ac_SR             = [0.0,0.0,0.0,0.0]
ac_SA             = [0.0,0.0,0.0,0.0]
ac_SAx            = [0.0,0.0,0.0,0.0]
ac_SRy            = [0.0,0.0,0.0,0.0]
ac_NdSlip         = [0.0,0.0,0.0,0.0]
ac_press          = [0.0,0.0,0.0,0.0]
ac_temp           = [0.0,0.0,0.0,0.0]
ac_dirt           = [0.0,0.0,0.0,0.0]
ac_carc           = [0.0,0.0,0.0,0.0]
ac_Mz             = [0.0,0.0,0.0,0.0]
tyreTempC         = [0.0,0.0,0.0,0.0]
ac_speed          = 0
ac_throttle       = 0
ac_brake          = 0

gforce_x=0
gforce_y=0
gforce_z=0
ac_ffb=0
AI_LINE      = []
BORDER_RIGHT = []
BORDER_LEFT  = []
BORDER_RIGHT2 = []
BORDER_LEFT2  = []
BORDER_RIGHT3 = []
BORDER_LEFT3  = []
BORDER_RIGHT4 = []
BORDER_LEFT4  = []

# tyre color palette
colorPal1 = []
colorPal2 = []
colorPal3 = []
colorPal4 = []
colorPal5 = []
colorPal6 = []
currPal = colorPal1
colors=256
colorstep=colors/3
for x in range(colors):
    r = 0
    g = 0
    b = 0
    if x<=colorstep:     # < 33%
        valperc = (colorstep-x) / 3 / colorstep
        r = 0
        g = 255 * valperc*3
        # g = 255 * (colors-x) ## - 255 * valperc*3/3
        # b = 255 - (255 * valperc*3/2) *(colors-x)/colors
        g = 255 * (1-valperc*3)
        b = 255 *    valperc*8
        #b = 128 *    valperc*6
    elif x<=colorstep*2: # < 66%
        valperc = (x - colorstep) / 3 / colorstep
        r = 255 * valperc*3
        g = 255# * valperc/3
        #Rb = 128 * (1-valperc*3)
    else:               # < 100%
        valperc = (x - colorstep*2) / 3 / colorstep
        r = 255
        g = 255 - 255 * valperc*3
        b = 0
    d=1.0
    #if x<127:
    d=min(1.0, 0.35 + (x/255)*(x/255) )
    color1=[(r/255*d), (g/255*d), (b/255*d)]
    color2=[(r/512), (g/512), (b/512) ]
    color3=[((1-b)/255),((g)/255), ((1-r)/255) ]
    color4=[((b)/255),((g)/255), ((r)/255) ]
    color5=[((g)/255),((g)/255), ((g)/255) ]
    color6=[((g)/255),((1-g)/255), ((1-g)/255) ]
    colorPal1.append(color1)
    colorPal2.append(color2)
    colorPal3.append(color3)
    colorPal4.append(color4)
    colorPal5.append(color5)
    colorPal6.append(color6)

##########################################################################

class FontMeasures:
  def __init__(self, name, italic, bold, size, ratio, distance, heightCompensation, widthCompensation):
    self.n = name					#font name
    self.i = italic					#font italic
    self.b = bold					#font bold
    self.s = size					#font multiplier for one pixel height
    self.r = ratio					#font width compared to height
    self.d = distance				#font distance between the leftmost point of one letter and another, avareage
    self.h = heightCompensation		#font height offset to put it centered vertically
    self.w = widthCompensation		#font width offset to put it centered horizontally
    self.f = 0						#font object to be used in rendering
    return

class ExtGL:
  CULL_MODE_FRONT = 0
  CULL_MODE_BACK = 1
  CULL_MODE_NONE = 2
  CULL_MODE_WIREFRAME = 4
  CULL_MODE_WIREFRAME_SMOOTH = 7
  BLEND_MODE_OPAQUE = 0
  BLEND_MODE_ALPHA_BLEND = 1
  BLEND_MODE_ALPHA_TEST = 2
  BLEND_MODE_ALPHA_ADD = 4
  BLEND_MODE_MULTIPLY_BOTH = 5
  FONT_ALIGN_LEFT = 0
  FONT_ALIGN_RIGHT = 1
  FONT_ALIGN_CENTER = 2

def onGforceDec(dummy, variable):
    global max_gforce_fac, base_gforce_fac, gforce_fac, userChanged
    userChanged=True
    if base_gforce_fac>1.1:
        base_gforce_fac-=0.5
    max_gforce_fac = base_gforce_fac
    gforce_fac = max_gforce_fac
    appResize()

def onGforceInc(dummy, variable):
    global max_gforce_fac, base_gforce_fac, gforce_fac, userChanged
    userChanged=True
    if base_gforce_fac<5:
        base_gforce_fac+=0.5
    max_gforce_fac = base_gforce_fac
    gforce_fac = max_gforce_fac
    appResize()


def appsubBGTransparencyUp(*args):
  global gOpacityBG
  gOpacityBG += 10
  if gOpacityBG>100:
    gOpacityBG = 100
  appResize()

def appsubBGTransparencyDn(*args):
  global gOpacityBG
  gOpacityBG -= 10
  if gOpacityBG<0:
    gOpacityBG = 0
  appResize()

def appDotSizeUp(*args):
  global histDotSize
  histDotSize += 1
  if histDotSize>20:
    histDotSize = 20
  appResize()

def appDotSizeDn(*args):
  global histDotSize
  histDotSize -= 1
  if histDotSize<1:
    histDotSize = 1
  appResize()

def appSteerMaxDec(*args):
  global gSteeringNormalizer, gSpeedNormalizer, gDataMode, maxRPM, minRPMdisplayed
  if gDataMode==1 or gDataMode==2 or gDataMode>=4:
    gSpeedNormalizer-=10
    if gSpeedNormalizer<100:
      gSpeedNormalizer=100
    onReset()
    appResize()
  elif gDataMode==0:
    gSteeringNormalizer = gSteeringNormalizer - 5
    if gSteeringNormalizer<5:
      gSteeringNormalizer = 5
    onReset()
    appResize()
  elif gDataMode==3:
    minRPMdisplayed -= 250
    if minRPMdisplayed<0:
      minRPMdisplayed=0
    onReset()
    appResize()

def appSteerMaxInc(*args):
  global gSteeringNormalizer, gSpeedNormalizer, gDataMode, minRPMdisplayed
  if gDataMode==1 or gDataMode==2 or gDataMode>=4:
    gSpeedNormalizer+=10
    if gSpeedNormalizer>800:
      gSpeedNormalizer=800
    onReset()
    appResize()
  elif gDataMode==0:
    gSteeringNormalizer = gSteeringNormalizer + 5
    if gSteeringNormalizer>180:
      gSteeringNormalizer = 180
    onReset()
    appResize()
  elif gDataMode==3:
    minRPMdisplayed += 250
    if minRPMdisplayed>int(maxRPM/3*2):
      minRPMdisplayed=int(maxRPM/3*2)
    onReset()
    appResize()

def appDataModeDec(*args):
  global gDataMode, maxdatamode, lastXYZ, lastXY, maxHistCount, rtIndexAS
  prevDataMode = gDataMode
  gDataMode = gDataMode - 1
  if gDataMode<0:
    gDataMode = 0
  lastXYZ    = [[111.0,111.0,111.0] * maxHistCount for i in range(maxHistCount)]
  lastXY     = [[111.0,111.0      ] * maxHistCount for i in range(maxHistCount)]
  if prevDataMode==7:
    #ac.ext_clearRenderTarget(rtIndexAS)
    appPrepareImages()
  appResize()
  on_click_anybutton()

def appDataModeInc(*args):
  global gDataMode, maxdatamode, lastXYZ, lastXY, maxHistCount, rtIndexAS
  prevDataMode = gDataMode
  gDataMode = gDataMode + 1
  if gDataMode>maxdatamode:
    gDataMode = maxdatamode
  lastXYZ    = [[111.0,111.0,111.0] * maxHistCount for i in range(maxHistCount)]
  lastXY     = [[111.0,111.0      ] * maxHistCount for i in range(maxHistCount)]
  if prevDataMode==6:
    #ac.ext_clearRenderTarget(rtIndexAS)
    appPrepareImages()
  appResize()
  on_click_anybutton()

def str2bool(v):
    return str(v).lower() in ("yes", "true", "t", "1")

def ondoResetOnFFB(*args):
    global DoResetOnUSERFFBChange
    DoResetOnUSERFFBChange = not DoResetOnUSERFFBChange
    # appResize()
    on_click_anybutton()

def getSetting(cfgdef, cfg, sect, value, valdef):
    res = valdef
    if cfgdef.has_option(sect, value):
        res = cfgdef[sect][value]
        if ';' in res:
            res = res.split(';')[0]
        if cfg.has_option(sect, value):
            res = cfg[sect][value]
            if ';' in res:
                res = res.split(';')[0]
    return str(res)

def get_numbers(s):
    result=""
    idx=0
    for l in s.strip():
        if l.isnumeric() or l=='.' or (idx<1 and l=='-'):
            result=result+l
        else:
            break
        idx+=1
    if result=="" or result=="-" or result==".":
        return ''
    return float(result)


def createSpinner(appWindow, text, value, x, y, width, height, rangeMin, rangeMax, step, visible = False):
    newSpinner = ac.addSpinner(appWindow, text)
    ac.setFontSize(newSpinner, 10)
    ac.setPosition(newSpinner, x, y)
    ac.setSize(newSpinner, width, height)
    ac.setRange(newSpinner, rangeMin, rangeMax)
    ac.setStep(newSpinner, step)
    ac.setValue(newSpinner, value)
    ac.setVisible(newSpinner, visible)
    return newSpinner



def comp_func(s1,s2):
    # 2023-01-22 19_30 mazda-mx5 Lap1 30203
    if not ' ' in s1[0] or not ' ' in s2[0]:
        return 1
    _,_,_,s41=s1[0].split(' ')
    _,_,_,s42=s2[0].split(' ')
    r = 1 if int(s41) > int(s42) else -1
    return r

def updateLap1():
  global appWindowLeB_YATT, laps_images_path, b_laps1, savedFiles
  id = int(ac.getValue(b_laps1))
  if gDataMode==4:
    if id>0 and id<len(savedFiles):
      ac.setBackgroundTexture(appWindowLeB_YATT, laps_images_path + savedFiles[id-1])
    else:
      ac.setBackgroundTexture(appWindowLeB_YATT, 'apps/python/leb_yatt/plot_blanc.png')
  else:
    ac.setBackgroundTexture(appWindowLeB_YATT, 'apps/python/leb_yatt/plot_blanc.png')

def updateLap2():
  global laps_images_path, b_laps2, savedFiles, l_laps2, savedFilesHeat, gDataMode, hsub, wsub, savedFilesAero, savedFilesSlip
  id = int(ac.getValue(b_laps2))
  if gDataMode==4:
    if id>0 and id<len(savedFiles):
      ac.setBackgroundTexture(l_laps2             , laps_images_path + savedFiles[id-1])
    else:
      ac.setBackgroundTexture(l_laps2             , 'apps/python/leb_yatt/plot_blanc.png')
  elif gDataMode==6:
    if id>0 and id<len(savedFilesAero):
      ac.setBackgroundTexture(l_laps2             , laps_images_path + savedFilesAero[id-1])
    else:
      ac.setBackgroundTexture(l_laps2             , 'apps/python/leb_yatt/plot_blanc.png')
  elif gDataMode==7:
    if id>0 and id<len(savedFilesSlip):
      ac.setBackgroundTexture(l_laps2             , laps_images_path + savedFilesSlip[id-1])
    else:
      ac.setBackgroundTexture(l_laps2             , 'apps/python/leb_yatt/plot_blanc.png')
  else:
    ac.setSize(l_laps2, min(hsub, wsub), min(hsub, wsub))
    if id>0 and id<len(savedFilesHeat):
      ac.setBackgroundTexture(l_laps2             , laps_images_path + savedFilesHeat[id-1])
    else:
      ac.setBackgroundTexture(l_laps2             , 'apps/python/leb_yatt/plot_blanc.png')

def updateLap3():
  global laps_images_path, b_laps3, l_laps3, foundFiles, foundFilesHeat, gDataMode, hsub, wsub, foundFilesAero, foundFilesSlip
  id = int(ac.getValue(b_laps3))
  if gDataMode==4:
    if id>0 and id<len(foundFiles):
      ac.setBackgroundTexture(l_laps3             , laps_images_path + foundFiles[id-1])
    else:
      ac.setBackgroundTexture(l_laps3             , 'apps/python/leb_yatt/plot_blanc.png')
  elif gDataMode==6:
    if id>0 and id<len(foundFilesAero):
      ac.setBackgroundTexture(l_laps3             , laps_images_path + foundFilesAero[id-1])
    else:
      ac.setBackgroundTexture(l_laps3             , 'apps/python/leb_yatt/plot_blanc.png')
  elif gDataMode==7:
    if id>0 and id<len(foundFilesSlip):
      ac.setBackgroundTexture(l_laps3             , laps_images_path + foundFilesSlip[id-1])
    else:
      ac.setBackgroundTexture(l_laps3             , 'apps/python/leb_yatt/plot_blanc.png')
  else:
    ac.setSize(l_laps2, min(hsub, wsub), min(hsub, wsub))
    if id>0 and id<len(foundFilesHeat):
      ac.setBackgroundTexture(l_laps3             , laps_images_path + foundFilesHeat[id-1])
    else:
      ac.setBackgroundTexture(l_laps3             , 'apps/python/leb_yatt/plot_blanc.png')

def ps_laps1(*args):
  updateLap1()
  on_click_anybutton()

def ps_laps2(*args):
  updateLap2()
  on_click_anybutton()

def ps_laps3(*args):
  updateLap3()
  on_click_anybutton()






########################################################################################################################################################
########################################################################################################################################################
########################################################################################################################################################
########################################################################################################################################################
########################################################################################################################################################
########################################################################################################################################################


def timeToString(time):
  try:
    if time <= 0:
      return "-:--:---"
    else:
      return "{:d}:{:0>2d}:{:0>3d}".format(int(time/60000), int((time%60000)/1000), int(time%1000))
  except:
    ac.log("leb_yatt: Error in timeToString: " + traceback.format_exc())
    return "-:--.---"

def acShutdown():
  global appSettingsPath, gColor, zForce, centeredZForce, gSizeGforceW, gOpacityFG, gOpacityTx, base_gforce_fac, bScaleFixed
  global showLabels, texid, histCount, histVisi, smoothValue, TempID, PressID, DoResetOnUSERFFBChange
  global ghistT, gDataMode, bRecording, gSpeedNormalizer
  global canvasSF, canvasSF2, canvasSF3, canvasSF4, PNGmultSF, PNGmultGF, maxSteerReached, wsub, datagf, gSteeringNormalizer, gSizeGforceW, histDotSize, maxRPMReached, maxSpeedReached, maxSpeed
  global minRPMdisplayed, currLap, Gears, geardatacount, geardatacountdone, gSizeGforceH, OverallLaps
  global rtIndexAS_orig, rtIndexAS, rtIndexAS_bg, rtIndexSP_orig, rtIndexSP_bg, rtIndexSP
  global rtIndexHeat_orig, rtIndexHeat, rtIndexSF, rtIndexSF2, rtIndexSF3, rtIndexSF4, rtIndex0, sCar, sTrack, bCSPActive, minRPMdisplayed
  try:
    t1=time.time()

    if bRecording:
      appSaveImages('')

    if rtIndexSF>-1 and bCSPActive:
      ac.ext_disposeRenderTarget(rtIndexSP)
      ac.ext_disposeRenderTarget(rtIndexSP_bg)
      ac.ext_disposeRenderTarget(rtIndexSP_orig)
      ac.ext_disposeRenderTarget(rtIndexAS)
      ac.ext_disposeRenderTarget(rtIndexAS_bg)
      ac.ext_disposeRenderTarget(rtIndexAS_orig)
      ac.ext_disposeRenderTarget(rtIndexSF)
      ac.ext_disposeRenderTarget(rtIndexSF2)
      ac.ext_disposeRenderTarget(rtIndexSF3)
      ac.ext_disposeRenderTarget(rtIndexSF4)
      ac.ext_disposeRenderTarget(rtIndex0)
      ac.ext_disposeRenderTarget(rtIndexHeat_orig)
      ac.ext_disposeRenderTarget(rtIndexHeat)
      rtIndexSF = -1
      rtIndexSF2 = -1
      rtIndexSF3 = -1
      rtIndexSF4 = -1
      rtIndex0 = -1
      rtIndexSP = -1
      rtIndexSP_bg = -1
      rtIndexSP_orig = -1
      rtIndexAS = -1
      rtIndexAS_bg = -1
      rtIndexAS_orig = -1
      rtIndexHeat_orig = -1
      rtIndexHeat = -1

    config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_"), comment_prefixes=(";","#","/","_"))
    config.optionxform = str
    config.read(appSettingsPath)
    if not config.has_section('GENERAL'):
      config.add_section('GENERAL')

    # config['GENERAL']['APPSIZE']              = str(gSizeGforceW)
    # config['GENERAL']['TXOPACITY']            = str(gOpacityTx)
    # config['GENERAL']['FGOPACITY']            = str(gOpacityFG)
    # config['GENERAL']['HISTORYOPACITY']       = str(ghistT)
    # config['GENERAL']['COLOR']                = str(gColor)
    # config['GENERAL']['SHOWVERTICALG']        = str(zForce)
    # config['GENERAL']['VERTICALGCENTERED']    = str(centeredZForce)
    # config['GENERAL']['TEXTUREID']            = str(int(texid))
    # config['GENERAL']['TRAILLENGHT']          = str(int(histCount))
    # config['GENERAL']['TRAILVISIBILITY']      = str(int(histVisi))
    # config['GENERAL']['SMOOTHVALUE']          = str(round(smoothValue,1))


    config['GENERAL']['SHOWLABELS']           = str(showLabels)
    config['GENERAL']['RECORDING']            = str(bRecording)
    config['GENERAL']['SAVEPERTRACKCAR']      = str(bSaveAllLaps)
    config['GENERAL']['DATAMODE']             = str(int(gDataMode))
    config['GENERAL']['APPSIZEW']             = str(gSizeGforceW)
    config['GENERAL']['APPSIZEH']             = str(gSizeGforceH)
    config['GENERAL']['HISTDOTSIZE']          = str(round(histDotSize,1))
    config['GENERAL']['BGOPACITY']            = str(gOpacityBG)

    # config['GENERAL']['SUBMINRPM']            = str(minRPMdisplayed)
    # config['GENERAL']['SUBMAXVAL']            = str(gSteeringNormalizer)

    config['GENERAL']['RESETONUSERFFBCHANGE'] = str(DoResetOnUSERFFBChange)

    #config['GENERAL']['SCALEFIXED']           = str(bScaleFixed)
    #config['GENERAL']['GFORCEFACT'] =str(float(base_gforce_fac ))
    if not config.has_section('CAR_GFACTOR'):
        config.add_section('CAR_GFACTOR')
    config['CAR_GFACTOR'][sCar] = str( round(float(base_gforce_fac), 1) )

    if not config.has_section('CAR_MAXSTEER'):
        config.add_section('CAR_MAXSTEER')
    config['CAR_MAXSTEER'][sCar] = str( round(float(gSteeringNormalizer), 1) )

    if not config.has_section('CAR_MAXSPEED'):
        config.add_section('CAR_MAXSPEED')
    config['CAR_MAXSPEED'][sCar] = str( int(gSpeedNormalizer) )

    if not config.has_section('CAR_MINRPM'):
        config.add_section('CAR_MINRPM')
    config['CAR_MINRPM'][sCar] = str( int(minRPMdisplayed) )

    with open(appSettingsPath, 'w') as configfile:
      config.write(configfile, space_around_delimiters=False)



    #if geardatacount>10:
    #  # ac.log(str(Gears))
    #  # with open('apps/python/leb_yatt/data/'+sTrack+'_'+carName+'.gear', 'wb') as fp:
    #  with open('apps/python/leb_yatt/data/'+carName+'.gear', 'wb') as fp:
    #      pickle.dump(Gears, fp)

    ac.log('leb_yatt saving images: ' + str(round(time.time()-t1,3))+'sec')


  except:
    ac.log('leb_yatt error: ' + traceback.format_exc() )




def acMain(ac_version):
  global TempID, PressID, act_idx2, showLabels, bRecording
  global gforce_last, gforce_max, max_gforce_fac, histCount, maxHistCount, histVisi, smoothValue
  global top, fontSize, b_vertToggle, b_reset, b_color, b_doResetOnFFB, b_Control
  global gOpacityFG, gOpacityTx, fontSize2, gColor, zForce, centeredZForce, gSizeGforceW, base_gforce_fac
  global appSettingsPath, appSettingsDefaultsPath, texture_dot2
  global b_showLabels, b_DataEnabled, b_saveResultsNow, b_texid, b_gforceDec, b_gforceInc
  global b_TrailSmoothDn, b_TrailSmoothUp, b_smoothValueUp, b_smoothValueDn, b_SaveAllLaps, b_FullScreen, b_TrailDn, b_TrailUp, b_transpFGDn, b_transpFGUp, b_transpTxDn, b_transpTxUp
  global texid, texture_circle, foundFiles, laps_images_path, foundFilesHeat
  global texture_dot, DoResetOnUSERFFBChange, sCar, userChanged
  global bScaleFixed, sCustomFontName, l_laps2, l_laps3, sFileAI, l_info
  global appWindowLeB_YATT, b_laps1, b_laps2, b_laps3, bSaveAllLaps
  global b_transphistUp, b_transphistDn, ghistT, f1, gDataMode, sTrack, sLayout
  global b_subSizeWDec, b_subSizeWInc, b_subSizeHDec, b_subSizeHInc, gSpeedNormalizer
  global b_subtranspBGDn, b_subtranspBGUp, gSizeGforceW, gOpacityBG, appWindowOverlayControls
  global b_DotSizeDec, b_DotSizeInc, b_subSteerMaxUp, b_subSteerMaxDn, gSteeringNormalizer, histDotSize, b_subdataModeUp, b_subdataModeDn
  global g_Reset_When_In_Pits, jsonPower, minRPMdisplayed, Gears, geardatacount, geardatacountdone, gSizeGforceH, maxSpeed, jsonTorque, jsonPower
  global jsonPowerCurveMax, jsonTorqueCurveMax, bCPhysCarcassEnabled
  global bNewTyreParams, bCPhysicsActive, ACD_FILE, drivername

  t1=time.time()
  try:
    import pydoc
    d = pydoc.Doc



    ### app windows
    appWindowLeB_YATT = ac.newApp("leb_yatt")
    appWindowOverlayControls = ac.newApp("    lap overlay control")
    b_FullScreen  = ac.addButton(appWindowOverlayControls, "toggle\nfull-screen")
    b_laps1       = createSpinner(appWindowOverlayControls, "lap overlay A"  , 1, 40, 100, 150, 21, 0, 0, 1)
    b_laps2       = createSpinner(appWindowOverlayControls, "lap overlay B"  , 1, 40, 200, 150, 21, 0, 0, 1)
    b_laps3       = createSpinner(appWindowOverlayControls, "lap overlay old", 1, 40, 300, 150, 21, 0, 0, 1)
    ac.setSize(appWindowOverlayControls, 220, 400)
    ac.setSize(b_FullScreen            , 155,  42)
    ac.setPosition(b_FullScreen        , 35,  30)


    texture_circle    = ac.newTexture("apps/python/leb_yatt/circle.png")
    texture_dot       = ac.newTexture("apps/python/leb_yatt/gforce_dot4.png")
    texture_dot2      = ac.newTexture("apps/python/leb_yatt/gforce_dot4_2.png")

    configdefault = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_",","), comment_prefixes=(";","#","/","_",","))
    configdefault.optionxform = str
    configdefault.read(appSettingsDefaultsPath)

    config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_",","), comment_prefixes=(";","#","/","_",","))
    config.optionxform = str
    config.read(appSettingsPath)

    ### too dangerous to leave it on?
    bSaveAllLaps             = str2bool(       getSetting(configdefault, config, 'GENERAL','SAVEPERTRACKCAR'      , str(bSaveAllLaps) ) )
    appPreparePath()
    if os.path.isfile(sFileAI) and os.path.getsize(sFileAI)>24:
      ReadAILine()
    else:
      sFileAI = ''

    histDotSize              =     float(      getSetting(configdefault, config, 'GENERAL', 'HISTDOTSIZE'         , str(histDotSize  ) ) )
    bRecording               = str2bool(       getSetting(configdefault, config, 'GENERAL', 'RECORDING'           , str(bRecording) ) )
    gDataMode                = int(float(      getSetting(configdefault, config, 'GENERAL', 'DATAMODE'            , str(gDataMode) ) ) )
    gSizeGforceW             = int(float(      getSetting(configdefault, config, 'GENERAL', 'APPSIZEW'            , str(gSizeGforceW) ) ) )
    gSizeGforceH             = int(float(      getSetting(configdefault, config, 'GENERAL', 'APPSIZEH'            , str(gSizeGforceW) ) ) )
    minRPMdisplayed          = int(float(      getSetting(configdefault, config, 'GENERAL', 'MINRPM'              , str(minRPMdisplayed) ) ) )
    ghistT                   = int(float(      getSetting(configdefault, config, 'GENERAL', 'HISTORYOPACITY'      , str(ghistT) ) ) )
    gOpacityBG               = int(float(      getSetting(configdefault, config, 'GENERAL', 'BGOPACITY'           , str(gOpacityBG  ) ) ) )

    DoResetOnUSERFFBChange   = str2bool(       getSetting(configdefault, config, 'GENERAL', 'RESETONUSERFFBCHANGE', str(DoResetOnUSERFFBChange) ) )
    g_Reset_When_In_Pits     = str2bool(       getSetting(configdefault, config, 'GENERAL', 'RESETWHENINPITS'     , str(g_Reset_When_In_Pits) ) )
    base_gforce_fac          =     float(      getSetting(configdefault, config, 'GENERAL', 'GFORCEFACT'          , str(base_gforce_fac) ) )
    max_gforce_fac = base_gforce_fac

    # bScaleFixed              = str2bool(       getSetting(configdefault, config, 'GENERAL', 'SCALEFIXED'          , str(bScaleFixed) ) )
    gOpacityTx               = int(float(      getSetting(configdefault, config, 'GENERAL', 'TXOPACITY'           , str(gOpacityTx  ) ) ) )
    gOpacityFG               = int(float(      getSetting(configdefault, config, 'GENERAL', 'FGOPACITY'           , str(gOpacityFG  ) ) ) )
    gColor                   = int(float(      getSetting(configdefault, config, 'GENERAL', 'COLOR'               , str(gColor) ) ) )
    zForce                   = str2bool(       getSetting(configdefault, config, 'GENERAL', 'SHOWVERTICALG'       , str(zForce) ) )
    centeredZForce           = str2bool(       getSetting(configdefault, config, 'GENERAL', 'VERTICALGCENTERED'   , str(centeredZForce) ) )
    showLabels               = str2bool(       getSetting(configdefault, config, 'GENERAL', 'SHOWLABELS'          , str(showLabels) ) )
    texid                    = int(            getSetting(configdefault, config, 'GENERAL', 'TEXTUREID'           , str(texid) ) )
    histCount                = int(            getSetting(configdefault, config, 'GENERAL', 'TRAILLENGHT'         , str(histCount) ) )
    histVisi                 = int(            getSetting(configdefault, config, 'GENERAL', 'TRAILVISIBILITY'     , str(histVisi) ) )

    smoothValue              = int(            getSetting(configdefault, config, 'GENERAL', 'SMOOTHVALUE'         , str(smoothValue) ) )
    gSteeringNormalizer      = int(float(      getSetting(configdefault, config, 'GENERAL', 'SUBMAXVAL'           , str(gSteeringNormalizer  ) ) ) )
    if config.has_section('CAR_MAXSTEER') and config.has_option('CAR_MAXSTEER', sCar):
      gSteeringNormalizer = max(10, int(float( config['CAR_MAXSTEER'][sCar] )) )

    minRPMdisplayed        = int(            getSetting(configdefault, config, 'GENERAL', 'SUBMINRPM'         , str(minRPMdisplayed) ) )
    if config.has_section('CAR_MINRPM') and config.has_option('CAR_MINRPM', sCar):
      minRPMdisplayed = min(5000, int(float( config['CAR_MINRPM'][sCar] )) )

    ####   "bhp": "444bhp",
    ####   "torque": "398Nm",
    CAR_JSON_PATH = "content/cars/%s/ui/ui_car.json" % sCar
    try:
      with open(CAR_JSON_PATH, "r", encoding="utf-8") as FP:
        CAR_JSON = json.load(FP, strict=False)
        CAR_POWER = get_numbers(CAR_JSON["specs"]["bhp"])
        if CAR_POWER != '':
          jsonPower = float(CAR_POWER)
        CAR_TORQUE = get_numbers(CAR_JSON["specs"]["torque"])
        if CAR_TORQUE != '':
          jsonTorque = float(CAR_TORQUE)
          if 'kgm' in CAR_JSON["specs"]["torque"].lower():
            jsonTorque = jsonTorque * 9.80665

        for step in CAR_JSON["powerCurve"]:
          #ac.log(str(step))
          if int(float(step[1])) >= jsonPowerCurveMax:
            jsonPowerCurveMax = int(float(step[1]))
            # jsonPowerCurveRpmMax = int(float(step[0]))
          #powcurPOWRPM.append(int(float(step[0])))
          #powcurPOWPOW.append(int(float(step[1])))
        for step in CAR_JSON["torqueCurve"]:
          #ac.log(str(step))
          if int(float(step[1])) >= jsonTorqueCurveMax:
            jsonTorqueCurveMax = int(float(step[1]))
            # maxTorqueRpmJson = int(float(step[0]))
          #powcurTORRPMJson.append(int(float(step[0])))
          #powcurTORJson.append(int(float(step[1])))
    except:
      ac.log("leb_yatt: JSON read error: %s" % CAR_JSON_PATH)




    if config.has_section('CAR_GFACTOR') and config.has_option('CAR_GFACTOR', sCar):
      base_gforce_fac = max(1.0, float( config['CAR_GFACTOR'][sCar] ) )
      max_gforce_fac = float(base_gforce_fac)
      userChanged = True
    else:
      try:
        with open(CAR_JSON_PATH, "r", encoding="utf-8") as FP:
          CAR_JSON = json.load(FP, strict=False)
          CAR_MASS = get_numbers(CAR_JSON["specs"]["weight"])
          CAR_POWER =get_numbers(CAR_JSON["specs"]["bhp"])
          base_gforce_fac =  min(base_gforce_fac, max(1.0, float( math.floor( (CAR_MASS-75) / CAR_POWER / 2 ) ) ) )  ### +0.5
          max_gforce_fac = base_gforce_fac
      except:
        ac.log("leb_yatt: JSON read error: %s" % CAR_JSON_PATH)

    maxSpeed = 100
    try:
      ### via json file
      with open(CAR_JSON_PATH, "r", encoding="utf-8") as FP:
        CAR_JSON = json.load(FP, strict=False)
        CAR_POWER = get_numbers(CAR_JSON["specs"]["bhp"])
        CAR_TOPSPEED = get_numbers(CAR_JSON["specs"]["topspeed"])
        # ac.log('CAR_POWER ' + str(CAR_POWER))
        # ac.log('CAR_TOPSPEED ' + str(CAR_TOPSPEED))
        if CAR_TOPSPEED!='':
          ### found topspeed
          maxSpeed = int(float(CAR_TOPSPEED))
          maxSpeed = int((maxSpeed/10.0+1.0)*10.0)
          #ac.log('CAR_TOPSPEED ' + str(maxSpeed))
        elif CAR_POWER!='':
          ### guess via power
          if   int(CAR_POWER)>650:
            maxSpeed = 400
          elif int(CAR_POWER)>500:
            maxSpeed = 300
          elif int(CAR_POWER)>250:
            maxSpeed = 280
          elif int(CAR_POWER)>150:
            maxSpeed = 260
          elif int(CAR_POWER)>100:
            maxSpeed = 200
          else:
            maxSpeed = 150
          # ac.log('CAR_POWER -> CAR_TOPSPEED ' + str(gSpeedNormalizer))
    except:
      ac.log("leb_yatt: JSON read error: %s" % CAR_JSON_PATH + '\n' + traceback.format_exc())

    if config.has_section('CAR_MAXSPEED') and config.has_option('CAR_MAXSPEED', sCar):
      # saved last time
      gSpeedNormalizer = max(50, int(float( config['CAR_MAXSPEED'][sCar] )) )
    else:
      gSpeedNormalizer = max(50, maxSpeed )


    gforce_last  = [0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    gforce_max   = [0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    act_idx2 = 0
    l_info      = ac.addButton(appWindowOverlayControls, "")
    l_laps2     = ac.addButton(appWindowLeB_YATT, "")
    l_laps3     = ac.addButton(appWindowLeB_YATT, "")
    ac.setBackgroundColor(  l_info, 0,0,0)
    ac.drawBorder(l_info,0)
    ac.setBackgroundOpacity(l_info, 0)
    ac.setBackgroundColor(  l_laps2, 0,0,0)
    ac.setBackgroundOpacity(l_laps2, 0)
    ac.setBackgroundColor(  l_laps3, 0,0,0)
    ac.setBackgroundOpacity(l_laps3, 0)

    b_gforceInc = ac.addButton(appWindowLeB_YATT, "+")
    b_gforceDec = ac.addButton(appWindowLeB_YATT, "-")

    b_Control = ac.addButton(appWindowLeB_YATT, "control")
    b_reset = ac.addButton(appWindowLeB_YATT, "reset")
    b_doResetOnFFB = ac.addButton(appWindowLeB_YATT, "reset on\nNum+/-")
    b_vertToggle = ac.addButton(appWindowLeB_YATT, "z0")
    b_color = ac.addButton(appWindowLeB_YATT, "c0")
    b_texid  = ac.addButton(appWindowLeB_YATT, "t0")

    b_smoothValueUp = ac.addButton(appWindowLeB_YATT, "+")
    b_smoothValueDn = ac.addButton(appWindowLeB_YATT, "-")
    b_TrailUp = ac.addButton(appWindowLeB_YATT, '   + trails')
    b_TrailDn = ac.addButton(appWindowLeB_YATT, "-" )
    b_TrailSmoothUp = ac.addButton(appWindowLeB_YATT, "+")
    b_TrailSmoothDn = ac.addButton(appWindowLeB_YATT, "-" )
    b_transpTxUp = ac.addButton(appWindowLeB_YATT, "+")
    b_transpTxDn = ac.addButton(appWindowLeB_YATT, "- tx")
    b_transpFGUp = ac.addButton(appWindowLeB_YATT, "+")
    b_transpFGDn = ac.addButton(appWindowLeB_YATT, "- fg")

    b_transphistUp = ac.addButton(appWindowLeB_YATT, "+")
    b_transphistDn = ac.addButton(appWindowLeB_YATT, "- history")

    b_showLabels    = ac.addButton(appWindowLeB_YATT, "x")
    b_SaveAllLaps  = ac.addButton(appWindowLeB_YATT, "save ALL data")

    b_DataEnabled   = ac.addButton(appWindowLeB_YATT, "x")
    b_saveResultsNow= ac.addButton(appWindowLeB_YATT, "save png's now")
    b_DotSizeDec    = ac.addButton(appWindowLeB_YATT, "+")
    b_DotSizeInc    = ac.addButton(appWindowLeB_YATT, "-" )

    b_subSizeWInc   = ac.addButton(appWindowLeB_YATT, "+")
    b_subSizeWDec   = ac.addButton(appWindowLeB_YATT, "-" )
    b_subSizeHInc   = ac.addButton(appWindowLeB_YATT, "+")
    b_subSizeHDec   = ac.addButton(appWindowLeB_YATT, "-" )
    b_subtranspBGUp = ac.addButton(appWindowLeB_YATT, "+")
    b_subtranspBGDn = ac.addButton(appWindowLeB_YATT, "- bg")
    b_subSteerMaxDn = ac.addButton(appWindowLeB_YATT, "+")
    b_subSteerMaxUp = ac.addButton(appWindowLeB_YATT, "-")
    b_subdataModeUp = ac.addButton(appWindowLeB_YATT, "+")
    b_subdataModeDn = ac.addButton(appWindowLeB_YATT, "-")

    ac.setSize(b_subSizeHDec       , 40, 40)
    ac.setSize(b_subSizeHInc       , 40, 40)
    ac.setSize(b_subSizeWDec       , 40, 40)
    ac.setSize(b_subSizeWInc       , 40, 40)
    ac.setSize(b_subtranspBGDn     , 35, 40)
    ac.setSize(b_subtranspBGUp     , 35, 40)
    ac.setSize(b_subSteerMaxDn     , 35, 40)
    ac.setSize(b_subSteerMaxUp     , 35, 40)
    ac.setSize(b_subdataModeDn     , 35, 40)
    ac.setSize(b_subdataModeUp     , 35, 40)

    ac.setSize(b_DotSizeDec     , 35, 40)
    ac.setSize(b_DotSizeInc     , 35, 40)
    ac.setSize(b_reset          , 80, 40)
    ac.setSize(b_doResetOnFFB   , 80, 40)
    ac.setSize(b_vertToggle     , 35, 40)
    ac.setSize(b_color          , 35, 40)
    ac.setSize(b_texid          , 35, 40)
    ac.setSize(b_gforceDec      , 30, 40)
    ac.setSize(b_gforceInc      , 30, 40)
    ac.setSize(b_smoothValueDn  , 25, 40)
    ac.setSize(b_smoothValueUp  , 25, 40)
    ac.setSize(b_TrailDn        , 25, 40)
    ac.setSize(b_TrailUp        , 25, 40)
    ac.setSize(b_TrailSmoothDn  , 25, 40)
    ac.setSize(b_TrailSmoothUp  , 25, 40)
    ac.setSize(b_transpTxDn     , 35, 40)
    ac.setSize(b_transpTxUp     , 35, 40)
    ac.setSize(b_transphistUp   , 50, 40)
    ac.setSize(b_transphistDn   , 50, 40)

    ac.setSize(b_showLabels     , 60, 39)
    ac.setSize(b_DataEnabled    ,100, 90)
    ac.setSize(b_saveResultsNow ,140, 25)
    ac.setSize(b_SaveAllLaps    ,140, 60)

    ac.setSize(b_transpFGUp     , 30, 40)
    ac.setSize(b_transpFGDn     , 30, 40)
    ac.setSize(b_Control        , 60, 30)
    ac.setPosition(b_Control    , -70, 100)

    # sub
    ac.setPosition(b_DataEnabled   , -50, -150)
    ac.setPosition(b_SaveAllLaps   ,  80, -150)
    ac.setPosition(b_saveResultsNow,  80, -85)

    ac.setSize(l_laps2, 300,300)
    ac.setPosition(l_laps2, 0,0)
    ac.setPosition(l_laps3, 0,0)
    ac.setPosition(b_subSizeWDec      , -30,-50)
    ac.setPosition(b_subSizeWInc      ,  10,-50)
    ac.setPosition(b_subSizeHDec      , -50,   0)
    ac.setPosition(b_subSizeHInc      , -50,  45)
    ac.setPosition(b_subtranspBGDn    ,  60, -50)
    ac.setPosition(b_subtranspBGUp    ,  95, -50)
    ac.setPosition(b_subSteerMaxUp    , 250, -50)
    ac.setPosition(b_subSteerMaxDn    , 285, -50)
    ac.setPosition(b_gforceDec        , 250,-100)
    ac.setPosition(b_gforceInc        , 281,-100)
    ac.setPosition(b_subdataModeDn    , 350, -50)
    ac.setPosition(b_subdataModeUp    , 385, -50)
    ac.setPosition(b_DotSizeInc       , 150, -50)
    ac.setPosition(b_DotSizeDec       , 185, -50)

    ac.setPosition(b_transphistDn     ,  20,-150)
    ac.setPosition(b_transphistUp     ,  70,-150)

    ac.setPosition(b_transpTxDn    , 145, -200)
    ac.setPosition(b_transpTxUp    , 180, -200)
    ac.setPosition(b_color         , 225, -200)
    ac.setPosition(b_texid         , 270, -200)
    ac.setPosition(b_reset         , 320, -150)
    ac.setPosition(b_doResetOnFFB  , 320, -100)
    ac.setPosition(b_transpFGDn    , -80, -235)
    ac.setPosition(b_transpFGUp    , -80, -265)

    ac.setPosition(b_smoothValueDn ,  60, -145)
    ac.setPosition(b_smoothValueUp ,  85, -145)
    ac.setPosition(b_TrailDn       , 120, -145)
    ac.setPosition(b_TrailUp       , 145, -145)
    ac.setPosition(b_TrailSmoothDn , 210, -145)
    ac.setPosition(b_TrailSmoothUp , 235, -145)
    ac.setPosition(b_vertToggle    , 270, -145)
    ac.setPosition(b_showLabels       , 250,-150)

    ac.setFontAlignment(b_showLabels    , 'right')
    ac.setFontAlignment(b_SaveAllLaps   , 'left')
    ac.setFontAlignment(b_FullScreen    , 'center')

    ac.setFontAlignment(l_info, "left")
    ac.setFontAlignment(l_laps2, "left")
    ac.setFontAlignment(l_laps3, "left")
    ac.setFontAlignment(b_TrailDn, "left")
    ac.setFontAlignment(b_smoothValueDn, "left")
    ac.setFontAlignment(b_TrailSmoothDn, "left")
    ac.setFontAlignment(b_transpTxDn, "left")
    ac.setFontAlignment(b_transpFGDn, "left")

    ac.setFontAlignment(b_TrailUp, "left")
    ac.setFontAlignment(b_smoothValueUp, "right")
    ac.setFontAlignment(b_TrailSmoothUp, "right")
    ac.setFontAlignment(b_transpTxUp, "right")
    ac.setFontAlignment(b_transphistDn, "center")
    ac.setFontAlignment(b_transpFGUp, "right")
    ac.setFontAlignment(b_subtranspBGDn, "left")

    # sub
    ac.addOnValueChangeListener(b_laps1, ps_laps1)
    ac.addOnValueChangeListener(b_laps2, ps_laps2)
    ac.addOnValueChangeListener(b_laps3, ps_laps3)
    ac.addOnClickedListener(b_subSteerMaxUp, appSteerMaxDec)
    ac.addOnClickedListener(b_subSteerMaxDn, appSteerMaxInc)
    ac.addOnClickedListener(b_subdataModeUp, appDataModeInc)
    ac.addOnClickedListener(b_subdataModeDn, appDataModeDec)
    ac.addOnClickedListener(b_subtranspBGDn, appsubBGTransparencyDn)
    ac.addOnClickedListener(b_subtranspBGUp, appsubBGTransparencyUp)
    ac.addOnClickedListener(b_subSizeHDec, onSizeHDec)
    ac.addOnClickedListener(b_subSizeHInc, onSizeHInc)
    ac.addOnClickedListener(b_subSizeWDec, onSizeWDec)
    ac.addOnClickedListener(b_subSizeWInc, onSizeWInc)

    ac.addOnClickedListener(b_DotSizeInc, appDotSizeDn)
    ac.addOnClickedListener(b_DotSizeDec, appDotSizeUp)

    ac.addOnClickedListener(b_gforceDec, onGforceDec)
    ac.addOnClickedListener(b_gforceInc, onGforceInc)
    ac.addOnClickedListener(b_reset, onReset)
    ac.addOnClickedListener(b_Control, onShowControl)
    ac.addOnClickedListener(b_doResetOnFFB, ondoResetOnFFB)
    ac.addOnClickedListener(b_vertToggle, onvertToggle)
    ac.addOnClickedListener(b_color, onColor)
    ac.addOnClickedListener(b_texid, onTexid)

    ac.addOnClickedListener(b_smoothValueDn, appsmoothValueDn)
    ac.addOnClickedListener(b_smoothValueUp, appsmoothValueUp)
    ac.addOnClickedListener(b_TrailDn, appTrailDn)
    ac.addOnClickedListener(b_TrailUp, appTrailUp)
    ac.addOnClickedListener(b_TrailSmoothDn, appTrailSmoothDn)
    ac.addOnClickedListener(b_TrailSmoothUp, appTrailSmoothUp)
    ac.addOnClickedListener(b_transpTxUp, appTxTransparencyUp)
    ac.addOnClickedListener(b_transpTxDn, appTxTransparencyDn)
    ac.addOnClickedListener(b_transpFGUp, appFGTransparencyUp)
    ac.addOnClickedListener(b_transpFGDn, appFGTransparencyDn)
    ac.addOnClickedListener(b_transphistUp, apphistTransparencyUp)
    ac.addOnClickedListener(b_transphistDn, apphistTransparencyDn)

    ac.addOnClickedListener(b_showLabels, onShowLabels)
    ac.addOnClickedListener(b_SaveAllLaps, onSaveAllLapsToggle)
    ac.addOnClickedListener(b_FullScreen, onToggleFullScreen)
    ac.addOnClickedListener(b_DataEnabled, onsaveResults)
    ac.addOnClickedListener(b_saveResultsNow, onsaveResultsNow)

    if bCSPActive:
      f1 = FontMeasures(sCustomFontName, 0, 0, 1.25, 0.69, 0.629, 0.616, 0.066)
      f1.f = ac.ext_glFontCreate(f1.n, f1.s, f1.i, f1.b)

    ac.addRenderCallback        (appWindowLeB_YATT, onRenderWindow)
    ac.addOnClickedListener     (appWindowLeB_YATT, on_click_anybutton)
    ac.addOnClickedListener     (l_laps3             , on_click_window)
    # ac.addOnAppDismissedListener(appWindow, appOnClosed)

    #if os.path.isfile('apps/python/leb_yatt/data/'+sCar+'.gear'):
    #  with open(      'apps/python/leb_yatt/data/'+sCar+'.gear', 'rb') as fp:
    #    Gears = pickle.load(fp)
    #    for gear in range(len(Gears)):
    #      geardatacount+=len(Gears[gear])
    #      geardatacountdone+=len(Gears[gear])
    #      for rpm in range(len(Gears[gear])):
    #        if Gears[gear][rpm]==0:
    #          geardatacountdone-=1

    ACD_FILE = ACD("content/cars/{}".format(sCar))

    bCPhysicsActive = False
    bCPhysCarcassEnabled = False
    bNewTyreParams = False

    bCPhysicsActive = ac.ext_isExtendedPhysics()
    if bCPhysicsActive:
      if 'ext_getTyreTempMult' in dir(ac):
        bNewTyreParams = True
      if 'ext_getTyreCarcassTemp' in dir(ac):
        bCPhysCarcassEnabled = True


    dname = ac.getDriverName(0)
    drivername =' '
    for s in dname:
        if ord(s)<127:
            drivername += s

  except:
    ac.log('leb_yatt error: ' + traceback.format_exc() )

  onReset(True)
  #appResize()
  appHideButtons()

  ac.log('leb_yatt loading ai line/creating map: ' + str(round(time.time()-t1,3))+'sec')

  return "leb_yatt"



def appPreparePath():
  global sFileAI, sCar, sTrack, sLayout, bSaveAllLaps, laps_images_path, foundFiles, foundFilesHeat, foundFilesAero, foundFilesSlip
  sCar = ac.getCarName(0)
  sTrack = ac.getTrackName(0)
  sLayout = ac.getTrackConfiguration(0)
  currDir = os.path.dirname(os.path.realpath(__file__))
  acdir = currDir.replace('apps\\python\\leb_yatt', '')
  sFileAI     = acdir + 'content\\tracks\\' + sTrack+ '\\ai\\fast_lane.ai'
  if sLayout!='':
    sFileAI = acdir + 'content\\tracks\\' + sTrack+'\\'+sLayout+'\\ai\\fast_lane.ai'
  if bSaveAllLaps:
    laps_images_path = currDir + '\\laps_images\\' + sTrack + '\\'
    if not os.path.isdir(laps_images_path):
      os.mkdir(laps_images_path)
    else:
      # touch (put new date) dir to find new laps easier
      dt = datetime.now()
      timestamp = time.mktime(dt.timetuple()) + dt.microsecond/1e6
      stat = os.stat(laps_images_path)
      os.utime(laps_images_path, (stat.st_atime, timestamp))

    if sLayout!='':
      sTrack = sTrack + '\\' + sLayout
      laps_images_path = currDir + '\\laps_images\\' + sTrack + '\\'
      if not os.path.isdir(laps_images_path):
        os.mkdir(laps_images_path)
      else:
        dt = datetime.now()
        timestamp = time.mktime(dt.timetuple()) + dt.microsecond/1e6
        stat = os.stat(laps_images_path)
        os.utime(laps_images_path, (stat.st_atime, timestamp))
  else:
    laps_images_path = currDir + '\\laps_images\\'

  # ac.log(laps_images_path)

  foundFiles = []
  foundFilesHeat = []
  foundFilesAero = []
  foundFilesSlip = []
  for filename in os.listdir(laps_images_path, ):
    # if sCar in filename and 'lap' in filename:
    if 'lap' in filename.lower() and not 'laps' in filename.lower() and not 'heatmap' in filename.lower() and not 'aerosus' in filename.lower():
      foundFiles.append(filename)
    if 'lap' in filename.lower() and not 'laps' in filename.lower() and 'heatmap' in filename.lower():
      foundFilesHeat.append(filename)
    if 'lap' in filename.lower() and not 'laps' in filename.lower() and 'aerosus' in filename.lower():
      foundFilesAero.append(filename)
    if 'lap' in filename.lower() and not 'laps' in filename.lower() and 'slip' in filename.lower():
      foundFilesSlip.append(filename)

  if len(foundFiles)>0:
    # 2023-01-22 19_30 mazda-mx5 Lap1 30203
    # foundFiles = collections.OrderedDict( sorted(foundFiles, key=functools.cmp_to_key(comp_func)) )
    ac.setRange(b_laps3, 0, len(foundFiles)-1)


def onShowControl(*args):
    global appWindowOverlayControls
    ac.setVisible(appWindowOverlayControls, 1)

def onReset(*args):
  try:
    global gforce_max, gforce_fac, gforce_last, base_gforce_fac, currCar
    global maxG_XGREpos, maxG_YGREpos, maxG_XYELpos, maxG_YYELpos, maxG_XORApos, maxG_YORApos, maxG_XREDpos, maxG_YREDpos
    global maxG_XYELneg, maxG_YYELneg, maxG_XORAneg, maxG_YORAneg, maxG_XREDneg, maxG_YREDneg, lastCarFFB
    global maxG_XGREneg, maxG_YGREneg, maxG_XBLUpos, maxG_YBLUpos, maxG_XBLUneg, maxG_YBLUneg
    global bCSPActive, maxSteerReached, maxSpeedReached, maxRPMReached
    global lastTime, firstClearDone, imgsloaded, lastLap, ac_session, ac_status, rtIndexSP
    global rtIndexSP_bg, rtIndexSF, rtIndexSF2, rtIndexSF3, rtIndexSF4, rtIndex0, rtIndexSP_orig, rtIndexHeat_orig, rtIndexHeat
    global rtIndexAS_orig, rtIndexAS, rtIndexAS_bg

    maxSteerReached = 0
    maxSpeedReached = 0
    maxRPMReached = 0
    lastTime = -1
    lastLap = -1
    lastTime = -1
    ac_session = -1
    ac_status = -1

    maxG_XGREpos=0.5 # 0.5
    maxG_XYELpos=0.5 # 0.55
    maxG_XORApos=0.5 # 0.60
    maxG_XREDpos=0.5 # 0.65
    maxG_XBLUpos=0.5 # 0.70
    maxG_XGREneg=0.5 # 0.5
    maxG_XYELneg=0.5 # 0.55
    maxG_XORAneg=0.5 # 0.60
    maxG_XREDneg=0.5 # 0.65
    maxG_XBLUneg=0.5 # 0.70
    maxG_YGREpos=0.5 # 0.5
    maxG_YYELpos=0.5 # 0.55
    maxG_YORApos=0.5 # 0.60
    maxG_YREDpos=0.5 # 0.65
    maxG_YBLUpos=0.5 # 0.70
    maxG_YGREneg=0.5 # 0.5
    maxG_YYELneg=0.5 # 0.55
    maxG_YORAneg=0.5 # 0.60
    maxG_YREDneg=0.5 # 0.65
    maxG_YBLUneg=0.5 # 0.70

    gforce_fac   = base_gforce_fac
    gforce_last  = [0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    gforce_max   = [0.0,0.0,0.0,0.0,0.0,0.0,0.0]

    rtIndexSF = -1
    rtIndexSF2 = -1
    rtIndexSF3 = -1
    rtIndexSF4 = -1
    rtIndex0 = -1
    rtIndexSP = -1
    rtIndexSP_bg = -1
    rtIndexSP_orig = -1
    rtIndexAS = -1
    rtIndexAS_bg = -1
    rtIndexAS_orig = -1
    rtIndexHeat_orig = -1
    rtIndexHeat = -1
    imgsloaded = False
    firstClearDone=False
    appPrepareImages()
    appResize()
  except:
    ac.log('leb_yatt error: ' + traceback.format_exc() )

def appResizeMain(wl,hl):
  global wmain, hmain
  wmain=int(wl)
  hmain=int(hl)

def appResize():
  global gSizeGforceW, fontSize, showLabels, gforce_fac
  global showHeader, top, gOpacityFG, gOpacityTx
  global b_reset, b_doResetOnFFB, DoResetOnUSERFFBChange, appWindowLeB_YATT
  global rtIndexSF, rtIndexSF2, rtIndexSF3, rtIndexSF4, rtIndex0, PNGmultSF, myImageSF, myImageSF4, myImageSF3, myImageSF2, myImageSP
  global wmain, hmain, wsub, hsub, bCSPActive, gSizeGforceH
  global gforcesteer_x_act, gforcesteer_y_act
  global gDataMode, fontSize2
  global b_subtranspBGDn, b_subtranspBGUp, gSizeGforceW, gOpacityBG, minioffset, minioffset2
  global b_laps1, b_laps2, l_laps2, l_laps3, b_laps3

  try:
    ac.drawBorder(appWindowLeB_YATT, 0)
    ac.drawBorder(l_laps2, 0)
    ac.drawBorder(l_laps3, 0)
    if gDataMode==0 or gDataMode==2:
      ac.setBackgroundTexture(appWindowLeB_YATT, "apps/python/leb_yatt/steer_gforce_blanc.png")
    else:
      ac.setBackgroundTexture(appWindowLeB_YATT, "apps/python/leb_yatt/plot_blanc.png")
    if gDataMode>=4:
      ac.setVisible(b_laps1, 1)
      ac.setVisible(b_laps2, 1)
      ac.setVisible(b_laps3, 1)
      if gDataMode==5:
        ac.setVisible(b_laps1, 0)
      else:
        ac.setVisible(b_laps1, 1)
      ac.setVisible(l_laps2, 1)
      ac.setVisible(l_laps3, 1)
    else:
      ac.setVisible(b_laps1, 0)
      ac.setVisible(b_laps2, 0)
      ac.setVisible(b_laps3, 0)
      ac.setVisible(l_laps2, 0)
      ac.setVisible(l_laps3, 0)

    if showHeader == 0:
      top=0
      ac.setTitle(appWindowLeB_YATT, "")
    else:
      top = 25
      ac.setTitle(appWindowLeB_YATT, "lblyatt")

    ac.setFontSize(l_laps2, fontSize2)
    ac.setFontSize(l_laps3, fontSize2)
    wsub=int(300*gSizeGforceW/100)
    hsub=int(300*gSizeGforceH/100)
    PNGmultSF = myImageSF.size[0] / wsub
    fontSize2   = 16
    minioffset = myImageSP.size[1]*0.05
    minioffset2 = max(4,myImageSP.size[1]/1024*7)

    setOverlayParams(wsub, hsub)
    ac.setSize(appWindowLeB_YATT, wsub, hsub)
    gforcesteer_x_act = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    gforcesteer_y_act = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 , 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
    ### center for first start
    for i in range(len(gforcesteer_x_act)):
      gforcesteer_x_act[i]=wsub/2
    for i in range(len(gforcesteer_y_act)):
      gforcesteer_y_act[i]=wsub/2

    updateLap1()
    updateLap2()
    updateLap3()
    on_click_anybutton()
  except:
    ac.log('leb_yatt error: ' + traceback.format_exc() )

def setOverlayParams(wo, ho):
  if gDataMode==5:
    w=min(wo, ho)
    ac.setPosition(l_laps2, w*0.1, w*0.14)
    ac.setPosition(l_laps3, w*0.1, w*0.14)
    ac.setSize(l_laps2, w*0.8, w*0.75)
    ac.setSize(l_laps3, w*0.8, w*0.75)
  else:
    ac.setPosition(l_laps2, 0, 0)
    ac.setPosition(l_laps3, 0, 0)
    ac.setSize(l_laps2, wo, ho)
    ac.setSize(l_laps3, wo, ho)


def onsaveResults(*args):
    global bRecording, b_DataEnabled, lastaiid, aiid
    bRecording = not bRecording
    lastaiid=-1
    aiid=-1
    on_click_anybutton()

def apphistTransparencyUp(*args):
    global ghistT
    ghistT += 10
    if ghistT>100:
        ghistT=100
    on_click_anybutton()

def apphistTransparencyDn(*args):
    global ghistT
    ghistT -= 10
    if ghistT<0:
        ghistT=0
    on_click_anybutton()

def appsmoothValueDn(*args):
  global smoothValue
  smoothValue -= 1
  if smoothValue<0:
    smoothValue=0
  appResize()
def appsmoothValueUp(*args):
  global smoothValue
  smoothValue += 1
  if smoothValue>50:
    smoothValue=50
  appResize()
def onShowLabels(*args):
  global showLabels
  showLabels=not showLabels
  appResize()
def onTexid(*args):
  global texid
  texid+=1
  appResize()

def appTrailDn(*args):
  global histCount, lastXYZ, lastXY, maxHistCount
  if histCount>50:
    histCount -= 50
  elif histCount>10:
    histCount -= 10
  elif histCount>1:
    histCount -= 1
  else:
    histCount=0
  lastXYZ    = [[111.0,111.0,111.0] * maxHistCount for i in range(maxHistCount)]
  lastXY     = [[111.0,111.0      ] * maxHistCount for i in range(maxHistCount)]
  appResize()

def appTrailUp(*args):
  global histCount, lastXYZ, lastXY, maxHistCount
  if histCount<10:
    histCount += 1
  elif histCount<50:
    histCount += 10
  elif histCount<maxHistCount:
    histCount += 50
  else:
    histCount=maxHistCount
  lastXYZ    = [[111.0,111.0,111.0] * maxHistCount for i in range(maxHistCount)]
  lastXY     = [[111.0,111.0      ] * maxHistCount for i in range(maxHistCount)]
  appResize()

def appTrailSmoothDn(*args):
  global histVisi
  if histVisi>0:
    histVisi -= 2
  else:
    histVisi=0
  appResize()

def appTrailSmoothUp(*args):
  global histVisi
  if histVisi<100:
    histVisi += 2
  else:
    histVisi=100
  appResize()

def appOnActivated(*args):
  on_click_anybutton()

def onColor(*args):
  global gColor
  if gColor<2:
    gColor+=1
  else:
    gColor=0
  appResize()

def appFGTransparencyUp(*args):
    global gOpacityFG
    gOpacityFG += 10
    if gOpacityFG>200:
        gOpacityFG=200
    appResize()
def appFGTransparencyDn(*args):
    global gOpacityFG
    gOpacityFG -= 10
    if gOpacityFG<0:
        gOpacityFG=0
    appResize()

def appTxTransparencyUp(*args):
    global gOpacityTx
    if gOpacityTx<100:
        gOpacityTx += 5
    if gOpacityTx>100:
        gOpacityTx=100
    appResize()
def appTxTransparencyDn(*args):
    global gOpacityTx
    if gOpacityTx>0:
        gOpacityTx -= 5
    if gOpacityTx<0:
        gOpacityTx=0
    appResize()

def onvertToggle(*args):
  global b_vertToggle, zForce, centeredZForce
  if not zForce:
    zForce         = True
    centeredZForce = False
    ac.setText(b_vertToggle,'z1')
  else:
    if not centeredZForce:
      zForce         = True
      centeredZForce = True
      ac.setText(b_vertToggle,'z2')
    else:
      zForce         = False
      centeredZForce = False
      ac.setText(b_vertToggle,'z0')
  appResize()

def onsubSizeDec(*args):
  global gSizeGforceW
  gSizeGforceW = gSizeGforceW - 20
  appResize()

def onsubSizeInc(*args):
  global gSizeGforceW
  gSizeGforceW = gSizeGforceW + 20
  appResize()


def onSizeWDec(dummy, variable):
  global gSizeGforceW, gSizeGforceH
  gSizeGforceW = gSizeGforceW - 20
  if gDataMode==5:
    gSizeGforceH=gSizeGforceW
  appResize()

def onSizeWInc(dummy, variable):
  global gSizeGforceW, gSizeGforceH
  gSizeGforceW = gSizeGforceW + 20
  if gDataMode==5:
    gSizeGforceH=gSizeGforceW
  appResize()


def onSizeHDec(dummy, variable):
  global gSizeGforceW, gSizeGforceH
  gSizeGforceH = gSizeGforceH - 20
  if gDataMode==5:
    gSizeGforceW=gSizeGforceH
  appResize()

def onSizeHInc(dummy, variable):
  global gSizeGforceW, gSizeGforceH
  gSizeGforceH = gSizeGforceH + 20
  if gDataMode==5:
    gSizeGforceW=gSizeGforceH
  appResize()


def onSaveAllLapsToggle(*args):
  global bSaveAllLaps
  bSaveAllLaps = not bSaveAllLaps
  appPreparePath()
  on_click_anybutton()

def onToggleFullScreen(*args):
  appToggleFullScreen()




##########################################################






def appSaveImages(postfix=''):
  global globalprefix, minioffset2, minioffset, lapTimes, lapTimesFlags, OverallLaps, datagf, currTime, sCar, sTrack
  global fontSize2, ac_status, laps_images_path, savedFiles, rtIndexSP, rtIndexHeat_orig, rtIndexHeat, rtIndexSP_bg, rtIndexSP_orig
  global canvasMap, myImageMap, myImageMapOrig, sFileAI, rtIndexAS_orig, rtIndexAS, rtIndexAS_bg, myImageSF, canvasSF
  global canvasAS, myImageAS
  localpostfix = postfix
  try:
    fTrackLength = ac.getTrackLength(0)
    CarSkin      = ac.getCarSkin(0)
    NationCode   = ac.getDriverNationCode(0)
    DriverName   = ac.getDriverName(0)

    sectFile       = 'content/tracks/' + sTrack+'/data/sections.ini'
    fileLivery     = "content/cars/" + sCar + "/skins/" + CarSkin + "/livery.png"
    fileMiniPrev   = "content/cars/" + sCar + "/skins/" + CarSkin + "/preview_mini.png"
    fileNationCode = "content/gui/NationFlags/" + NationCode + ".png"


    # draw some text while here


    # 'Steering angle vs Lateral g-force'
    mult=myImageSF.size[0]/1024
    # paint in a cross
    canvasSF.rectangle( ( myImageSF.size[0]/2-6 , myImageSF.size[1]/2-1 , myImageSF.size[0]/2+6 , myImageSF.size[1]/2+1  ), fill=(0,0,0) )
    canvasSF.rectangle( ( myImageSF.size[0]/2-1 , myImageSF.size[1]/2-6 , myImageSF.size[0]/2+1 , myImageSF.size[1]/2+6  ), fill=(0,0,0) )
    canvasSF.rectangle( ( myImageSF.size[0]/2-5 , myImageSF.size[1]/2   , myImageSF.size[0]/2+5 , myImageSF.size[1]/2    ), fill=(255,255,255) )
    canvasSF.rectangle( ( myImageSF.size[0]/2   , myImageSF.size[1]/2-5 , myImageSF.size[0]/2   , myImageSF.size[1]/2+5  ), fill=(255,255,255) )

    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(25*mult))
    canvasSF.text((myImageSF.size[0]*0.01, myImageSF.size[0]-int(350*mult)), 'Steering vs Lat. g-force'                      , font=font)
    # canvasSF.text((myImageSF.size[0]*0.01, myImageSF.size[0]-int(350*mult)), 'Steering angle  VS'                                       , font=font)
    # DrawRotated(myImageSF, 'Lateral g-force', font, mult)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(18*mult))
    canvasSF.text(               (20, myImageSF.size[0]*0.95 - 230*mult) ,"max Steering angle"                                          , font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 - 200*mult) ,"    displayed (x)       ±" + str(int(gSteeringNormalizer))   , font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 - 180*mult) ,"    reached              " + str(int(maxSteerReached))       , font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 - 140*mult) ,"max g's"                                                     , font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 - 110*mult) ,"    displayed (y)       ±" + str(round(base_gforce_fac,2))   , font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 -  90*mult) ,"    left                 " + str(round(abs(gforce_max[0]),2)), font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 -  70*mult) ,"    right                " + str(round(abs(gforce_max[1]),2)), font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 -  50*mult) ,"    on brakes*           " + str(round(abs(gforce_max[2]),2)), font=font)
    canvasSF.text(               (20, myImageSF.size[0]*0.95 -  30*mult) ,"    on throttle*         " + str(round(abs(gforce_max[3]),2)), font=font)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
    canvasSF.text((20, myImageSF.size[1]*0.95 +  30*mult),
        '|  ' + sCar +  '  |  ' + ac.getTrackName(0) + '  |  ' +
        "data points: " + str(int(datagf)) + '  |  *not in graph  |',
        font=font)


    ### 'Speed vs Engine RPM'
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(25*mult))
    canvasSF2.text((myImageSF2.size[0]*0.01, myImageSF2.size[0]-int(350*mult)),'Speed vs Engine RPM'                                    , font=font)
    #canvasSF2.text((myImageSF2.size[0]*0.01, myImageSF2.size[0]-int(350*mult)),'Speed  VS '                                             , font=font)
    #DrawRotated(myImageSF2, 'Engine RPM', font, mult)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(18*mult))
    # str(int(currentRPM))+' rpm\n' + str(int(maxRPM)) + ' max', 40 + fontSize2, int(hsub/2))
    # str(int(ac_speed))+' km/h         ', int(wsub*0.6), int(hsub-fontSize*2), align=ExtGL.FONT_ALIGN_RIGHT)
    canvasSF2.text(               (20, myImageSF2.size[0]*0.95 - 230*mult) ,"max Speed in km/h"                                                         , font=font)
    canvasSF2.text(               (20, myImageSF2.size[0]*0.95 - 200*mult) ,"    displayed (x)        " + "50-" +str(int(gSpeedNormalizer))             , font=font)
    canvasSF2.text(               (20, myImageSF2.size[0]*0.95 - 180*mult) ,"    reached              " + str(round(maxSpeedReached,2))                 , font=font)
    canvasSF2.text(               (20, myImageSF2.size[0]*0.95 - 140*mult) ,"max engine RPM"                                                            , font=font)
    canvasSF2.text(               (20, myImageSF2.size[0]*0.95 - 110*mult) ,"    displayed (y)        " + str(minRPMdisplayed) + '-' + str(int(maxRPM)) , font=font)
    canvasSF2.text(               (20, myImageSF2.size[0]*0.95 -  90*mult) ,"    reached              " + str(round(maxRPMReached,1))                   , font=font)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
    canvasSF2.text((20, myImageSF2.size[1]*0.95 +  30*mult),
        '|  ' + sCar +  '  |  ' + ac.getTrackName(0)+ '  |  ' +
        'data points: ' + str(int(datagf)) + '  |  ',
        font=font)




    ### 4th image, 'Speed vs Longit. g-force'
    # paint in a cross
    canvasSF3.rectangle( ( myImageSF3.size[0]/2-6 , myImageSF3.size[1]/2-1 , myImageSF3.size[0]/2+6 , myImageSF3.size[1]/2+1  ), fill=(0,0,0) )
    canvasSF3.rectangle( ( myImageSF3.size[0]/2-1 , myImageSF3.size[1]/2-6 , myImageSF3.size[0]/2+1 , myImageSF3.size[1]/2+6  ), fill=(0,0,0) )
    canvasSF3.rectangle( ( myImageSF3.size[0]/2-5 , myImageSF3.size[1]/2   , myImageSF3.size[0]/2+5 , myImageSF3.size[1]/2    ), fill=(255,255,255) )
    canvasSF3.rectangle( ( myImageSF3.size[0]/2   , myImageSF3.size[1]/2-5 , myImageSF3.size[0]/2   , myImageSF3.size[1]/2+5  ), fill=(255,255,255) )

    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(25*mult))
    canvasSF3.text((myImageSF3.size[0]*0.01, myImageSF3.size[0]-int(350*mult)),'Speed vs Lon. g-force', font=font)
    # canvasSF3.text((myImageSF3.size[0]*0.01, myImageSF3.size[0]-int(350*mult)),'Speed  VS '         , font=font)
    # DrawRotated(myImageSF3, 'Longit. g-force', font, mult)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(18*mult))
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 - 230*mult) ,"max Speed in km/h (x)"                                       , font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 - 200*mult) ,"    displayed            " + "50-" +str(int(gSpeedNormalizer))  , font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 - 180*mult) ,"    reached              " + str(round(maxSpeedReached,2))         , font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 - 140*mult) ,"max g's (y)"                                                 , font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 - 110*mult) ,"    displayed           ±" + str(round(base_gforce_fac,2))   , font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 -  90*mult) ,"    left*                " + str(round(abs(gforce_max[0]),2)), font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 -  70*mult) ,"    right*               " + str(round(abs(gforce_max[1]),2)), font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 -  50*mult) ,"    on brakes            " + str(round(abs(gforce_max[2]),2)), font=font)
    canvasSF3.text(               (20, myImageSF3.size[0]*0.95 -  30*mult) ,"    on throttle          " + str(round(abs(gforce_max[3]),2)), font=font)

    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
    canvasSF3.text((20, myImageSF3.size[1]*0.95 +  30*mult),
        '|  ' + sCar +  '  |  ' + ac.getTrackName(0)+ '  |  ' +
        'data points: ' + str(int(datagf))  + '  |  *not in graph  |',
        font=font)




    ### 5th image, 'RPM vs power'
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(25*mult))
    canvasSF4.text((myImageSF4.size[0]*0.01, myImageSF4.size[0]-int(350*mult)),'RPM vs Torque/Power'                                     , font=font)
    # canvasSF4.text((myImageSF4.size[0]*0.01, myImageSF4.size[0]-int(350*mult)),'Speed  VS '                                            , font=font)
    # DrawRotated(myImageSF4, 'Longit. g-force', font, mult)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(18*mult))
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 - 230*mult) ,"max RPM (x)"                                                , font=font)
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 - 200*mult) ,"    displayed       " + str(minRPMdisplayed) + '-' + str(round(maxRPM,2))  , font=font)
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 - 180*mult) ,"    reached         " + str(round(maxRPMReached,2))         , font=font)
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 - 140*mult) ,"max Torque/Power (y)"                                       , font=font)
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 - 110*mult) ,"    displayed       " + str(int(MaxPowDiv))                 , font=font)
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 -  90*mult) ,"    max Torque Nm   " + str(round(maxTorque,3))             , font=font)
    canvasSF4.text(               (20, myImageSF4.size[0]*0.95 -  70*mult) ,"    max Power bHp   " + str(round(maxPower,3))              , font=font)

    # canvasSF4.text(               (20, myImageSF4.size[0]*0.95 -  90*mult) ,"    left*:               " + str(round(abs(gforce_max[0]),2)), font=font)
    # canvasSF4.text(               (20, myImageSF4.size[0]*0.95 -  70*mult) ,"    right*:              " + str(round(abs(gforce_max[1]),2)), font=font)
    # canvasSF4.text(               (20, myImageSF4.size[0]*0.95 -  50*mult) ,"    on brakes:           " + str(round(abs(gforce_max[2]),2)), font=font)
    # canvasSF4.text(               (20, myImageSF4.size[0]*0.95 -  30*mult) ,"    on throttle:         " + str(round(abs(gforce_max[3]),2)), font=font)

    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
    canvasSF4.text((20, myImageSF4.size[0]*0.95 +  30*mult),
        '|  ' + sCar +  '  |  ' + ac.getTrackName(0)+ '  |  ' +
        'data points: ' + str(int(datagf))  + '  |  ',
        font=font)






    ### remove any current lap
    c=0
    for lapimg in savedFiles:
      if os.path.isfile(laps_images_path + lapimg):
        c+=1
    if c==OverallLaps and len(lapTimes)>0:
      myImageSP.putalpha(0)
    else:
      if len(AI_LINE)>0:
        ### save heatmap
        if bSaveAllLaps:
          myImageMap.save(laps_images_path  + globalprefix + ' heatmap.png')
        else:
          myImageMap.save(laps_images_path  + postfix      + ' heatmap.png')

    ### paste all saved imgs
    for lapimg in savedFiles:
      if os.path.isfile(lapimg):
        iml = Image.open(lapimg)
        maskF = iml.split()[-1]
        myImageSP.paste(iml, (0,0), maskF)

    ### save blanc
    if bSaveAllLaps:
      myImageSP.save(       laps_images_path + globalprefix + ' Laps_combined0'  + '.png', compress_level=1)
    else:
      myImageSP.save(       laps_images_path + 'Laps_combined0'  + '.png', compress_level=1)








    ### 6th image, 'Speed vs PoT Point of Track'
    mult=myImageSP.size[0]/1024
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(10*mult))
    canvasSP.text((myImageSP.size[0]*0.01, myImageSP.size[1]*0.02),'Steering'                               , font=font)
    canvasSP.text((myImageSP.size[0]*0.01, myImageSP.size[1]*0.13),'Throttle'                               , font=font)
    canvasSP.text((myImageSP.size[0]*0.01, myImageSP.size[1]*0.24),'Brake'                                  , font=font)
    canvasSP.text((myImageSP.size[0]*0.01, myImageSP.size[1]*0.35),'Gear'                                   , font=font)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(16*mult))
    canvasSP.text((myImageSP.size[0]*0.01, myImageSP.size[1]*0.55),'Speed vs lap'   , font=font)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(10*mult))
    canvasSP.text(               (myImageSP.size[0]*0.01, myImageSP.size[1]*0.6)  ,"displayed  " + "50-" +str(int(gSpeedNormalizer)) +' km/h', font=font)
    canvasSP.text(               (myImageSP.size[0]*0.01, myImageSP.size[1]*0.625) ,"reached    " + str(round(maxSpeedReached,2))    +' km/h', font=font)

    #canvasSP.text((myImageSP.size[0]*0.01, myImageSP.size[1]*0.35),'Speed'                                  , font=font)
    # myImageSP.text((myImageSF4.size[0]*0.01, myImageSP.size[0]-int(350*mult)),'Speed  VS '                                                , font=font)
    # DrawRotated(myImageSP, 'Longit. g-force', font, mult)
    #font = ImageFont.truetype('content/fonts/consola.ttf', size=int(18*mult))
    #canvasSP.text(               (20, myImageSP.size[0]*0.95 - 230*mult) ,"max RPM (x)"                                               , font=font)
    #canvasSP.text(               (20, myImageSP.size[0]*0.95 - 200*mult) ,"    displayed:     " + str(minRPMdisplayed) + '-' + str(round(maxRPM,2))  , font=font)



    # laps + laptimes + color legend
    # ac.log('laptimes: ' + str(len(lapTimes))+ ' ' + str(lapTimes))
    OverallLaps2=OverallLaps
    bestLap  = 0
    worstLap = 0
    if len(lapTimes)>0:
      loclapTimes = lapTimes
      loclapTimesFlags = lapTimesFlags
      i=0
      while i<len(loclapTimes):
        if lapTimesFlags[i]=='† ':
          loclapTimes.pop(i)
          loclapTimesFlags.pop(i)
        else:
          i+=1
      if len(loclapTimes)>0:
        bestLap  = min(loclapTimes)
        worstLap = max(loclapTimes)
    if len(lapTimes)==0 and currTime>0:
      lapTimes.append(currTime)
      lapTimesFlags.append('* ')
      OverallLaps2+=1

    # laps + laptimes + color legend
    if len(lapTimes)>0:
      font = ImageFont.truetype('content/fonts/consola.ttf', size=int(9*mult))
      y = myImageSP.size[1]*0.75   #  # 855
      canvasSP.text(      (20, y + myImageSP.size[1]*0.03+2) , 'Laps', font=font)
      i=0
      offset=0
      tenc=0
      for j in range(OverallLaps2):
        if j<10:
          font = ImageFont.truetype('content/fonts/consola.ttf', size=int(8*mult))
          canvasSP.text(      (  100  + 45 + i*149         , y + myImageSP.size[1]*0.04)  , str(j+1), font=font)
        font = ImageFont.truetype('content/fonts/consola.ttf', size=int(8*mult))
        if j<len(lapTimes):
          if lapTimesFlags[j]=='† ':
            canvasSP.text(    (  100  + i*150              , y + myImageSP.size[1]*0.065+offset) , lapTimesFlags[j] + timeToString(lapTimes[j]), font=font, fill=(172,172,172))
          elif lapTimes[j]==bestLap and bestLap!=0:
            canvasSP.text(    (  100  + i*150              , y + myImageSP.size[1]*0.065+offset) , lapTimesFlags[j] + timeToString(lapTimes[j]), font=font, fill=(144,255,144))
          else:
            # diff=min(242, int((bestLap-lapTimes[j])*10000))
            diff=0
            if worstLap!=0:
              diff=min(0,max(128, int((bestLap/worstLap*225))))
            if lapTimes[j]==worstLap and worstLap!=0:
              canvasSP.text(    (  100  + i*150             , y + myImageSP.size[1]*0.065+offset) , lapTimesFlags[j] + timeToString(lapTimes[j]), font=font, fill=(255,144,144))
            else:
              canvasSP.text(    (  100  + i*150             , y + myImageSP.size[1]*0.065+offset) , lapTimesFlags[j] + timeToString(lapTimes[j]), font=font, fill=(255,255-diff,255-diff))
        rgb = getColorGear2(i % 10 )
        if j<10:
          canvasSP.rectangle( (  100  + i*150             , y + myImageSP.size[1]*0.03,
                                 100  + i*150 + 100*mult/2, y + myImageSP.size[1]*0.03+2*mult),
                                 fill=(int(rgb[0]*255), int(rgb[1]*255), int(rgb[2]*255) ) )
        i+=1
        if i>0 and (i % 10) == 0:
          tenc+=1
          font = ImageFont.truetype('content/fonts/consola.ttf', size=int(8*mult))
          canvasSP.text(      (  20  , y + myImageSP.size[1]*0.095 + offset)  , '+' + str(tenc*10), font=font)
          offset += myImageSP.size[1]*0.025
          i=0



    ### insert section names
    try:
      if os.path.isfile(sectFile):
        off = 0
        sectConf = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_"), comment_prefixes=(";","#","/","_"))
        sectConf.optionxform = str
        with open(sectFile, "r", encoding="utf-8", errors="ignore") as F:
              sectConf.read_string("[ACHEADER]\n" + F.read() ) # .encode('ascii', 'ignore').decode('ascii'))
        # sectConf.read_file(codecs.open(sectFile, 'r', 'utf_8', errors='ignore'))

        # font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
        font = ImageFont.truetype('content/fonts/consola.ttf', size=int(6*mult))
        for section in sectConf:
          if 'SECTION_' in section:
            IN  = float(sectConf.get(section,'IN') )
            OUT = float(sectConf.get(section,'OUT') )
            # txt = '↕ '+str(sectConf.get(section,'TEXT')).strip()
            # txt = '▴\n'+str(sectConf.get(section,'TEXT')).strip()+'\n▾'
            # ˂˃˄˅⋁⋀⌵ ⌄⌃ ◃▹◅▻▵▿∆∇△▽◁▷ ◂▸◄►◀▶ ▴▾⏶⏷▲▼⏴⏵⏮⏭ <> ≪≫ ⫷⫸ ⋘⋙ ←↑↕↨→↓↔↗↙
            # ⇀ ⇉ ⇒ ⇛ ⇝ ⇢ ⇥ ⇑⇓⇨ ↞↠↢↢↢↣ → ⤳ ↜↭↝ ↦ ⅏ ․ ‥ …   ┉ ┈  ⃛  ⃜  ⁗ ′ ″ ‴ ‶ ‷ ⁗
            currPoT = (OUT+IN)/2.0

            off+=int(8*mult)
            if off>int(8*mult)*7+7:
              off=0
            x=int(currPoT*myImageSP.size[0])
            y=int(myImageSP.size[1]*0.625+off)
            TXT = '▲ '+ str(sectConf.get(section,'TEXT')).strip()
            t     = TXT.split(' ') # we added '▲ ', so it must have one at least
            i=0
            b=False
            while i<len(t):
              if i==0:
                canvasSP.text((x, y+int(i*9*mult)), t[i], font=font)
                off+=int(4*mult)
              else:
                if i+1<len(t) and (len(t[i])<3 or len(t[i+1])<3):
                  w, h = canvasSP.textsize(t[i]+' '+t[i+1])
                  if x+w/2>myImageSP.size[0] or x-w/2<0:
                    w=w*2
                  canvasSP.text((int(x-w/2), y+int(i*9*mult)), t[i]+' '+t[i+1], font=font)
                  off+=int(4*mult)
                  b=True
                  i+=1
                else:
                  w, h = canvasSP.textsize(t[i])
                  if x+w/2>myImageSP.size[0] or x-w/2<0:
                    w=w*2
                  if b:
                    canvasSP.text((int(x-w/2), y+int((i-1)*9*mult)), t[i], font=font)
                  else:
                    canvasSP.text((int(x-w/2), y+int(i*9*mult)), t[i], font=font)
                  off+=int(4*mult)
              i+=1

      # gray lines on pil image
      ### paint center steering wheel line
      cur_y = min(1,histDotSize) + minioffset
      for x in range(0, myImageSP.size[0], 5):
        canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(127, 127, 127))
      cur_y = (1-(5-2)/7) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.33
      for x in range(0, myImageSP.size[0], 20):
        canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(127, 127, 127))
      cur_y = (1-(3-2)/7) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.33
      for x in range(0, myImageSP.size[0], 10):
        canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(127, 127, 127))
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.105
      for x in range(0, myImageSP.size[0], 10):
        canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(64, 64, 64))
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.215
      for x in range(0, myImageSP.size[0], 10):
        canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(64, 64, 64))
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.325
      for x in range(0, myImageSP.size[0], 10):
        canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(64, 64, 64))
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.44+minioffset2/2
      canvasSP.line([(0, cur_y), (myImageSP.size[0], cur_y)], fill=(172, 172, 172))
      # for x in range(0, myImageSP.size[0], 10):
      #   canvasSP.line([(x, cur_y), (x + 2, cur_y)], fill=(64, 64, 64))

      # meter scala
      # m track scale from left to right
      font = ImageFont.truetype('content/fonts/consola.ttf', size=int(6*mult))
      div=250
      if fTrackLength>=2000:
        div=500
      if fTrackLength>=5000:
        div=1000
      if fTrackLength>=10000:
        div=2000
      if fTrackLength>=15000:
        div=2500
      if fTrackLength>=30000:
        div=5000
      y = myImageSP.size[1]*0.45
      for i in range(int(fTrackLength)):
        if i % div == 0:
          x = int( i/fTrackLength * myImageSP.size[0] )
          canvasSP.rectangle( ( x-1     , y-6 ,
                                x+1     , y+6  ), fill=(0,0,0) )
          canvasSP.rectangle( ( x       , y-5 ,
                                x       , y+5  ), fill=(255,255,255) )
          if i==0:
            canvasSP.text((       x+mult*5, y+mult*4), str(i)+'m', font=font)
          else:
            canvasSP.text((       x-mult*5, y+mult*4), str(i)+'m', font=font)
      w, h = canvasSP.textsize(str(int(fTrackLength))+'m')
      canvasSP.text((myImageSP.size[0]+5  , y+mult*4), str(0)+'m', font=font)
      canvasSP.text((myImageSP.size[0]-w-5, y+mult*4), str(int(fTrackLength))+'m', font=font)
      # km/h scale on the right
      for i in range(50, maxSpeed+1):
        if i % 50 == 0:
          x = int( myImageSP.size[0]-mult*4 )
          y = myImageSP.size[1] - myImageSP.size[1]*0.56 * (i-50)/(maxSpeed-50)
          canvasSP.rectangle( ( x-6     , y-1 ,
                                x+6     , y+1  ), fill=(0,0,0) )
          canvasSP.rectangle( ( x-5     , y ,
                                x+5     , y  ), fill=(255,255,255) )
          if i >= maxSpeed-51:
            canvasSP.text((       x-mult*30, y+mult*4), str(i)+'km/h', font=font)
          else:
            canvasSP.text((       x-mult*30, y-mult*2), str(i)+'km/h', font=font)


      # data info mode 4 (5 in ui) add nation flag, livery, miniskin if available
      w, h = canvasSP.textsize(DriverName)
      myImLivery = 0
      myImMiniPrev = 0
      myImFlag = 0
      if os.path.exists(fileNationCode):
        myImFlag = Image.open(fileNationCode)
        hhh = int(16*mult)
        www = int(hhh/myImFlag.size[1]*myImFlag.size[0])
        myImFlag = myImFlag.resize((www, hhh),resample=Image.ANTIALIAS)
      if os.path.exists(fileLivery):
        myImLivery = Image.open(fileLivery)
        hhh = int(18*mult)
        www = int(hhh/myImLivery.size[1]*myImLivery.size[0])
        myImLivery = myImLivery.resize((www, hhh),resample=Image.ANTIALIAS)
      if os.path.exists(fileMiniPrev):
        myImMiniPrev = Image.open(fileMiniPrev)
        hhh = int(minioffset*1.75)
        www = int(hhh/myImMiniPrev.size[1]*myImMiniPrev.size[0])
        myImMiniPrev = myImMiniPrev.resize((www, hhh),resample=Image.ANTIALIAS)

      if myImFlag != 0:
        maskF = myImFlag.split()[-1]
        myImageSP.paste(myImFlag    , (int(myImFlag.size[0]/2)           , int(myImageSP.size[1]*0.96-myImFlag.size[0]*1.4        )), maskF)
      if myImLivery != 0:
        myImageSP.paste(myImLivery  , (int(myImLivery.size[0]/2  +w*2.75), int(myImageSP.size[1]*0.96-myImLivery.size[0]*1.4      )), myImLivery.split()[-1])
      if myImMiniPrev != 0:
        myImageSP.paste(myImMiniPrev, (int(myImMiniPrev.size[0]  +w*1.75), int(myImageSP.size[1]*0.96-myImMiniPrev.size[0]*0.6    )), myImMiniPrev.split()[-1])

      font = ImageFont.truetype('content/fonts/consola.ttf', size=int(8*mult))
      if ac_status==1: # replay
        canvasSP.text((w*1.5, myImageSP.size[1]*0.95 +  30*mult/10),
            DriverName + '      ' + sCar +  '  |  ' + sTrack + '  |  ' +
            'data points: ' + str(int(datagf))  + '  |',
            font=font)
      else:
        canvasSP.text((w*1.5, myImageSP.size[1]*0.95 +  30*mult/10),
            DriverName + '      ' + sCar +  '  |  ' + sTrack + '  |  ' +
            'data points: ' + str(int(datagf))  + '  |  max Tyre temps Core/O/M/I:',
            font=font)
    except:
      ac.log('leb_yatt pic painting error: ' + traceback.format_exc())




    mult=myImageAS.size[1]/1024

    ### 6th image, 'Aero susp rideheight'
    # gDataMode==6
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(25*mult))
    canvasAS.text((myImageAS.size[0]/2-int(mult*10), int(20*mult)),'Aero/Suspensions/RideHeight', font=font)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
    canvasAS.text((20, myImageAS.size[1]*0.95 +  10),
        '|  ' + sCar +  '  |  ' + ac.getTrackName(0)+ '  |  ' +
        'data points: ' + str(int(datagf))  + '  |  ',
        font=font)


    ### 7th image, 'Slipangle vs SlipRatio'
    # gDataMode==7
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(25*mult))
    canvasAS_bg.text((myImageAS_bg.size[0]*0.01, myImageAS_bg.size[1]/2-int(mult*10)),'SlipAngle vs SlipRatio', font=font)
    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(18*mult))
    canvasAS_bg.text(               (20, myImageAS_bg.size[1]*0.95 -  50*mult) ,"    slip angle (x)  ± 10 °" , font=font)
    canvasAS_bg.text(               (20, myImageAS_bg.size[1]*0.95 -  30*mult) ,"    slip ratio (y)  ± 25 % ", font=font)
    cur_x = myImageAS_bg.size[0]/4
    cur_y = myImageAS_bg.size[1]/4
    for x in range(0, myImageAS_bg.size[0], 5):
      # appDrawLineA(1,1,1,1,x, cur_y, x + 3, cur_y, 2)
      canvasAS.line([(x, cur_y), (x + 3, cur_y)], fill=(127, 127, 127))
    cur_x = myImageAS_bg.size[0]/4
    cur_y = myImageAS_bg.size[1]/4*3
    for x in range(0, myImageAS_bg.size[0], 5):
      # appDrawLineA(1,1,1,1,x, cur_y, x + 3, cur_y, 2)
      canvasAS.line([(x, cur_y), (x + 3, cur_y)], fill=(127, 127, 127))
    cur_x = myImageAS_bg.size[0]/4
    cur_y = myImageAS_bg.size[1]/4
    for x in range(0, myImageAS_bg.size[1], 5):
      # appDrawLineA(1,1,1,1,cur_x, x, cur_x, x + 3, 2)
      canvasAS.line([(cur_x, x), (cur_x, x + 3)], fill=(127, 127, 127))
    cur_x = myImageAS_bg.size[0]/4*3
    cur_y = myImageAS_bg.size[1]/4*3
    for x in range(0, myImageAS_bg.size[1], 5):
      # appDrawLineA(1,1,1,1,cur_x, x, cur_x, x + 3, 2)
      canvasAS.line([(cur_x, x), (cur_x, x + 3)], fill=(127, 127, 127))

    font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
    canvasAS.text((20, myImageAS.size[1]*0.95 +  10),
        '|  ' + sCar +  '  |  ' + ac.getTrackName(0)+ '  |  ' +
        'data points: ' + str(int(datagf))  + '  |  ',
        font=font)











    if bSaveAllLaps:
      ### image names with car + track
      myImageAS.save(     laps_images_path + globalprefix + ' Laps_aerosusp' + '.png', compress_level=1)
      myImageAS_bg.save(  laps_images_path + globalprefix + ' Laps_slip'     + '.png', compress_level=1)
      myImageSP.save(     laps_images_path + globalprefix + ' Laps_Combined' + '.png', compress_level=1)
      myImageSF.save(     laps_images_path + globalprefix + ' Steer_GForce'  + '.png', compress_level=1)
      myImageSF2.save(    laps_images_path + globalprefix + ' Speed_RPM'     + '.png', compress_level=1)
      myImageSF3.save(    laps_images_path + globalprefix + ' Speed_GForce'  + '.png', compress_level=1)
      myImageSF4.save(    laps_images_path + globalprefix + ' RPM_Power'     + '.png', compress_level=1)
    else:
      ### image names always the same
      if len(AI_LINE)>0:
        myImageMap.save(    laps_images_path + localpostfix + ' heatmap'       + '.png', compress_level=1)
      myImageAS.save(     laps_images_path + localpostfix + ' Laps_slip'     + '.png', compress_level=1)
      myImageAS_bg.save(  laps_images_path + localpostfix + ' Laps_aerosusp' + '.png', compress_level=1)
      myImageSP.save(     laps_images_path + localpostfix + ' Laps_Combined' + '.png', compress_level=1)
      myImageSF.save(     laps_images_path + localpostfix + ' Steer_GForce'  + '.png', compress_level=1)
      myImageSF2.save(    laps_images_path + localpostfix + ' Speed_RPM'     + '.png', compress_level=1)
      myImageSF3.save(    laps_images_path + localpostfix + ' Speed_GForce'  + '.png', compress_level=1)
      myImageSF4.save(    laps_images_path + localpostfix + ' RPM_Power'     + '.png', compress_level=1)
  except:
    ac.log('leb_yatt saving images error: ' + traceback.format_exc())

##########################################################









def appDrawText(c, t, x, y, sz=12, align=ExtGL.FONT_ALIGN_CENTER):
    global f1, bCSPActive
    if bCSPActive:
        ac.ext_glFontColor(f1.f, c, c, c, 1)
        ac.ext_glFontUse(f1.f, t, x, y, sz, align)

def appDrawTextRGB(r,g,b,a, t, x, y, sz=12, align=ExtGL.FONT_ALIGN_CENTER):
    global f1, bCSPActive
    if bCSPActive:
        ac.ext_glFontColor(f1.f, r, g, b, a)
        ac.ext_glFontUse(f1.f, t, x, y, sz, align)


def drawBox4Points(r, g, b, a, x1,y1, x2,y2, x3,y3, x4,y4):
  ac.glBegin(acsys.GL.Quads)
  ac.glColor4f(r,g,b,a)
  ac.glVertex2f(x1,y1)
  ac.glVertex2f(x2,y2)
  ac.glVertex2f(x3,y3)
  ac.glVertex2f(x4,y4)
  ac.glEnd()

def appDrawLine2(r,g,b,a,x1,y1,width=10,height=10):
    ac.glColor4f(r,g,b,a)
    ac.glQuad(x1,y1,width,height)

def appDrawLine1(r,g,b,a,x1,y1,x2,y2,width=4):
  w=width
  ac.glBegin(acsys.GL.Quads)
  ac.glColor4f(r,g,b,a)
  ac.glVertex2f(x1-width/2,y1)
  ac.glVertex2f(x2-width/2,y2)
  ac.glVertex2f(x2+width/2,y2)
  ac.glVertex2f(x1+width/2,y1)
  ac.glEnd()

def appDrawLine0(r,g,b,a,x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Quads)
  ac.glColor4f(r,g,b,a)
  ac.glVertex2f(x1,y1-width/2)
  ac.glVertex2f(x2,y2-width/2)
  ac.glVertex2f(x2,y2+width/2)
  ac.glVertex2f(x1,y1+width/2)
  ac.glEnd()

def appDrawLine(r,g,b,a,x1,y1,x2,y2,width=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glColor4f(r,g,b,a)
    ac.glVertex2f(x1-width/2,y1)
    ac.glVertex2f(x2-width/2,y2)
    ac.glVertex2f(x2+width/2,y2)
    ac.glVertex2f(x1+width/2,y1)
    ac.glEnd()

def appDrawLineA(r,g,b,a,x1,y1,x2,y2,width=1):
  w=width/2
  #if abs(x1-x2)>abs(y1-y2):
  if abs(y1-y2)<=2:
    appDrawLine0(r,g,b,a,x1,y1,x2,y2,width)
    #appDrawLine(r,g,b,a,x1,y1,x2,y2,width)
  else:
    appDrawLine(r,g,b,a,x1,y1,x2,y2,width)


def appDrawDot(r,g,b,a,x1,y1,sizeX,sizeYneg, sizeYpos, tex):
  global gSizeGforceW
  ac.glColor4f(r,g,b,a)
  # ac.glQuadTextured(x1-sizeX/2*graphW, y1-sizeYneg/2*graphH, sizeX*graphW, sizeYpos*graphH, tex)
  ac.glQuadTextured(x1-sizeX/2*gSizeGforceW, y1-sizeYneg/2*gSizeGforceW, sizeX*gSizeGforceW, (sizeYneg/2+sizeYpos/2)*gSizeGforceW, tex)

def appDrawDotBothAxes(r,g,b,a,x1,y1,sizeXneg, sizeXpos, sizeYneg, sizeYpos, tex):
  global gSizeGforceW
  ac.glColor4f(r,g,b,a)
  # ac.glQuadTextured(x1-sizeX/2*graphW, y1-sizeYneg/2*graphH, sizeX*graphW, sizeYpos*graphH, tex)
  ac.glQuadTextured(x1-sizeXneg/2*gSizeGforceW, y1-sizeYneg/2*gSizeGforceW, (sizeXneg/2+sizeXpos/2)*gSizeGforceW, (sizeYneg/2+sizeYpos/2)*gSizeGforceW, tex)



def DrawRotated(img, text, font, mult):
  # rotated
  txt=Image.new('L', (int(img.size[0]/2),int(img.size[0]/2)))
  d=ImageDraw.Draw(txt)
  d.text( (0, 0), text, font=font, fill=255)
  wtxt=txt.rotate(90, expand=0)
  img.paste( ImageOps.colorize(wtxt, (0,0,0), (255,255,184)), (int(380*mult),int(img.size[0]*0.425)), wtxt)

def DrawColored(img, text, font, mult, r,g,b):
  # rotated
  txt=Image.new((int(img.size[0]),int(img.size[0])))
  d=ImageDraw.Draw(txt)
  d.text( (0, 0), text, font=font, fill=(r,g,b))
  img.paste( ImageOps.colorize(txt, (0,0,0), (255,255,184)), (int(380*mult),int(img.size[0]*0.425)), txt)

def appDrawDotBothAxesPIL(r,g,b,a,x1,y1,sizeXneg, sizeXpos, sizeYneg, sizeYpos, img, img2):
    global gSizeGforceW, wmain, PNGmultGF
    sz_halfH = int( (sizeXneg+sizeXpos)*gSizeGforceW/2)
    sz_halfV = int( (sizeYneg+sizeYpos)*gSizeGforceW/2)
    newImg = img2.resize((sz_halfH, sz_halfV),
                          resample=Image.ANTIALIAS)
                          #resample=Image.Resampling.LANCZOS)
    newImg2 = ImageOps.colorize(newImg.convert("L"), (0,0,0), (r*255,g*255,b*255))
    mask = newImg.split()[-1]
    enh = ImageEnhance.Brightness(mask)
    mask = enh.enhance(a*2)
    newImg2.putalpha(mask)

    img.paste(newImg2,
              (int(PNGmultGF*wmain/2 - sizeXneg*gSizeGforceW/2),
               int(PNGmultGF*wmain/2 - sizeYneg*gSizeGforceW/2)),
              mask)



########################################################################################################################
########################################################################################################################
########################################################################################################################
########################################################################################################################


### draw on 2nd graph
def appDrawDot3(r,g,b,alpha,x1,y1,size,texdot, DataMode=0, useCol=False):
    global wsub, hsub, texture_dot, PNGmultSF, texture_dot2, histDotSizePNG, myImageSF
    ### this is a mess!

    if (DataMode==0):
      if x1<myImageSF.size[0]/2:
        xx=math.sqrt( (myImageSF.size[0]/2-x1)  /myImageSF.size[0])
      else:
        xx=math.sqrt( (x1-(myImageSF.size[0]/2))/myImageSF.size[0])
      if y1<myImageSF.size[1]/2:
        yy=math.sqrt( (myImageSF.size[1]/2-y1)  /myImageSF.size[1])
      else:
        yy=math.sqrt( (y1-(myImageSF.size[1]/2))/myImageSF.size[1])
    else:
      if x1<myImageSF.size[0]/2:
        xx=math.sqrt( (myImageSF.size[0]/2-x1)  /myImageSF.size[0])
      else:
        xx=math.sqrt( (x1-(myImageSF.size[0]/2))/myImageSF.size[0])
      yy=1-y1/myImageSF.size[1]

    if not useCol:
      ac.glColor4f(yy,yy,yy,alpha)
    else:
      ac.glColor4f(r,g,b,alpha)

    ### this is a mess2!
    #if dataMode==3:
    if (DataMode==1 or DataMode==2) and not useCol:
      if currentGear>0:
        rgb = getColorGear2(currentGear % 10)
        ac.glColor4f(rgb[0]*yy*2,rgb[1]*yy*2,rgb[2]*yy*2,alpha)
    elif DataMode==0:
      if gColor==0:
        ac.glColor4f( abs(yy), abs(yy), abs(abs(yy)), alpha)
      elif gColor==1:
        #ac.glColor4f(0.5-abs(yy*yy), 0.5, (abs(xx)+abs(yy))*yy, alpha)
        ac.glColor4f(1-abs(yy*yy), 1-xx*2, (abs(xx)+abs(yy))*yy*2, alpha)
        #ac.glColor4f(abs(yy*yy)*2, 0.5+((abs(xx)+abs(yy))), ((abs(xx)+abs(yy)))*yy, alpha)
      else:
        ac.glColor4f(1-xx,1-yy, (abs(xx)+abs(yy)), alpha)

    ac.glQuadTextured(x1-size/2, y1-size/2, size, size, texdot)


### draw on 2nd graph
def appDrawDot33(r,g,b,alpha,x1,y1,size,texdot, DataMode=0, useCol=False):
  global wsub, hsub, texture_dot, PNGmultSF, texture_dot2, histDotSizePNG, myImageSF
  if x1<myImageSF.size[0]/2:
    xx=1-math.sqrt( (myImageSF.size[0]/2-x1)  /myImageSF.size[0])
  else:
    xx=1-math.sqrt( (x1-(myImageSF.size[0]/2))/myImageSF.size[0])
  if y1<myImageSF.size[1]/2:
    yy=1-math.sqrt( (myImageSF.size[1]/2-y1)  /myImageSF.size[1])
  else:
    yy=1-math.sqrt( (y1-(myImageSF.size[1]/2))/myImageSF.size[1])

  if useCol:
    if DataMode==3:
      yy=1-(y1/myImageSF.size[1])
      ac.glColor4f(r*yy,g*yy,b*yy,alpha)
    else:
      ac.glColor4f(r*yy,g*yy,b*yy,alpha)
  else:
    ac.glColor4f(yy,yy,yy,alpha)
  ac.glQuadTextured(x1-size/2, y1-size/2, size, size, texdot)



################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################






### window painting

def onRenderWindow(deltaT):
  global appWindowLeB_YATT, lastXY, currCar, currID, histCount, histVisi, maxHistCount, smoothValue, rgbT, rgbB
  global gforcesteer_x_act, gforcesteer_y_act, act_idx2, bActiveTimer, currentGear, geardatacountdone, geardatacount
  global PNGmultSF, wmain, hmain, wsub, hsub, rtIndexSF, rtIndexSF2, rtIndexSF3, rtIndexSF4, rtIndexSP, rtIndexHeat_orig, rtIndexHeat, rtIndexSP_bg, myImageSF, bCSPActive, txcnt, maxSpeed
  global fadeoutime, timerIMG, ghistT, maxSteerReached, datagf, SteeringAngle, currentRPM, ac_speed, maxRPM, speedDiv, MaxPowDiv, SlipAng_Front, SlipAng_Rear
  global histDotSize, gSteeringNormalizer, gDataMode, gforce_x, fontSize, valx, valy, valxx, valyy, maxTorque, currTorque, currLap, Gears, gOpacityBG, OverallLaps, ac_throttle, ac_brake
  global valyFL, valyFR, valyRL, valyRR, txcnt2, BORDER_LEFT, BORDER_RIGHT, BORDER_RIGHT2, BORDER_LEFT2, BORDER_LEFT3, BORDER_RIGHT3, BORDER_LEFT4, BORDER_RIGHT4, aiid, lastaiid, AI_LINE
  global rtIndexAS_orig, rtIndexAS, rtIndexAS_bg, susForce, gHeatmapMode
  global AEROCDv, AEROCLf, AEROCLr, AERODownforceF, AERODownforceR, AERODrag, baseAEROdens, StaticDeflection
  global turboTorque, valxxx, valyyy, valxxxx, valyyyy, ac_SA, ac_SAx, ac_SRy, ac_LocalV, png_size, histDotSizePNG, histDotSize


  try:
    # if bActiveTimer: ### palette test
    #     for i in range(255):
    #         appDrawLine0(colorPal1[i][0], colorPal1[i][1], colorPal1 [i][2], 1, -150, 256-i, -100, 256-i, 1)

    if bCSPActive:
      #BBlock = True
      # bitblit (blend) painted image to screen
      ac.glBegin(acsys.GL.Quads)
      #ac.ext_glSetBlendMode(0)
      #ac.glColor4f(1,1,1,ghistT/100.0)
      ac.glColor4f(1,1,1,1)
      if   gDataMode==0:
        ac.ext_glSetTexture(rtIndexSF, 0)
      elif gDataMode==1:
        ac.ext_glSetTexture(rtIndexSF2, 0)
      elif gDataMode==2:
        ac.ext_glSetTexture(rtIndexSF3, 0)
      elif gDataMode==3:
        ac.ext_glSetTexture(rtIndexSF4, 0)
      elif gDataMode==4:
        ac.ext_glSetTexture(rtIndexSP, 0)
      elif gDataMode==5:
        ac.ext_glSetTexture(rtIndexHeat, 0)
      elif gDataMode==6:
        ac.ext_glSetTexture(rtIndexAS, 0)
      elif gDataMode==7:
        ac.ext_glSetTexture(rtIndexAS_bg, 0)
      ac.ext_glVertexTex(0,0,0,0)
      if gDataMode==5:
        msub = min(wsub,hsub)
        ac.ext_glVertexTex(0   ,msub,0,1)
        ac.ext_glVertexTex(msub,msub,1,1)
        ac.ext_glVertexTex(msub,   0,1,0)
      else:
        ac.ext_glVertexTex(0   ,hsub,0,1)
        ac.ext_glVertexTex(wsub,hsub,1,1)
        ac.ext_glVertexTex(wsub,   0,1,0)
      ac.glEnd()

    if showLabels or bActiveTimer:
      if   gDataMode==0:
        appDrawText(1, str(int(SteeringAngle))+' °        max ±' + str(gSteeringNormalizer), int(wsub*0.6), int(hsub-fontSize2*2), fontSize2, align=ExtGL.FONT_ALIGN_RIGHT)
        appDrawText(1, str(round(gforce_x,2))+' g\nmax ±'+str(round(base_gforce_fac,1))                                                        , 40+fontSize2*0.25, int(hsub/2), fontSize2)
      elif gDataMode==1:
        # appDrawText(1, str(int(currentRPM))+' rpm\n' + str(int(maxRPM)) + ' max\n' + str(int(maxRPM/2)) + ' min', 40+fontSize2*0.25, int(hsub/2))
        appDrawText(1, str(round(ac_speed,1))+' km/h         max '+str(round(maxSpeedReached,2)), int(wsub*0.8), int(hsub-fontSize2*2), fontSize2, align=ExtGL.FONT_ALIGN_RIGHT)
        if gSizeGforceW<=100:
          appDrawText(1, str(int(maxRPMReached)) + ' max\n' + str(int(currentRPM))+' rpm\n' + str(int(minRPMdisplayed)) + ' min', 40+fontSize2*0.25, int(hsub/2-fontSize2*3), fontSize2)
        else:
          appDrawText(1, str(int(maxRPMReached)) + ' max\n\n\n' + str(int(currentRPM))+' rpm\n\n\n' + str(int(minRPMdisplayed)) + ' min', 40+fontSize2*0.25, int(hsub/2-fontSize2*6), fontSize2)
        appDrawText(1, str(int(currPower))+' bHp\nmax ' + str(int(maxPower))                                                                   , 40+fontSize2*0.25, int(hsub/8), fontSize2)
      elif gDataMode==2:
        appDrawText(1, str(round(ac_speed,1))+' km/h         max '+str(round(maxSpeedReached,2)), int(wsub*0.8), int(hsub-fontSize2*2), fontSize2, align=ExtGL.FONT_ALIGN_RIGHT)
        appDrawText(1, str(round(gforce_y,2))+' g\nmax ±'+str(round(base_gforce_fac/2,1))                                                      , 40+fontSize2*0.25, int(hsub/2), fontSize2)
        appDrawText(1, str(int(currPower))+' bHp\nmax ' + str(int(maxPower))                                                                   , 40+fontSize2*0.25, int(hsub/8), fontSize2)
      elif gDataMode==3:
        # rpm vs power/torque
        appDrawText(1, str(int(minRPMdisplayed)) + ' min        ' + str(int(currentRPM))+' rpm        max '+ str(int(maxRPM)), int(wsub*0.5), int(hsub-fontSize2*2), fontSize2, align=ExtGL.FONT_ALIGN_CENTER)
        appDrawTextRGB(1,0.25,0.25,1, str(int(currPower))+' bHp\nmax ' + str(int(maxPower)) , 40+fontSize2*0.25, int(hsub/3  )-fontSize2, fontSize2)
        appDrawTextRGB(1,1   ,0.25,1, str(int(currTorque))+' Nm\nmax ' + str(int(maxTorque)), 40+fontSize2*0.25, int(hsub/3*2)-fontSize2, fontSize2)
        # appDrawTextRGB(1,0.25,0.25,1, str(int(MaxPowDiv))+' Tor/Pow div', 40+fontSize2*0.25, int(hsub-fontSize2), fontSize2)
        if info.static.maxTurboBoost>0.0:
          appDrawTextRGB(0.25,0.25,1,1, 'turbo\n' + str(round(info.physics.turboBoost,3))+'x', 40+fontSize2*0.25, int(hsub/2)-fontSize2*1, fontSize2)
          #appDrawTextRGB(0.25,0.25,1,1, 'turbo\n' + str(round(info.physics.turboBoost,3))+'x\n' + str(int(turboTorque))+'Nm'  , 40+fontSize2*0.25, int(hsub/2)-fontSize2*2, fontSize2)
        #appDrawText(1, 'max ' +str(int(MaxPowDiv)), int(20/png_size*wsub), 20/png_size*wsub, fontSize2, align=ExtGL.FONT_ALIGN_LEFT)

        # appDrawText(1, str(round(ac_wspeed[0],3)),  40, gSizeGforceW*0.8)
        # appDrawText(1, str(round(ac_wspeed[1],3)), 120, gSizeGforceW*0.8)
        # appDrawText(1, str(round(ac_wspeed[2],3)),  40, gSizeGforceW*2.2)
        # appDrawText(1, str(round(ac_wspeed[3],3)), 120, gSizeGforceW*2.2)
        #appDrawText(1, str(int(currentRPM))+' rpm\nmax '   + str(int(maxRPM))   , 40+fontSize2*0.25, int(hsub/2.3))
        #appDrawText(1, str(int(currPower))+'Nm       max ' + str(int(maxPower))             , int(wsub*0.7), int(hsub-fontSize2*2), align=ExtGL.FONT_ALIGN_RIGHT)
      elif gDataMode==4:
        # Speed vs Track Position
        # speed
        appDrawText(1, 'max '+str(round(maxSpeedReached,2)) + '\n\n\n' + str(int(ac_speed))+'km/h\n\n\nmin 50'      , wsub*0.95, int(hsub/1.85), fontSize2*0.75, align=ExtGL.FONT_ALIGN_RIGHT)
        #appDrawText(1,        str(round(valxx/wsub*100,2))+'%', int(wsub*0.7), int(hsub-fontSize2*3), fontSize2, align=ExtGL.FONT_ALIGN_RIGHT)
        # track progress
        # appDrawText(1, str(round(distTraveled/1000,2))+'km  -  ' + "{:.2f}".format(valxx/wsub*100)+'%'    , int(wsub*0.7), int(hsub-fontSize2*3), fontSize2*0.75, align=ExtGL.FONT_ALIGN_RIGHT)
        appDrawText(1, str(round(AI_LINE[aiid][3]/1000,3))+'km  -  ' + "{:.2f}".format(valxx/wsub*100)+'%'    , int(wsub*0.7), int(hsub-fontSize2*3), fontSize2*0.75, align=ExtGL.FONT_ALIGN_RIGHT)
      elif gDataMode==5:
        minwh = min(wsub,hsub)
        if gHeatmapMode==0:
          appDrawText(1, 'Throttle: ' +str(int(ac_throttle*100))+'%', int(20/png_size*wsub),   90/png_size*minwh - 30/png_size*minwh, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          appDrawText(1, 'Brakes:   ' +str(int(ac_brake   *100))+'%', int(20/png_size*wsub),  130/png_size*minwh                    , fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        else:
          appDrawText(1, 'Speed: ' +str(round(ac_speed,0))+'km/h', int(20/png_size*wsub),   90/png_size*minwh - 30/png_size*minwh, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          appDrawText(1, 'lat G: ' +str(round(gforce_x,2))+''    , int(20/png_size*wsub),  130/png_size*minwh                    , fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
      elif gDataMode==6:
        rgb=getColorGear(2)
        appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'DownForce rear:   ' +str(int(AERODownforceR))+''  , int(20/png_size*wsub),  fontSize2*1, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        rgb=getColorGear(1)
        appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'DownForce front:  '+str(int(AERODownforceF))+''   , int(20/png_size*wsub),  fontSize2*2, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        rgb=getColorGear(9)
        appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'Lift rear:        ' +str(int(AEROCLr))+''         , int(20/png_size*wsub),  fontSize2*3, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'Lift front:       ' +str(int(AEROCLf))+''         , int(20/png_size*wsub),  fontSize2*4, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        rgb=getColorGear(5)
        # appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'Drag:           ' +str(int(AERODrag))+''         , int(20/png_size*wsub),  fontSize2*9, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'Drag:             ' +str(int(AEROCDv))+''         , int(20/png_size*wsub),  fontSize2*5, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        rgb=getColorGear(7)
        appDrawTextRGB(1, 1, 1, 1,                'Air density base: ' +str(round(baseAEROdens,4))+'', int(20/png_size*wsub),  fontSize2*6, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, '         current: ' +str(round(AEROdens, 4))+''   , int(20/png_size*wsub),  fontSize2*7, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)

        if maxSuspForceREAR>0.0 and maxSuspForceFRONT>0.0:
          rgb=getColorGear(1)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'susForce fl:      ' +str(round(susForce[0]/1000,2))+'k'      , int(20/png_size*wsub),  fontSize2*9, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(2)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'susForce fr:      ' +str(round(susForce[1]/1000,2))+'k'      , int(20/png_size*wsub),  fontSize2*10, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(5)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'susForce rl:      ' +str(round(susForce[2]/1000,2))+'k'      , int(20/png_size*wsub),  fontSize2*11, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(6)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'susForce rr:      ' +str(round(susForce[3]/1000,2))+'k'      , int(20/png_size*wsub),  fontSize2*12, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)

        if maxSuspTravFRONT!=0.0 and maxSuspTravREAR!=0.0:
          rgb=getColorGear(1)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'suspTravel fl:      ' +str(round(suspTravel[0]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*14, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(2)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'suspTravel fr:      ' +str(round(suspTravel[1]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*15, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(5)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'suspTravel rl:      ' +str(round(suspTravel[2]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*16, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(6)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'suspTravel rr:      ' +str(round(suspTravel[3]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*17, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        if maxDampTravFRONT!=0.0 and maxDampTravREAR!=0.0:
          rgb=getColorGear(1)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'dampTravel fl:      ' +str(round(dampTravel[0]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*19, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(2)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'dampTravel fr:      ' +str(round(dampTravel[1]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*20, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(5)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'dampTravel rl:      ' +str(round(dampTravel[2]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*21, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(6)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'dampTravel rr:      ' +str(round(dampTravel[3]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*22, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
        if RideHeightMax[0]!=0.0 and RideHeightMax[1]!=0.0:
          rgb=getColorGear(1)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'RideHeight f:      ' +str(round(RideHeight[0]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*24, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(2)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'RideHeight r:      ' +str(round(RideHeight[1]*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*25, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
          rgb=getColorGear(5)
          appDrawTextRGB(rgb[0], rgb[1], rgb[2], 1, 'Rake:              ' +str(round(Rake*1000,2))+'mm'      , int(20/png_size*wsub),  fontSize2*26, fontSize2*0.6, align=ExtGL.FONT_ALIGN_LEFT)
      elif gDataMode==7:
          appDrawTextRGB(1,1,1,1,str(round(ac_SR[0]*100,1))+'%\n'+str(round(ac_SA[0],1))+'°', 10          , fontSize2*1          , fontSize2*0.8, align=ExtGL.FONT_ALIGN_LEFT)
          appDrawTextRGB(1,1,1,1,str(round(ac_SR[1]*100,1))+'%\n'+str(round(ac_SA[1],1))+'°', int(wsub-70), fontSize2*1          , fontSize2*0.8, align=ExtGL.FONT_ALIGN_LEFT)
          appDrawTextRGB(1,1,1,1,str(round(ac_SR[2]*100,1))+'%\n'+str(round(ac_SA[2],1))+'°', 10          , int(hsub-fontSize2*3), fontSize2*0.8, align=ExtGL.FONT_ALIGN_LEFT)
          appDrawTextRGB(1,1,1,1,str(round(ac_SR[3]*100,1))+'%\n'+str(round(ac_SA[3],1))+'°', int(wsub-70), int(hsub-fontSize2*3), fontSize2*0.8, align=ExtGL.FONT_ALIGN_LEFT)
          # appDrawTextRGB(1,1,1,1,str(round(ac_LocalV[0]      ,3)), 10, fontSize2*6, fontSize2*0.8, align=ExtGL.FONT_ALIGN_LEFT)
          # appDrawTextRGB(1,1,1,1,str(round(ac_LocalV[2]      ,3)), 10, fontSize2*7, fontSize2*0.8, align=ExtGL.FONT_ALIGN_LEFT)


    rgb = getColorGear2(OverallLaps % 10)
    if gDataMode==4:
      # rgb = getColorByGear(currLap % 10)
      appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valxx, valyy, 10, texture_dot2, gDataMode, True)
    elif gDataMode==5:
      # rgbT, rgbB
      appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valxx, valyy, 10, texture_dot2, gDataMode, True)
    elif gDataMode==3: # 4 in ui
      appDrawDot3(1, 0.1, 0.1, 1, valxx, valyy, 10, texture_dot2, gDataMode, True)
    elif gDataMode!=0 and gDataMode!=6 and gDataMode!=7:
      #appDrawDot3(valyy/hsub, valyy/hsub, valyy/hsub, 1, valxx, valyy, 5*gSizeGforceW/100, texture_dot2, gDataMode, True)
      #if valyy<hsub/8:
      appDrawDot3(1, 0.1, 0.1, 1, valxx, valyy, 10, texture_dot2, gDataMode, True)
    elif gDataMode==7:
      rgb = getColorStuff( min(255, abs(ac_SAx[0]*ac_SR[0]*50))*255)
      appDrawLineA(rgb[0], rgb[1], rgb[2], 1, wsub/4 * 1, hsub/4 * 1, valx   , valy)
      appDrawDot3( 1,1,1, 1,                         valx   , valy   , 10, texture_dot2,6,True)
      rgb = getColorStuff( min(255, abs(ac_SAx[1]*ac_SR[1]*50))*255)
      appDrawLineA(rgb[0], rgb[1], rgb[2], 1, wsub/4 * 3, hsub/4 * 1, valxx  , valyy)
      appDrawDot3( 1,1,1, 1,                         valxx  , valyy  , 10, texture_dot2,6,True)
      rgb = getColorStuff( min(255, abs(ac_SAx[2]*ac_SR[2]*50))*255)
      appDrawLineA(rgb[0], rgb[1], rgb[2], 1, wsub/4 * 1, hsub/4 * 3, valxxx , valyyy)
      appDrawDot3( 1,1,1, 1,                         valxxx , valyyy , 10, texture_dot2,6,True)
      rgb = getColorStuff( min(255, abs(ac_SAx[3]*ac_SR[3]*50))*255)
      # ac_SR[0]*ac_SAx[0]
      appDrawLineA(rgb[0], rgb[1], rgb[2], 1, wsub/4 * 3, hsub/4 * 3, valxxxx, valyyyy)
      appDrawDot3( 1,1,1, 1,                         valxxxx, valyyyy, 10, texture_dot2,6,True)
      ### velo rect:
      #drawBox4Points(1,1,1,1,
      #  wsub/2                 , hsub/2-1,
      #  wsub/2 - ac_LocalV[0]+1, hsub/2-1,
      #  wsub/2 - ac_LocalV[0]+1, hsub/2-ac_LocalV[2]+1,
      #  wsub/2                 , hsub/2-ac_LocalV[2]+1)


      #appDrawLineA(1,1,1,1,
      #     BORDER_LEFT3 [aiid][0],
      #     BORDER_LEFT3 [aiid][1],
      #     BORDER_RIGHT3[aiid][0],
      #     BORDER_RIGHT3[aiid][1], histDotSize*4)

    # if gDataMode==5: # not active atm
    #   appDrawDot3(1, 1, 1, 0.75,  valx - SlipAng_Front/100*(ac_SlipRatio ["FL"]+ac_SlipRatio ["FR"])/2, valy-gSizeGforceW/5, 10, texture_dot2)
    #   appDrawDot3(1, 1, 1, 0.75,  valx + SlipAng_Rear /100*(ac_SlipRatio ["RL"]+ac_SlipRatio ["RR"])/2, valy+gSizeGforceW/5, 10, texture_dot2)
    #   appDrawLine(                valx - SlipAng_Front/100*(ac_SlipRatio ["FL"]+ac_SlipRatio ["FR"])/2, valy-gSizeGforceW/5,
    #                               valx + SlipAng_Rear /100*(ac_SlipRatio ["RL"]+ac_SlipRatio ["RR"])/2, valy+gSizeGforceW/5)

    if gDataMode==5: # ac_throttle ac_brake
      minwh = min(wsub,hsub)
      mult=255/png_size*minwh
      if gHeatmapMode==0:
        appDrawBlock(1,1,1,1,250/png_size*minwh+(ac_throttle*mult)  ,  90/png_size*minwh - 20/png_size*minwh,histDotSize*2, 20/png_size*minwh)
        appDrawBlock(1,1,1,1,250/png_size*minwh+(ac_brake   *mult)  , 130/png_size*minwh +  1/png_size*minwh,histDotSize*2, 20/png_size*minwh)
      else:
        appDrawBlock(1,1,1,1,250/png_size*minwh+(ac_speed/gSpeedNormalizer*mult)  ,  90/png_size*minwh - 20/png_size*minwh,histDotSize*2, 20/png_size*minwh)
        appDrawBlock(1,1,1,1,250/png_size*minwh+(abs(gforce_x)/gforce_fac*mult)  , 130/png_size*minwh +  1/png_size*minwh,histDotSize*2, 20/png_size*minwh)


    elif gDataMode<=4:
      #### draw history array
      if histCount!=0:
        lastXY[currID][0] = valx
        lastXY[currID][1] = valy

        localID = currID + 1
        if localID >= histCount: # wrap around the history array
          localID = 0
        count = 0
        while count < histCount:
          if lastXY[localID][0] != 111.0:
            a=0.99
            if histVisi>0:
              a=count/histCount/histVisi*5
            if gDataMode==3:
              appDrawDot3(1, 1, 0.05,    a, lastXY[localID][0], lastXY[localID][1], 10, texture_dot)
            else:
              appDrawDot3(1, 1, 1      , a, lastXY[localID][0], lastXY[localID][1], 10, texture_dot)
          count += 1
          localID += 1
          if localID >= histCount: # wrap around the history array
            localID = 0

        if gDataMode==3:
          appDrawDot3(1 , 1, 0.05, 1, lastXY[currID][0], lastXY[currID][1], 10, texture_dot2, gDataMode, True)
        else:
          appDrawDot3(0.2, 1, 0.2, 1, lastXY[currID][0], lastXY[currID][1], 10, texture_dot2, gDataMode)
        a=1
        currID += 1
        if currID >= histCount:
          currID = 0
      else: # without trail
        if gDataMode==4:
          appDrawDot3(1, 1, 0.05, 1, valx, valy, 10, texture_dot2, gDataMode)
        else:
          appDrawDot3(1, 1, 1, 1, valx, valy, 10, texture_dot2, gDataMode)


    ### ### check gears
    ### if currentGear>2 and geardatacountdone >= 10 and len(Gears)>1:
    ###   pwPrevGear = -1
    ###   pwCurrGear = -1
    ###   pwNextGear = -1
    ###   # id = int(currentRPM/maxRPM*int(maxRPM/speedDiv))
    ###   id = int(currentRPM/maxRPM*int(maxSpeed/speedDiv))
    ###   pwPrevGear = Gears[currentGear-1][id]
    ###   pwCurrGear = Gears[currentGear  ][id]
    ###   if currentGear+1 < len(Gears):
    ###     pwNextGear = Gears[currentGear+1][id]
    ###   #
    ###   # ˂˃˄˅⋁⋀⌵ ⌄⌃ ◃▹◅▻△▽◁▷ ◂▸◄►◀▶ <> ≪≫ ⫷⫸ ⋘⋙ ←↑→↓↔↗↙(↔ ․ ‥ …   ┉ ┈  ⃛  ⃜  ⁗ ′ ″ ‴ ‶ ‷ ⁗
    ###   # ▵▿∆∇△▽ ▴▾⏶⏷▲▼  ⏴⏵⏮⏭ ⇀ ⇉ ⇒ ⇛ ⇝ ⇢ ⇥ ⇑⇓⇨ ↞↠↢↢↢↣ → ⤳ ↜↭↝ ↦ ⅏
    ###   # ⤊⤋ ⇑⇓ ⇧⇩⇪ ↑↓ ⇈ ⇊ ⇣⇡ ↟↡ ⩓⩔⋰⋱⋗⋖≻≺ ⚟⚞⟀⬱⇶⇚⇛ ⧏⧐⧎ ∙ ⁚ ⁝ ┋ ┊ |
    ###   #
    ###   t = ''
    ###   if pwPrevGear!=-1 and pwPrevGear>pwCurrGear and currentRPM<maxRPM/3*2:
    ###     t+='⋀'
    ###   if pwNextGear!=-1 and pwNextGear>pwCurrGear and currentRPM>maxRPM/2:
    ###     t+='⋁'
    ###   #if t!='':
    ###   appDrawText(1, t, wsub/2, hsub-fontSize2)
    ### #
    ### if geardatacountdone >= 10 and len(Gears)>1:
    ###   lrealX=-1.0
    ###   lrealY=-1.0
    ###   offset=wsub/len(Gears)
    ###   for gear in range(len(Gears)):
    ###     for speed in range(len(Gears[gear])):
    ###       if Gears[gear][speed]>MaxPowDiv/2:
    ###         # realX = gear*offset + speed*speedDiv / maxSpeed * offset
    ###         #if gear>0 and Gears[gear-1][speed]>Gears[gear][speed]:
    ###         #  offset += speed*speedDiv / maxRPM * wsub/wsub/len(Gears)
    ###         realX = speed*speedDiv / gSpeedNormalizer * wsub
    ###         realY = 10+ (1-Gears[gear][speed]/MaxPowDiv) * hsub/4
    ###         #realY = hsub/4*3 + (1-Gears[gear][speed]/MaxPowDiv) * hsub/4
    ###         rgb=getColorByGear(gear)
    ###         if lrealX>-1.0:
    ###           # appDrawLineA(rgb[0], rgb[1], rgb[2], 1, lrealrpmX, lrealrpmY, realX, realrpmY, 10)
    ###           appDrawDot3(   rgb[0], rgb[1], rgb[2], 1, realX, realY, gSizeGforceW/100, texture_dot, 2, True)
    ###         lrealX=realX
    ###         lrealY=realY

  except:
    ac.log('leb_yatt error: ' + traceback.format_exc())






















def appToggleFullScreen():
  global fullscreenflag, appWindowLeB_YATT, wsub, hsub, lastx, lasty, lastwsub, lasthsub
  global dblclickTimerON, dblclickTimer, dblclickCounter, l_laps3, l_laps2, lastOpacity, gOpacityBG, b_FullScreen
  if fullscreenflag:
    wsub=lastwsub
    hsub=lasthsub
    gOpacityBG = lastOpacity
    # appResize()
    ac.setBackgroundOpacity(appWindowLeB_YATT, float(gOpacityBG/100.0) )
    ac.setPosition(appWindowLeB_YATT, lastx, lasty)
    ac.setSize(appWindowLeB_YATT, lastwsub, lasthsub)
    setOverlayParams(lastwsub, lasthsub)
    # ac.setPosition(b_SaveAllLaps   , -80, -205)
  else:
    lastx, lasty = ac.getPosition(appWindowLeB_YATT)
    lastwsub=wsub
    lasthsub=hsub
    lastOpacity = gOpacityBG
    gOpacityBG = 100
    ac.setBackgroundOpacity(appWindowLeB_YATT, float(gOpacityBG/100.0) )
    ac.setPosition(appWindowLeB_YATT, 0, 0)
    ac.setSize(appWindowLeB_YATT, gScreenW,gScreenH)
    setOverlayParams(gScreenW, gScreenH)
    wsub=gScreenW
    hsub=gScreenH
  fullscreenflag = not fullscreenflag
  updateLap1()
  updateLap2()
  updateLap3()
  updateLapsInfo()
  dblclickTimerON=False
  dblclickTimer=0.0
  dblclickCounter=0


def updateTyreParams(tirenameShort, *args):
    global PRACTICAL_TEMP_RATIO, temp_curveF, temp_curveR, ACD_FILE
    config = configparser.ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","#","/",), comment_prefixes=(";","#","/",), strict=False, allow_no_value=True)
    config.optionxform = str
    config.read_string("[ACHEADER]\n" + ACD_FILE.get_file("tyres.ini"))

    temp_curveF      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_FRONT", "PERFORMANCE_CURVE"   , "SHORT_NAME", tirenameShort)
    temp_curveR      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_REAR" , "PERFORMANCE_CURVE"   , "SHORT_NAME", tirenameShort)
    if len(temp_curveF)>0 and len(temp_curveR)>0:
        for s in temp_curveF.split('\n'):
            t=s.split('|')
            if len(t)>1:
                tempFtemp.append(get_float(t[0]))
                tempFgrip.append(get_float(t[1]))
        for s in temp_curveR.split('\n'):
            t=s.split('|')
            if len(t)>1:
                tempRtemp.append(get_float(t[0]))
                tempRgrip.append(get_float(t[1]))

    if config.has_section('_EXTENSION') and config.has_option('_EXTENSION', 'PRACTICAL_TEMP_RATIO'):
        s = config['_EXTENSION']['PRACTICAL_TEMP_RATIO']
        ss = s
        if ';' in s:
            ss = float(s.split(';')[0])
        if '#' in s:
            ss = float(s.split('#')[0])
        if ' ' in ss:
            ss = float(s.split(' ')[0])
        if ss.isnumeric():
            PRACTICAL_TEMP_RATIO = float(ss)





################################################################################################################################
################################################################################################################################
################################################################################################################################
################################################################################################################################
### data gathering, buffer and result image painting

def acUpdate(deltaT):
  global gforce_last, gforce_max
  global act_idx2, texture_dot
  global gforce_fac, top, max_gforce_fac, base_gforce_fac
  global histCount, lastXYZ, currID, lastXY
  global bActiveTimer, fTimer, fTimer2, dataTimer, dataTimerUpdate, gOpacityFG, gOpacityTx, gColor, smoothValue
  global lastCarFFB, DoResetOnUSERFFBChange, currCar
  global ac_speed, ac_throttle, ac_brake, gforce_x, gforce_z, gforce_y, ac_ffb
  global ac_press, ac_temp, ac_dirt, ac_SR, ac_SA, ac_NdSlip, ac_Mz, ac_LocalV
  global CurrNumberOfTyresOut, bScaleFixed, rgbT, rgbB, turboTorque
  global isInPits, bDoneResetInPits, b_gforceDec, userChanged
  global PNGmultSF, PNGmultGF, wmain, hmain, wsub, hsub, texture_circle
  global canvasSP, canvasSF4, canvasSF3, canvasSF2, canvasSF, rtIndexSF, rtIndexSP, rtIndexHeat_orig, rtIndexSP_bg, rtIndexSP_bg1, rtIndexSP_bg2, rtIndex0, myImageSF, myImageSF2
  global myImageSF3, myImageSF4, myImageSP, rtIndexSF2, rtIndexSF3, rtIndexSF4, myImageSP_bg, myImageSP_bg1, myImageSP_bg2
  global fadeoutime, timerIMG2, ghistT, datagfperlap, rtIndexAS_orig, rtIndexAS, rtIndexAS_bg
  global histDotSize, gSteeringNormalizer, gDataMode, fontSize, valx, valy, valxx, valyy, SlipAng_Front, SlipAng_Rear
  global datagf, SteeringAngle, currentGear, currentRPM, maxSpeedReached, maxRPMReached, maxSteerReached, maxSpeed
  global currTorque, maxTorque, ac_wspeed, maxRPM, rpmHalf, speedRange, Gears, geardatacount, geardatacountdone
  global maxPower, currPower, jsonPower, MaxPowDiv, minRPMdisplayed, txcnt2, txcnt, globalprefix, aiid, lastaiid, jsonTorque
  global lvalx1, lvaly1, lvaly2, lvaly3, lvaly4, lvaly5, ac_TempMult, maxtemp, bCSPActive, timerIMG, BBlock, minx, miny
  global lcurrPoT, lcurrPoT2, lastLap, lastLap2, firstClearDone, lastTime, lapTimes, lapTimesFlags, currLap, currTime, OverallLaps
  global valyFL, valyFR, valyRL, valyRR, lastSessonTime, ResetOnSessionRestart, iCounter, minioffset, minioffset2, ac_status, LapInvalidated, allowedNumberOfTyresOut
  global dblclickTimer, dblclickTimerON, dblclickCounter, fullscreenflag, tyreTempC, distTraveled, ac_session
  global canvasMap, myImageMap, myImageMapOrig, sFileAI, png_mapoffset
  global AI_LINE, BORDER_LEFT, BORDER_RIGHT, BORDER_RIGHT2, BORDER_LEFT2, BORDER_LEFT3, BORDER_RIGHT3, BORDER_LEFT4, BORDER_RIGHT4
  global RideHeight, RideHeightMax, RideHeightMin, Rake, baseAEROdens, maxDownForce, maxDrag
  global pitch, roll, cgHeight, carCoordinates, dampTravel, susForce, suspMaxTravel, suspTravel, StaticDeflection
  global maxDampTravFRONT, minDampTravFRONT, maxDampTravREAR, minDampTravREAR, maxSuspTravFRONT
  global minSuspTravFRONT, maxSuspTravREAR, minSuspTravREAR, maxSuspForceFRONT, minSuspForceFRONT, maxSuspForceREAR, minSuspForceREAR
  global bDAMPERsON, bSuspensionForceEnabled, bShowSuspTravel, bCPhysCarcassEnabled
  global myImageAS, myImageAS_bg, canvasAS, canvasAS_bg, canvasAS_bg1, canvasAS_bg2
  global AEROCDv, AEROCLf, AEROCLr, AERODownforceF, AERODownforceR, AERODrag, AEROdens, gHeatmapMode
  global jsonTorqueCurveMax, jsonPowerCurveMax, png_size, histDotSizePNG
  global valxxx, valyyy, valxxxx, valyyyy, lasttyres, ac_Grip, tempFgrip, tempRgrip, tempRtemp, tempFtemp, drivername

  # if dblclickTimerON:
  #   dblclickTimer+=deltaT
  #   if dblclickCounter>=1:
  #     appToggleFullScreen()
  #     dblclickTimerON=False
  #     dblclickTimer=0.0
  #     dblclickCounter=0
  #   if dblclickTimer>0.3:
  #     dblclickTimerON=False
  #     dblclickTimer=0.0
  #     dblclickCounter=0

  ### hide buttons when timer runs out
  if bActiveTimer:
    fTimer -= deltaT
    if fTimer <= 0.0:
      bActiveTimer = False
      appHideButtons()




  try:

    timerIMG += deltaT
    #appDrawText(1, str(int(sa)) + '\n' + str(int(sa/gSteeringNormalizer*SizeGforce)), 0, hsub/2)
    if timerIMG>fadeoutime:
      timerIMG = 0.0
      if bCSPActive and rtIndexSP>0:
        # paint over myself with a black almost transparent image
        txcnt+=1 # dont do it all the time for all, but individually
        currindex=rtIndexSF
        if txcnt==1:
          currindex = rtIndexSF2
        elif txcnt==2:
          currindex = rtIndexSF3
        elif txcnt==3:
          currindex = rtIndexSF4
        elif txcnt==4:
          currindex = rtIndexAS
        elif txcnt==5:
          currindex = rtIndexAS_bg
          txcnt=-1
        ac.ext_bindRenderTarget(currindex)
        ac.glBegin(acsys.GL.Quads)
        ac.glColor4f(0,0,0,0.1)
        # just barely visible overall, but darkens image enough
        # mode: 0 for opaque, 1 for alpha blend,
        # 2 for alpha test, 4 for additive, 5 for multiplicative
        ac.ext_glSetBlendMode(1)
        ac.ext_glSetTexture(rtIndex0, 0)
        ac.ext_glVertexTex(0         ,       0, 0, 0)
        ac.ext_glVertexTex(0         ,png_size, 0, 1)
        ac.ext_glVertexTex(png_size*2,png_size, 1, 1)
        ac.ext_glVertexTex(png_size*2,       0, 1, 0)
        ac.glEnd()
        ac.ext_restoreRenderTarget()

        currenttyres = str(ac.getCarTyreCompound(currCar))
        if lasttyres!=currenttyres:
            lasttyres = currenttyres
            updateTyreParams(currenttyres)



    ### lazy data update for smoother graph
    dataTimer += deltaT
    if dataTimer > dataTimerUpdate:
      dataTimer=0.0
      ac.setBackgroundOpacity(appWindowLeB_YATT, float(gOpacityBG/100.0) )

      if bNewTyreParams and bCPhysicsActive and bCSPActive:
          ac_Grip[0] = float(ac.ext_getTyreTempMult(0, 0))
          ac_Grip[1] = float(ac.ext_getTyreTempMult(0, 1))
          ac_Grip[2] = float(ac.ext_getTyreTempMult(0, 2))
          ac_Grip[3] = float(ac.ext_getTyreTempMult(0, 3))
          # ac.setTitle(appCurves, 'eek-1')
      elif len(tempFgrip)>0 and len(tempRgrip)>0 and len(tempFtemp)>0 and len(tempRtemp):
          if bCPhysicsActive and PRACTICAL_TEMP_RATIO!=-1000:
              if bCPhysCarcassEnabled:
                  # ac.setTitle(appCurves, 'eek0')
                  # surface x practical_temp_ratio + CARCASStemp x (1-practical_temp_ratio)
                  ac_Grip[0] = get_val_from_lut(info.physics.tyreTempM[0], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,0), tempFtemp, tempFgrip)
                  ac_Grip[1] = get_val_from_lut(info.physics.tyreTempM[1], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,1), tempFtemp, tempFgrip)
                  ac_Grip[2] = get_val_from_lut(info.physics.tyreTempM[2], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,2), tempRtemp, tempRgrip)
                  ac_Grip[3] = get_val_from_lut(info.physics.tyreTempM[3], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,3), tempRtemp, tempRgrip)
              else:
                  # ac.setTitle(appCurves, 'eek2')
                  # surface x practical_temp_ratio + COREtemp x (1-practical_temp_ratio)
                  ac_Grip[0] = get_val_from_lut(info.physics.tyreTempM[0], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[0], tempFtemp, tempFgrip)
                  ac_Grip[1] = get_val_from_lut(info.physics.tyreTempM[1], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[1], tempFtemp, tempFgrip)
                  ac_Grip[2] = get_val_from_lut(info.physics.tyreTempM[2], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[2], tempRtemp, tempRgrip)
                  ac_Grip[3] = get_val_from_lut(info.physics.tyreTempM[3], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[3], tempRtemp, tempRgrip)
          else:
              # ac.setTitle(appCurves, 'eek')
              # from temp lut, 25% surface temp, 75% core temp
              ac_Grip[0] = get_val_from_lut(info.physics.tyreTempM[0]*0.25 + info.physics.tyreCoreTemperature[0]*0.75, tempFtemp, tempFgrip)
              ac_Grip[1] = get_val_from_lut(info.physics.tyreTempM[1]*0.25 + info.physics.tyreCoreTemperature[1]*0.75, tempFtemp, tempFgrip)
              ac_Grip[2] = get_val_from_lut(info.physics.tyreTempM[2]*0.25 + info.physics.tyreCoreTemperature[2]*0.75, tempRtemp, tempRgrip)
              ac_Grip[3] = get_val_from_lut(info.physics.tyreTempM[3]*0.25 + info.physics.tyreCoreTemperature[3]*0.75, tempRtemp, tempRgrip)



      # dont record from another car
      #currentCar                   = ac.getFocusedCar()
      currCar                       = 0



      # wth CS.TyreSlip is all 0? the official way? only working with help from SharedMem
      # ac_TSlip                               = ac.getCarState(currentCar, acsys.CS.TyreSlip)
      ac_TyreSlip                            = info.physics.wheelSlip
      gforce_x, gforce_z, gforce_y           = ac.getCarState(currCar, acsys.CS.AccG)
      ac_SR                                  = ac.getCarState(currCar, acsys.CS.SlipRatio)
      ac_SA                                  = ac.getCarState(currCar, acsys.CS.SlipAngle)
      ac_NdSlip                              = ac.getCarState(currCar, acsys.CS.NdSlip)
      ac_Mz                                  = ac.getCarState(currCar, acsys.CS.Mz)
      ac_wspeed                              = ac.getCarState(currCar, acsys.CS.WheelAngularSpeed)
      #ac_wspeed                             = str(info.physics.wheelAngularSpeed)
      ac_load                                = ac.getCarState(currCar, acsys.CS.Load)

      ac_press                               = ac.getCarState(currCar, acsys.CS.DynamicPressure)
      ac_dirt                                = ac.getCarState(currCar, acsys.CS.TyreDirtyLevel)
      # tyreTempC                              = info.physics.tyreCoreTemperature

      tyreTempC                              = ac.getCarState(currCar, acsys.CS.CurrentTyresCoreTemp)
      tyreTempO = info.physics.tyreTempO
      tyreTempM = info.physics.tyreTempM
      tyreTempI = info.physics.tyreTempI
      ac_dy = [0.0,0.0,0.0,0.0]
      ac_dy     = ac.getCarState(currCar, acsys.CS.DY)
      ac_LocalV = ac.getCarState(currCar, acsys.CS.LocalVelocity)

      if bCSPActive:
        ac_TempMult[0] = ac.ext_getTyreTempMult(0, 0)
        ac_TempMult[1] = ac.ext_getTyreTempMult(0, 1)
        ac_TempMult[2] = ac.ext_getTyreTempMult(0, 2)
        ac_TempMult[3] = ac.ext_getTyreTempMult(0, 3)
        maxtemp = max(ac_TempMult[0],ac_TempMult[1],ac_TempMult[2],ac_TempMult[3])
      #    D0 + D1 * load/2000
      # slx = V*SR*cos(SA)
      # sly = V*   sin(SA)
      ac_SAx[0]      = max(-myImageAS.size[0]/4, min(myImageAS.size[0]/4,  math.sin( math.radians(ac_SA[0]))*4  )   )
      ac_SAx[1]      = max(-myImageAS.size[0]/4, min(myImageAS.size[0]/4,  math.sin( math.radians(ac_SA[1]))*4  )   )
      ac_SAx[2]      = max(-myImageAS.size[0]/4, min(myImageAS.size[0]/4,  math.sin( math.radians(ac_SA[2]))*4  )   )
      ac_SAx[3]      = max(-myImageAS.size[0]/4, min(myImageAS.size[0]/4,  math.sin( math.radians(ac_SA[3]))*4  )   )
      # used as ac_SRy
      ac_SRy[0] = max(-1.0, min(1.0, ac_SR[0]*4 ))
      ac_SRy[1] = max(-1.0, min(1.0, ac_SR[1]*4 ))
      ac_SRy[2] = max(-1.0, min(1.0, ac_SR[2]*4 ))
      ac_SRy[3] = max(-1.0, min(1.0, ac_SR[3]*4 ))

      SteeringAngle                = ac.getCarState(currCar, acsys.CS.Steer)
      ac_throttle                  = ac.getCarState(currCar, acsys.CS.Gas)
      ac_brake                     = ac.getCarState(currCar, acsys.CS.Brake)
      ac_ffb                       = ac.getCarState(currCar, acsys.CS.LastFF)
      ac_speed                     = ac.getCarState(currCar, acsys.CS.SpeedKMH)
      currentRPM                   = ac.getCarState(currCar, acsys.CS.RPM)
      currentGear                  = ac.getCarState(currCar, acsys.CS.Gear)
      currPoT                      = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
      currLap                      = ac.getCarState(currCar, acsys.CS.LapCount)
      currTime                     = ac.getCarState(currCar, acsys.CS.LapTime)
      currentSessonTime            = info.graphics.sessionTimeLeft
      completedLaps                = info.graphics.completedLaps
      #totalLaps                    = info.graphics.numberOfLaps
      distTraveled                 = round(info.graphics.distanceTraveled,2)
      CurrNumberOfTyresOut         = info.physics.numberOfTyresOut

      pitch = info.physics.pitch
      roll = info.physics.roll
      cgHeight = info.physics.cgHeight
      carCoordinates = info.graphics.carCoordinates
      #carCoordinates = ac.getCarState(currCar, acsys.CS.WorldPosition)

      if bCSPActive and bDAMPERsON:
          dampTravel[0]     = ac.ext_getDamperTravel(0)
          dampTravel[1]     = ac.ext_getDamperTravel(1)
          dampTravel[2]     = ac.ext_getDamperTravel(2)
          dampTravel[3]     = ac.ext_getDamperTravel(3)
          ### both ac.ext_getDamperTravel and ac.ext_getSuspensionTravel are buggy
          ### and return same FL for all wheels
          if dampTravel[0]<minDampTravFRONT:
              minDampTravFRONT=dampTravel[0]
          if dampTravel[1]<minDampTravFRONT:
              minDampTravFRONT=dampTravel[1]
          if dampTravel[2]<minDampTravREAR:
              minDampTravREAR=dampTravel[2]
          if dampTravel[3]<minDampTravREAR:
              minDampTravREAR=dampTravel[3]
          if dampTravel[0]>maxDampTravFRONT:
              maxDampTravFRONT=dampTravel[0]
          if dampTravel[1]>maxDampTravFRONT:
              maxDampTravFRONT=dampTravel[1]
          if dampTravel[2]>maxDampTravREAR:
              maxDampTravREAR=dampTravel[2]
          if dampTravel[3]>maxDampTravREAR:
              maxDampTravREAR=dampTravel[3]
      if bShowSuspTravel:
          ### both ac.ext_getDamperTravel and ac.ext_getSuspensionTravel are buggy and return same FL for all wheels
          suspMaxTravel  = info.static.suspensionMaxTravel
          # suspTravel     = info.physics.suspensionTravel
          suspTravel =  ac.getCarState(currCar, acsys.CS.SuspensionTravel)
          # suspTravel = ac.ext_getSuspensionTravel()

          if suspTravel[0]<minSuspTravFRONT:
              minSuspTravFRONT=suspTravel[0]
          if suspTravel[1]<minSuspTravFRONT:
              minSuspTravFRONT=suspTravel[1]
          if suspTravel[2]<minSuspTravREAR:
              minSuspTravREAR=suspTravel[2]
          if suspTravel[3]<minSuspTravREAR:
              minSuspTravREAR=suspTravel[3]
          if suspTravel[0]>maxSuspTravFRONT:
              maxSuspTravFRONT=suspTravel[0]
          if suspTravel[1]>maxSuspTravFRONT:
              maxSuspTravFRONT=suspTravel[1]
          if suspTravel[2]>maxSuspTravREAR:
              maxSuspTravREAR=suspTravel[2]
          if suspTravel[3]>maxSuspTravREAR:
              maxSuspTravREAR=suspTravel[3]
      if bSuspensionForceEnabled and bCSPActive:
          susForce[0]       = ac.ext_getSusForce(0)
          susForce[1]       = ac.ext_getSusForce(1)
          susForce[2]       = ac.ext_getSusForce(2)
          susForce[3]       = ac.ext_getSusForce(3)
          if susForce[0]<minSuspForceFRONT:
              minSuspForceFRONT=susForce[0]
          if susForce[1]<minSuspForceFRONT:
              minSuspForceFRONT=susForce[1]
          if susForce[2]<minSuspForceREAR:
              minSuspForceREAR=susForce[2]
          if susForce[3]<minSuspForceREAR:
              minSuspForceREAR=susForce[3]
          if susForce[0]>maxSuspForceFRONT:
              maxSuspForceFRONT=susForce[0]
          if susForce[1]>maxSuspForceFRONT:
              maxSuspForceFRONT=susForce[1]
          if susForce[2]>maxSuspForceREAR:
              maxSuspForceREAR=susForce[2]
          if susForce[3]>maxSuspForceREAR:
              maxSuspForceREAR=susForce[3]
          # if susForce[0]==susForce[0] and susForce[2]==susForce[3] and susForce[0]==susForce[2]:
          #     bSuspensionForceEnabled = False



      RideHeight = ac.getCarState(currCar, acsys.CS.RideHeight)
      #RideHeight = info.physics.rideHeight
      if RideHeight[0]>RideHeightMax[0]:
          RideHeightMax[0] = RideHeight[0]
      if RideHeight[1]>RideHeightMax[1]:
          RideHeightMax[1] = RideHeight[1]
      if RideHeight[0]<RideHeightMin[0]:
          RideHeightMin[0] = RideHeight[0]
      if RideHeight[1]<RideHeightMin[1]:
          RideHeightMin[1] = RideHeight[1]
      Rake = RideHeight[1]-RideHeight[0]


      AEROdens=info.physics.airDensity
      if baseAEROdens == -1.0:
          baseAEROdens = AEROdens
      if ac_speed<5 and AEROdens>0.0:
          # baseAEROdens = AEROdens
          AEROCDv=0
          AEROCLf=0
          AEROCLr=0
      else:
          # AEROCDv=ac.getCarState(currCar, acsys.AERO.CD      )
          # AEROCLf=ac.getCarState(currCar, acsys.AERO.CL_Front)
          # AEROCLr=ac.getCarState(currCar, acsys.AERO.CL_Rear )
          AEROCDv=ac.getCarState(currCar, acsys.AERO.CD      , 0)
          AEROCLf=ac.getCarState(currCar, acsys.AERO.CL_Front, 1)
          AEROCLr=ac.getCarState(currCar, acsys.AERO.CL_Rear , 2)

      if bCSPActive:
          #ac.ext_getAeroRoll()
          #ac.ext_getAeroSpeed()
          #ac.ext_getYawDeriv()
          #ac.ext_getTCSlip()

          # StaticDeflection[0] = ac.ext_getStaticDeflection(0)
          # StaticDeflection[1] = ac.ext_getStaticDeflection(1)
          # StaticDeflection[2] = ac.ext_getStaticDeflection(2)
          # StaticDeflection[3] = ac.ext_getStaticDeflection(3)

          AERODownforceF   = ac.ext_getDownforce(0)  ###  * 0.102 # / 9.81   ### todo: div by g or not?
          AERODownforceR   = ac.ext_getDownforce(1)  ###  * 0.102 # / 9.81   ### todo: div by g or not?
          AERODownforce    = ac.ext_getDownforce(2)  ###  * 0.102 # / 9.81   ### todo: div by g or not?
          if AEROCLr!=0.0 and AEROCLf!=0.0:
            rearRatio = AEROCLr / (AEROCLr+AEROCLf)
          else:
            rearRatio = 0.5
          AERODownforceF = (1-rearRatio) * AERODownforce
          AERODownforceR =    rearRatio  * AERODownforce
          #if AERODownforceF==0.0 and AERODownforce!=0.0 and AERODownforceR!=0.0:
          #    AERODownforceF=AERODownforce-AERODownforceR
          if maxDownForce < AERODownforce:
              if AERODownforce<500:
                  maxDownForce = AERODownforce * 2
              else:
                  maxDownForce = AERODownforce + AERODownforce/4
          AERODrag        = ac.ext_getDrag()        ### * 0.102 # / 9.81   ### todo: div by g or not?
          if maxDrag < AERODrag:
              if AERODrag<500:
                  maxDrag = AERODrag * 2
              else:
                  maxDrag = AERODrag + AERODrag/4








      if info.physics.numberOfTyresOut > allowedNumberOfTyresOut:
        LapInvalidated = True

      datagf+=1
      # if showLabels and not bActiveTimer:
      #   ac.setTitle(appWindowSteerGForce, 'data points : ' + str(datagf) )

      ### prepare max data
      if abs(SteeringAngle) > maxSteerReached:
        maxSteerReached = abs(SteeringAngle)
      if abs(ac_speed) > maxSpeedReached:
        maxSpeedReached = ac_speed
      if abs(ac_speed) > maxSpeed:
        maxSpeed = ac_speed
      if abs(currentRPM) > maxRPMReached:
        maxRPMReached = currentRPM
      if maxSpeed<gSpeedNormalizer:
        maxSpeed=gSpeedNormalizer
      if maxRPM<0:
        maxRPM  = info.static.maxRpm
        rpmHalf = maxRPM/2
      ### prepare torque/power
      if maxTorque == -1:
        maxTurboBoost =  info.static.maxTurboBoost
        if maxTurboBoost>0.0:
          maxTorque     =  info.static.maxTorque * (1+maxTurboBoost)
          maxPower      =  maxTorque / 745.7
        else:
          maxTorque     =  info.static.maxTorque
          maxPower      =  maxTorque / 745.7

        if jsonTorque!=0.0 and jsonTorque>maxTorque:
          maxTorque=jsonTorque
          maxPower      =  maxTorque / 745.7
        if jsonPower!=0.0 and jsonPower>maxPower:
          maxPower=jsonPower
        if jsonTorqueCurveMax>maxTorque:
          maxTorque=jsonTorqueCurveMax

        if 'formula_lithium' in sCar:
          maxTorque = maxTorque*0.5

        if jsonPowerCurveMax>maxPower:
          maxPower=jsonPowerCurveMax
        if jsonTorque>maxTorque:
          maxTorque=jsonTorque
        if jsonPower>maxPower:
          maxPower=jsonPower
        MaxPowDiv = max(maxPower, maxTorque)

      if bCSPActive:
        currTorque = ac.ext_getCurrentTorque()
      else:
        currTorque = ac_throttle * maxTorque
      currPower = max(0.0, currTorque * currentRPM*0.10472 / 745.7)
      #currPower  = max(0.0, currTorque * currentRPM / 5252.0)


      ### handle laps
      ### handle laps
      ### handle laps
      if currentSessonTime > lastSessonTime and ac.isAcLive():
        # ac.log('session restart: '
        #  + 'session: ' + str(info.graphics.session)+ '\n'
        #  + 'status        '   +str(info.graphics.status)+ '\n'
        #  + 'currLaps      '   +str(currLap)
        #  + 'overalllaps   '   +str(OverallLaps)+ '\n'
        #  + 'completedLaps '   +str(completedLaps)+ '\n'
        #  + 'currentSessonTime'+str(currentSessonTime) + '\n'
        #  + 'lastSessonTime'   +str(lastSessonTime)  )
        #  + ' all = -1'  )

        lastLap = -1
        lastTime = -1    #### 10000000
        ac_session = -1
        ac_status = -1
        #if ResetOnSessionRestart:
        #  firstClearDone=False

      lastSessonTime = currentSessonTime




      ####AC_STATUS info.graphics.status
      # AC_OFF = 0
      # AC_REPLAY = 1
      # AC_LIVE = 2
      # AC_PAUSE = 3
      ###AC_SESSION_TYPE info.graphics.session
      # AC_UNKNOWN = -1       AC_HOTLAP = 3
      # AC_PRACTICE = 0       AC_TIME_ATTACK = 4
      # AC_QUALIFY = 1        AC_DRIFT = 5
      # AC_RACE = 2           AC_DRAG = 6

      if ac_status==-1 and info.graphics.session!=-1 and info.graphics.status>0:
        if info.graphics.status==1: # replay
          ac_status = info.graphics.status
          globalprefix = ''
          if bSaveAllLaps:
              globalprefix = time.strftime("%y-%m-%d %H_%M ") + drivername
          globalprefix += 'replay '
          if 'ext_getReplayFrameMS' in dir(ac):
            dataTimerUpdate = ac.ext_getReplayFrameMS()/1000.0
            ac.log('leb_yatt: found replay timer = ' + str(ac.ext_getReplayFrameMS()) + 'ms = ' + str(int(1000.0/ac.ext_getReplayFrameMS())) + ' Hz')

      if globalprefix=='' and (ac_session == -1 or ac_session != info.graphics.session) and info.graphics.status>0:
        ac_session = info.graphics.session
        globalprefix = time.strftime('%y-%m-%d %H_%M ') + ''
        if ac_session==0:
          globalprefix += 'prac '
        if ac_session==1:
          globalprefix += 'qual '
        if ac_session==2:
          globalprefix += 'race  '
        if ac_session==3:
          globalprefix += 'hotl '
        if ac_session==4:
          globalprefix += 'time '
        if ac_session==5:
          globalprefix += 'drif '
        if ac_session==6:
          globalprefix += 'drag '
        globalprefix += sCar
        globalprefix += drivername
        #ac.log(globalprefix)






      # prevent vertical lines on lap wrap around
      if ((ac_session == 2 or ac_session == 3) and ac_status == 1) or \
          lastLap!=currLap or abs(lcurrPoT-currPoT)>0.1 or \
          ac.isCarInPitlane(0) or ac.isCarInPit(0):   ###  or (currentTime>0 and info.graphics.iLastTime==0):
        lvalx1  = -1.0
        lvaly1  = -1.0
        lvaly2  = -1.0
        lvaly3  = -1.0
        lvaly4  = -1.0
        lvaly5  = -1.0
        lcurrPoT= -1.0
        lastLap = currLap
        if len(BORDER_RIGHT)>0:
          lastaiid = int(currPoT*len(BORDER_RIGHT))
        iCounter+=1
        if bClosedTrack and len(BORDER_LEFT)>0:
          # Throttle
          rgbt = getColorStuff( min(255, ac_throttle*155))
          canvasMap.line( (
            BORDER_LEFT[len(BORDER_LEFT)-2][0],
            BORDER_LEFT[len(BORDER_LEFT)-2][1],
            BORDER_LEFT[0][0],
            BORDER_LEFT[0][1]),
            fill=(int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
            width=int(histDotSizePNG))
          # Brakes
          rgbt = getColorStuff( min(255, ac_brake * 255))
          canvasMap.line( (
            BORDER_RIGHT[len(BORDER_RIGHT)-2][0],
            BORDER_RIGHT[len(BORDER_RIGHT)-2][1],
            BORDER_RIGHT[0][0],
            BORDER_RIGHT[0][1]),
            fill=(int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
            width=int(histDotSizePNG))

        if iCounter>=1 and not firstClearDone:
          appPrepareImages()
          firstClearDone=True
          #ac.log('appPrepareImages: firstClearDone=True - '+ str(iCounter) + ' times')
      else:
        lcurrPoT=currPoT





      #ac.setTitle(appWindowSteerGForce,
      #    'session            '+str(info.graphics.session)+ '\n'
      #  + 'status             '+str(info.graphics.status)+ '\n'
      #  + 'currLaps           '+str(currLap)+ '\n'
      #  + 'overalllaps        '+str(OverallLaps)+ '\n'
      #  + 'completedLaps      '+str(completedLaps)+ '\n'
      #  + 'currentTime        '+str(currTime) + '\n'
      #  #+ 'currentSessonTime  '+str(round(currentSessonTime,2)) + '\n'
      #  #+ 'lastSessonTime     '   +str(round(lastSessonTime,2))
      #  )





      if OverallLaps<=0:
        datagfperlap+=1

      if bRecording and abs(lcurrPoT2-currPoT)<0.1 and lastLap2 < currLap and lastTime > currTime and info.graphics.iLastTime > 0 and currTime > 1:
        if not firstClearDone:
          #appPrepareImages()
          firstClearDone=True
          #ac.log('firstClearDone   NO ! appCreatePilImages()')
        lastLap2 = currLap
        OverallLaps+=1
        # lapData.append(info.graphics.iLastTime)
        lapTimes.append(info.graphics.iLastTime)
        if LapInvalidated:
          lapTimesFlags.append('† ')
        else:
          lapTimesFlags.append('')

        LapInvalidated=False
        if bSaveAllLaps:
            # 2023-01-22 19_30 mazda-mx5 Lap1 30203
            fname = ' Lap' + str(OverallLaps) + ' ' +str(info.graphics.iLastTime)
            runSaveImagesLapsThread(fname)
        else:
            fname = 'Lap' + str(OverallLaps)+' '
            runSaveImagesLapsThread(fname)

        #ac.log('lap filename ' + fname)
        #ac.log('lap filename ' + fname +'\n'
        #  + str(info.graphics.session)+ '\n'
        #  + 'status            '+str(info.graphics.status)+ '\n'
        #  + 'currLaps          '+str(currLap)
        #  + 'overalllaps       '+str(OverallLaps)+ '\n'
        #  + 'completedLaps     '+str(completedLaps)+ '\n'
        #  + 'currentSessonTime '+str(currentSessonTime) + '\n'
        #  + 'lastSessonTime    '+str(lastSessonTime)  )
        #appSaveImagesLap('_lap' + str(OverallLaps))

      lastTime = currTime
      lcurrPoT2 = currPoT







      ### ### fill gear data
      ### while len(Gears) <= currentGear:
      ###   speedRange   = [0]*(int(maxSpeed/speedDiv)+1)
      ###   Gears.append(speedRange)
      ###   geardatacount += len(speedRange)
      ###   ac.log('Gears: '+ str(len(Gears)) + ' - datacount '+ str(geardatacount))
      ### ### fill each gears data
      ### if ac_throttle>0.95 and ac_speed>0 and geardatacountdone < geardatacount and currentRPM>maxRPM/2:
      ###   id = int(ac_speed/maxSpeed*int(maxSpeed/speedDiv))
      ###   if Gears[currentGear][id]==0:
      ###     geardatacountdone += 1
      ###     Gears[currentGear][id] = int(currPower)
      ### #if geardatacountdone == geardatacount:
      ### #  ac.log('gear data completed!!!!!!!!!!!!!!!')





      ### ignore high z, and abnormal x/y above user setting
      ### limit sensitive max values only in normal driving situations
      if (  ac_speed>10
        and abs(gforce_z)<1.0
        #and abs(gforce_x)<max_gforce_fac*10 \
        #and abs(gforce_y)<max_gforce_fac*1.5 \
        and CurrNumberOfTyresOut < 4
        and ac_SR[0]<2.0 and ac_SR[1]<2.0 and ac_SR[2]<2.0 and ac_SR[3]<2.0
        and ac_NdSlip[0]<2.0 and ac_NdSlip[1]<2.0 and ac_NdSlip[2]<2.0 and ac_NdSlip[3]<2.0) :
        #and abs(gforce_x)<max(abs(gforce_max[0])*1.5,abs(gforce_max[1])*1.5) and abs(gforce_y)<max(abs(gforce_max[2])*1.5,abs(gforce_max[3])*1.5):

        if gforce_x < gforce_max[0]:
          gforce_max[0] = gforce_x
        if gforce_x > gforce_max[1]:
          gforce_max[1] = gforce_x

        if gforce_y < gforce_max[2]:
          gforce_max[2] = gforce_y
        if gforce_y > gforce_max[3]:
          gforce_max[3] = gforce_y

        # if bScaleFixed:
        #   ### limit gforce to user setting
        #newgforce_fac = min(base_gforce_fac, max(max_gforce_fac, gforce_fac, abs(math.ceil(gforce_max[0])), abs(math.floor(gforce_max[1])), abs(math.ceil(gforce_max[2])), abs(math.floor(gforce_max[3]) )))
        # else:
        #newgforce_fac = max(base_gforce_fac, max( (abs(gforce_max[0])), (abs(gforce_max[1])), (abs(gforce_max[2])), (abs(gforce_max[3])) ) )

        ### limit gforce to user setting
        #newgforce_fac = min(base_gforce_fac, max(max_gforce_fac, gforce_fac, abs(math.ceil(gforce_max[0])), abs(math.floor(gforce_max[1])), abs(math.ceil(gforce_max[2])), abs(math.floor(gforce_max[3]) )))

        ### limit gforce to currentmax
        if not userChanged:
          newgforce_fac = math.ceil(max( math.ceil(abs(gforce_max[0])), math.ceil(abs(gforce_max[1])), math.ceil(abs(gforce_max[2])), math.ceil(abs(gforce_max[3])) ))
          if newgforce_fac - gforce_fac > 0.1:
            gforce_fac = newgforce_fac
            base_gforce_fac = gforce_fac
            max_gforce_fac = gforce_fac
            ac.setText(b_gforceDec     , '- ' + str(round(base_gforce_fac,1)) + '\n     MAX g')

        if gforce_z < gforce_max[4]:
          gforce_max[4] = gforce_z
        if gforce_z > gforce_max[5]:
          gforce_max[5] = gforce_z



      # count down overshooting gforces
      if bScaleFixed:
        if gforce_max[0]<-gforce_fac:
          if gforce_max[0]+0.05 > -gforce_fac:
            gforce_max[0] = -gforce_fac
          else:
            gforce_max[0] = gforce_max[0]+0.05
        if gforce_max[1]> gforce_fac:
          if gforce_max[1]-0.05 < gforce_fac:
            gforce_max[1] = gforce_fac
          else:
            gforce_max[1] = gforce_max[1]-0.05
        if gforce_max[2]<-gforce_fac:
          if gforce_max[2]+0.05 > -gforce_fac:
            gforce_max[2] = -gforce_fac
          else:
            gforce_max[2] = gforce_max[2]+0.05
        if gforce_max[3]> gforce_fac:
          if gforce_max[3]-0.05 < gforce_fac:
            gforce_max[3] = gforce_fac
          else:
            gforce_max[3] = gforce_max[3]-0.05
        if gforce_max[4]<-gforce_fac:
          gforce_max[4] = gforce_max[4]+0.05
        if gforce_max[5]> gforce_fac:
          gforce_max[5] = gforce_max[5]-0.05

      ### FFB max reset on user FFB mult change
      if DoResetOnUSERFFBChange:
        currCarFFB = ac.getCarFFB()
        if lastCarFFB != currCarFFB:
          lastCarFFB = currCarFFB
          onReset()

      global g_Reset_When_In_Pits
      if g_Reset_When_In_Pits:
        if not isInPits and (ac.isCarInPitlane(currCar) or ac.isCarInPit(currCar)):
          isInPits = True
          bDoneResetInPits = True
          # if saveResults:
          #   ### not a good idea, double saved when user quits after pits
          #   runSaveImagesThread('_pit')
          onReset()

        if isInPits and not (ac.isCarInPitlane(currCar) or ac.isCarInPit(currCar)):
          isInPits = False
          bDoneResetInPits = False





      # steering vs lat g-force
      valxSF = min(max(0, myImageSF2.size[0]/2 + SteeringAngle/gSteeringNormalizer * myImageSF2.size[0]/2), myImageSF2.size[0])
      valySF = min(max(0, myImageSF2.size[1]/2 -      gforce_x/base_gforce_fac     * myImageSF2.size[1]/2), myImageSF2.size[1])

      if smoothValue>0:
        # smooth steering vs lat gforce
        gforcesteer_x_act[act_idx2] = valxSF
        gforcesteer_y_act[act_idx2] = valySF
        act_idx2 += 1
        if act_idx2 > smoothValue-1:
          act_idx2 = 0
        for idx in range(smoothValue-1):
          valxSF += gforcesteer_x_act[idx]
          valySF += gforcesteer_y_act[idx]
        valxSF = valxSF / float(smoothValue)
        valySF = valySF / float(smoothValue)


      ########### DATAMODE 0 (1 in ui) steering angle vs lat g-force
      ########### DATAMODE 0 (1 in ui) steering angle vs lat g-force
      ########### DATAMODE 0 (1 in ui) steering angle vs lat g-force
      if gDataMode==0: ### set curr val for active drawing
        valx = min(max(0, wsub/2 + SteeringAngle/gSteeringNormalizer * wsub/2), wsub)
        valy = min(max(0, hsub/2 -      gforce_x/base_gforce_fac     * hsub/2), hsub)

      if bRecording and ac_speed>10 and ac_throttle>0.25:
        if valxSF<myImageSF2.size[0]/2:
          xx=math.sqrt( (        myImageSF2.size[0]/2-valxSF)/myImageSF2.size[0])
        else:
          xx=math.sqrt( (valxSF-(myImageSF2.size[0]/2)      )/myImageSF2.size[0])
        if valySF<myImageSF2.size[1]/2:
          yy=math.sqrt( (        myImageSF2.size[1]/2-valySF)/myImageSF2.size[1])
        else:
          yy=math.sqrt( (valySF-(myImageSF2.size[1]/2)      )/myImageSF2.size[1])
        if gColor==0:
          rgb =       (0.5+(abs(yy)/2), 0.5+(abs(yy)/2), 0.5+(abs(yy)/2))
        elif gColor==1:
          rgb =       (1-abs(yy*yy), 1-xx*2, (abs(xx)+abs(yy))*yy*2)
          #rgb =       (abs(yy*yy)*2, 0.5+((abs(xx)+abs(yy))), ((abs(xx)+abs(yy)))*yy)
        else:
          rgb =       (1-xx,1-yy, (abs(xx)+abs(yy)))
        # paint result img
        if currTime>0:
          yy=1
          canvasSF.ellipse((valxSF-histDotSizePNG/2, valySF-histDotSizePNG/2,
                              valxSF+histDotSizePNG/2, valySF+histDotSizePNG/2),
                              fill=(min(255, int(rgb[0]*255*yy)), min(255, int(rgb[1]*255*yy)), min(255, int(rgb[2]*255*yy)) ) )
          if bCSPActive and rtIndexSF>0:
            # paint on memory texture
            ac.ext_bindRenderTarget(rtIndexSF)
            appDrawDot3(1, 1, 1, 1, valxSF, valySF, histDotSize, texture_dot, 0)
            ac.ext_restoreRenderTarget()


      ######### DATAMODE 1 (2 in ui) speed vs rpm
      ######### DATAMODE 1 (2 in ui) speed vs rpm
      ######### DATAMODE 1 (2 in ui) speed vs rpm
      valx1 =                   ac_speed   / gSpeedNormalizer  * myImageSF2.size[0]
      valy1 = min(myImageSF2.size[1], (myImageSF2.size[1] - (currentRPM-minRPMdisplayed)/(maxRPM-minRPMdisplayed ) * myImageSF2.size[1]*0.75))
      if gDataMode==1: ### set curr val for active drawing
        valx = ac_speed   / gSpeedNormalizer  * wsub
        valy = min(hsub, (hsub - (currentRPM-minRPMdisplayed)/(maxRPM-minRPMdisplayed ) * hsub*0.75))
      rgb = getColorGear(currentGear % 10)

      if bRecording and ac_speed>10:
        yy = 1-valy1/myImageSF2.size[1]
        # paint result img
        if currTime>0:
          # canvasSF2.rectangle((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
          canvasSF2.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                             valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                             fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )

          if bCSPActive and rtIndexSF2>0:
            # paint on memory texture
            ac.ext_bindRenderTarget(rtIndexSF2)
            # speed
            appDrawDot3(1, 1, 1, 1, valx1, valy1, histDotSize, texture_dot, 1)

            # power additionally
            valy2 = histDotSize+myImageSF2.size[1]/4 - max(0, min(myImageSF2.size[1]/4, currPower / MaxPowDiv * myImageSF2.size[1]/4) )
            yy = currPower / MaxPowDiv*4
            if gDataMode==1:
              valxx = valx
              valyy = hsub/4 - max(0, min(hsub/4, currPower / MaxPowDiv * hsub/4) )
            appDrawDot33(rgb[0]*yy,rgb[1]*yy, rgb[2]*yy, 1, valx1, valy2, histDotSize, texture_dot, 1, True)
            ac.ext_restoreRenderTarget()
            # paint power on pil result img
            canvasSF2.ellipse((valx1-histDotSizePNG/2, valy2-histDotSizePNG/2,
                               valx1+histDotSizePNG/2, valy2+histDotSizePNG/2),
                               fill=(int(255*rgb[0]*yy/4), int(255*rgb[1]*yy/4), int(255*rgb[2]*yy/4)) )


      ########## DATAMODE 2 (3 in ui) speed vs long. g-force
      ########## DATAMODE 2 (3 in ui) speed vs long. g-force
      ########## DATAMODE 2 (3 in ui) speed vs long. g-force
      valx1 =                      ac_speed    / gSpeedNormalizer    * myImageSF3.size[0]
      valy1 = min(max(0, (-gforce_y/base_gforce_fac * myImageSF3.size[1]/2) + myImageSF3.size[1]/2), myImageSF3.size[1])
      if gDataMode==2: ### set curr val for active drawing
        valx = ac_speed    / gSpeedNormalizer    * wsub
        valy = min(max(0, (-gforce_y/base_gforce_fac*hsub/2) + hsub/2), hsub)

      if bRecording and ac_speed>10:
        yy = 1-valy1/myImageSF3.size[1]
        if currTime>0:
          # paint result img
          canvasSF3.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                               valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                               fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )
          if bCSPActive and rtIndexSF3>0:
            # paint on memory texture
            ac.ext_bindRenderTarget(rtIndexSF3)
            appDrawDot3(1, 1, 1, 1, valx1, valy1, histDotSize, texture_dot, 2)

            # power additionally
            valy2 = histDotSize + myImageSF3.size[1]/4 - max(0, min(myImageSF3.size[1]/4, currPower / MaxPowDiv * myImageSF3.size[1]/4) )
            yy = currPower / MaxPowDiv*4
            if gDataMode==2:
              # drawn in OnRender()
              valxx = valx
              valyy = hsub/4 - max(0, min(hsub/4, currPower / MaxPowDiv * hsub/4) )
            appDrawDot33(rgb[0]*yy,rgb[1]*yy, rgb[2]*yy, 1, valx1, valy2, histDotSize, texture_dot, 1, True)
            ac.ext_restoreRenderTarget()
            # paint power on pil result img
            canvasSF3.ellipse((valx1-histDotSizePNG/2, valy2-histDotSizePNG/2,
                               valx1+histDotSizePNG/2, valy2+histDotSizePNG/2),
                               fill=(int(255*rgb[0]*yy/4), int(255*rgb[1]*yy/4), int(255*rgb[2]*yy/4)) )


      ########## DATAMODE 3 (4 in ui) RPM vs Torque/Power
      ########## DATAMODE 3 (4 in ui) RPM vs Torque/Power
      ########## DATAMODE 3 (4 in ui) RPM vs Torque/Power
      # angular velocity in rad/s of driven axle
      # divided by engine speed in rad/s
      #valx1 = currPower / maxPower * hsub*0.9
      #valy1 = hsub - currentRPM / info.static.maxRpm * wsub
      #valx = currPower / maxPower * hsub
      #valy = currentRPM / info.static.maxRpm * wsub
      valx1 = max(0, (currentRPM-minRPMdisplayed)/(maxRPM-minRPMdisplayed )) * myImageSF4.size[0]
      valy1 = myImageSF4.size[1] - max(0, min(myImageSF4.size[1], currTorque / MaxPowDiv * myImageSF4.size[1]) )
      if gDataMode==3: ### set curr val for active drawing
        valx = max(0, (currentRPM-minRPMdisplayed)/(maxRPM-minRPMdisplayed )) * wsub
        valy = hsub - max(0, min(hsub, currTorque / MaxPowDiv * hsub) )

      if bRecording and ac_speed>10:
        if currTime>0:
          yy = 1-valy1/myImageSF4.size[1]
          # power additionally in red
          valy2 = myImageSF4.size[1] - max(0, min(myImageSF4.size[1], currPower / MaxPowDiv * myImageSF4.size[1]) )
          # paint yellow torque on pil result img
          canvasSF4.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                             valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                             fill=(int(255*yy), int(255*yy), int(32*yy)) )
          # paint power on pil result img
          canvasSF4.ellipse((valx1-histDotSizePNG/2, valy2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy2+histDotSizePNG/2),
                              fill=(int(255*yy), int(32*yy), int(32*yy)) )

          # paint on memory texture
          if bCSPActive and rtIndexSF4>0:

            ac.ext_bindRenderTarget(rtIndexSF4)
            appDrawDot3(1*yy, 1*yy, 0.1*yy, 1, valx1, valy1, histDotSize, texture_dot, 3, True)

            if gDataMode==3:
              # drawn in OnRender()
              valxx = valx
              valyy = hsub - max(0, min(hsub, currPower / MaxPowDiv * hsub) )
            appDrawDot33(1, 0.1, 0.1, 1, valx1, valy2, histDotSize, texture_dot, 3, True)


            # ac_LocalAngV = ac.getCarState(currentCar, acsys.CS.LocalAngularVelocity) #xyz
            # angular velocity in rad/s of driven axle
            # divided by engine speed in rad/s
            #valx1 = currPower / maxPower * hsub*0.9
            #valy1 = hsub - currentRPM / info.static.maxRpm * wsub
            #valx = currPower / maxPower * hsub
            #valy = currentRPM / info.static.maxRpm * wsub

            # wheel speed vs rpm
            # #ac.log(str(ac_wspeed))
            #valy2 = max(0,          min(hsub/2, hsub/2 - (ac_wspeed[0]+ac_wspeed[1])/currentRPM * hsub*5) ) ### + offsetByGear()
            # appDrawDot33(1, 1, 1, 1, valx1, valy1, histDotSize, texture_dot, 1)
            # valy2 = max(0, hsub/2 + min(hsub/2, hsub/2 - (ac_wspeed[2]+ac_wspeed[3])/currentRPM * hsub*5) ) ### + offsetByGear()
            # appDrawDot33(1, 1, 1, 1, valx1, valy2, histDotSize, texture_dot, 1)

            ac.ext_restoreRenderTarget()



      ########## DATAMODE 4 (5 in ui)  Speed vs PoT + power/throttle/brakes per lap
      ########## DATAMODE 4 (5 in ui)  Speed vs PoT
      ########## DATAMODE 4 (5 in ui)  Speed vs PoT
      # ac_wspeed
      valyFL =  myImageSP.size[1]*0.2 * (ac_wspeed[0]-ac_wspeed[1])
      valyFR =  myImageSP.size[1]*0.2 * (ac_wspeed[1]-ac_wspeed[0])
      valyRL =  myImageSP.size[1]*0.2 * (ac_wspeed[2]-ac_wspeed[3])
      valyRR =  myImageSP.size[1]*0.2 * (ac_wspeed[3]-ac_wspeed[2])


      valx1 =                       currPoT * myImageSP.size[0]
      # speed
      valy1 = (1-(max(0,ac_speed-50))/(gSpeedNormalizer)) * myImageSP.size[1]*0.55 + myImageSP.size[1]*0.45
      # (power) steering
      #valy2 = (1-currPower / MaxPowDiv) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3))
      valy2 = max(0, min(myImageSP.size[1]*0.1, (1-SteeringAngle / gSteeringNormalizer) * minioffset)) + max(1,int(histDotSizePNG*3))
      # throttle
      valy3 =           (1-ac_throttle) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.11
      # brakes
      valy4 =              (1-ac_brake) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.22
      # gear
      valy5 =     (1-(currentGear-2)/7) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.33
      if gDataMode==4:
        valx = currPoT * wsub
        valy = (1-(max(0,ac_speed-50))/(gSpeedNormalizer)) * hsub*0.55 + hsub*0.45
        valxx = valx
        # (power) steering
        #valyy = (1-currPower / MaxPowDiv) * hsub*0.1
        valyy = max(0, min(hsub*0.1, (1-SteeringAngle / gSteeringNormalizer) ) * hsub*0.05)
      yy = 1    ### disable shading # ac_speed/gSpeedNormalizer
      rgb = getColorGear2(OverallLaps % 10)

      if bRecording and len(BORDER_LEFT)>0 and sFileAI!='':
        aiid = int(currPoT*len(BORDER_LEFT))
        # aiid = int(currPoT*len(BORDER_LEFT))
        if gDataMode==5: # 6 in ui
          valxx = AI_LINE[aiid][0]/png_size*min(hsub, wsub)
          valyy = AI_LINE[aiid][1]/png_size*min(wsub, hsub)
        if aiid>=0 and aiid<len(BORDER_LEFT):
          if gHeatmapMode==0:
            ## Throttle heatmap
            rgbT = getColorStuff( min(255, (ac_throttle)*255))
          else:
            ## Speed heatmap
            rgbT = getColorStuff( min(255, (ac_speed/gSpeedNormalizer)*255))
          #canvasMap.polygon(
          #      [(BORDER_LEFT [lastaiid][0] ,BORDER_LEFT [lastaiid][1]),
          #      (BORDER_LEFT [aiid][0]     ,BORDER_LEFT [aiid][1]),
          #      (BORDER_LEFT3[aiid][0]     ,BORDER_LEFT3[aiid][1]),
          #      (BORDER_LEFT3[lastaiid][0],BORDER_LEFT3[lastaiid][1])],
          #      4, fill=(int(rgbT[0]*255)))
          canvasMap.line( (
            BORDER_LEFT[aiid-1][0],
            BORDER_LEFT[aiid-1][1],
            BORDER_LEFT[aiid  ][0],
            BORDER_LEFT[aiid  ][1]),
            fill=(int(rgbT[0]*255) ,int(rgbT[1]*255), int(rgbT[2]*255)),
            width=int(histDotSizePNG*4))
          if gHeatmapMode==0:
            # Brakes heatmap
            rgbB = getColorStuff( min(255, ac_brake * 255))
          else:
            # g-force heatmap
            rgbB = getColorStuff( min(255, min(255,abs(gforce_x)/gforce_fac) * 255))
          #canvasMap.polygon(
          #      [(BORDER_RIGHT [lastaiid][0],BORDER_RIGHT [lastaiid][1]),
          #      (BORDER_RIGHT [aiid][0]    ,BORDER_RIGHT [aiid][1]),
          #      (BORDER_RIGHT3[aiid][0]    ,BORDER_RIGHT3[aiid][1]),
          #      (BORDER_RIGHT3[lastaiid][0],BORDER_RIGHT3[lastaiid][1])],
          #      4, fill=(int(rgbT[0]*255)))
          canvasMap.line( (
            BORDER_RIGHT[aiid-1][0],
            BORDER_RIGHT[aiid-1][1],
            BORDER_RIGHT[aiid  ][0],
            BORDER_RIGHT[aiid  ][1]),
            fill=(int(rgbB[0]*255) ,int(rgbB[1]*255), int(rgbB[2]*255)),
            width=int(histDotSizePNG*4))

          if bCSPActive and rtIndexHeat>0:
            # paint heatmap on memory texture
            ac.ext_bindRenderTarget(rtIndexHeat)
            #appDrawDot3(rgbT[0], rgbT[1], rgbT[2], 1, BORDER_LEFT[aiid][0] , BORDER_LEFT[aiid][1] , 10, texture_dot2, gDataMode, True)
            #appDrawDot3(rgb[0] , rgb[1] , rgb[2] , 1, BORDER_RIGHT[aiid][0], BORDER_RIGHT[aiid][1], 10, texture_dot2, gDataMode, True)
            # appDrawDot3(rgbT[0], rgbT[1], rgbT[2], 1,
            #   BORDER_LEFT[aiid-1][0]-histDotSize*2,
            #   BORDER_LEFT[aiid-1][1]-histDotSize*2,
            #   histDotSize*4, texture_dot, 5, True)
            # appDrawDot33(rgbB[0], rgbB[1], rgbB[2], 1,
            #   BORDER_RIGHT[aiid-1][0]-histDotSize*2,
            #   BORDER_RIGHT[aiid-1][1]-histDotSize*2,
            #   histDotSize*4, texture_dot, 5, True)

            if lastaiid!=-1 and lastaiid<len(AI_LINE):
              drawBox4Points(rgbT[0], rgbT[1], rgbT[2], 1,
                BORDER_LEFT [lastaiid][0],
                BORDER_LEFT [lastaiid][1],
                BORDER_LEFT [aiid][0],
                BORDER_LEFT [aiid][1],
                BORDER_LEFT2[aiid][0],
                BORDER_LEFT2[aiid][1],
                BORDER_LEFT2[lastaiid][0],
                BORDER_LEFT2[lastaiid][1])
              drawBox4Points(rgbB[0], rgbB[1], rgbB[2], 1,
                BORDER_RIGHT [lastaiid][0],
                BORDER_RIGHT [lastaiid][1],
                BORDER_RIGHT [aiid][0],
                BORDER_RIGHT [aiid][1],
                BORDER_RIGHT2[aiid][0],
                BORDER_RIGHT2[aiid][1],
                BORDER_RIGHT2[lastaiid][0],
                BORDER_RIGHT2[lastaiid][1])
            # appDrawLineA(rgbT[0], rgbT[1], rgbT[2], 1,
            #   BORDER_LEFT [aiid][0],
            #   BORDER_LEFT [aiid][1],
            #   BORDER_LEFT3[aiid][0],
            #   BORDER_LEFT3[aiid][1],
            #   max(1,int(histDotSize*3)))
            # appDrawLineA(rgbB[0], rgbB[1], rgbB[2], 1,
            #   BORDER_RIGHT [aiid][0],
            #   BORDER_RIGHT [aiid][1],
            #   BORDER_RIGHT3[aiid][0],
            #   BORDER_RIGHT3[aiid][1],
            #   max(1,int(histDotSize*3)))
            ac.ext_restoreRenderTarget()
            lastaiid=aiid


          ### # ndSlip
          ### rgbt = getColorStuff( min(255,sum(ac_NdSlip) * 50))
          ### canvasMap.line( (
          ###   BORDER_LEFT2[aiid-1][0],
          ###   BORDER_LEFT2[aiid-1][1],
          ###   BORDER_LEFT2[aiid  ][0],
          ###   BORDER_LEFT2[aiid  ][1]),
          ###   (int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
          ###   width=5)
          ### # slip angle
          ### rgbt = getColorStuff( min(255,max(ac_SA) * 15))
          ### canvasMap.line( (
          ###   BORDER_LEFT[aiid-1][0],
          ###   BORDER_LEFT[aiid-1][1],
          ###   BORDER_LEFT[aiid  ][0],
          ###   BORDER_LEFT[aiid  ][1]),
          ###   (int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
          ###   width=5)
          ### # speed
          ### rgbt = getColorStuff( min(255, ac_speed/maxSpeed * 255))
          ### canvasMap.line( (
          ###   AI_LINE[aiid-1][0],
          ###   AI_LINE[aiid-1][1],
          ###   AI_LINE[aiid  ][0],
          ###   AI_LINE[aiid  ][1]),
          ###   (int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
          ###   width=5)
          ### # slipratio
          ### rgbt = getColorStuff( min(255,sum(ac_SR)*10 * 255))
          ### canvasMap.line( (
          ###   BORDER_RIGHT[aiid-1][0],
          ###   BORDER_RIGHT[aiid-1][1],
          ###   BORDER_RIGHT[aiid  ][0],
          ###   BORDER_RIGHT[aiid  ][1]),
          ###   (int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
          ###   width=5)
          ### # Wheel Slip
          ### rgbt = getColorStuff( min(255,sum(ac_TyreSlip) * 20))
          ### canvasMap.line( (
          ###   BORDER_RIGHT2[aiid-1][0],
          ###   BORDER_RIGHT2[aiid-1][1],
          ###   BORDER_RIGHT2[aiid  ][0],
          ###   BORDER_RIGHT2[aiid  ][1]),
          ###   (int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)),
          ###   width=5)

      if bRecording and currTime>0 and lvalx1!=-1.0:
        ### wh_speed
        #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, myImageSP.size[1]*0.2 - valyFL/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
        #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, myImageSP.size[1]*0.2 - valyFR/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
        #appDrawDot3(rgb[0], rgb[1], rgb[2], 1,                   valx1, myImageSP.size[1]     - valyRL/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
        #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, myImageSP.size[0]-valx1, myImageSP.size[1]     - valyRR/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
        # paint on screen
        # # throttle
        # appDrawLineA(rgb[0], rgb[1], rgb[2], 1,
        #              lvalx1, lvaly3,
        #              valx1 , valy3 , histDotSize )
        # # brakes
        # appDrawLineA(rgb[0], rgb[1], rgb[2], 1,
        #              lvalx1, lvaly4,
        #              valx1 , valy4 , histDotSize)
        # # gear
        # appDrawLineA(rgb[0], rgb[1], rgb[2], 1,
        #              lvalx1, lvaly5,
        #              valx1 , valy5 , histDotSize)
        # # speed big
        # appDrawLineA(rgb[0], rgb[1], rgb[2], 1,
        #              lvalx1, lvaly1,
        #              valx1 , valy1, histDotSize )

        # paint on pil result img
        # steering
        canvasSP.line((lvalx1, lvaly2,
                        valx1 , valy2),
                        fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)),
                        width=max(1,int(histDotSizePNG)))
        # throttle
        canvasSP.line((lvalx1, lvaly3,
                       valx1 , valy3),
                       fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)),
                       width=max(1,int(histDotSizePNG)))
        # brake
        canvasSP.line((lvalx1, lvaly4,
                       valx1 , valy4),
                       fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)),
                       width=max(1,int(histDotSizePNG)))
        # gear
        canvasSP.line((lvalx1, lvaly5,
                       valx1 , valy5),
                       fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)),
                       width=max(1,int(histDotSizePNG)))
        # speed big
        canvasSP.line((lvalx1, lvaly1,
                       valx1 , valy1),
                       fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)),
                       width=max(1,int(histDotSizePNG)))

        # canvasSP.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
        #                   valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
        #                   fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )


        ### # speed big
        ### canvasSP.rectangle((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
        ###                     valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
        ###                     fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )
        ### # throttle
        ### canvasSP.rectangle((valx1-histDotSizePNG/2, myImageSP.size[1]*0.11 + valy3-histDotSizePNG/2,
        ###                     valx1+histDotSizePNG/2, myImageSP.size[1]*0.11 + valy3+histDotSizePNG/2),
        ###                     fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )
        ### # brake
        ### canvasSP.rectangle((valx1-histDotSizePNG/2, myImageSP.size[1]*0.22 + valy4-histDotSizePNG/2,
        ###                     valx1+histDotSizePNG/2, myImageSP.size[1]*0.22 + valy4+histDotSizePNG/2),
        ###                     fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )
        ### steering wheel angle
        ###### valy1 =                       ac_brake * myImageSP.size[1]*0.1
        ###### canvasSP.rectangle((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
        ######                     valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
        ######                     fill=(int(rgb[0]*255*yy),int(rgb[1]*255*yy), int(rgb[2]*255*yy)) )




      if bRecording and currTime>0 and info.graphics.status!=1:   ### not in replay
        lac_SA = ac_SA
        lac_SA = ac_SR
        #canvasSP.rectangle((valx1                 , myImageSP.size[1]-minioffset2*6,
        #                    valx1+histDotSizePNG*2, myImageSP.size[1]-minioffset2*5),
        #                    fill=(int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)) )
        #canvasSP.rectangle((valx1                 , myImageSP.size[1]-minioffset2*5,
        #                    valx1+histDotSizePNG*2, myImageSP.size[1]-minioffset2*4),
        #                    fill=(int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)) )

        # core temps on pil image
        rgbt = getColorTyres( max(tyreTempC) )
        canvasSP.rectangle((valx1                 , myImageSP.size[1]-minioffset2*4,
                            valx1+histDotSizePNG*2, myImageSP.size[1]-minioffset2*3),
                            fill=(int(rgbt[0]*255),int(rgbt[1]*255), int(rgbt[2]*255)) )
        # outer - note interchanges w inner temps! bc its ac
        rgbt = getColorTyres( max(tyreTempI[0], tyreTempO[1], tyreTempI[2], tyreTempO[3]) )
        canvasSP.rectangle((valx1                 , myImageSP.size[1]-minioffset2*3,
                            valx1+histDotSizePNG*2, myImageSP.size[1]-minioffset2*2),
                            fill=(int(rgbt[0]*255),int(rgbt[1]*255), int(rgbt[2]*255)) )
        # middle
        rgbt = getColorTyres( max(tyreTempM) )
        canvasSP.rectangle((valx1                 , myImageSP.size[1]-minioffset2*2 ,
                            valx1+histDotSizePNG*2, myImageSP.size[1]-minioffset2*1  ),
                            fill=(int(rgbt[0]*255),int(rgbt[1]*255), int(rgbt[2]*255)) )
        # inner - note interchanges w outer temps! bc its ac
        rgbt = getColorTyres( max(tyreTempO[0], tyreTempI[1], tyreTempO[2], tyreTempI[3]) )
        canvasSP.rectangle((valx1                  , myImageSP.size[1]-minioffset2*1  ,
                            valx1+histDotSizePNG*2    , myImageSP.size[1]                  ),
                            fill=(int(rgbt[0]*255) ,int(rgbt[1]*255), int(rgbt[2]*255)) )


      if bRecording and bCSPActive and rtIndexSP>0:
        # paint on memory texture
        ac.ext_bindRenderTarget(rtIndexSP)
        if info.graphics.status!=1:   ### not in replay
          # marker
          appDrawBlock(0, 0, 0, 1, valx1+histDotSize*3, myImageSP.size[1]-minioffset2*4, histDotSize*3, minioffset2*4)
          # # slipangle
          # rgbt = getColorTyres( min(255,max(ac_SA) * 10))
          # appDrawBlock(rgbt[0], rgbt[1], rgbt[2], 0.5, valx1, myImageSP.size[1]-minioffset2*6, histDotSize*2, minioffset2)
          # # slipratio
          # rgbt = getColorTyres( min(255,sum(ac_SR) *3 * 255))
          # appDrawBlock(rgbt[0], rgbt[1], rgbt[2], 0.5, valx1, myImageSP.size[1]-minioffset2*5, histDotSize*2, minioffset2)
          # core tyreTemps + OMI
          rgbt = getColorTyres( max(tyreTempC) )
          appDrawBlock(rgbt[0], rgbt[1], rgbt[2], 0.5, valx1, myImageSP.size[1]-minioffset2*4, histDotSize*3, minioffset2)
          # outer - note interchanges w inner temps! bc its ac
          rgbt = getColorTyres( max(tyreTempI[0], tyreTempO[1], tyreTempI[2], tyreTempO[3]) )
          appDrawBlock(rgbt[0], rgbt[1], rgbt[2], 0.5, valx1, myImageSP.size[1]-minioffset2*3, histDotSize*3, minioffset2)
          # middle
          rgbt = getColorTyres( max(tyreTempM) )
          appDrawBlock(rgbt[0], rgbt[1], rgbt[2], 0.5, valx1, myImageSP.size[1]-minioffset2*2, histDotSize*3, minioffset2)
          # inner - note interchanges w outer temps! bc its ac
          rgbt = getColorTyres( max(tyreTempO[0], tyreTempI[1], tyreTempO[2], tyreTempI[3]) )
          appDrawBlock(rgbt[0], rgbt[1], rgbt[2], 0.5, valx1, myImageSP.size[1]-minioffset2*1, histDotSize*3, minioffset2)

        if lvalx1!=-1.0:
          # paint on memory texture
          appDrawLineA(rgb[0], rgb[1], rgb[2], 1, lvalx1, lvaly1, valx1, valy1, histDotSize)
          appDrawLineA(rgb[0], rgb[1], rgb[2], 1, lvalx1, lvaly2, valx1, valy2, histDotSize)
          appDrawLineA(rgb[0], rgb[1], rgb[2], 1, lvalx1, lvaly3, valx1, valy3, histDotSize)
          appDrawLineA(rgb[0], rgb[1], rgb[2], 1, lvalx1, lvaly4, valx1, valy4, histDotSize)
          appDrawLineA(rgb[0], rgb[1], rgb[2], 1, lvalx1, lvaly5, valx1, valy5, histDotSize)

          # whspeed
          #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1 , myImageSP.size[1]*0.2 + valyFL/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
          #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1 , myImageSP.size[1]*0.2 + valyFR/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
          #appDrawDot3(rgb[0], rgb[1], rgb[2], 1,                   valx1 , myImageSP.size[1]     - valyRL/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)
          #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, myImageSP.size[0]-valx1 , myImageSP.size[1]     - valyRR/maxSpeed/2*myImageSP.size[1]*0.2, histDotSize, texture_dot)

          # appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1,           valy1, histDotSize, texture_dot, 3, True)
          # appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, hsub*0.11+valy3, histDotSize, texture_dot, 3, True)
          # appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, hsub*0.22+valy4, histDotSize, texture_dot, 3, True)

          # appDrawDot33(rgb[0], rgb[1], rgb[2], 1, valx1, valy2, histDotSize, texture_dot, 3, True)
          #
        ac.ext_restoreRenderTarget()



      lvalx1=valx1
      lvaly1=valy1
      lvaly2=valy2
      lvaly3=valy3
      lvaly4=valy4
      lvaly5=valy5
      lcurrPoT=currPoT




      # ########## DATAMODE 5 (6 in ui)  aero
      # ########## DATAMODE 5 (6 in ui)  aero
      # ########## DATAMODE 5 (6 in ui)  aero
      #ac.ext_getAeroRoll()
      #ac.ext_getAeroSpeed()
      #ac.ext_getYawDeriv()
      #ac.ext_getTCSlip()

      if bRecording and rtIndexAS>0:
        # 0=aero+susp   1=slipangle vs grip
        ### if gDataMode==6:
        if True:
          valx1 = currPoT * myImageAS.size[0]
          yspan = myImageAS.size[1]/6

          yoff  = yspan
          if maxDownForce!=0.0:
            valy1 = int(yoff - max(-yspan, min(yspan, AERODownforce*(1-rearRatio) / maxDownForce * yspan/2)))
            rgb=getColorGear(1)   # AERODownforceF paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            if bCSPActive:   # paint on memory texture
              ac.ext_bindRenderTarget(rtIndexAS)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy1, histDotSize, texture_dot, 3, True)
              ac.ext_restoreRenderTarget()

            valy2 = int(yoff - max(-yspan, min(yspan, AERODownforce*rearRatio / maxDownForce * yspan/2)))
            rgb=getColorGear(2)   # AERODownforceR paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            if bCSPActive:            # paint on memory texture
              ac.ext_bindRenderTarget(rtIndexAS)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy2, histDotSize, texture_dot, 3, True)
              ac.ext_restoreRenderTarget()


          if maxDrag!=0.0:
            rgb=getColorGear(5)   # Drag paint on pil image
            # valy3 = yoff - AERODrag / maxDrag * yspan
            valy3 = int(yoff - max(-yspan, min(yspan, AEROCDv / 100 * yspan)))
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy3-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy3+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            if bCSPActive:   # paint on memory texture
              ac.ext_bindRenderTarget(rtIndexAS)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy3, histDotSize, texture_dot, 3, True)
              ac.ext_restoreRenderTarget()


          rgb=getColorGear(7)   # air density paint on pil image
          valy5 = int(yoff - max(-yspan, min(yspan, baseAEROdens * yspan/2)))
          valy6 = int(yoff - max(-yspan, min(yspan, AEROdens     * yspan/2)))
          canvasAS.ellipse((valx1-histDotSizePNG/2, valy5-yspan/2-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy5-yspan/2+histDotSizePNG/2),
                            fill=('white') )
          canvasAS.ellipse((valx1-histDotSizePNG/2, valy6-yspan/2-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy6-yspan/2+histDotSizePNG/2),
                            fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
          if bCSPActive:
            ac.ext_bindRenderTarget(rtIndexAS)
            appDrawDot33(1, 1, 1, 1      , valx1, valy5, histDotSize/2, texture_dot, 5, True)
            appDrawDot33(1, 0.75, 0.75, 1, valx1, valy6, histDotSize, texture_dot, 5, True)
            # appDrawDot33(rgb[0], rgb[1], rgb[2], 1, valx1, valy6, histDotSize, texture_dot, 5, True)
            ac.ext_restoreRenderTarget()


          yoff  = yspan
          rgb=getColorGear(9)   # aero lift paint on pil image
          valy7 = int(yoff - AEROCLr/100 * yspan/2)
          valy8 = int(yoff - AEROCLf/100 * yspan/2)
          canvasAS.ellipse((valx1-histDotSizePNG/2, valy7-yspan/2-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy7-yspan/2+histDotSizePNG/2),
                            fill=('white') )
          canvasAS.ellipse((valx1-histDotSizePNG/2, valy8-yspan/2-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy8-yspan/2+histDotSizePNG/2),
                            fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
          if bCSPActive:   # paint on memory texture
            ac.ext_bindRenderTarget(rtIndexAS)
            appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy7, histDotSize, texture_dot, 5, True)
            appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy8, histDotSize, texture_dot, 5, True)
            ac.ext_restoreRenderTarget()



          # susForce
          # suspTravel
          # dampTravel
          if maxSuspForceREAR>0.0 and maxSuspForceFRONT>0.0:
          #if True:
            yoff  = yspan * 2.5
            valy10 = int(yoff - max(-yspan, min(yspan, yspan * susForce[0]/maxSuspForceFRONT)))
            valy11 = int(yoff - max(-yspan, min(yspan, yspan * susForce[1]/maxSuspForceFRONT)))
            valy12 = int(yoff - max(-yspan, min(yspan, yspan * susForce[2]/maxSuspForceREAR)))
            valy13 = int(yoff - max(-yspan, min(yspan, yspan * susForce[3]/maxSuspForceREAR)))
            rgb=getColorGear(1)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy10-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy10-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(2)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy11-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy11-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(5)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy12-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy12-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(6)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy13-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy13-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            #if gDataMode==6:   # paint on memory texture
            if bCSPActive:
              ac.ext_bindRenderTarget(rtIndexAS)
              rgb=getColorGear(1)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy10, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(2)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy11, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(5)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy12, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(6)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy13, histDotSize, texture_dot, 5, True)
              ac.ext_restoreRenderTarget()

          if maxSuspTravFRONT!=0.0 and maxSuspTravREAR!=0.0:
            yoff  = yspan * 3.5
            valy10 = int(yoff - max(-yspan, min(yspan, suspTravel[0]/maxSuspTravFRONT * yspan)))
            valy11 = int(yoff - max(-yspan, min(yspan, suspTravel[1]/maxSuspTravFRONT * yspan)))
            valy12 = int(yoff - max(-yspan, min(yspan, suspTravel[2]/maxSuspTravREAR  * yspan)))
            valy13 = int(yoff - max(-yspan, min(yspan, suspTravel[3]/maxSuspTravREAR  * yspan)))
            rgb=getColorGear(1)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy10-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy10-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(2)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy11-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy11-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(5)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy12-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy12-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(6)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy13-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy13-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            #if gDataMode==6:   # paint on memory texture
            if bCSPActive:
              ac.ext_bindRenderTarget(rtIndexAS)
              rgb=getColorGear(1)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy10, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(2)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy11, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(5)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy12, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(6)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy13, histDotSize, texture_dot, 5, True)
              ac.ext_restoreRenderTarget()

          if maxDampTravFRONT!=0.0 and maxDampTravREAR!=0.0:
            yoff  = yspan * 5
            valy10 = int(yoff - max(-yspan, min(yspan, dampTravel[0]/maxDampTravFRONT * yspan)))
            valy11 = int(yoff - max(-yspan, min(yspan, dampTravel[1]/maxDampTravFRONT * yspan)))
            valy12 = int(yoff - max(-yspan, min(yspan, dampTravel[2]/maxDampTravREAR  * yspan)))
            valy13 = int(yoff - max(-yspan, min(yspan, dampTravel[3]/maxDampTravREAR  * yspan)))
            rgb=getColorGear(1)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy10-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy10-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(2)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy11-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy11-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(5)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy12-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy12-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(6)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy13-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy13-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            if bCSPActive:   # paint on memory texture
              ac.ext_bindRenderTarget(rtIndexAS)
              rgb=getColorGear(1)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy10, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(2)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy11, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(5)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy12, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(6)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy13, histDotSize, texture_dot, 5, True)
              ac.ext_restoreRenderTarget()

          if RideHeightMax[0]!=0.0 and RideHeightMax[1]!=0.0 and RideHeight[0]!=0.0 and RideHeight[1]!=0:
            yoff  = yspan * 5.5
            valy10 = int(yoff - max(-yspan, min(yspan, RideHeight[0]/(RideHeightMax[0]+RideHeightMin[0])/5 * yspan/2)))
            valy11 = int(yoff - max(-yspan, min(yspan, RideHeight[1]/(RideHeightMax[1]+RideHeightMin[1])/5 * yspan/2)))
            valy12 = int(yoff - max(-yspan, min(yspan, Rake/max(RideHeight[0], RideHeight[1])           /5 * yspan/2)))
            #valy13 = yoff - dampTravel[3]/maxDampTravREAR  * yspan
            rgb=getColorGear(1)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy10-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy10-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(2)    # StaticDeflection, paint on pil image
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy11-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy11-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(5)    # rake
            canvasAS.ellipse((valx1-histDotSizePNG/2, valy12-yspan/2-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, valy12-yspan/2+histDotSizePNG/2),
                              fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            rgb=getColorGear(9)    # rake center
            canvasAS.ellipse((valx1-histDotSizePNG/2, yoff-histDotSizePNG/2,
                              valx1+histDotSizePNG/2, yoff+histDotSizePNG/2),
                              fill=('white') )
            #rgb=getColorGear(7)    # StaticDeflection, paint on pil image
            #canvasAS.ellipse((valx1-histDotSizePNG/2, valy13-yspan/2-histDotSizePNG/2,
            #                  valx1+histDotSizePNG/2, valy13-yspan/2+histDotSizePNG/2),
            #                  fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
            if bCSPActive:   # paint on memory texture
              ac.ext_bindRenderTarget(rtIndexAS)
              rgb=getColorGear(0)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy10, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(2)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy11, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(5)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy12, histDotSize, texture_dot, 5, True)
              rgb=getColorGear(9)
              appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, yoff, histDotSize, texture_dot, 5, True)
              #rgb=getColorGear(7)
              #appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy13, histDotSize, texture_dot, 5, True)
              ac.ext_restoreRenderTarget()

          # rgb=getColorGear(5)   # Drag paint on pil image
          # valy4 = yoff - AERODrag / maxDrag * yspan
          # canvasAS.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
          #                   valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
          #                   fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
          # if gDataMode==5:   # paint on memory texture
          #   ac.ext_bindRenderTarget(rtIndexAS)
          #   appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy4, histDotSize, texture_dot, 3, True)
          #   ac.ext_restoreRenderTarget()


          # AEROCDv    ### drag Coefficient
          # AEROCLf    ### Aero, o=1 lift Coefficient front
          # AEROCLr    ### Aero, o=2 lift Coefficient rear

          ### yoff  = yspan * 2

        ### if gDataMode==7:
        ### 7 - slipangle vs slipratio
        if True:

          #rgb = getColorStuff( min(255, (ac_speed/gSpeedNormalizer)*255))
          valx1=int(myImageAS.size[0]/4 * 1 +ac_SAx[0]  * myImageAS.size[0]/4)
          valy1=int(myImageAS.size[1]/4 * 1 +ac_SRy[0]  * myImageAS.size[1]/4)
          rgb = getColorStuff( min(255, (abs(ac_SR[0]*ac_SAx[0])*50)*255))
          if gDataMode==7: ### set curr val for active drawing
            valx = max(-wsub, min(wsub, wsub/4 * 1 +ac_SAx[0]  * wsub/4))
            valy = max(-hsub, min(hsub, hsub/4 * 1 +ac_SRy[0]  * hsub/4))
          canvasAS_bg.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                            fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )

          valx1=int(myImageAS.size[0]/4 * 3 +ac_SAx[1]  * myImageAS.size[0]/4)
          valy1=int(myImageAS.size[1]/4 * 1 +ac_SRy[1]  * myImageAS.size[1]/4)
          rgb = getColorStuff( min(255, (abs(ac_SR[1]*ac_SAx[1])*50)*255))
          if gDataMode==7: ### set curr val for active drawing
            valxx = max(-wsub, min(wsub, wsub/4 * 3 +ac_SAx[1]  * wsub/4))
            valyy = max(-hsub, min(hsub, hsub/4 * 1 +ac_SRy[1]  * hsub/4))
          canvasAS_bg.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                            fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )

          valx1=int(myImageAS.size[0]/4 * 1 +ac_SAx[2]  * myImageAS.size[0]/4)
          valy1=int(myImageAS.size[1]/4 * 3 +ac_SRy[2]  * myImageAS.size[1]/4)
          rgb = getColorStuff( min(255, (abs(ac_SR[2]*ac_SAx[2])*50)*255))
          if gDataMode==7: ### set curr val for active drawing
            valxxx = max(-wsub, min(wsub, wsub/4 * 1 +ac_SAx[2]  * wsub/4))
            valyyy = max(-hsub, min(hsub, hsub/4 * 3 +ac_SRy[2]  * hsub/4))
          canvasAS_bg.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                            fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )

          valx1=int(myImageAS.size[0]/4 * 3 +ac_SAx[3]  * myImageAS.size[0]/4)
          valy1=int(myImageAS.size[1]/4 * 3 +ac_SRy[3]  * myImageAS.size[1]/4)
          rgb = getColorStuff( min(255, (abs(ac_SR[3]*ac_SAx[3])*50)*255))
          if gDataMode==7: ### set curr val for active drawing
            valxxxx = max(-wsub, min(wsub, wsub/4 * 3 +ac_SAx[3]       * wsub/4))
            valyyyy = max(-hsub, min(hsub, hsub/4 * 3 +ac_SRy[3]  * hsub/4))
          canvasAS_bg.ellipse((valx1-histDotSizePNG/2, valy1-histDotSizePNG/2,
                            valx1+histDotSizePNG/2, valy1+histDotSizePNG/2),
                            fill=(int(rgb[0]*255) ,int(rgb[1]*255), int(rgb[2]*255)) )
          if bCSPActive:
            ac.ext_bindRenderTarget(rtIndexAS_bg)
            rgb = getColorStuff( min(255, (abs(ac_SR[0]*ac_SAx[0])*50)*255))
            valx1=myImageAS.size[0]/4 * 1 +ac_SAx[0]  * myImageAS.size[0]/4
            valy1=myImageAS.size[1]/4 * 1 +ac_SRy[0]  * myImageAS.size[1]/4
            appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy1, histDotSize, texture_dot, 5, True)
            rgb = getColorStuff( min(255, (abs(ac_SR[1]*ac_SAx[1])*50)*255))
            valx1=myImageAS.size[0]/4 * 3 +ac_SAx[1]  * myImageAS.size[0]/4
            valy1=myImageAS.size[1]/4 * 1 +ac_SRy[1]  * myImageAS.size[1]/4
            appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy1, histDotSize, texture_dot, 5, True)
            rgb = getColorStuff( min(255, (abs(ac_SR[2]*ac_SAx[2])*50)*255))
            valx1=myImageAS.size[0]/4 * 1 +ac_SAx[2]  * myImageAS.size[0]/4
            valy1=myImageAS.size[1]/4 * 3 +ac_SRy[2]  * myImageAS.size[1]/4
            appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy1, histDotSize, texture_dot, 5, True)
            rgb = getColorStuff( min(255, (abs(ac_SR[3]*ac_SAx[3])*50)*255))
            valx1=myImageAS.size[0]/4 * 3 +ac_SAx[3]  * myImageAS.size[0]/4
            valy1=myImageAS.size[1]/4 * 3 +ac_SRy[3]  * myImageAS.size[1]/4
            appDrawDot3(rgb[0], rgb[1], rgb[2], 1, valx1, valy1, histDotSize, texture_dot, 5, True)
            ac.ext_restoreRenderTarget()





      # SlipAng_Front = (ac_SA[0] + ac_SA[1]) / gSteeringNormalizer * gSizeGforceW
      # SlipAng_Rear  = (ac_SA[2] + ac_SA[3]) / gSteeringNormalizer * gSizeGforceW
      # valx =        (currentRPM / maxRPM * wsub - wsub/2)*2
      # valy = hsub - ac_throttle * hsub/3*2 - hsub/6
      #if gDataMode==5:
      #    valx = wsub/2  + math.sin( math.radians(SlipAng_Front  ))*gSizeGforceW
      #    valy = wsub/2  + math.cos( math.radians(SlipAng_Rear   ))*gSizeGforceW/2


#      ### rideheight
#      ## rideheight max
#      appDrawLine2 (1.0, 0.8, 0.6, 0.8, TravelOffsetX + TOhw - TOhw/2, TravelOffsetY - TOoffsety + TOhh  -rhMax[0]*TOhw+1, TOhw, max(1,TOAppSize) )
#      appDrawLine2 (1.0, 0.8, 0.6, 0.8, TravelOffsetX + TOhw - TOhw/2, TravelOffsetY + TOoffsety + TOhh*2-rhMax[1]*TOhw+1, TOhw, max(1,TOAppSize) )
#      ## rideheight min
#      appDrawLine2 (1.0, 0.8, 0.6, 0.8, TravelOffsetX                , TravelOffsetY - TOoffsety + TOhh                +1, TOhw*2, max(1,TOAppSize) )
#      appDrawLine2 (1.0, 0.8, 0.6, 0.8, TravelOffsetX                , TravelOffsetY + TOoffsety + TOhh*2              +1, TOhw*2, max(1,TOAppSize) )
#
#      ## rideheight curr
#      if rh[0]>0.01:
#          appDrawLine2 (1.0, 0.8, 0.6,                 0.8, TravelOffsetX + TOhw-TOminwidth/4, TravelOffsetY  -TOoffsety + TOhh  -rh[0]*TOhw, TOminwidth/2, 3*TOAppSize )
#      else:
#          appDrawLine2 (1        ,       1,         1, 0.8, TravelOffsetX + TOhw-TOminwidth/4, TravelOffsetY  -TOoffsety + TOhh  -rh[0]*TOhw, TOminwidth/2, 3*TOAppSize )
#      if rh[1]>0.01:
#          appDrawLine2 (1.0, 0.8, 0.6                , 0.8, TravelOffsetX + TOhw-TOminwidth/4, TravelOffsetY  +TOoffsety + TOhh*2-rh[1]*TOhw, TOminwidth/2, 3*TOAppSize )
#      else:
#          appDrawLine2 (1        ,       1,         1, 0.8, TravelOffsetX + TOhw-TOminwidth/4, TravelOffsetY  +TOoffsety + TOhh*2-rh[1]*TOhw, TOminwidth/2, 3*TOAppSize )
#
#    if bShowTravel:
#        ### dark blue
#        # min/max suspension travel markers
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw*0.7+TOoffsetx , TravelOffsetY-TOoffsety + TOhh   - (minSuspTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw*0.7+TOoffsetx , TravelOffsetY-TOoffsety + TOhh   - (maxSuspTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw*0.7+TOoffsetx , TravelOffsetY+TOoffsety + TOhh*2 - (minSuspTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw*0.7+TOoffsetx , TravelOffsetY+TOoffsety + TOhh*2 - (maxSuspTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#        if TOoffsetx!=0 or TOoffsety!=0:
#            appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx , TravelOffsetY-TOoffsety + TOhh   - (minSuspTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx , TravelOffsetY-TOoffsety + TOhh   - (maxSuspTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx , TravelOffsetY+TOoffsety + TOhh*2 - (minSuspTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx , TravelOffsetY+TOoffsety + TOhh*2 - (maxSuspTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#        # curr suspension travel
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw - TOminwidth/4 - TOoffsetx + TOhw*0.27      , TravelOffsetY-TOoffsety + TOhh   - (ac_SuspTrav["FL"])/(1+maxSuspTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw + TOminwidth/4 + TOoffsetx - TOhw*0.27-10   , TravelOffsetY-TOoffsety + TOhh   - (ac_SuspTrav["FR"])/(1+maxSuspTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw - TOminwidth/4 - TOoffsetx + TOhw*0.27      , TravelOffsetY+TOoffsety + TOhh*2 - (ac_SuspTrav["RL"])/(1+maxSuspTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#        appDrawLine2(    0.0,0.4,1.0,0.8, TravelOffsetX + TOhw + TOminwidth/4 + TOoffsetx - TOhw*0.27-10   , TravelOffsetY+TOoffsety + TOhh*2 - (ac_SuspTrav["RR"])/(1+maxSuspTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#
#        if bDAMPERsON:
#            ### light blue
#            # min/max damper travel markers
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY-TOoffsety + TOhh   - (minDampTravFRONT)*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY-TOoffsety + TOhh   - (maxDampTravFRONT)*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY+TOoffsety + TOhh*2 - (minDampTravREAR )*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY+TOoffsety + TOhh*2 - (maxDampTravREAR )*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            # if TOoffsetx!=0 or TOoffsety!=0:
#            #    appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX - TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY-TOoffsety + TOhh   + (minDampTravFRONT)*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            #    appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX - TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY-TOoffsety + TOhh   + (maxDampTravFRONT)*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            #    appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX - TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY+TOoffsety + TOhh*2 + (minDampTravREAR )*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            #    appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX - TOhw-TOoffsetx-TOfntSize*6 , TravelOffsetY+TOoffsety + TOhh*2 + (maxDampTravREAR )*TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            # curr damper travel
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx-6 , TravelOffsetY-TOoffsety + TOhh  -(dampTravel["FL"])/(1+maxDampTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw+TOoffsetx-7 , TravelOffsetY-TOoffsety + TOhh  -(dampTravel["FR"])/(1+maxDampTravFRONT)*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw-TOoffsetx-6 , TravelOffsetY+TOoffsety + TOhh*2-(dampTravel["RL"])/(1+maxDampTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#            appDrawLine2(0.4,0.7,1.0,0.8, TravelOffsetX + TOhw+TOoffsetx-7 , TravelOffsetY+TOoffsety + TOhh*2-(dampTravel["RR"])/(1+maxDampTravREAR )*TOAppSize*TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#
#        if SuspensionForceEnabled:
#            ### green
#            # min/max suspension travel markers
#            appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*1.1 - TOoffsetx-TOfntSize*0.75, TravelOffsetY-TOoffsety + TOhh   - (minSuspForceFRONT/40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*1.1 - TOoffsetx-TOfntSize*0.75, TravelOffsetY-TOoffsety + TOhh   - (maxSuspForceFRONT/40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*1.1 - TOoffsetx-TOfntSize*0.75, TravelOffsetY+TOoffsety + TOhh*2 - (minSuspForceREAR /40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*1.1 - TOoffsetx-TOfntSize*0.75, TravelOffsetY+TOoffsety + TOhh*2 - (maxSuspForceREAR /40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            if TOoffsetx!=0 or TOoffsety!=0:
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*0.7 + TOoffsetx, TravelOffsetY-TOoffsety + TOhh   - (minSuspForceFRONT/40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*0.7 + TOoffsetx, TravelOffsetY-TOoffsety + TOhh   - (maxSuspForceFRONT/40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*0.7 + TOoffsetx, TravelOffsetY+TOoffsety + TOhh*2 - (minSuspForceREAR /40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw*0.7 + TOoffsetx, TravelOffsetY+TOoffsety + TOhh*2 - (maxSuspForceREAR /40000)*TOAppSize * TOhh*2-TOfntSize*3, 10*TOAppSize+TOfntSize*2, 3*TOAppSize)
#            # curr suspension travel
#            if maxSuspForceFRONT!=-1.0:
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw - TOoffsetx + TOhw*0.17      , TravelOffsetY-TOoffsety + TOhh   - (susForce["FL"]/40000) * TOAppSize *TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw + TOoffsetx - TOhw*0.17-10   , TravelOffsetY-TOoffsety + TOhh   - (susForce["FR"]/40000) * TOAppSize *TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#            if maxSuspForceREAR!=-1.0:
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw - TOoffsetx + TOhw*0.17      , TravelOffsetY+TOoffsety + TOhh*2 - (susForce["RL"]/40000) * TOAppSize *TOhh*2-TOfntSize*3, 10, 3*TOAppSize)
#                appDrawLine2(    0.4,1.0,0.7, 0.8, TravelOffsetX + TOhw + TOoffsetx - TOhw*0.17-10   , TravelOffsetY+TOoffsety + TOhh*2 - (susForce["RR"]/40000) * TOAppSize *TOhh*2-TOfntSize*3, 10, 3*TOAppSize)



      if bRecording and bCSPActive:
        if   gDataMode==0:
          currindex = rtIndexSF
        elif gDataMode==1:
          currindex = rtIndexSF2
        elif gDataMode==2:
          currindex = rtIndexSF3
        elif gDataMode==3:
          currindex = rtIndexSF4
        elif gDataMode==4:
          currindex = rtIndexSP
        elif gDataMode==5:
          currindex = rtIndexHeat
        elif gDataMode==6:
          currindex = rtIndexAS
        else:
          currindex = rtIndexAS_bg
        ac.ext_generateMips(currindex)


  except:
    ac.log('leb_yatt error: ' + traceback.format_exc())

### acUpdate() end
### acUpdate() end
### acUpdate() end
















































def appPrepareImages():
  global canvasSP, myImageSF, canvasSF, myImageSF2, canvasSF2, myImageSF3, canvasSF3, myImageSF4, canvasSF4, id50m, id10m, mapscale
  global rtIndexSP_bg, rtIndex0, rtIndexSP, rtIndexSF, rtIndexSF2, rtIndexSF3, rtIndexSF4, datagf, minioffset, minioffset2, bCSPActive, imgsloaded, rtIndexHeat, rtIndexHeat_orig
  global BBlock, myImageSP_bg1, myImageSP_bg2, myImageSP_bg, myImageSP, rtIndexSP_bg1, rtIndexSP_bg2, canvasSP_bg1, canvasSP_bg2, canvasSP_bg, rtIndexSP_orig
  global BORDER_LEFT4, BORDER_RIGHT4, BORDER_LEFT3, BORDER_RIGHT3, BORDER_LEFT2, BORDER_RIGHT2, BORDER_LEFT, BORDER_RIGHT, AI_LINE
  global rtIndexAS_orig, rtIndexAS, rtIndexAS_bg, myImageAS, myImageAS_bg, canvasAS, canvasAS_bg, canvasAS_bg1, canvasAS_bg2
  t1=time.time()
  try:
    datagf = 0
    if not imgsloaded:
      # ac.log('load pil imgs')
      imgsloaded = True
      myImageSF = Image.open('apps/python/leb_yatt/steer_gforce_blanc.png')
      myImageSF2 = Image.open('apps/python/leb_yatt/plot_blanc.png')
      myImageSF3 = Image.open('apps/python/leb_yatt/steer_gforce_blanc.png')
      myImageSF4 = Image.open('apps/python/leb_yatt/plot_blanc.png')
      myImageSF.putalpha(0)
      myImageSF2.putalpha(0)
      myImageSF3.putalpha(0)
      myImageSF4.putalpha(0)
      canvasSF = ImageDraw.Draw(myImageSF)
      canvasSF2 = ImageDraw.Draw(myImageSF2)
      canvasSF3 = ImageDraw.Draw(myImageSF3)
      canvasSF4 = ImageDraw.Draw(myImageSF4)

      myImageSP_bg1 = Image.open('apps/python/leb_yatt/plot_blanc.png')
      myImageSP_bg1 = myImageSP_bg1.resize((myImageSP_bg1.size[0]*2,myImageSP_bg1.size[1]))
      myImageSP_bg1.putalpha(0)
      myImageSP_bg2 = myImageSP_bg1.copy()
      myImageSP     = myImageSP_bg1
      myImageSP_bg  = myImageSP_bg2
      canvasSP      = ImageDraw.Draw(myImageSP)
      canvasSP_bg   = ImageDraw.Draw(myImageSP_bg)
      canvasSP_bg1  = canvasSP
      canvasSP_bg2  = canvasSP_bg

      myImageAS = Image.open('apps/python/leb_yatt/plot_blanc.png')
      myImageAS = myImageAS.resize((myImageAS.size[0]*2,myImageAS.size[1]))
      myImageAS.putalpha(0)
      myImageAS_bg = myImageAS.copy()
      canvasAS      = ImageDraw.Draw(myImageAS)
      canvasAS_bg   = ImageDraw.Draw(myImageAS_bg)
    else:
      # ac.log('clear pil imgs')
      #myImageAS.putalpha(0)
      myImageSP.putalpha(0)
      myImageSF2.putalpha(0)
      myImageSF3.putalpha(0)
      myImageSF4.putalpha(0)
      if len(AI_LINE)>0:
        myImageMap.putalpha(0)

    if bCSPActive:
      if rtIndex0>-1:
        # clear mem image
        ac.ext_clearRenderTarget(rtIndexSF)
        ac.ext_clearRenderTarget(rtIndexSF2)
        ac.ext_clearRenderTarget(rtIndexSF3)
        ac.ext_clearRenderTarget(rtIndexSF4)
        ac.ext_clearRenderTarget(rtIndexSP_bg)
        # ac.ext_clearRenderTarget(rtIndexAS_bg)

        # restore blanc image w line4
        ac.ext_bindRenderTarget(rtIndexSP_bg)
        ac.glBegin(acsys.GL.Quads)
        ac.glColor4f(1,1,1,1)
        ac.ext_glSetTexture(rtIndexSP_orig, 0)
        ac.ext_glVertexTex(0                ,                0,0,0)
        ac.ext_glVertexTex(0                ,myImageSP.size[1],0,1)
        ac.ext_glVertexTex(myImageSP.size[0],myImageSP.size[1],1,1)
        ac.ext_glVertexTex(myImageSP.size[0],                0,1,0)
        ac.glEnd()
        ac.ext_restoreRenderTarget()

        # clear mem image
        ac.ext_clearRenderTarget(rtIndexHeat)
        # restore blanc image w track outline
        ac.ext_bindRenderTarget(rtIndexHeat)
        ac.glBegin(acsys.GL.Quads)
        ac.glColor4f(1,1,1,1)
        ac.ext_glSetTexture(rtIndexHeat_orig, 0)
        ac.ext_glVertexTex(0       ,                0,0,0)
        ac.ext_glVertexTex(0       ,png_size,0,1)
        ac.ext_glVertexTex(png_size,png_size,1,1)
        ac.ext_glVertexTex(png_size,                0,1,0)
        ac.glEnd()
        ac.ext_restoreRenderTarget()
      else:
        ### create mem textures
        #ac.log('create mem imgs')
        rtIndex0        = ac.ext_createRenderTarget(png_size, png_size, False)
        rtIndexSF       = ac.ext_createRenderTarget(myImageSF.size[0] , myImageSF.size[1]         , True)
        rtIndexSF2      = ac.ext_createRenderTarget(myImageSF2.size[0], myImageSF2.size[1]        , True)
        rtIndexSF3      = ac.ext_createRenderTarget(myImageSF3.size[0], myImageSF3.size[1]        , True)
        rtIndexSF4      = ac.ext_createRenderTarget(myImageSF4.size[0], myImageSF4.size[1]        , True)
        rtIndexSP_orig  = ac.ext_createRenderTarget(myImageSP.size[0] , myImageSP.size[1]       , True)
        rtIndexSP_bg1   = ac.ext_createRenderTarget(myImageSP.size[0] , myImageSP.size[1]       , True)
        rtIndexSP_bg2   = ac.ext_createRenderTarget(myImageSP.size[0] , myImageSP.size[1]       , True)
        rtIndexSP       = rtIndexSP_bg1
        rtIndexSP_bg    = rtIndexSP_bg2
        rtIndexHeat     = ac.ext_createRenderTarget(png_size, png_size       , True)
        rtIndexHeat_orig= ac.ext_createRenderTarget(png_size, png_size       , True)
        rtIndexAS_orig  = ac.ext_createRenderTarget(myImageAS.size[0] , myImageAS.size[1]       , True)
        rtIndexAS       = ac.ext_createRenderTarget(myImageAS.size[0] , myImageAS.size[1]       , True)
        rtIndexAS_bg    = ac.ext_createRenderTarget(myImageAS.size[0] , myImageAS.size[1]       , True)

        # prepare blending image to fade out stuff, black almost transparent image
        ac.ext_bindRenderTarget(rtIndex0)
        ac.glBegin(acsys.GL.Quads)
        ac.glColor4f(0,0,0,0.1)
        ac.glVertex2f(0,              0)
        ac.glVertex2f(0       ,png_size)
        ac.glVertex2f(png_size,png_size)
        ac.glVertex2f(png_size,       0)
        ac.glEnd()
        ac.ext_restoreRenderTarget()
      # else:
      #   ac.log('clear mem imgs')
      #   # clear mem textures

      # ac.ext_clearRenderTarget(rtIndexAS_orig)
      if gDataMode==7:
        ac.ext_bindRenderTarget(rtIndexAS_orig)
        cur_x = myImageAS.size[0]/4
        cur_y = myImageAS.size[1]/4
        for x in range(0, myImageAS.size[0], 5):
          appDrawLineA(1,1,1,1,x, cur_y, x + 3, cur_y, 2)
        cur_x = myImageAS.size[0]/4
        cur_y = myImageAS.size[1]/4*3
        for x in range(0, myImageAS.size[0], 5):
          appDrawLineA(1,1,1,1,x, cur_y, x + 3, cur_y, 2)
        cur_x = myImageAS.size[0]/4
        cur_y = myImageAS.size[1]/4
        for x in range(0, myImageAS.size[1], 5):
          appDrawLineA(1,1,1,1,cur_x, x, cur_x, x + 3, 2)
        cur_x = myImageAS.size[0]/4*3
        cur_y = myImageAS.size[1]/4*3
        for x in range(0, myImageAS.size[1], 5):
          appDrawLineA(1,1,1,1,cur_x, x, cur_x, x + 3, 2)
        ac.ext_restoreRenderTarget()

      #ac.log('gray lines mem img')
      # gray lines on mem image
      ac.ext_clearRenderTarget(rtIndexSP_orig)
      ac.ext_bindRenderTarget(rtIndexSP_orig)
      cur_y = max(1,int(histDotSizePNG*3)) + minioffset
      for x in range(0, myImageSP.size[0], 5):
        appDrawLine0(1,1,1,1,x, cur_y, x + 2, cur_y, histDotSize)
      cur_y = (1-(5-2)/7) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.33
      for x in range(0, myImageSP.size[0], 20):
        appDrawLine0(1,1,1,1,x, cur_y, x + 2, cur_y, histDotSize)
      cur_y = (1-(3-2)/7) * myImageSP.size[1]*0.1 + max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.33
      for x in range(0, myImageSP.size[0], 10):
        appDrawLine0(1,1,1,1,x, cur_y, x + 2, cur_y, histDotSize)
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.105
      for x in range(0, myImageSP.size[0], 30):
        appDrawLine0(0.5,0.5,0.5,0.5,x, cur_y, x + 2, cur_y, histDotSize)
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.215
      for x in range(0, myImageSP.size[0], 30):
        appDrawLine0(0.5,0.5,0.5,0.5,x, cur_y, x + 2, cur_y, histDotSize)
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.325
      for x in range(0, myImageSP.size[0], 30):
        appDrawLine0(0.5,0.5,0.5,0.5,x, cur_y, x + 2, cur_y, histDotSize)
      cur_y = max(1,int(histDotSizePNG*3)) + myImageSP.size[1]*0.44
      for x in range(0, myImageSP.size[0], 30):
        appDrawLine0(0.5,0.5,0.5,0.5,x, cur_y, x + 2, cur_y, histDotSize)
      ac.ext_restoreRenderTarget()

      # save image w gray lines for later use
      ac.ext_bindRenderTarget(rtIndexSP)
      ac.glBegin(acsys.GL.Quads)
      ac.glColor4f(1,1,1,1)
      ac.ext_glSetTexture(rtIndexSP_orig, 0)
      ac.ext_glVertexTex(0                ,                0,0,0)
      ac.ext_glVertexTex(0                ,myImageSP.size[1],0,1)
      ac.ext_glVertexTex(myImageSP.size[0],myImageSP.size[1],1,1)
      ac.ext_glVertexTex(myImageSP.size[0],                0,1,0)
      ac.glEnd()
      ac.ext_restoreRenderTarget()
      ac.ext_generateMips(rtIndexSP_orig)
      ac.ext_generateMips(rtIndexSP)

      # save image w gray lines for later use
      ac.ext_bindRenderTarget(rtIndexAS)
      ac.glBegin(acsys.GL.Quads)
      ac.glColor4f(1,1,1,1)
      ac.ext_glSetTexture(rtIndexAS_orig, 0)
      ac.ext_glVertexTex(0                ,                0,0,0)
      ac.ext_glVertexTex(0                ,myImageSP.size[1],0,1)
      ac.ext_glVertexTex(myImageSP.size[0],myImageSP.size[1],1,1)
      ac.ext_glVertexTex(myImageSP.size[0],                0,1,0)
      ac.glEnd()
      ac.ext_restoreRenderTarget()
      ac.ext_generateMips(rtIndexAS_orig)
      ac.ext_generateMips(rtIndexAS)

      ac.ext_bindRenderTarget(rtIndexHeat_orig)
      if len(BORDER_LEFT4)>0:
        # s/f marker
        appDrawLineA(0.5,1,0.5,1,
          BORDER_LEFT4[0][0],
          BORDER_LEFT4[0][1],
          BORDER_RIGHT4[0][0],
          BORDER_RIGHT4[0][1], width=4)
        appDrawLineA(0.5,1,0.5,1,
          BORDER_LEFT4[0][0],
          BORDER_LEFT4[0][1],
          BORDER_LEFT[int(id50m*1/mapscale/2)][0],
          BORDER_LEFT[int(id50m*1/mapscale/2)][1], width=4)
        appDrawLineA(0.5,1,0.5,1,
          BORDER_RIGHT4[0][0],
          BORDER_RIGHT4[0][1],
          BORDER_RIGHT[int(id50m*1/mapscale/2)][0],
          BORDER_RIGHT[int(id50m*1/mapscale/2)][1], width=4)

        # draw outline
        for i in range(1,len(AI_LINE)-1):
          appDrawLineA(1,1,1,1,
            BORDER_LEFT[i-1][0],
            BORDER_LEFT[i-1][1],
            BORDER_LEFT[i  ][0],
            BORDER_LEFT[i  ][1], width=1) # int(histDotSizePNG))
          appDrawLineA(1,1,1,1,
            BORDER_RIGHT[i-1][0],
            BORDER_RIGHT[i-1][1],
            BORDER_RIGHT[i  ][0],
            BORDER_RIGHT[i  ][1], width=1) # int(histDotSizePNG))
          #appDrawLineA(1,1,1,1,
          #  AI_LINE[i-1][0],
          #  AI_LINE[i-1][1],
          #  AI_LINE[i  ][0],
          #  AI_LINE[i  ][1], width=int(histDotSizePNG))

        # close outline
        if bClosedTrack:
          appDrawLineA(1,1,1,1,
            BORDER_LEFT[len(BORDER_LEFT)-2][0],
            BORDER_LEFT[len(BORDER_LEFT)-2][1],
            BORDER_LEFT[0][0],
            BORDER_LEFT[0][1], width=1) # int(histDotSizePNG))
          appDrawLineA(1,1,1,1,
            BORDER_RIGHT[len(BORDER_RIGHT)-2][0],
            BORDER_RIGHT[len(BORDER_RIGHT)-2][1],
            BORDER_RIGHT[0][0],
            BORDER_RIGHT[0][1], width=1) # int(histDotSizePNG))

        # draw palette ac_throttle ac_brake
        for i in range(255):
          rgbt = getColorStuff(i)
          appDrawLine1(rgbt[0], rgbt[1], rgbt[2], 1,
                       250+i  , 90,
                       250+i+1, 130),


      ac.ext_restoreRenderTarget()
      ac.ext_generateMips(rtIndexHeat)

      # image w map for later use
      ac.ext_bindRenderTarget(rtIndexHeat)
      ac.glBegin(acsys.GL.Quads)
      ac.glColor4f(1,1,1,1)
      ac.ext_glSetTexture(rtIndexHeat_orig, 0)
      ac.ext_glVertexTex(0       ,       0,0,0)
      ac.ext_glVertexTex(0       ,png_size,0,1)
      ac.ext_glVertexTex(png_size,png_size,1,1)
      ac.ext_glVertexTex(png_size,       0,1,0)
      ac.glEnd()
      ac.ext_restoreRenderTarget()
      ac.ext_generateMips(rtIndexHeat_orig)

  except:
    ac.log('leb_yatt error: ' + traceback.format_exc())
  ac.log('leb_yatt preparing images: ' + str(round(time.time()-t1,3))+'sec')






##########################################################


def runAsThread(sf):
  try:
    global AI_LINE, myImageSP, myImageSF, myImageSF2, myImageSF3, myImageSF4, myImageSP_bg, bCSPActive, rtIndexSP_bg, sTrack, sLayout, laps_images_path, myImageAS_bg
    if len(AI_LINE)>0:
      myImageMap.save( laps_images_path + sf + ' HeatMap' +' Lap'+str(OverallLaps) + '.png', compress_level=1)
    myImageSP.save(  laps_images_path + sf +             ' Lap'+str(OverallLaps) + '.png', compress_level=1)
    myImageAS.save(  laps_images_path + sf + ' aerosusp'+' Lap'+str(OverallLaps) + '.png', compress_level=1)
    myImageSF.save(  laps_images_path + sf + ' Steer_GForce'                     + '.png', compress_level=1)
    myImageSF2.save( laps_images_path + sf + ' Speed_RPM'                        + '.png', compress_level=1)
    myImageSF3.save( laps_images_path + sf + ' Speed_GForce'                     + '.png', compress_level=1)
    myImageSF4.save( laps_images_path + sf + ' RPM_Power'                        + '.png', compress_level=1)
    myImageAS.save(  laps_images_path + sf + ' AeroSusp'+' Lap'+str(OverallLaps) + '.png', compress_level=1)
    myImageAS_bg.save(  laps_images_path + sf + ' AeroSusp'+' Lap'+str(OverallLaps) + '.png', compress_level=1)
    #myImageSP_bg.putalpha(0)
    #if bCSPActive and rtIndexSP_bg>-1:
    #  ac.ext_clearRenderTarget(rtIndexSP_bg)
    #onReset(True)
  except:
    ac.log('leb_yatt error: ' + traceback.format_exc())

def runSaveImagesThread(sf):
  global thread
  if not thread or not thread.is_alive():
      thread = threading.Thread(target=runAsThread, args=(sf,))
      thread.start()

def onsaveResultsNow(*args):
  global globalprefix
  runSaveImagesThread(globalprefix)

def runAsThreadLap(sf):
  appSaveImagesLap(sf)
  # onReset()

def runSaveImagesLapsThread(sf):
  global flag, thread, bCSPActive
  global canvasSP, canvasSP_bg, canvasSP_bg1, canvasSP_bg2
  global canvasAS, canvasAS_bg, canvasAS_bg1, canvasAS_bg2
  global rtIndexSP, rtIndexSP_bg, rtIndexSP_bg1, rtIndexSP_bg2
  global rtIndexAS, rtIndexAS_bg
  global myImageSP, myImageSP_bg, myImageSP_bg1, myImageSP_bg2
  global myImageAS, myImageAS_bg
  #if bCSPActive and rtIndexSP>-1:
  #  ac.ext_clearRenderTarget(rtIndexSP)
  if not thread or not thread.is_alive():
    if flag:
      myImageSP    = myImageSP_bg2
      myImageSP_bg = myImageSP_bg1
      rtIndexSP    = rtIndexSP_bg2
      rtIndexSP_bg = rtIndexSP_bg1
      canvasSP     = canvasSP_bg2
      canvasSP_bg  = canvasSP_bg1
      #myImageAS    = myImageAS_bg2
      #myImageAS_bg = myImageAS_bg1
      #rtIndexAS    = rtIndexAS_bg2
      #rtIndexAS_bg = rtIndexAS_bg1
      #canvasAS     = canvasAS_bg2
      #canvasAS_bg  = canvasAS_bg1
    else:
      myImageSP    = myImageSP_bg1
      myImageSP_bg = myImageSP_bg2
      rtIndexSP    = rtIndexSP_bg1
      rtIndexSP_bg = rtIndexSP_bg2
      canvasSP     = canvasSP_bg1
      canvasSP_bg  = canvasSP_bg2
      #myImageAS    = myImageAS_bg1
      #myImageAS_bg = myImageAS_bg2
      #rtIndexAS    = rtIndexAS_bg1
      #rtIndexAS_bg = rtIndexAS_bg2
      #canvasAS     = canvasAS_bg1
      #canvasAS_bg  = canvasAS_bg2
    flag = not flag
    #thread = threading.Thread(target=runAsThreadLap, args=(sf,))
    thread = threading.Thread(target=appSaveImagesLap, args=(sf,))
    thread.start()




def appSaveImagesLap(lapdesc=''):
  global lapTimes, OverallLaps, datagf, currTime, sCar, sTrack, fontSize2, ac_status, minioffset, savedFilesHeat, savedFilesAero, savedFilesSlip
  global myImageSF, myImageSF2, myImageSF3, myImageSF4, BBlock, myImageSP, myImageSP_bg, rtIndexSP_bg, laps_images_path
  global b_laps1, b_laps2, b_laps3, savedFiles, AI_LINE
  global canvasMap, myImageMap, myImageMapOrig, sFileAI, myImageAS_bg
  try:
    while BBlock: ### wait for last blitting mem img to screen
        continue

    # BBlock=True
    # myImageSP_bg.save(       laps_images_path + postfix + '.png')
    if bSaveAllLaps:
      myImageSP_bg.save(    laps_images_path + globalprefix +               lapdesc + '.png', compress_level=1)
      savedFiles.append(    laps_images_path + globalprefix +               lapdesc + '.png')
      myImageAS.save(       laps_images_path + globalprefix + ' aerosusp '+ lapdesc + '.png', compress_level=1)
      savedFilesAero.append(laps_images_path + globalprefix + ' aerosusp '+ lapdesc + '.png')
      myImageAS_bg.save(    laps_images_path + globalprefix + ' slip '    + lapdesc + '.png', compress_level=1)
      savedFilesSlip.append(laps_images_path +                 'slip '    + lapdesc + '.png')
      if len(AI_LINE)>0:
        myImageMap.save  (    laps_images_path + globalprefix + ' heatmap ' + lapdesc + '.png', compress_level=1)
        savedFilesHeat.append(laps_images_path + globalprefix + ' heatmap ' + lapdesc + '.png')
    else:
      myImageSP_bg.save(    laps_images_path +                              lapdesc + '.png', compress_level=1)
      savedFiles.append(    laps_images_path +                              lapdesc + '.png')
      myImageAS.save(       laps_images_path +                 'AeroSusp ' + lapdesc + '.png', compress_level=1)
      savedFilesAero.append(laps_images_path +                 'AeroSusp ' + lapdesc + '.png')
      myImageAS_bg.save(    laps_images_path +                 'Slip '    + lapdesc + '.png', compress_level=1)
      savedFilesSlip.append(laps_images_path +                 'Slip '    + lapdesc + '.png')
      if len(AI_LINE)>0:
        myImageMap.save  (    laps_images_path +                 'Heatmap ' + lapdesc + '.png', compress_level=1)
        savedFilesHeat.append(laps_images_path +                 'Heatmap ' + lapdesc + '.png')

    if len(AI_LINE)>0:
      myImageMap = myImageMapOrig.copy()
      canvasMap=ImageDraw.Draw(myImageMap)
    ac.setRange(b_laps1, 0, len(savedFiles)-1)
    ac.setRange(b_laps2, 0, len(savedFiles)-1)
    updateLapsInfo()

    myImageSP_bg.putalpha(0)
    if bCSPActive and rtIndexSP_bg!=-1:
      #if AEROSUSP_MODE==0:
      ac.ext_clearRenderTarget(rtIndexAS)

      # clear mem image
      ac.ext_clearRenderTarget(rtIndexSP_bg)
      # restore blanc image w lines
      ac.ext_bindRenderTarget(rtIndexSP_bg)
      ac.glBegin(acsys.GL.Quads)
      ac.glColor4f(1,1,1,1)
      ac.ext_glSetTexture(rtIndexSP_orig, 0)
      ac.ext_glVertexTex(0                ,                0,0,0)
      ac.ext_glVertexTex(0                ,myImageSP.size[1],0,1)
      ac.ext_glVertexTex(myImageSP.size[0],myImageSP.size[1],1,1)
      ac.ext_glVertexTex(myImageSP.size[0],                0,1,0)
      ac.glEnd()
      ac.ext_restoreRenderTarget()

      # clear mem image
      ac.ext_clearRenderTarget(rtIndexHeat)
      # restore blanc image w track outline
      ac.ext_bindRenderTarget(rtIndexHeat)
      ac.glBegin(acsys.GL.Quads)
      ac.glColor4f(1,1,1,1)
      ac.ext_glSetTexture(rtIndexHeat_orig, 0)
      ac.ext_glVertexTex(0       ,                0,0,0)
      ac.ext_glVertexTex(0       ,png_size,0,1)
      ac.ext_glVertexTex(png_size,png_size,1,1)
      ac.ext_glVertexTex(png_size,                0,1,0)
      ac.glEnd()
      ac.ext_restoreRenderTarget()
  except:
    ac.log('leb_yatt error: ' + traceback.format_exc())
  # BBlock=False





def updateLapsInfo():
  s=''
  if gDataMode==4:
    id = int(ac.getValue(b_laps1))
    if id>0 and len(savedFiles)>0 and id<len(savedFiles):
      sf = os.path.basename(savedFiles[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          #ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+='\n\n\n\n\n '+str(len(savedFiles)-1) + '\n'+sf+'\n\n'
    elif len(savedFiles)>1:
      s+='\n\n\n\n\n '+str(len(savedFiles)-1) + '\n\n\n\n\n'
    else:
      s+='\n\n\n\n\n\n\n\n'

    id = int(ac.getValue(b_laps2))
    if id>0 and len(savedFiles)>1 and id<len(savedFiles):
      sf = os.path.basename(savedFiles[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+=' '+str(len(savedFiles)-1) + '\n'+sf+'\n\n'
    elif len(savedFiles)>1:
      s+=' '+str(len(savedFiles)-1) + '\n\n\n\n\n'
    else:
      s+='\n\n\n\n\n\n\n'

    # 2023-01-22 19_30 mazda-mx5 Lap1 30203
    id = int(ac.getValue(b_laps3))
    if id>0 and len(foundFiles)>1 and id<len(foundFiles):
      sf = os.path.basename(foundFiles[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+=' '+str(len(foundFiles)-1) + '\n'+sf  #.replace('_','').replace('.png','')
    elif len(foundFiles)>1:
      s+=' '+str(len(foundFiles)-1) + '\n'


  elif gDataMode==6:

    s+='\n\n\n\n\n\n\n'

    id = int(ac.getValue(b_laps2))
    if id>0 and len(savedFilesAero)>1 and id<len(savedFilesAero):
      sf = os.path.basename(savedFilesAero[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+='\n\n\n '+str(len(savedFilesAero)-1) + '\n'+sf+'\n\n'
    elif len(savedFilesAero)>1:
      s+='\n\n\n '+str(len(savedFilesAero)-1) + '\n\n\n\n\n'
    else:
      s+='\n\n\n\n\n\n\n\n'

    # 2023-01-22 19_30 mazda-mx5 Lap1 30203
    id = int(ac.getValue(b_laps3))
    if id>0 and len(foundFilesAero)>1 and id<len(foundFilesAero):
      sf = os.path.basename(foundFilesAero[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+=' '+str(len(foundFilesAero)-1) + '\n'+sf  #.replace('_','').replace('.png','')
    elif len(foundFilesAero)>1:
      s+=' '+str(len(foundFilesAero)-1) + '\n'

  elif gDataMode==7:

    s+='\n\n\n\n\n\n\n'

    id = int(ac.getValue(b_laps2))
    if id>0 and len(savedFilesSlip)>1 and id<len(savedFilesSlip):
      sf = os.path.basename(savedFilesSlip[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+='\n\n\n '+str(len(savedFilesSlip)-1) + '\n'+sf+'\n\n'
    elif len(savedFilesSlip)>1:
      s+='\n\n\n '+str(len(savedFilesSlip)-1) + '\n\n\n\n\n'
    else:
      s+='\n\n\n\n\n\n\n\n'

    # 2023-01-22 19_30 mazda-mx5 Lap1 30203
    id = int(ac.getValue(b_laps3))
    if id>0 and len(foundFilesSlip)>1 and id<len(foundFilesSlip):
      sf = os.path.basename(foundFilesSlip[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+=' '+str(len(foundFilesSlip)-1) + '\n'+sf  #.replace('_','').replace('.png','')
    elif len(foundFilesSlip)>1:
      s+=' '+str(len(foundFilesSlip)-1) + '\n'


  else:

    s+='\n\n\n\n\n\n\n'

    id = int(ac.getValue(b_laps2))
    if id>0 and len(savedFilesHeat)>1 and id<len(savedFilesHeat):
      sf = os.path.basename(savedFilesHeat[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+='\n\n\n '+str(len(savedFilesHeat)-1) + '\n'+sf+'\n\n'
    elif len(savedFilesHeat)>1:
      s+='\n\n\n '+str(len(savedFilesHeat)-1) + '\n\n\n\n\n'
    else:
      s+='\n\n\n\n\n\n\n\n'

    # 2023-01-22 19_30 mazda-mx5 Lap1 30203
    id = int(ac.getValue(b_laps3))
    if id>0 and len(foundFilesHeat)>1 and id<len(foundFilesHeat):
      sf = os.path.basename(foundFilesHeat[id-1]).replace(' Lap','\nLap')
      row2 = sf.split('\n')
      if len(row2)>1:
        stime=row2[1].lower().replace('.png','').split(' ')
        if len(stime)>1 and len(sf)>1:
          row2 = stime[0]
          # ac.log(str(row2) +' '+ stime[0] + '  ' + stime[1])
          # stime[1] = sf.split('\n')[0] + ' ' + timeToString(int(stime[1]))
          if stime[1]!='' and str(stime[1]).isnumeric():
            sf = sf.split('\n')[0] + '\n' + row2 + '  ' + timeToString(int(stime[1]))
      s+=' '+str(len(foundFilesHeat)-1) + '\n'+sf  #.replace('_','').replace('.png','')
    elif len(foundFilesHeat)>1:
      s+=' '+str(len(foundFilesHeat)-1) + '\n'

  s = s.replace(' '+sCar,'\n'+sCar)
  ac.setText(l_info, s)



def on_click_window(*args):
  ### global dblclickTimer, dblclickTimerON, dblclickCounter
  ### if dblclickTimerON: ### and dblclickTimer<0.3:
  ###   dblclickCounter+=1
  ### dblclickTimerON=True
  ### # dblclickTimer=0
  on_click_anybutton()

def on_click_anybutton(*args):
  global texid, b_texid, gOpacityFG, gOpacityTx, bActiveTimer, fTimer, b_color, b_subSizeHDec, b_subSizeHInc, b_subSizeWDec, b_subSizeWInc
  global gSizeGforceW, b_vertToggle, b_transpFGDn, b_transpFGUp, b_transpTxUp, b_transpTxDn, showLabels
  global b_transpTxDn, b_showLabels, histCount, b_TrailDn, b_TrailUp, b_TrailSmoothDn, b_TrailSmoothUp
  global histVisi, b_smoothValueDn, b_smoothValueUp, smoothValue, appWindowOverlayControls
  global b_FullScreen, b_SaveAllLaps, TempID, PressID, b_gforceDec, b_gforceInc, base_gforce_fac, b_doResetOnFFB
  global gforce_fac, bScaleFixed, b_reset, DoResetOnUSERFFBChange, b_Control
  global b_transphistUp, b_transphistDn, b_laps1, b_laps2, savedFiles, b_laps3
  global b_subtranspBGDn, b_subtranspBGUp, gSizeGforceW, gOpacityBG
  global appWindowLeB_YATT, gDataMode, gSpeedNormalizer, bRecording, b_DataEnabled, b_saveResultsNow
  global b_DotSizeDec, b_DotSizeInc, b_subSteerMaxUp, b_subSteerMaxDn, gSteeringNormalizer, histDotSize, b_subdataModeUp, b_subdataModeDn
  global maxdatamode, minRPMdisplayed, l_laps2, foundFiles, l_laps3
  try:
    ### if dblclickCounter>=1:
    ###   return

    bActiveTimer = True
    fTimer = 5.0
    ac.setText(b_gforceDec     , '- ' + str(round(base_gforce_fac,1)) + '\n     MAX g')
    # if bScaleFixed:
    #ac.setText(b_gforceDec     , '- '   + str(round(base_gforce_fac,1)) + '\n     MAX g' +
    #                            '\n '   + str(round(gforce_fac,1)) + '\n     MAX g')
    ac.setIconPosition(appWindowLeB_YATT, -80, -40)

    if gDataMode>=4: # 5 in ui
      updateLapsInfo()


    if gDataMode==0: # 1 Steering vs lat. g-force
      ac.setTitle(appWindowLeB_YATT, "Steering angle vs Lat. g-force")
    if gDataMode==1: # 2 Speed vs RPM         with gears colored different
      ac.setTitle(appWindowLeB_YATT, "Speed vs RPM      + gear colors/power")
    if gDataMode==2: # 3 Speed vs long gforce with gears colored different
      ac.setTitle(appWindowLeB_YATT, "Speed vs Lon. g-force      + gear colors/power")
    if gDataMode==3: # 4 RPM vs Torque/Power
      ac.setTitle(appWindowLeB_YATT, "RPM vs Torque/Power")
      # ac.setTitle(appWindowSteerGForce, "RPM vs Wheelspeed      + gear colors")
    if gDataMode==4: # 5 RPM vs throttle
      ac.setTitle(appWindowLeB_YATT, "Speed vs PoT")
    if gDataMode==5: #
      #ac.setTitle(appWindowLeB_YATT, "           Heatmap Throttle + Brakes")
      ac.setTitle(appWindowLeB_YATT, "Heatmap Speed + lat g-force")
    if gDataMode==6: #
      ac.setTitle(appWindowLeB_YATT, "       Aero/Suspension/Rideheight")
    if gDataMode==7: #
      ac.setTitle(appWindowLeB_YATT, "SlipAngle vs SlipRatio")

    ac.setText(b_reset, "reset\nmax g & ffb")
    if DoResetOnUSERFFBChange:
      ac.setText(b_doResetOnFFB, "numpad +/-\nreset: ON")
    else:
      ac.setText(b_doResetOnFFB, "numpad +/-\nreset: off")
    ac.setText(b_smoothValueDn  , '-  '    + str(int(smoothValue)) + '\nsmooth')
    ac.setText(b_subSizeWDec    , '  - '   + str(int(300*gSizeGforceW/100))  + '\n     width px')
    ac.setText(b_subSizeHDec    , '  - \n' + str(int(300*gSizeGforceH/100))  + '\n\nheigth')
    ac.setText(b_transpTxDn     , '- '     + str(int(gOpacityTx))  + '%\ntextOpac.')
    ac.setText(b_transpFGDn     , '- '     + str(int(gOpacityFG))  + '%\ncirc Opac.')
    ac.setText(b_transphistDn   , '  - '   + str(int(ghistT))      + '%\n           historyTransp')
    ac.setText(b_TrailDn        , '- '     + str(int(histCount))  + '\n length')
    ac.setText(b_TrailSmoothDn  , ' - '    + str(int(histVisi))   + '%\nalpha')
    ac.setText(b_subtranspBGDn  , '-  '    + str(int(gOpacityBG))  + '%\n BackGrnd')
    ac.setText(b_DotSizeInc     , '  - '   + str(round(histDotSize,1))      + 'px\n       hist dot-size')
    if gDataMode==1 or gDataMode==2 or gDataMode>=4:
      ac.setText(b_subSteerMaxUp     , '  - ' + str(int(gSpeedNormalizer))  + 'kmh  \n      max Speed')
    elif gDataMode==0:
      ac.setText(b_subSteerMaxUp     , '  - ' + str(int(gSteeringNormalizer))  + '°  \n     max Steer')
    elif gDataMode==3:
      ac.setText(b_subSteerMaxUp     , '  - ' + str(int(minRPMdisplayed))  + '  \n     min RPM')
    else:
      ac.setText(b_subSteerMaxUp     , '    ')
    ac.setText(b_subdataModeDn     , '  - ' + str(int(gDataMode+1))  + ' / '+str(maxdatamode+1)+' \n        data Mode')


    if zForce==True:
      if centeredZForce==True:
        ac.setText(b_vertToggle, "2/2\nGz")
      else:
        ac.setText(b_vertToggle, "1/2\nGz")
    else:
      ac.setText(b_vertToggle, "0/2\nGz")
    ac.setText(b_color         , str(gColor)+'/2\ncol')
    ac.setText(b_texid         , str(texid) + '/6\ngrid')
    if showLabels:
      ac.setText(b_showLabels,'text\nON')
    else:
      ac.setText(b_showLabels,'text\noff')

    if bRecording:
      ac.setText(b_DataEnabled,"\ndata recording\nON")
    else:
      ac.setText(b_DataEnabled,"\ndata recording\noff")

    if bSaveAllLaps:
      ac.setText(b_SaveAllLaps,'Save laps per\ntrack & car\nON (!) ')
    else:
      ac.setText(b_SaveAllLaps,'Save laps per\ntrack & car\noff (overwrite old)')

    # ac.setVisible(b_transpFGUp, 1)
    # ac.setVisible(b_transpFGDn, 1)
    # ac.setVisible(b_transpTxUp, 1)
    # ac.setVisible(b_transpTxDn, 1)
    # ac.setVisible(b_vertToggle, 1)
    # ac.setVisible(b_smoothValueDn, 1)
    # ac.setVisible(b_smoothValueUp, 1)
    # ac.setVisible(b_TrailUp, 1)
    # ac.setVisible(b_TrailDn, 1)
    # ac.setVisible(b_TrailSmoothDn, 1)
    # ac.setVisible(b_TrailSmoothUp, 1)
    # ac.setVisible(b_color, 1)
    # ac.setVisible(b_texid, 1)
    # ac.setVisible(b_transphistUp, 1)
    # ac.setVisible(b_transphistDn, 1)

    ac.setVisible(b_showLabels, 1)
    ac.setVisible(b_DataEnabled, 1)
    ac.setVisible(b_saveResultsNow, 1)
    ac.setVisible(b_gforceDec, 1)
    ac.setVisible(b_gforceInc, 1)
    ac.setVisible(b_reset, 1)
    ac.setVisible(b_Control, 1)
    ac.setVisible(b_doResetOnFFB, 1)
    ac.setVisible(b_SaveAllLaps, 1)

    ac.setVisible(b_subSizeWDec, 1)
    ac.setVisible(b_subSizeWInc, 1)
    ac.setVisible(b_subSizeHDec, 1)
    ac.setVisible(b_subSizeHInc, 1)
    ac.setVisible(b_subtranspBGUp, 1)
    ac.setVisible(b_subtranspBGDn, 1)
    ac.setVisible(b_DotSizeDec, 1)
    ac.setVisible(b_DotSizeInc, 1)
    ac.setVisible(b_subSteerMaxDn, 1)
    ac.setVisible(b_subSteerMaxUp, 1)
    ac.setVisible(b_subdataModeDn, 1)
    ac.setVisible(b_subdataModeUp, 1)

    # if gDataMode>=4: # 5 in ui
    #   ac.setVisible(appWindowOverlayControls, 1)
    # else:
    #   ac.setVisible(appWindowOverlayControls, 0)
  except:
    ac.log('leb_yatt error: ' + traceback.format_exc())


def appHideButtons():
  global b_vertToggle, b_transpFGDn, b_transpFGUp, b_transpTxDn, b_transpTxUp, b_reset, b_doResetOnFFB, b_color, b_Control
  global b_subSizeWDec, b_subSizeWInc, b_TrailDn, b_TrailUp, b_smoothValueDn, b_smoothValueUp, b_gforceDec, b_gforceInc, b_DataEnabled
  global b_subdataModeDn, b_subdataModeUp, b_saveResultsNow, b_subSizeHDec, b_subSizeHInc, b_laps1, b_laps2, b_laps3
  global b_transphistUp, b_transphistDn, appWindowLeB_YATT, b_subtranspBGDn, b_subtranspBGUp, l_laps2
  if showHeader == 0:
    ac.setTitle(appWindowLeB_YATT, "")

  # ac.setVisible(b_laps1, 0)
  # ac.setVisible(b_laps2, 0)
  # ac.setVisible(b_laps3, 0)
  # ac.setVisible(b_FullScreen, 0)
  ac.setText(l_laps2, '')
  ac.setText(l_laps3, '')
  ac.setIconPosition(appWindowLeB_YATT, -10000, -10000)
  ac.setVisible(b_DotSizeDec, 0)
  ac.setVisible(b_DotSizeInc, 0)
  ac.setVisible(b_subSteerMaxDn, 0)
  ac.setVisible(b_subSteerMaxUp, 0)
  ac.setVisible(b_subdataModeDn, 0)
  ac.setVisible(b_subdataModeUp, 0)
  ac.setVisible(b_transphistUp, 0)
  ac.setVisible(b_transphistDn, 0)
  ac.setVisible(b_vertToggle, 0)
  ac.setVisible(b_gforceDec , 0)
  ac.setVisible(b_gforceInc , 0)
  ac.setVisible(b_transpFGUp, 0)
  ac.setVisible(b_transpFGDn, 0)
  ac.setVisible(b_transpTxUp, 0)
  ac.setVisible(b_transpTxDn, 0)
  ac.setVisible(b_TrailUp   , 0)
  ac.setVisible(b_TrailDn   , 0)
  ac.setVisible(b_TrailSmoothDn, 0)
  ac.setVisible(b_TrailSmoothUp, 0)
  ac.setVisible(b_smoothValueDn, 0)
  ac.setVisible(b_smoothValueUp, 0)
  ac.setVisible(b_color, 0)
  ac.setVisible(b_reset, 0)
  ac.setVisible(b_Control, 0)
  ac.setVisible(b_doResetOnFFB, 0)
  ac.setVisible(b_subSizeWDec, 0)
  ac.setVisible(b_subSizeWInc, 0)
  ac.setVisible(b_subSizeHDec, 0)
  ac.setVisible(b_subSizeHInc, 0)
  ac.setVisible(b_showLabels, 0)
  ac.setVisible(b_DataEnabled, 0)
  ac.setVisible(b_saveResultsNow, 0)
  ac.setVisible(b_SaveAllLaps, 0)
  ac.setVisible(b_texid, 0)
  ac.setVisible(b_subtranspBGUp, 0)
  ac.setVisible(b_subtranspBGDn, 0)



def appDrawBlock(r,g,b,a,x1,y1,width=10,height=10):
    ac.glColor4f(r,g,b,a)
    ac.glQuad(x1,y1,width,height)

gearscols=[
  (0.06, 0.49, 0.85),
  (0.48, 0.60, 1.00),
  (0.47, 0.80, 1.00),
  (0.14, 0.80, 0.14),
  (0.92, 0.92, 0.10),
  (1.00, 0.65, 0.24),
  (1.00, 0.66, 0.66),
  (1.00, 0.33, 0.33),
  (0.67, 0.47, 0.92),
  (0.67, 0.67, 0)]

  # if g==0: #0
  #   rgb=(0.7019607814, 0.2392156, 0.77647058)
  # elif g==1: #1
  #   rgb=(0.1529411764, 0.6823529, 0.93725490)
  # elif g==2: #2
  #   rgb=(0.5294117647, 0.7372549, 0.27058823)
  # elif g==3: #3
  #   rgb=(0.7411764705, 0.8117647, 0.19607843)
  # elif g==4: #4
  #   rgb=(0.9294117647, 0.8823529, 0.35686274)
  # elif g==5: #4
  #   rgb=(0.9294117647, 0.7490196, 0.2)
  # elif g==6: #5
  #   rgb=(0.9372549019, 0.6078431, 0.12549019)
  # elif g==7: #6
  #   rgb=(0.9568627450, 0.4156862, 0.60784313)
  # elif g==8: #7
  #   rgb=(0.9176470588, 0.3333333, 0.27058823)
  # elif g==9: #8
  #   rgb=(0.6666666666, 0.6666666, 0.66666666)
  # return rgb
  #1. Retro Metro
  #p1 = ["#ea5545", "#f46a9b", "#ef9b20", "#edbf33", "#ede15b", "#bdcf32", "#87bc45", "#27aeef", "#b33dc6", "#aaaaaa"]
  #2. Dutch Field
  # [#e60049", "#0bb4ff", "#50e991", "#e6d800", "#9b19f5", "#ffa300", "#dc0ab4", "#b3d4ff", "#00bfa0"]
  #3. River Nights
  # ["#b30000", "#7c1158", "#4421af", "#1a53ff", "#0d88e6", "#00b7c7", "#5ad45a", "#8be04e", "#ebdc78"]
  #4. Spring Pastels
  # ["#fd7f6f", "#7eb0d5", "#b2e061", "#bd7ebe", "#ffb55a", "#ffee65", "#beb9db", "#fdcce5", "#8bd3c7"]

def getColorGear2(g):
  return gearscols[g]
  # return ( colorPal2[ int(min(255,g/10*255)) ] )
  #return ( int(colorPal1[ int(min(255,g/10*255)) ][0]*0.5) ,
  #         int(colorPal1[ int(min(255,g/10*255)) ][1]*0.5) ,
  #         int(colorPal1[ int(min(255,g/10*255)) ][2]*0.5)   )

def getColorGear(g):
  # return ( colorPal1[ int(min(255,g/10*255)) ] )
  return gearscols[g]

def getColorTyres(temp):
    global ac_TempMult, maxtemp
    minTF=50
    maxTF=120
    #x = fact/4 * ( max(0,min(maxTF, temp-minTF)))/(maxTF-minTF) * 1
    #x =  ( max(0,min(maxTF, temp-minTF)))/(maxTF-minTF) * 255
    x =  ( max(0,min(maxTF, temp-minTF)))/(maxTF-minTF) * maxtemp * 350
    return (colorPal1[int(min(255,x))])

def getColorStuff(x):
    return (colorPal1[int(min(255,max(0,x)))])

def distance(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2 )

def ReadAILine():
    global AI_LINE, BORDER_RIGHT, BORDER_LEFT, BORDER_RIGHT2, BORDER_LEFT2, BORDER_LEFT3, BORDER_RIGHT3, BORDER_LEFT4, BORDER_RIGHT4, bClosedTrack
    global sTrack, sLayout, png_mapoffset, mapscale
    global minx, miny, sFileAI, canvasMap, myImageMap, myImageMapOrig, id10m, id50m
    try:
        data_ideal   = []
        data_detail  = []
        AI_LINE      = []
        BORDER_LEFT  = []
        BORDER_RIGHT = []
        BORDER_LEFT2  = []
        BORDER_RIGHT2 = []
        BORDER_LEFT3  = []
        BORDER_RIGHT3 = []
        BORDER_LEFT4  = []
        BORDER_RIGHT4 = []
        AI_LINE_LENGTH = 0.0
        minx=10000000.0
        miny=10000000.0
        maxx=-10000000.0
        maxy=-10000000.0
        id10m=0
        id50m=0

        with open(sFileAI, "rb") as buffer:
            # read header, detailCount is number of data points available
            header, detailCount, u1, u2 = struct.unpack("4i", buffer.read(4 * 4))
            # read ideal-line data
            for i in range(detailCount):       # 4 floats, one integer
                data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
                x , z , y, dist, id = data_ideal[i]
                coordscurr = ( float(x), -float(y), float(z)  )
                if i>0:
                    AI_LINE_LENGTH += distance( coordscurr, coordslast )
                coordslast = coordscurr
                if id10m==0 and dist>10:
                    id10m=i
                if id50m==0 and dist>50:
                    id50m=i
            # read more details data
            for i in range(detailCount):        # 18 floats
                data_detail.append(struct.unpack("18f", buffer.read(4 * 18)))

            if detailCount<3:
                ac.log('leb_xatt: bad ai line')
            else:
                # find maximas
                xl, zl, yl, dist, id = data_ideal[len(data_ideal)-1]
                yl = -yl
                for i in range(len(data_ideal)):
                    xC, zC, yC, dist, id = data_ideal[i]
                    yC = -yC
                    if xC<minx:
                        minx = xC
                    if xC>maxx:
                        maxx = xC
                    if yC<miny:
                        miny = yC
                    if yC>maxy:
                        maxy = yC

                ### borrowed from "create_png" (map_display app by 'Never Eat Yellow Snow' APPS)
                spreadx = max(maxx-minx, 100)
                spready = max(maxy-miny, 100)
                width  = png_size - png_mapoffset*2
                height = png_size - png_mapoffset*2
                mapscale = min((width - png_mapoffset) / spreadx, (height - png_mapoffset) / spready)
                # choose offset that avg(minx,maxx) and avg(miny,maxy) is mapped to center
                ocenterx = 0.5*(minx+maxx)
                ocentery = 0.5*(miny+maxy)
                insideoffset = 1/mapscale * histDotSizePNG*3

                # new img
                myImageMap = Image.new("RGBA", (int(width+png_mapoffset*2), int(height+png_mapoffset*2)),(255,255,255,0) )
                canvasMap = ImageDraw.Draw(myImageMap)

                # set scaled values
                xl, zl, yl, dist, id = data_ideal[len(data_ideal)-1]
                yl = -yl
                for i in range(len(data_ideal)):
                    xC, zC, yC, dist, id = data_ideal[i]
                    yC = -yC
                    direction = ( -math.degrees( math.atan2(yl - yC, xC - xl)))
                    xl = xC
                    yl = yC

                    x          = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction + 90) * math.pi / 180) * mapscale
                    y          = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction + 90) * math.pi / 180) * mapscale
                    coordsAI = ( float(x), float(y), float(zC), dist)

                    x          = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction + 90) * math.pi / 180) * mapscale * insideoffset*1
                    x2         = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction + 90) * math.pi / 180) * mapscale * insideoffset*3
                    x3         = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction + 90) * math.pi / 180) * mapscale * insideoffset*5
                    x4         = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction + 90) * math.pi / 180) * mapscale * insideoffset*7
                    y          = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction + 90) * math.pi / 180) * mapscale * insideoffset*1
                    y2         = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction + 90) * math.pi / 180) * mapscale * insideoffset*3
                    y3         = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction + 90) * math.pi / 180) * mapscale * insideoffset*5
                    y4         = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction + 90) * math.pi / 180) * mapscale * insideoffset*7
                    coordsR    = ( float(x), float(y), float(z)  )
                    coordsR2   = ( float(x2), float(y2), float(z)  )
                    coordsR3   = ( float(x3), float(y3), float(z)  )
                    coordsR4   = ( float(x4), float(y4), float(z)  )

                    x          = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction - 90) * math.pi / 180) * mapscale * insideoffset*1
                    x2         = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction - 90) * math.pi / 180) * mapscale * insideoffset*3
                    x3         = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction - 90) * math.pi / 180) * mapscale * insideoffset*5
                    x4         = png_mapoffset + width/2  - (ocenterx - xC) * mapscale + math.cos((-direction - 90) * math.pi / 180) * mapscale * insideoffset*7
                    y          = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction - 90) * math.pi / 180) * mapscale * insideoffset*1
                    y2         = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction - 90) * math.pi / 180) * mapscale * insideoffset*3
                    y3         = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction - 90) * math.pi / 180) * mapscale * insideoffset*5
                    y4         = png_mapoffset + height/2 + (ocentery - yC) * mapscale + math.sin((-direction - 90) * math.pi / 180) * mapscale * insideoffset*7
                    coordsL    = ( float(x), float(y), float(z)  )
                    coordsL2   = ( float(x2), float(y2), float(z)  )
                    coordsL3   = ( float(x3), float(y3), float(z)  )
                    coordsL4   = ( float(x4), float(y4), float(z)  )

                    AI_LINE.append(coordsAI)
                    BORDER_LEFT.append(coordsL)
                    BORDER_RIGHT.append(coordsR)
                    BORDER_LEFT2.append(coordsL2)
                    BORDER_RIGHT2.append(coordsR2)
                    BORDER_LEFT3.append(coordsL3)
                    BORDER_RIGHT3.append(coordsR3)
                    BORDER_LEFT4.append(coordsL4)
                    BORDER_RIGHT4.append(coordsR4)
                ### for end

                # draw outline
                for i in range(1,len(AI_LINE)-1):
                  canvasMap.line( (
                    BORDER_LEFT[i-1][0],
                    BORDER_LEFT[i-1][1],
                    BORDER_LEFT[i  ][0],
                    BORDER_LEFT[i  ][1]), fill="white", width=1) # int(histDotSizePNG))
                  canvasMap.line( (
                    BORDER_RIGHT[i-1][0],
                    BORDER_RIGHT[i-1][1],
                    BORDER_RIGHT[i  ][0],
                    BORDER_RIGHT[i  ][1]), fill="white", width=1) # int(histDotSizePNG))
                  # ai-line
                  #canvasMap.line( (
                  #  AI_LINE[i-1][0],
                  #  AI_LINE[i-1][1],
                  #  AI_LINE[i  ][0],
                  #  AI_LINE[i  ][1]), fill="green", width=int(histDotSizePNG))

                # close outline
                bClosedTrack=False
                if distance(BORDER_LEFT[len(BORDER_LEFT)-1], BORDER_LEFT[0]) < 20.0:
                  bClosedTrack=True
                if bClosedTrack:
                  canvasMap.line( (
                    BORDER_LEFT[len(BORDER_LEFT)-2][0],
                    BORDER_LEFT[len(BORDER_LEFT)-2][1],
                    BORDER_LEFT[0][0],
                    BORDER_LEFT[0][1]), fill="white", width=1) # int(histDotSizePNG))
                  canvasMap.line( (
                    BORDER_RIGHT[len(BORDER_RIGHT)-2][0],
                    BORDER_RIGHT[len(BORDER_RIGHT)-2][1],
                    BORDER_RIGHT[0][0],
                    BORDER_RIGHT[0][1]), fill="white", width=1) # int(histDotSizePNG))
                  # ai-line
                  # canvasMap.line( (
                  #   AI_LINE[len(BORDER_RIGHT)-2][0],
                  #   AI_LINE[len(BORDER_RIGHT)-2][1],
                  #   AI_LINE[0][0],
                  #   AI_LINE[0][1]), fill="green", width=1) # int(histDotSizePNG*3))

                # s/f marker
                canvasMap.line( (
                  BORDER_LEFT4[0][0],
                  BORDER_LEFT4[0][1],
                  BORDER_RIGHT4[0][0],
                  BORDER_RIGHT4[0][1]), fill="green", width=4)
                canvasMap.line( (
                  BORDER_LEFT4[0][0],
                  BORDER_LEFT4[0][1],
                  BORDER_LEFT[int(id50m*1/mapscale/2)][0],
                  BORDER_LEFT[int(id50m*1/mapscale/2)][1]), fill="green", width=4)
                canvasMap.line( (
                  BORDER_RIGHT4[0][0],
                  BORDER_RIGHT4[0][1],
                  BORDER_RIGHT[int(id50m*1/mapscale/2)][0],
                  BORDER_RIGHT[int(id50m*1/mapscale/2)][1]), fill="green", width=4)

                mult=width/1024
                font = ImageFont.truetype('content/fonts/consola.ttf', size=int(12*mult))
                # canvasMap.text((10, myImageMap.size[1]*0.9               ), "most left  - Non-Dimensional Slip"  , font=font)
                # canvasMap.text((10, myImageMap.size[1]*0.9+int( 8*mult*2)), "left       - Slip Angle"            , font=font)
                # canvasMap.text((10, myImageMap.size[1]*0.9+int(16*mult*2)), "center     - Speed"                 , font=font)
                # canvasMap.text((10, myImageMap.size[1]*0.9+int(24*mult*2)), "right      - Slip Ratio"            , font=font)
                # canvasMap.text((10, myImageMap.size[1]*0.9+int(32*mult*2)), "most right - Wheel Slip"            , font=font)

                #canvasMap.text((10, myImageMap.size[1]*0.9+int( 8*mult*2)), "left       - Throttle"              , font=font)
                # canvasMap.text((10, myImageMap.size[1]*0.9+int(16*mult*2)), "center     - Speed"                 , font=font)
                #canvasMap.text((10, myImageMap.size[1]*0.9+int(24*mult*2)), "right      - Brakes"                , font=font)
                canvasMap.text((10, myImageMap.size[1]*0.9+int( 8*mult*2)), "left       - Speed"              , font=font)
                canvasMap.text((10, myImageMap.size[1]*0.9+int(24*mult*2)), "right      - lat. g-force"       , font=font)

                # draw palette
                for i in range(255):
                  rgbt = getColorStuff(i)
                  canvasMap.line((myImageMap.size[0]*0.5+i  , myImageMap.size[1]*0.95               ,
                                  myImageMap.size[0]*0.5+i+1, myImageMap.size[1]*0.95+int(12*mult)  ),
                                  fill=(int(rgbt[0]*255), int(rgbt[1]*255), int(rgbt[2]*255) ) )

                myImageMapOrig = myImageMap.copy()
                # ac.log(laps_images_path + 'heatmap_bare.png')
                # myImageMap.save(laps_images_path + 'heatmap_bare.png')
                # ac.log(sFileAI + " read: " + str(len(BORDER_LEFT)) + ' ' + str(len(BORDER_RIGHT)) )
                # ac.log('leB_yatt: AI line - ' + str(round(AI_LINE_LENGTH,3)) + 'm - ' + str(len(AI_LINE)) + ' points')
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())
        AI_LINE      = []
        BORDER_RIGHT = []
        BORDER_LEFT  = []
        BORDER_RIGHT2 = []
        BORDER_LEFT2  = []
        BORDER_RIGHT3 = []
        BORDER_LEFT3  = []
        BORDER_RIGHT4 = []
        BORDER_LEFT4  = []
