Install:
Unpack archive to AC root.

I made my own version of one of the "Custom Shaders Patch" apps, available here: https://github.com/ac-custom-shaders-patch/acc-extension-apps

Its the debug app and atm it replaces the original in "assettocorsa\apps\python\AccExtHelper" completely, as it has the same base.
To work properly you obviously have to install "Custom Shaders Patch" (https://acstuff.ru/patch/). Only the FPS counter would work without it.


It provides some values for track makers ie when making
data\cameras.ini
data\ai_hints.ini
data\overlays.ini (used for TimeAttack-mode)


Values shown:
-Shaders Patch version
-FPS (min/max): current
-track light count (lights in mirror)
  -currently visible lights (min/max): current
-FOV
-current global ambient value
(then the values mentioned for "Copy" button below)

Buttons:
"Driver" - toggle driver visibility
"🚪"     - toggle open/close door
"V +/-"  - toggle vao-visibility (if any vao-patch was loaded)
"V o/N" - toggle vao-patch mode (gray-scaled/normal)
"🔦" - toggle light-debug view
"r" - reset min/max values for fps- and light-counters
"Step back" - only available in "Practice" mode! - sets the car back on the AI-line for about 500 meters
"c" - copies only camera "POSITION=x,y,z" in Windows-Clipboard
"Copy" - copies some more values into Windows-Clipboard:
  WORLD_POSITION=118.857, 1.644, -155.86  (current camera position)
  ORIENTATION=-0.1244, 0.0323, 0.9249     (current camera direction)
  xyz-dist=-118.857, -1.644, 155.86 (dist. to last cam [after using copy button])
  dist2last=9211.0143925 (dist. to last cam position also after using copy button)
  currPoT=0.973901 - current Point of Track (0.0...1.0)
    is the percentage value on the ai-spline for following params in "camera.ini":
IN_POINT=0.95
OUT_POINT=1.0
    and also for the following values in "data\ai_hints.ini":
START=0.4
END=0.41

With only F3 and F7 and a xeroxed "camera.ini" you get a result pretty fast
Be aware of "IS_FIXED=1" in camera.ini, it was a hunt for me ;)

"record overlays.ini" button generates the "data\overlays.ini" for TimeAttack-mode, follow this abc-picture


button "new 'cameras(_X).ini' "
-creates new cameras.ini, leaves existing cameras.ini or cameras_1.ini and such alone and adds a number for a new one
-use it in a replay, where you can pause the game
-switch to free-cam mode with "F7"
-move camera around with cursor-keys plus Ctrl and/or Shift
-follow steps 1-5 below:

note1: to finish creating 'cameras.ini', you click the button "add camera #X" again, the app should auto detect if the lap is over (after the car crossed the finish line and started a new lap)
note2: you could also just close the game after you set the last camera (before the start/finish camera again)
note3: please edit "camera.ini" to your liking, as it only has some generic default values
note4: takes current FOV +-20 into acount when adding a camera (thats why the FOV-buttons)


Update 0.3: fixed showing app every session, even if closed last time
Update 0.4+0.5: error fixes
Update 0.6: distance to last cam fix
Update 0.7: -fixed some errors with overlays.ini
-added recording "camera.ini" feature
-made FOV-keys optional (off by default), made modifier keys for it adjustable (ALT, Ctrl, Shift, Win)

used info from:
Roberto Olivetti - https://www.assettocorsa.net/forum/index.php?threads/how-to-make-time-attack-mode-work.20535/
Fat-Alfie - https://www.racedepartment.com/threads/thomson-road-grand-prix-singapore.127582/page-8#post-2377425

Update 0.8:
- added "Reset Car" button, resets car to (not really) the nearest point of track without going back to the pits
- added keyboard shortcuts for "Reset Car" and "Step back" buttons
- "Reset car" and "Step back" button should work in "Practice" and "Hotlap" mode
- though when used in "Hotlap" mode, you laptime gets invalidated immediately
- if you want to assign a wheel button to the app, use JoyToKey https://joytokey.net/en/download
 for mapping an existing shortcut to a wheel-button

Update 0.9:
-fixed generating "cameras.ini", does not use same camera for first and last anymore
-added flatspot/blister/grain info for all tyres (before it was only rear left one displayed ;) )
-added small button "v"/"^" to toggle some of the details
-added "c" button next to "Copy" button, which only copies "POSITION=x,y,z" into clipboard like original app

Update 0.95:
-fixed app working without "settings.ini", sorry
-fixed app writing incomplete "cameras.ini" on shutdown, now it gets deleted
-"r" button now resets generating "cameras.ini" or "overlays.ini"

Update 0.96:
-fixed settings saving
-fixed UP parameter when generating "cameras.ini" and when using "Copy" button
-added coordinates relative to car center when using "Copy" button

Update 0.97:
-hopefully fixed the up/forward thing

Update 0.98:
-fixed the up/forward thing and spaces in " = " params

Update 0.99:
-added shortcuts for driver and door toggle buttons; reminder: shortcuts are off by default

Update 0.99a:
-changed default key for door toogle to "F" as Ctrl+"C" is already occupied by toggle AI driving

Update 0.99b:
-changed lowest FOV to 1 (10 before)
-changed UP xyz-coordinates for clipboard/camera files to have opposite minus sign, which should now be the correct for dynamic cams too

Update 0.99f:
-added min/max fov and isfixed params when using "create camerasX.ini"
-added track-camera check, so you know which one is active atm, can take upto 1.5 seconds to update, last line in text-output

Update 0.99g:
-fixed app icon not found (call of ac.newApp() with wrong caption)

Update 0.99h:
-changed behaviour after not seeing s/f line, unfinished "cameras.ini" will not be removed, but renamed, it gets txt extension:
"camerasX.ini_unfinished.txt"

Update 0.99i:
-made the unfinished "camerasX.ini_unfinished.txt" having the correct numbers in it

Update 0.99j:
-fixed renaming if "...unfinished..." with same name is already there, else you would end up with old unfinished

Update 0.99k:
-added "App size multiplier" option, set in CM->Settings->APPS->Shaders Extension Debug (not available ingame)
-added "auto recording 'cameras.ini'" feature,
  >based on AI-line and car-cam, has some options when activated:
  >distance in meters for IN_POINT/OUT_POINT
  >min/max height, random value is used from resulting range
  >result may still need adjustment!

Update 0.99m:
-now with included "settings\settings_defaults.ini"
-added some check if ai-line is missing

Update 0.99n:
-added some more values copied to clipboard
-added configurable shortcut for "copy" button

Update 1.0:
-removed cam info, use CamInfo app :) https://www.racedepartment.com/downloads/caminfo.46609/
-fixed auto recording and overlays recording
-fixed shortcuts disabled by the app itself on the slightest error

Update 1.2:
-cleaned up ui, 4 layouts with the those two buttons:
-handling of shortcuts changed, you can only set one

Update 1.3:
-fixed recording "overlays.ini"
