Shows some CustomPhysics values from CustomShadersPatch,
also works as normal tyre app on vanilla AC.

Unpack to AC folder under steam.

Brake temps only as option in ContentManager->Settings->Apps->"tyres_app_ext" (see down below), all other options also in game.

Thx to chas1723 and others for endless testing hours

v1.1
Todo: Font colors

v1.2
-fixed pressure colors when too low/high
-Directions 'Star' Colors: green - steering wheel, blue - slipangle front, red - slipangle rear.

-redone slip angle+ratio as circle+triangle, in red when braking, in blue when sliding from power
-TyreSlip and ndSlip as fading rectangles on the upper/lower edges of tyres
-Mz self aligning torque as small yellow triangles on the wheel centers, growing outward/inward

-with "more" enabled:
 +front/rear RideHeight bars
 +x/y gforces, in green
 +cars x velocity as x, current CG height as y, in red
 +cars angular velocity x/y, in blue
 +Dy in gray->red besides each tire

v1.3
bugfix release, update timer to high, separated Nm option for brakes

v1.4
another bugfix release, tyre colors were the same all the time

v1.5
-fixed pressure/wear color again
-fixed updating if tyres are changed
-fixed reading ideal pressure, if not found current is used (trigger live reading with "read curr" button)
-fixed wrong circle/triangle direction for left tyres (slipangle), made them more visible when all is red already
-bigger Dy display, values for rideheight (w/ "more" enabled)
-added second circle that grows until FRICTION_LIMIT_ANGLE is reached
-improved min/max temp reading
-buttons hidden (faster) on session startup

v1.6
-fixed saving options

v1.7
-fixed bad bug on reading in stuff

v1.8
-fixed more bad bugs on reading in stuff again

v1.9
-again some fixes and tirename seen more often

v1.9.2
-shifted damper/suspension stuff to the side and added min/max for them

v1.9.3
-fixed wear for encrypted cars, introduced in v1.9 i think

v1.9.4
-fixed some pressure = 0 error with damage

v1.9.5
-fixed reading max ideal temps
-adjusted coloring (again), tamed slip text position
-fixed brake temp bars not showing on cars that have them

v1.9.6
-hopefully fixed brakes dissapearing after session restart
-separated some values to be moved around

v1.9.7
-small fix for vanilla ac without csp

v1.9.8
-fix for rideheight display (with "more" enabled)
-made abs/tc optional, off by default, only in CM/settings.ini, not as option in game
-disabled damper-travel stuff, suspension now correct (with "↑↓" enabled; long-term bug in CSP gives back wrong suspension/damper travel, only for the front left wheel, switched to shared mem values; it works for cars with dwb suspension though)
-added a bit of gradient to "circle.png" (used for slipangle)

v1.9.9
-fixed config situation

v1.9.9a
-fixed config situation and tyre color

v1.9.9c
-changed wear and pressure display, compacted buttons, added foreground +/-

v2.0
-fixed units reading from config
-finally fixed brakes for lots of cars, see list in CM (screenshot), working slipstream detection with vanilla AC
-more options:
  toggle wear graph/text, background text, aero text
  toggle pressure-diff (only in CM)
-added DownForce and Drag bars
 (with AERO on, you can disable in code, lines 26/27)
-please restart ContentManager after you installed manually
 (some descriptions in CM ui for the default config might not have updated properly)
-you might need to configure some options again

v2.1
-fixed colors für tyres with data available, it was bugged to only work for encrypted cars
-dirt transparency fixed
-aerotext without aerograph fixed
-starting maxBrakeTemp=500 (red, was 125)
-fixed "read current" button for pressure

v2.1a
-fixed aero bar only moving 10 pixels when green/red

v2.1b
-fixed again :(

v2.2
-fixes

v2.3
-fixed weargraph droping below borders (wear over 5%)

-changed slip circle behaviour
--visible when gripping
--changed to elipse style

-added second app window for tyre INFO
--option in CM to show/not show it on session start
--will auto close after 15 secs or if driving above 50 km/h
--will stay open if you click on it

v2.4
-fixed "read current" not resetting everything

v2.5
-fixed wear display

v2.6
-fixed wear again
-added grip bars, calculated from tyres Virtual km, off by default, also shown as numbers in tyre info window
-click on pressure display opens tyre info window
-pressure color earlier cold/hot
-fixed issue after tyre change

v2.7
-slipangle always visible
-disabled loading tyre-data on car change with Ctrl+Num1/Num3

v2.8
-fixed recognizing tyre change in game

v3.0
-fixed errors when using vanilla AC

v3.1
-changed some defaults
-color "mult" saved per car
-pressure more readable
-IMO temps can be disabled
-grip bars now show Grip from 95-100%, based on 'd_temp'
-click on right pres. vals: toggle diff to ideal
 (like before: click left on pressure vals: show tyre info window)
-added another slip graph

v3.2
-added tyre selector in info window, will switch back to current after some seconds
-fixed some ui positions

v3.3
-fixed unreadable fonts when hot/cold
-fixed brake temps out of place for some cars

v3.4
-background loading for new/other tyres
-flatspots/blister/grain better visible
-added brake temp option for ingame ui (will turn off again if not available)
-fixed drawing slipangles, switched to filled circle for slipratio (was inverted circle before as for load too)
-fixed other small issues

v3.5
-brake temp on/off will not be saved, option from CM ui is used
-added this in code, not in UI: ALWAYSSHOW_FLATSPOTSBLISTERGRAIN = False

v3.6
-added wear/pressure to grip calc

v3.7
-redone colors, first palette is made from colors in "...system/cfg/tyres_app.ini"
-12 palettes to choose from, those with * are for colorblind people
-other small fixes

v3.8
-added brake core temps for cars that have it
-fixed hiding brake surface temps
-changed grip calc in favor of wear
-many other small adjustments

v3.8 again
-fixed brake temps
-note: you might see brake temps disapear for most cars, thats normal, initially the app does not know if the car has them

v3.9
-moved options into their own window
-added option to not display pressure bars
-optimized data loading, especially when switching to another car

v4.0
-added ABS/TC button, ABS/TC works correctly from CSP 0.2.2 and up
-added option for flatspot/grain/blisters
-added option for IMO temps only
-added option to change font and font-size used for numbers
-added fancy mode with tyre colors fading into each other, enabled by default
 (some options are not availabe)

v4.1
-fixed not working in VR
-more visual changes
-added 2 buttons to show min/max values for 5 seconds (atm CSP only)
-added dedicated option for width and height of the app
-added dedicated option for pressure text
-added graphic pressure display, a horizontal bar with green ideal marker in the middle

v4.2
-fixed not loading some images used for visuals
-fixed wear disappearing after changing options

v4.3
-fixed wear not being displayed correctly
-added "hot" graphics/text as extra options
-added options for carcass and brake temps
-made mini/maximas more readable

v4.4
-fixed hottext settings loading/saving
-fixed wear
-put road/ambient/grip below the app

v4.5
-fixed imo temp colors
-locked marker more smooth

v4.6
-fixed temps too hot making parts of the tyre invisible
-fixed some aero text display issues

v4.7
-fixed brake temps colors linked to tyre temps

v4.8
-fix for some strange crashes

v4.9
-fixed the app being invisible on first install

v5.0
-fixed brakes temps/text not saved correctly

v5.1
-fixed brake options not saved correctly, after using a a car with no brake-temps available

v5.2
-moved min/max values to tyre window and added a couple more values there
-added a second set of images for fancy mode without fading (img2\ folder)
-increased legibliity by moving around some overlapping stuff and adding shadows to road/air display
-fixed brake core temps display being drawn before outer brakedisc temps (for cars that have)
