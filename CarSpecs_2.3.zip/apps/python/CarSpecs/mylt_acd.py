#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Decrypt and extract information files about a car.
Big thanks for aluigi@ZenHaxs.com that have the patience to help me to open the ACD files.

@author: albertowd
"""
import os, configparser, traceback, itertools, math
import codecs
from sys import exc_info
from collections import OrderedDict
from configparser import ConfigParser
from struct import unpack


#if __name__ == '__main__':
#  from myno_util import log
#else:
from mylt_util import log


def get_float(s):
  result=""
  for l in s.strip():
    if l.isnumeric() or l=='.' or l=='-':
      result=result+l
    else:
      break
  if result=="" or result=="-" or result==".":
    result="0"
  return float(result)

class ACD(object):
    """ Stores the ACD file contents. """

    def __init__(self, path):
        """ Default constructor receives the ACD file path. """
        self.path = path # only for real export
        path_v = path.split("/")

        # Initiate the class fields.
        self.__car = path_v[-1]
        self.__content = str()
        self.__content_size = len(self.__content)
        self.__files = OrderedDict()
        self.__key = generate_key(self.__car)
        # log('++++++++++++++++++++++++\n' + self.__key)

        # Verify if the data.acd exists to load car information.
        data_acd_path = "{}/data.acd".format(path)
        if os.path.isfile(data_acd_path):
            log(self.__car + " loading from " + self.__car + "/data.acd ...")
            self.__load_from_file(data_acd_path)
        else:
            # If it don't, try to load from data folder.
            log(self.__car + " loading from data folder...")
            self.__load_from_folder("{}/data".format(path))

    def __load_from_file(self, path):
        """ Loads the car information by the data.acd encrypted file. """

        # Read all the file into memory.
        try:
            with open(path, "rb") as rb:
                self.__content = rb.read()
                self.__content_size = len(self.__content)
        except:
            log("Failed to open file {}:".format(path))
            for info in exc_info():
                log(info)

        if self.__content_size > 8:
            # Verify the "version" of the file.
            offset = 0
            dummy = unpack("l", self.__content[offset:offset + 4])[0]
            offset += 4
            if dummy < 0:
                # New cars, just pass the first 8 bytes.
                dummy = unpack("L", self.__content[offset:offset + 4])[0]
                offset += 4
            else:
                # Old cars don't have any version.
                offset = 0

            # Parse each inner file.
            while offset < self.__content_size:
                # Size of the file name.
                name_size = unpack("L", self.__content[offset:offset + 4])[0]
                offset += 4

                # File name.
                file_name = self.__content[offset:offset +
                                           name_size].decode("utf8")
                offset += name_size

                # File size.
                file_size = unpack("L", self.__content[offset:offset + 4])[0]
                offset += 4

                # Get the content and slices each 4 bytes.
                packed_content = self.__content[offset:offset + file_size * 4][::4]

                offset += file_size * 4

                # Decrypt the content of the file.
                decrypted_content = "" # bytearray()
                key_size = len(self.__key)

                for i in range(file_size):
                    code = packed_content[i] - ord(self.__key[i % key_size])
                    if code < 0: code = 256-abs(code)
                    # decrypted_content.append(ord(chr(code)))
                    decrypted_content += chr(code)

                # Save the decrypted file.
                self.set_file(decrypted_content, file_name)

                # Save the decrypted file on disk. data folder must exist
                #with codecs.open(self.path + '/data/' + file_name, 'wb') as w:
                #    w.write(decrypted_content)

        elif self.__content_size > 0:
            log("File too small to decrypt: {} bytes.".format(self.__content_size))

    def __load_from_folder(self, path):
        """ Loads the car information by the data folder. """
        if os.path.isdir(path):
            for file_name in os.listdir(path):
                file_path = "{}/{}".format(path, file_name)
                if os.path.isfile(file_path):
                    # log(file_name)
                    try:
                        with open(file_path, 'r') as r:
                            self.set_file(r.read(), file_name)
                    except:
                        log(' - warning - previous file skipped.')
        else:
            log(' - warning - previous file skipped.')

    def __str__(self):
        """ Just print some useful information. """
        info  = "Car: {} - {} byte\n".format(self.__car, self.__content_size)
        info += "Key: {}\nFiles:\n".format(self.__key)
        for name in self.__files:
            info += "   {} - {}b\n".format(name, len(self.__files[name]))
        return info

    def check_file(self, name):
        """ Returns True if inner file exists. """
        return name in self.__files

    def get_file(self, name):
        """ Returns the content of an inner file. """
        if name in self.__files:
            lines1 = self.__files[name].encode('ascii', 'ignore').decode('ascii').strip()
            lines2 = ''
            for s1 in lines1.split('\n'):
                s2 = s1.strip()
                if s2!='' and s2[0]!=';' and s2[0]!='/' and s2[0]!='\\' and s2[0]!='#':
                    if ';' in s2:
                        lines2 += s2.split(';')[0]+'\n'
                    else:
                        lines2 += s2+'\n'
                    #if '=' in s2:
                    #    sA=s2.split('=')
                    #    lines2 += sA+ '='+sA
                    #else:
                    #    lines2 += s2+'\n'
            lines1 = str(lines2).strip()
            return lines1
        else:
            return ""

    def set_file(self, content, name):
        """ Sets a new content to an inner file. """
        self.__files[name] = content

    #################################################

    def get_file_section_value(self, config, section, valuename, valueNameGiven="", valueGiven="", opt=""):
        res=""
        if valueGiven!="" and valueNameGiven!="":
            for i in range(10):
                sectname = "FRONT{}".format("_{}".format(i))
                if i==0 and config.has_section("FRONT"):
                    sectname = "FRONT"
                if config.has_option(sectname, valueNameGiven):
                    if config[sectname][valueNameGiven] == valueGiven:
                        sectname = section + "{}".format("" if i == 0 else "_{}".format(i))
                        if config.has_option(sectname, valuename):
                            res = get_float(config[sectname][valuename])
                            break
            return str(res)
        if config.has_section(section):
            if config.has_option(section,valuename):
                res = get_float(config[section][valuename])
        return str(res)

    # [THERMAL_FRONT]
    # PERFORMANCE_CURVE=tcurve_semis.lut				;File to use for temperature/grip relation
    # [FRONT]
    # NAME=Semislicks
    # SHORT_NAME=SM
    # WEAR_CURVE=semislicks_front.lut		; file with lookup table to call

    def get_file_section_value_as_curve(self, config, section, valuename, valueNameGiven="", valueGiven="", opt=""):
        res=[]
        if valueGiven!="" and valueNameGiven!="":
            for i in range(10):
                sectname = "FRONT{}".format("_{}".format(i))
                if i==0 and config.has_section("FRONT"):
                    sectname = "FRONT"
                if config.has_option(sectname, valueNameGiven):
                    if config[sectname][valueNameGiven] == valueGiven:
                        sectname = section + "{}".format("" if i == 0 else "_{}".format(i))
                        if config.has_option(sectname, valuename):
                            Curve = config[sectname][valuename]
                            if self.check_file(Curve):
                                # lut in file, get and parse values
                                # lines = self.get_file(Curve).split("\n")
                                # for i in range(len(lines)):
                                #     v=lines(i).split('|')
                                #     if len(v)>1:
                                #         lines[i] = lines[i].strip().replace("=","|")
                                # return lines
                                return self.get_file(Curve)
                            else:
                                if "|" in Curve:
                                    # inline lut
                                    lines = Curve.split("|")
                                    for i in range(len(lines)):
                                        lines[i] = lines[i].strip().replace("=","|")
                                    return lines
                                return Curve
            try:
                if len(config.sections)>0:
                    for s in config.sections:
                        log(s + ' - ' + section)
                        if s in section.lower(): # section
                            if config.has_option(s,valueNameGiven): # valuename
                                if config[s][valueNameGiven] == valueGiven: # value
                                    if config.has_option(s,valuename): #
                                        sect2 = s.replace(s,)
                                        return config[s][valuename]
            except:
                log('could not read [' + section + '] - ' + valuename + ' - ' + valueNameGiven)
            return res

        if config.has_section(section):
            if config.has_option(section,valuename):
                Curve = config[section][valuename]
                if self.check_file(Curve):
                    # lut in file
                    return self.get_file(Curve)
                else:
                    if "|" in Curve:
                        # inline lut
                        lines = Curve.split("|")
                        for i in range(len(lines)):
                            lines[i] = lines[i].strip().replace("=","|")
                        return lines
                    return Curve
        return []



    #################################################

    def get_ideal_pressure(self, compound, wheel):
        """ Returns the compound ideal pressure. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            if compound=="":
                compound = get_tire_name("", config, wheel)
            res = 0.0
            for s in config.sections():
                if 'FRONT' in s and wheel<2:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            if config.has_option(s,"PRESSURE_IDEAL"):
                                return get_float(config[s]["PRESSURE_IDEAL"])
                if 'REAR' in s and wheel>1:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            if config.has_option(s,"PRESSURE_IDEAL"):
                                return get_float(config[s]["PRESSURE_IDEAL"])
            return float(res)
        except:
            log("Failed to get tire ideal pressure: "+ name + "\n" + traceback.format_exc())
            #for info in exc_info():
            #    log(info)
            #raise
            return 0.0

    def get_FRICTION_LIMIT_ANGLE(self, compound, wheel):
        """ Returns the compound ideal pressure. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            if compound=="":
                compound = get_tire_name("", config, wheel)
            res = 5.0
            for s in config.sections():
                if 'FRONT' in s and wheel<2:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            if config.has_option(s,"FRICTION_LIMIT_ANGLE"):
                                return get_float(config[s]["FRICTION_LIMIT_ANGLE"])
                if 'REAR' in s and wheel>1:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            if config.has_option(s,"FRICTION_LIMIT_ANGLE"):
                                return get_float(config[s]["FRICTION_LIMIT_ANGLE"])
            return float(res)
        except:
            log("Failed to get tire ideal pressure: "+ name + "\n" + traceback.format_exc())
            #for info in exc_info():
            #    log(info)
            #raise
            return 5.0


    def getTyreWidthFront(self, compound):
        """ Returns the Front tyre width. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini").replace('%', 'mod') )
        try:
            name = get_tire_name(compound, config, 0)
            sect=''
            for s in config.sections():
                if 'FRONT' in s:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            sect = s
                            break
                if sect!='':
                    break
            if sect!='':
                if config.has_option(sect, "WIDTH"):
                    return get_float(config[sect]["WIDTH"])
                else:
                    return 0.0
            else:
                return 0.0
        except:
            #log('error: ' + traceback.format_exc() )
            log("Failed to get tire width:")
            for info in exc_info():
                log(info)
            raise

    def getTyreWidthRear(self, compound):
        """ Returns the Rear tyre width. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            name = get_tire_name(compound, config, 2)
            sect=''
            for s in config.sections():
                if 'REAR' in s:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            sect = s
                            break
                if sect!='':
                    break
            if sect!='':
                if config.has_option(sect, "WIDTH"):
                    return get_float(config[sect]["WIDTH"])
                else:
                    return 0.0
            else:
                return 0.0
        except:
            #log('error: ' + traceback.format_exc() )
            log("Failed to get tire width:")
            for info in exc_info():
                log(info)
            raise

    def getRimRadiusRear(self, compound):
        """ Returns the Rear rim radius. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            name = get_tire_name(compound, config, 2)
            sect=''
            for s in config.sections():
                if 'REAR' in s:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            sect = s
                            break
                if sect!='':
                    break
            if sect!='':
                if config.has_option(sect, "RIM_RADIUS"):
                    return get_float(config[sect]["RIM_RADIUS"])
                else:
                    return 0.0
            else:
                return 0.0
        except:
            #log('error: ' + traceback.format_exc() )
            log("Failed to get tire width:")
            for info in exc_info():
                log(info)
            raise

    def getRimRadiusFront(self, compound):
        """ Returns the Front rim radius. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            name = get_tire_name(compound, config, 0)
            sect=''
            for s in config.sections():
                if 'FRONT' in s:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            sect = s
                            break
                if sect!='':
                    break
            if sect!='':
                if config.has_option(sect, "RIM_RADIUS"):
                    return get_float(config[sect]["RIM_RADIUS"])
                else:
                    return 0.0
            else:
                return 0.0
        except:
            #log('error: ' + traceback.format_exc() )
            log("Failed to get tire width:")
            for info in exc_info():
                log(info)
            raise

    def getTyreRadiusFront(self, compound):
        """ Returns the Rear TYRE radius. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            name = get_tire_name(compound, config, 0)
            sect=''
            for s in config.sections():
                if 'FRONT' in s:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            sect = s
                            break
                if sect!='':
                    break
            if sect!='':
                if config.has_option(sect, "RADIUS"):
                    return get_float(config[sect]["RADIUS"])
                else:
                    return 0.0
            else:
                return 0.0
        except:
            #log('error: ' + traceback.format_exc() )
            log("Failed to get tire width:")
            for info in exc_info():
                log(info)
            raise

    def getTyreRadiusRear(self, compound):
        """ Returns the Rear TYRE radius. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        try:
            name = get_tire_name(compound, config, 0)
            sect=''
            for s in config.sections():
                if 'FRONT' in s:
                    for name, value in config.items(s):
                        if (name=='short_name' or name=='name') and value==compound:
                            sect = s
                            break
                if sect!='':
                    break
            if sect!='':
                if config.has_option(sect, "RADIUS"):
                    return get_float(config[sect]["RADIUS"])
                else:
                    return 0.0
            else:
                return 0.0
        except:
            #ac.log('error: ' + traceback.format_exc() )
            log("Failed to get tire width:")
            for info in exc_info():
                log(info)
            raise

    def get_power_curve(self):
        """ Returns the rpm x power curve. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        try:
            if config.has_section("HEADER"):
                return self.get_file(config["HEADER"]["POWER_CURVE"])
        except:
            log("Failed to get rpm power curve")


    def get_rpm_upshift(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("drivetrain.ini"))
        #'AUTO_SHIFTER', 'UP'
        #'AUTO_SHIFTER', 'DOWN'
        if config.has_option("AUTO_SHIFTER","UP"):
            return float(config["AUTO_SHIFTER"]["UP"])
        else:
            return self.get_rpm_limiter() / 2.0

    def get_rpm_downshift(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("drivetrain.ini"))
        #'AUTO_SHIFTER', 'UP'
        #'AUTO_SHIFTER', 'DOWN'
        if config.has_option("AUTO_SHIFTER","DOWN"):
            return float(config["AUTO_SHIFTER"]["DOWN"])
        else:
            return self.get_rpm_limiter()/2

    def get_gearcount(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("drivetrain.ini"))
        if config.has_option("GEARS","COUNT"):
            res = config["GEARS"]["COUNT"]
        else:
            res = "0"
        return int(res)

    def get_coast_torque(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        # [COAST_REF]
        # RPM=7500                        ; rev number reference
        # TORQUE=85                        ; engine braking torque value in Nm at rev number reference
        if config.has_option("COAST_REF", "TORQUE"):
            return float(config["COAST_REF"]["TORQUE"])
        return 0.0

    def get_turbo_count(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        cnt = 1
        for i in range(10):
            name = "TURBO{}".format("_{}".format(i))
            if i==0 and config.has_section("TURBO"):
                name = "TURBO"
            if config.has_option(name, "MAX_BOOST"):
                cnt += 1
        return cnt

    def get_turbo(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        wastegate = 0.0
        cntw = 1
        for i in range(10):
            name = "TURBO{}".format("_{}".format(i))
            if i==0 and config.has_section("TURBO"):
                name = "TURBO"
            if config.has_option(name, "MAX_BOOST"):
                if config.has_option(name, "WASTEGATE"):
                    # WASTEGATE=0.625                ; Max level of boost before the wastegate does its things. 0 = no wastegate#
                    wastegate += float(config[name]["WASTEGATE"])
                    cntw += 1
        #if cnt>0:
        #    turbo = turbo / float(cnt)
        #if wastegate>0.0:
        #    turbo = wastegate / float(cntw)
        # return turbo
        return wastegate

    def get_wastegate(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        turbo = 0.0
        wastegate = 0.0
        cnt = 1
        cntw = 1
        for i in range(10):
            name = "TURBO{}".format("_{}".format(i))
            if i==0 and config.has_section("TURBO"):
                name = "TURBO"
            if config.has_option(name, "MAX_BOOST"):
                turbo += float(config[name]["MAX_BOOST"])
                cnt += 1
                if config.has_option(name, "WASTEGATE"):
                    # WASTEGATE=0.625                ; Max level of boost before the wastegate does its things. 0 = no wastegate#
                    wastegate += float(config[name]["WASTEGATE"])
                    cntw += 1
        #if cnt>0:
        #    turbo = turbo / float(cnt)
        #if wastegate>0.0:
        #    turbo = wastegate / float(cntw)
        # return turbo
        return wastegate

    def get_wastegate_display(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        turbo = 0.0
        cnt = 1
        for i in range(10):
            name = "TURBO{}".format("_{}".format(i))
            if i == 0 and config.has_section("TURBO"):
                name = "TURBO"
            if config.has_option(name, "DISPLAY_MAX_BOOST"):
                turbo += float(config[name]["DISPLAY_MAX_BOOST"])
        return turbo

    def get_ers_curve(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("ers.ini"))
        if config.has_option("KERS","TORQUE_CURVE"):
            return self.get_file(config["KERS"]["TORQUE_CURVE"])
        elif config.has_option("KINETIC","TORQUE_CURVE"):
            return self.get_file(config["KINETIC"]["TORQUE_CURVE"])
        return ""

    def get_totalmass(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("car.ini"))
        if config.has_option("BASIC","TOTALMASS"):
            res = config["BASIC"]["TOTALMASS"]
        else:
            res = float(0)
        return float(res)

    def get_carname(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("car.ini"))
        # [INFO]
        # SCREEN_NAME=ACL BMW CSL 3.5
        # SHORT_NAME=CSL 3.5
        if config.has_option("INFO","SCREEN_NAME"):
            res = config["INFO"]["SCREEN_NAME"]
        else:
            res = ''
        return res

    def get_driveType(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("drivetrain.ini"))
        if config.has_option("TRACTION","TYPE"):
            return config["TRACTION"]["TYPE"]
        else:
            return ""

    def get_brakeTorque(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("brakes.ini"))
        #self.get_file("brakes.ini"):
        #    config.read_file(itertools.chain(['[HEADER]'], fp), source="brakes.ini")
        if config.has_option("DATA","MAX_TORQUE"):
            res = config["DATA"]["MAX_TORQUE"]
        else:
            res = "0"
        return float(res)

    def get_handbrakeTorque(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("brakes.ini"))
        if config.has_option("DATA","HANDBRAKE_TORQUE"):
            res = config["DATA"]["HANDBRAKE_TORQUE"]
        else:
            res = 0.0
        return float(res)

    def get_rpm_limiter(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        #'ENGINE_DATA', 'LIMITER'
        if config.has_option("ENGINE_DATA","LIMITER"):
            return float(config["ENGINE_DATA"]["LIMITER"])
        else:
            return 0.0

    def get_rpm_damage(self):
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("engine.ini"))
        #'DAMAGE', 'RPM_THRESHOLD'
        if config.has_option("DAMAGE","RPM_THRESHOLD"):
            res = config["DAMAGE"]["RPM_THRESHOLD"]
            res = get_float(res)
        else:
            res = self.get_rpm_limiter()+100
        return float(res)

    def get_temp_curve(self, compound, wheel):
        """ Returns the compound temperature grip curve. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))
        name = "THERMAL_{}".format(get_tire_name(compound, config, wheel))
        if config.has_section(name):
            if config.has_option(name,"PERFORMANCE_CURVE"):
                Curve = config[name]["PERFORMANCE_CURVE"]
                if self.check_file(Curve):
                    return self.get_file(Curve)
                else:
                    if "|" in Curve:
                        lines = Curve.split("|")
                        for i in range(len(lines)):
                            lines[i] = lines[i].replace("=","|")
                        return lines
                    return Curve

#    lines = Split(s2, "|")
#    linesC = UBound(lines)
#    If linesC <= 0 Then: Exit Function
#    For i = 0 To linesC - 1
#        lines(i) = Replace(lines(i), "=", "|")
#    Next

        else:
            return []

    def get_wear_curve(self, compound, wheel):
        """ Returns the compound wear curve. """
        config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)
        config.read_string("[ACHEADER]\n" + self.get_file("tyres.ini"))

        name = get_tire_name(compound, config, wheel)
        if config.has_section(name):
            if config.has_option(name,"WEAR_CURVE"):
                Curve = config[name]["WEAR_CURVE"]
                if self.check_file(Curve):
                    return self.get_file(Curve)
                else:
                    if "|" in Curve:
                        lines = Curve.split("|")
                        for i in range(len(lines)):
                            lines[i] = lines[i].replace("=","|")
                        return lines
                    return Curve
        else:
            return []

def generate_key(car_name):
    """ Generates the 8 values key from the car name. """
    i = 0
    key1 = 0
    while i < len(car_name):
        key1 += ord(car_name[i])
        i += 1
    key1 &= 0xff

    i = 0
    key2 = 0
    while i < len(car_name) - 1:
        key2 *= ord(car_name[i])
        i += 1
        key2 -= ord(car_name[i])
        i += 1
        #ac.log(str(key2) + ' - '+str(type(key2)))
    key2 &= 0xff
    # ac.log(str(key2) + ' - '+str(type(key2)))

    i = 1
    key3 = 0
    while i < len(car_name) - 3:
        key3 *= ord(car_name[i])
        i += 1
        key3 = int(key3 / (ord(car_name[i]) + 0x1b))
        i -= 2
        key3 += -0x1b - ord(car_name[i])
        i += 4
    key3 &= 0xff

    i = 1
    key4 = 0x1683
    while i < len(car_name):
        key4 -= ord(car_name[i])
        i += 1
    key4 &= 0xff

    i = 1
    key5 = 0x42
    while i < len(car_name) - 4:
        tmp = (ord(car_name[i]) + 0xf) * key5
        i -= 1
        key5 = (ord(car_name[i]) + 0xf) * tmp + 0x16
        i += 5
    key5 &= 0xff

    i = 0
    key6 = 0x65
    while i < len(car_name) - 2:
        key6 -= ord(car_name[i])
        i += 2
    key6 &= 0xff

    i = 0
    key7 = 0xab
    while i < len(car_name) - 2:
        key7 %= ord(car_name[i])
        i += 2
    key7 &= 0xff

    i = 0
    key8 = 0xab
    while i < len(car_name) - 1:
        key8 = int(key8 / ord(car_name[i])) + ord(car_name[i + 1])
        i += 1
    key8 &= 0xff

    return "{}-{}-{}-{}-{}-{}-{}-{}".format(key1, key2, key3, key4, key5, key6, key7, key8)

############################################################################################

def get_tire_id_max(config):
    prefix = "FRONT{}"
    prefixr = "REAR{}"
    max=0
    for i in range(10):
        name  = prefix.format("" if i == 0 else "_{}".format(i))
        namer = prefixr.format("" if i == 0 else "_{}".format(i))
        if config.has_option(name, "SHORT_NAME") and config.has_option(namer, "SHORT_NAME"):
            max += 1
    if max>0:
        return max
    i = 0
    if config.has_option("COMPOUND_DEFAULT","INDEX"):
        i = int(config["COMPOUND_DEFAULT"]["INDEX"])
        name = prefix.format("" if i == 0 else "_{}".format(i))
        namer = prefixr.format("" if i == 0 else "_{}".format(i))
        if config.has_option(name, "SHORT_NAME") and config.has_option(namer, "SHORT_NAME"):
            max += 1
    return max

def get_tire_id(compound, config):
    prefix = "FRONT{}"
    prefixr = "REAR{}"
    if compound!="":
        for i in range(10):
            name  = prefix.format("" if i == 0 else "_{}".format(i))
            namer = prefixr.format("" if i == 0 else "_{}".format(i))
            # Check if the SHORT_NAME index exists for tire backward compatibility.
            if config.has_option(name, "SHORT_NAME") and config[name]["SHORT_NAME"] == compound \
               and config.has_option(namer, "SHORT_NAME") and config[namer]["SHORT_NAME"] == compound:
                return i
    i = 0
    if config.has_option("COMPOUND_DEFAULT","INDEX"):
        i = int(config["COMPOUND_DEFAULT"]["INDEX"])
        name = prefix.format("" if i == 0 else "_{}".format(i))
        namer = prefixr.format("" if i == 0 else "_{}".format(i))
        if config.has_option(name, "SHORT_NAME") and config.has_option(namer, "SHORT_NAME"):
            return i
    return 0

def get_tire_name(compound, config, wheel):
    """ Returns the compound session name on the tire.ini configuration file. """
    prefix = "FRONT{}" if int(wheel)<2 else "REAR{}"
    if compound!="":
        for i in range(10):
            name = prefix.format("" if i == 0 else "_{}".format(i))
            # Check if the SHORT_NAME index exists for tire backward compatibility.
            if config.has_option(name, "SHORT_NAME") and config[name]["SHORT_NAME"] == compound:
                return config[name]["SHORT_NAME"]
    i = 0
    if config.has_option("COMPOUND_DEFAULT","INDEX"):
        i = int(config["COMPOUND_DEFAULT"]["INDEX"])
        name = prefix.format("" if i == 0 else "_{}".format(i))
        if config.has_option(name, "SHORT_NAME"):
            return config[name]["SHORT_NAME"]
    return ""

def get_tire_name_by_id(id, config):
    prefix = "FRONT{}"
    for i in range(10):
        name = prefix.format("" if i == 0 else "_{}".format(i))
        # Check if the SHORT_NAME index exists for tire backward compatibility.
        if config.has_option(name, "SHORT_NAME") and id == i:
            return config[name]["SHORT_NAME"]
    return ""

def get_tire_namelong(compound, config, wheel):
    """ Returns the compound session name on the tire.ini configuration file. """
    prefix = "FRONT{}" if int(wheel)<2 else "REAR{}"
    for i in range(10):
        name = prefix.format("" if i == 0 else "_{}".format(i))
        # Check if the SHORT_NAME index exists for tire backward compatibility.
        #log('acd: ' + name + ' ' + compound)
        if config.has_option(name, "NAME") and config.has_option(name, "SHORT_NAME") and config[name]["SHORT_NAME"] == compound:
            # log('acd:   ' + compound + ' - ' + config[name]["NAME"] )
            return config[name]["NAME"]
    i = 0
    #ac.log('prefix:   ' + prefix + ' ' + compound)
    if config.has_option("COMPOUND_DEFAULT","INDEX"):
        i = int(config["COMPOUND_DEFAULT"]["INDEX"])
        name = prefix.format("" if i == 0 else "_{}".format(i))
        if config.has_option(name, "NAME"):
            return config[name]["NAME"]
    return "-"   # prefix.format("" if i == 0 else "_{}".format(i))

def mapFromTo(val,a,b,x,y):
    return (val-a)/(b-a)*(y-x)+x

def get_val_from_lut(currvalue, lutLines1, lutLines2, reverseflag=False):
    # Lines1, tmp, v1 [   0     20     40  currvalue    75      90       100        140       160       200]
    # Lines2, res, v2 [0.90   0.94   0.99          x   1.0     1.0     0.995      0.985      0.92      0.88]
    if len(lutLines1) == 0 or len(lutLines2) == 0: return 0
    currvalue = min(currvalue, max(lutLines1) )
    if not reverseflag:
        tmp = float(lutLines1[0])
        res = float(lutLines2[0])
        for v1,v2 in zip(lutLines1,lutLines2):
            if float(v1) >= currvalue:
                if float(v1) == currvalue:
                    res = float(v2)
                else:
                    if float(v1)!=0.0 and float(v2)!=0.0 and float(v1) - float(tmp)!=0.0 and float(v2) - float(res)!=0:
                        if v2!=0:
                            res = mapFromTo(currvalue, tmp, v1, res, v2)
                break
            tmp = v1
            res = v2
    else:
        tmp = float(lutLines1[len(lutLines1)-1])
        res = float(lutLines2[len(lutLines2)-1])
        for v1,v2 in zip(lutLines1[::-1],lutLines2[::-1]): # reverse
            if float(v1) >= currvalue:
                if float(v1) == currvalue:
                    res = float(v2)
                else:
                    if float(v1)!=0.0 and float(v2)!=0.0 and float(tmp)!=0.0 and float(res)!=0.0 and float(v1) - float(tmp)!=0.0 and float(v2) - float(res)!=0.0:
                        if v2!=0:
                            res = mapFromTo(currvalue,tmp,v1,v2,res)
                break
            tmp = v1
            res = v2
    return res

# def get_val_from_lut2(currvalue, lutx, luty):
#     # find lutx_lower, luty_lower
#     #      lutx_higher, luty_higher
#     # where currvalue is between   lutx_lower and lutx_higher
#     res = mapFromTo(currvalue, lutx_lower, luty_lower, lutx_higher, luty_higher)

def round5(x, base=5):
    #return round(base * x/base,2)
    return base * int(x/base) - base
    # return math.ceil(round(base * x/base,1) - 5)
    #return base * int(math.floor(x/base))
    #return base * int(math.ceil(x/base))
    # return int(int(x * base) / base)


def find_str(s, char):
    index = 0
    if len(char)>0 and char in s:
        c = char[0]
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index
            index += 1
    return -1

def get_numbers(s):
    try:
        result=""
        idx=0
        for l in s.strip():
            if l.isnumeric() or l=='.' or (idx<1 and l=='-'):
                result=result+l
            else:
                break
            idx+=1
        if result=="" or result=="-" or result==".":
            result="1"
        return float(result)
    except:
        log('CarSpecs app: error ' + traceback.format_exc() )

##########################################################################
def thick_line(canvas, xy, direction, fill=None, width=0):
        #xy – Sequence of 2-tuples like [(x, y), (x, y), ...]
        #direction – Sequence of 2-tuples like [(x, y), (x, y), ...]
        if xy[0] != xy[1]:
            self.line(xy, fill = fill, width = width)
        else:
            x1, y1 = xy[0]
            dx1, dy1 = direction[0]
            dx2, dy2 = direction[1]
            if dy2 - dy1 < 0:
                x1 -= 1
            if dx2 - dx1 < 0:
                y1 -= 1
            if dy2 - dy1 != 0:
                if dx2 - dx1 != 0:
                    k = - (dx2 - dx1)/(dy2 - dy1)
                    a = 1/math.sqrt(1 + k**2)
                    b = (width*a - 1) /2
                else:
                    k = 0
                    b = (width - 1)/2
                x3 = x1 - math.floor(b)
                y3 = y1 - int(k*b)
                x4 = x1 + math.ceil(b)
                y4 = y1 + int(k*b)
            else:
                x3 = x1
                y3 = y1 - math.floor((width - 1)/2)
                x4 = x1
                y4 = y1 + math.ceil((width - 1)/2)
            canvas.line([(x3, y3), (x4, y4)], fill = fill, width = 1)
        return

def dashed_line(canvas, xy, dash=(2,2), fill=None, width=0):
    #xy – Sequence of 2-tuples like [(x, y), (x, y), ...]
    for i in range(len(xy) - 1):
        x1, y1 = xy[i]
        x2, y2 = xy[i + 1]
        x_length = x2 - x1
        y_length = y2 - y1
        length = math.sqrt(x_length**2 + y_length**2)
        dash_enabled = True
        postion = 0
        while postion <= length:
            for dash_step in dash:
                if postion > length:
                    break
                if dash_enabled:
                    start = postion/length
                    end = min((postion + dash_step - 1) / length, 1)
                    thick_line(canvas, [(round(x1 + start*x_length),
                                         round(y1 + start*y_length)),
                                        (round(x1 + end*x_length),
                                         round(y1 + end*y_length))],
                                    xy, fill, width)
                dash_enabled = not dash_enabled
                postion += dash_step
    return


#if False:
if __name__ == '__main__':
    #CARDIR='p:/Steam/steamapps/common/assettocorsa/content/cars/ks_porsche_911_gt3_r_2016'
    #CARDIR='p:/Steam/steamapps/common/assettocorsa/content/cars/ac_legends_bmw_csl'
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/some1_acura_nsx_zanardi_1999"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/gmp_abflug_s900"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/dhs_nissan_skyline_2000gtr_Turbo"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/bmw_e46_m3_csl"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/ag_subaru_impreza_wrx_tuned"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/rt_bacmono"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/bmw_z4_gt3"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/delage_15s8"
    #CARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/darche"
    #CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/devel_sixteen'
    #CARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/ks_toyota_ae86_tuned'
    #CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ddm_toyota_mr2_sw20_shuto'
    #CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/bo_singer_awd'
    #CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ks_porsche_cayenne'
    #CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/TeamEffort_LS400'
    #CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/shelby_cobra_427sc'

    CARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/tmm_clio_cup_x98'
    carname = 'tmm_clio_cup_x98'

    CARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/ks_toyota_supra_mkiv'
    carname = 'ks_toyota_supra_mkiv'

    CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ier_p13c'
    carname = 'ier_p13c'

    CARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/trw_mazda_rx7_feed'
    carname = 'trw_mazda_rx7_feed'

    ACD_FILE = ACD(CARDIR)

    config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","/","#","\\","\t"), comment_prefixes=(";","/","#","\\","\t"), strict=False, allow_no_value=True)

    # config.read_string(ACD_FILE.get_file("tyres.ini"))
    config.read_string("[ACHEADER]\n" + ACD_FILE.get_file("tyres.ini") )
    compName = get_tire_name("", config, 0)
    print(compName + " - " + str(ACD_FILE.get_ideal_pressure(compName,0)))
    print(compName + " - " + str(ACD_FILE.get_ideal_pressure(compName,2)))
    temp_curve1 = ACD_FILE.get_temp_curve(compName, 0)
    temp_curve2 = ACD_FILE.get_temp_curve(compName, 2)
    wear_curve1 = ACD_FILE.get_wear_curve(compName, 0)
    wear_curve2 = ACD_FILE.get_wear_curve(compName, 2)
    print(str(temp_curve1))
    print(str(temp_curve2))
    print(str(wear_curve1))
    print(str(wear_curve1))

    temp_curveF      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_FRONT", "PERFORMANCE_CURVE", "SHORT_NAME", compName)
    temp_curveR      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_REAR" , "PERFORMANCE_CURVE", "SHORT_NAME", compName)


    radiiTyreF  = ACD_FILE.getTyreRadiusFront(compName) # *1000.0
    radiiTyreR  = ACD_FILE.getTyreRadiusRear (compName) # *1000.0
    tyreWidthF  = ACD_FILE.getTyreWidthFront (compName) # *1000.0
    tyreWidthR  = ACD_FILE.getTyreWidthRear  (compName) # *1000.0
    radiiRimF   = ACD_FILE.getRimRadiusFront (compName) # *1000.0 - 2.54
    radiiRimR   = ACD_FILE.getRimRadiusRear  (compName) # *1000.0 - 2.54
    # i.e. RIM_RADIUS=0.255  ; rim radius in meters (use 1 inch more than nominal)
    # so we substract 1 inch from value we got, 1 inch = 2.54cm
    # radiiRimF   = radiiRimF # + 0.0254/3
    # radiiRimR   = radiiRimR # + 0.0254/3

    sTyres = ""
    sTyresR = ""
    if tyreWidthF>=0.001 and tyreWidthR>=0.001:
      ratioF = (radiiTyreF - radiiRimF) / tyreWidthF * 100
      ratioR = (radiiTyreR - radiiRimR) / tyreWidthR * 100
      # ratioF = ((radiiRimF*2)/2.45 - 2.45) * 10
      # ratioR = ((radiiRimR*2)/2.45 - 2.45) * 10
      sTyres  = str(int(tyreWidthF*1000)) + " / " + str(round5(ratioF)) + " R" + str(int(radiiRimF*1000*0.2/2.45-1.45)) + "''"
      sTyresR = str(int(tyreWidthR*1000)) + " / " + str(round5(ratioR)) + " R" + str(int(radiiRimR*1000*0.2/2.45-1.45)) + "''"
    if sTyres!=sTyresR:
      sTyres = "Front: " + sTyres + "\n Rear: " + sTyresR
    else:
      sTyres = "Front+Rear: " + sTyres
    print(sTyres)
    # bac : 205 / 20 R17''
    # bac : 245 / 25 R17''

    #print('turbo ' + str(ACD_FILE.get_turbo()))

    # dlc_ui_car.json ui_car.json
    CAR_JSON_PATH =  CARDIR+'/ui/ui_car.json'

    powcurTORTOR=[]
    powcurTORRPM=[]
    powcurPOWPOW=[]
    powcurPOWRPM=[]
    maxPowerJson = 0.0
    maxTorqueJson = 0.0
    maxPowerRpmJson = 0
    maxTorqueRpmJson = 0
    powmaxrpmpow=0
    powmaxpowrpm=0
    rpmMAX=0










    import re, json, io
    if not os.path.isfile(CAR_JSON_PATH):
      print('path not found: ' + CAR_JSON_PATH)
    else:
      with io.open(CAR_JSON_PATH,encoding="utf8") as uiFile:
        uiDataString = uiFile.read().encode('ascii', 'ignore').decode('ascii').strip()
      uiDataString = uiDataString.replace('</br>', '').replace('\n\r\n\r', '').replace('\r\n\r\n', '').replace('\r', '').replace('\t', '').replace('\n', '').replace('\r', '')
      uiDataJson = json.loads( uiDataString )

      for step in uiDataJson["torqueCurve"]:
        #ac.log(str(step))
        if int(float(step[1])) >= maxTorqueJson:
          maxTorqueJson       = float(step[1])
          maxTorqueRpmJson    = float(step[0])
        powcurTORTOR.append(   float(step[1]))
        powcurTORRPM.append(float(step[0]))
      for step in uiDataJson["powerCurve"]:
        #ac.log(str(step))
        if int(float(step[1])) >= maxPowerJson:
          maxPowerJson    = float(step[1])
          maxPowerRpmJson = float(step[0])
        powcurPOWRPM.append(float(step[0]))
        powcurPOWPOW.append(float(step[1]))

    #powcurTORTOR=[]
    #powcurTORRPM=[]
    if len(powcurTORTOR)!=0:
      print( 'using data from ui.json' )
    else:
      powcur   = re.sub(r'^\s*$', '',  str(ACD_FILE.get_power_curve()).strip() )
      ersCurve = re.sub(r'^\s*$', '',  str(ACD_FILE.get_ers_curve()).strip() )
      #ac.log( 'using data from power.lut' )
      print( 'using data from power.lut' )
      for line in powcur.strip('').split('\n'):
        if find_str(line.strip(),';')!=0 and '|' in line:
          line = line.replace("\r","").replace("\n","")
          a=line.replace("'","").split('|')
          if ',' in a[0]:
            a = a[0].split(',')
          if len(a)>1:
            readRPMS=float(get_numbers(a[0]))
            if ',' in a[1]:
              a[1] = a[1].split(',')[0]
            readTORQUE=float(get_numbers(a[1]))
            if ';' in a[1]:
              readTORQUE = float(get_numbers(a[1].split(';')[0]))
            powcurTORRPM.append(readRPMS)
            powcurTORTOR.append(readTORQUE)
            if int(powmaxrpmpow)<readTORQUE:
              powmaxrpm=readRPMS # max rpm
              powmaxrpmpow=readTORQUE
            if int(powmaxpowrpm)<readRPMS:
              powmaxpowrpm=readRPMS
            rpmMAX = max(powmaxrpmpow, rpmMAX)

    global maxPowerSAVED, maxRpmSAVED
    maxPowerSAVED=max(powcurTORTOR) ###, max(powcurPOWPOW))

    if len(powcurPOWPOW)==0:
      print('no curve found')
    else:
      # add some rpm values for strange curves
      # powcurPOWPOW.append(powcurPOWPOW[len(powcurPOWPOW)-1]/3*2)
      # powcurPOWRPM.append(powcurPOWRPM[len(powcurPOWRPM)-1]+500)
      # powcurPOWPOW.append(powcurPOWPOW[len(powcurPOWPOW)-1]/3)
      # powcurPOWRPM.append(powcurPOWRPM[len(powcurPOWRPM)-1]+1000)
      # powcurPOWPOW.append(powcurPOWPOW[len(powcurPOWPOW)-1]/3)
      # powcurPOWRPM.append(powcurPOWRPM[len(powcurPOWRPM)-1]+1000)

      # powcurTORTOR.append(powcurTORTOR[len(powcurTORTOR)-1]/3*2)
      # powcurTORRPM.append(powcurTORRPM[len(powcurTORRPM)-1]+500)
      # powcurTORTOR.append(powcurTORTOR[len(powcurTORTOR)-1]/3)
      # powcurTORRPM.append(powcurTORRPM[len(powcurTORRPM)-1]+1000)
      # powcurTORTOR.append(powcurTORTOR[len(powcurTORTOR)-1]/3)
      # powcurTORRPM.append(powcurTORRPM[len(powcurTORRPM)-1]+1000)


      from PIL import Image, ImageDraw, ImageOps, ImageFont, ImageEnhance

      maxTurboBoost  = ACD_FILE.get_wastegate_display()
      rpmLimiter     = ACD_FILE.get_rpm_limiter()
      rpmMAX = max(maxPowerRpmJson, maxTorqueRpmJson, rpmLimiter)


      ### draw Power/Torque curve
      # 350x210
      linewidth=3
      w=350 #*4 ### *4
      h=200 #*4 ### *4
      img = Image.new("RGBA", (w,h),(255,255,255,0) )
      h2=h-linewidth


      canvas = ImageDraw.Draw(img)
      maxRpmSAVED=max(maxTorqueRpmJson,maxPowerRpmJson)
      # maxPowerSAVED=max(powmaxrpmpow, maxTorqueJson, maxPowerJson)
      #maxPowerSAVED=maxTorqueJson
      maxPowerSAVED=max(max(powcurTORTOR), max(powcurPOWPOW))
      #maxPowerSAVED=max(max(powcurTORTOR), max(powcurPOWPOW))
      #maxPowerSAVED=maxTorqueJson
      if maxTurboBoost>0.0:
      #  maxPowerSAVED=max(maxTorqueJson,maxPowerJson)    *(1+maxTurboBoost)
        maxPowerSAVED=max(powcurTORTOR) *(1+maxTurboBoost)

      print('maxPowerSAVED : ' + str(maxPowerSAVED) + '\nmaxRpmSAVED   : ' +str(maxRpmSAVED))
      print('maxTorqueJson : ' + str(maxTorqueJson) + '\nmaxPowerJson  : ' +str(maxPowerJson))
      print('maxTurboBoost : ' + str(maxTurboBoost))
      print('limiter       : ' + str(rpmLimiter))
      print('rpmMAX        : ' + str(rpmMAX))
      print(str(powcurTORTOR))



      xl=  powcurPOWRPM[0]/rpmMAX       *w
      yl=h-powcurPOWPOW[0]/maxPowerSAVED*h2
      for i in range(1,len(powcurPOWPOW)):
        x=  powcurPOWRPM[i]/rpmMAX       *w
        y=h-powcurPOWPOW[i]/maxPowerSAVED*h2
        if maxTurboBoost>0.0:
          # dashed_line(canvas,(xl,yl, x,y),dash=(5,5),fill=(248,6,6), width=2)
          #canvas.line((xl,yl, x,y),fill=(248,6,6,128), width=linewidth)
          #canvas.line((xl,yl, xl+(xl-x)/2,yl+(yl-y)/2),fill='red', width=1)
          canvas.ellipse((x-1,y-1, x+1,y+1),outline='red', width=1)
          #canvas.point((x,y),fill='red')
        else:
          canvas.line((xl,yl, x,y),fill=('red'), width=linewidth)
        xl=x
        yl=y
      xl=powcurTORRPM[0]/rpmMAX         *w
      yl=h-powcurTORTOR[0]/maxPowerSAVED*h2
      for i in range(1,len(powcurTORTOR)):
        x=  powcurTORRPM[i]/rpmMAX       *w
        y=h-powcurTORTOR[i]/maxPowerSAVED*h2
        if maxTurboBoost>0.0:
          #dashed_line(canvas,(xl,yl, x,y),dash=(5,5),fill=(248,248,6), width=2)
          #canvas.line((xl,yl, x,y),fill=(248,248,6,128), width=linewidth)
          #canvas.line((xl,yl, xl+(xl-x)/2,yl+(yl-y)/2),fill='yellow', width=1)
          canvas.ellipse((x-1,y-1, x+1,y+1),outline='yellow', width=1)
          #canvas.point((x,y),fill='yellow')
        else:
          canvas.line((xl,yl, x,y),fill=('yellow'), width=linewidth)
        xl=x
        yl=y

      if maxTurboBoost>0.0:
        xl=  (                   powcurPOWRPM[0]/rpmMAX       )*w
        yl=h-((1+maxTurboBoost)* powcurPOWPOW[0]/maxPowerSAVED)*h2
        for i in range(1,len(powcurPOWPOW)):
          x=  (                   powcurPOWRPM[i]/rpmMAX       )*w
          y=h-((1+maxTurboBoost)* powcurPOWPOW[i]/maxPowerSAVED)*h2
          canvas.line((xl,yl, x,y),fill=('red'), width=linewidth)
          xl=x
          yl=y
        xl=  (                   powcurTORRPM[0]/rpmMAX       )*w
        yl=h-((1+maxTurboBoost)* powcurTORTOR[0]/maxPowerSAVED)*h2
        for i in range(1,len(powcurTORTOR)):
          x=  (                   powcurTORRPM[i]/rpmMAX       )*w
          y=h-((1+maxTurboBoost)* powcurTORTOR[i]/maxPowerSAVED)*h2
          canvas.line((xl,yl, x,y),fill=('yellow'), width=linewidth)
          xl=x
          yl=y


      path_v = os.path.dirname(__file__).replace('\\','/').lower().replace('carspecs.py','')
      if len(path_v)==0:
        log('some error')
      else:
        if not os.path.isdir(path_v + '/curves'):
          os.mkdir(path_v + '/curves')
        img.save(path_v + '/curves/' + carname +'.png')

      config.read_string("[ACHEADER]\n" + ACD_FILE.get_file("tyres.ini") )
      compName = get_tire_name("", config, 0)
      tempFtemp=[]
      tempRtemp=[]
      tempFgrip=[]
      tempRgrip=[]
      temp_curveF      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_FRONT", "PERFORMANCE_CURVE"   , "SHORT_NAME", compName)
      wear_curveF      = ACD_FILE.get_file_section_value_as_curve(config, "FRONT"        , "WEAR_CURVE"          , "SHORT_NAME", compName)
      temp_curveR      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_REAR" , "PERFORMANCE_CURVE"   , "SHORT_NAME", compName)
      wear_curveR      = ACD_FILE.get_file_section_value_as_curve(config, "REAR"         , "WEAR_CURVE"          , "SHORT_NAME", compName)
      if len(temp_curveF)>0 and len(temp_curveR)>0:
          for s in temp_curveF.split('\n'):
              t=s.split('|')
              if len(t)>1:
                  tempFtemp.append(get_float(t[0]))
                  tempFgrip.append(get_float(t[1]))
          for s in temp_curveR.split('\n'):
              t=s.split('|')
              if len(t)>1:
                  tempRtemp.append(get_float(t[0]))
                  tempRgrip.append(get_float(t[1]))

      print(str(100* get_val_from_lut(40.0*0.25 + 40*0.75, tempFtemp, tempFgrip)))
      print(str(100* get_val_from_lut(45.0*0.25 + 45*0.75, tempFtemp, tempFgrip)))
      print(str(100* get_val_from_lut(60.0*0.25 + 60*0.75, tempRtemp, tempRgrip)))
      print(str(100* get_val_from_lut(65.0*0.25 + 65*0.75, tempRtemp, tempRgrip)))