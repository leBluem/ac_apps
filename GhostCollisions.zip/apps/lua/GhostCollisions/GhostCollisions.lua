local description = [[
-only on tracks with ExtendedPhysics
-should work in race/trackday/weekend modes
-invalidates laptime for any ghosted car, not the player laptime (you can turn that ON)
-Ghosting cars (disable collider) based on:
--speed<10
--wheelsout>2
--car direction more than +-90° against ai line direction
--2 seconds grace time
--before enabling collider again, it will check for 4 nearest cars if too close, then resets grace timer
--cars with more than 100% damage on any of the 5 damage parts will be sent back to pits
-otherwise there is still AC logic in place for sending them to pits
]]

local ConfigFile = ac.INIConfig.load(ac.getFolder(ac.FolderID.ACApps) .. "/lua/GhostCollisions/" .. "settings.ini", ac.INIFormat.Default)

local alsoGhostPlayerCar = ConfigFile:get("SETTINGS", "alsoGhostPlayerCar", 0) == 1
local bON                = ConfigFile:get("SETTINGS", "ON", 1) == 1
local col = string.split(  ConfigFile:get("SETTINGS", "GhostColor", "") , ",")

local function settitle()
    if physics.allowed() and bON then
        ac.setWindowTitle('main', "Ghost Collisions v1.1" .. " - Ghosting ON.")
    else
        ac.setWindowTitle('main', "Ghost Collisions v1.1" .. " - Ghosting OFF!")
    end
end
settitle()

-- default if not set from ini
local GhostColor         = rgbm( 0.25,0,1, 0.5 )
if col and #col==3 then
    -- from ini
    GhostColor         = rgbm( tonumber(col[1]), tonumber(col[2]), tonumber(col[3]), 0.5 )
end

local sim = ac.getSim()
local SessionSwitched = true
local previousSessionStartTimer = sim.sessionTimeLeft-0.002

local TableDir = {}
local TableCars = {}
local TableSimpleCollider = {}
local TableDT = {}

local upd2 = 0.2
local vUp = vec3(0, 1, 0)
local bPaused = false


local function SetCarVisible(carl, vis)
    if carl.index>0 then
        ac.findNodes('carRoot:'..carl.index):findMeshes("?"):setVisible(vis)
        ac.setDriverVisible(carl.index, vis)
    end
end


local function CreateBorders()
    table.clear(TableDir)
    local cSpline2 = 1.0 - 1/sim.trackLengthM
    local p2 = ac.trackProgressToWorldCoordinate(cSpline2)
    cSpline2 = 0.0
    local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    while cSpline2 < 1.0 do
        -- local roll = -math.deg( math.atan2(p1.x-p2.x, p1.z-p2.z) )
        local dir = math.atan2(p1.z-p2.z, p1.x-p2.x)
        table.insert(TableDir, 90-(-math.deg(dir)-90) )   -- -- minus fest -- --
        p1:copyTo(p2)
        cSpline2 = cSpline2 + 1/sim.trackLengthM
        p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    end -- while
end

function IsAngledRight(carl)
    local id = math.floor(carl.splinePosition*#TableDir)
    if id>0 and id<=#TableDir then
        -- if carl.index==0 then
        --     local aidir  = 90 + math.deg( -TableDir[id] )
        --     local cardir = 180 + math.deg(math.atan2(carl.look.z, carl.look.x) )
        --     local diff   = math.abs(aidir-cardir)
        --     ac.debug("direction ailine", aidir )
        --     ac.debug("direction car"   , cardir)
        --     ac.debug("direction diff"  , diff)
        --     ac.debug("comp"   , cardir > aidir-90 and cardir < aidir+90) -- /360)
        -- end
        local diff = math.abs(
            TableDir[id] -
            (180 + math.deg(math.atan2(carl.look.z, carl.look.x) ))
        )
        return diff<90 or diff>270
    else
        return true
    end
end

function CheckForStalledAI()
    for i=0, sim.carsCount-1 do
        local carl = ac.getCar(i)
        if carl and
           not carl.isInPit and
           not carl.isInPitlane and
           not table.contains(TableCars, carl)
        then
            if  (not carl.isRemote and (carl.isAIControlled and (alsoGhostPlayerCar or carl.index>0))
                or alsoGhostPlayerCar or carl.index>0 )
                and
                carl.lapTimeMs>2000 and
                (carl.speedKmh      < 10 or  -- speed
                 carl.wheelsOutside > 2  or  -- wheelsoutside
                 not IsAngledRight(carl))   -- facing wrong > than 90 degrees
            then
                ac.debug('collision disabled' , 'car '..carl.index)
                upd2=0.2 -- reset timer for more visual feedback
                -- render.on('main.root.transparent'
                local carmesh = {
                    mesh = ac.SimpleMesh.carShape(carl.index, false),
                    transform = carl.bodyTransform,
                    textures = {},
                    values = {col=GhostColor},
                    shader = [[
                    float4 main(PS_IN pin) {
                    float g = dot(normalize(pin.NormalW), normalize(pin.PosC));
                    return float4 ( gWhiteRefPoint*0.5 *
                                    float3(
                                        col.r,
                                        col.g,
                                        col.b),
                                    pow(1-abs(g), 2));
                    }]]
                    -- return float4 ( float3( saturate(-g), saturate(g), 1) * gWhiteRefPoint*0.5, pow(1 - abs(g), 2));
                    -- return float4(pin.Tex.x, pin.Tex.y, 0, 1);
                    -- return float4(float3(0.5,0,1), 0.5);
                }
                table.insert(TableSimpleCollider, carmesh) -- draw3d
                table.insert(TableCars, carl) -- car ref
                table.insert(TableDT, 0.0) -- grace timer
                if alsoGhostPlayerCar or carl.index>0 then
                    physics.disableCarCollisions(i, true)
                end
                if carl.index>0 then
                    SetCarVisible(carl, false)
                end
            end
        end
    end
end


local function resetGhostedCars()
    if bON and physics.allowed() then
        for i=0, sim.carsCount-1 do
            SetCarVisible(ac.getCar(i), true)
            if i>0 or alsoGhostPlayerCar then
                physics.disableCarCollisions(i, false)
            end
        end
    end
end


function script.Draw3D(dt)
    if physics.allowed() then
        for i = 1, #TableSimpleCollider do
            -- render.debugArrow(TableCars[i].position+vUp*3.5, TableCars[i].position+vUp*1.5, 0.25, rgbm.colors.red*10)
            -- SetCarVisible(TableCars[i], false)
            if TableCars[i].index>0 then
                render.mesh(TableSimpleCollider[i])
            end
        end
    end
end


local replaydone=true
local gray = rgbm(0.2,0.2,0.2,0.25)
local x = sim.windowWidth/2
local y = sim.windowHeight/2
local wd = sim.windowHeight/10

function UICallback()
    if #TableCars>0 then
        for i = 1, #TableCars do
            if TableCars[i].index==0 and sim.focusedCar==0 then
                -- draw message on screen when player car is ghosted
                ui.drawRectFilled(                      vec2(x-wd*2, y-wd/6*2), vec2(x+wd/2, y+wd/6/2), gray, 8, ui.CornerFlags.All)
                ui.dwriteDrawTextClipped("ghosted", 18, vec2(x-wd*2, y-wd+wd/4)  , vec2(x+wd/2, y+wd/2)  , ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))
                break
            end
        end
    end
end


function script.update(dt)
    if not bPaused and previousSessionStartTimer < sim.sessionTimeLeft and (not sim.isReplayActive) then
        -- clear ghosted cars, but before reset them back
        SessionSwitched = true
        if bON and physics.allowed() then
            resetGhostedCars()
            TableSimpleCollider = {}
            TableCars = {}
            TableDT = {}
        end
    elseif SessionSwitched then
        SessionSwitched = false
    end
    previousSessionStartTimer = sim.sessionTimeLeft-0.002

    if bON and sim.isReplayActive and not replaydone and not bPaused then
        -- unhide cars in replay
        replaydone=true
        for i=1, #TableCars do
            SetCarVisible(TableCars[i], true)
        end
    end

    if  bON and
        not bPaused and
        physics.allowed() and not sim.isReplayActive
    then
        if replaydone then replaydone=false end
        upd2 = upd2 - dt
        if upd2<0.0 and #TableDir>0 then
            upd2 = 0.2
            -- main check for AI cars every 0.2 secs
            CheckForStalledAI()
        end
    end

    if  bON and
        not bPaused and
        not sim.isReplayActive and
        #TableCars>0 and #TableDir>0 and
        (sim.raceSessionType==ac.SessionType.Practice or
         sim.raceSessionType==ac.SessionType.Race or
         sim.raceSessionType==ac.SessionType.Qualify)
         and sim.carsCount>1
    then
        -- check ghosted cars to be re-enabled
        for i = 1, #TableCars do
            if  TableCars[i].isInPit or
                TableCars[i].isInPitlane or
              ((TableCars[i].wheelsOutside<2 and
                TableCars[i].speedKmh>20) and
                IsAngledRight(TableCars[i]))
            then
                if TableCars[i].isInPit or TableCars[i].isInPitlane then
                    TableDT[i]=3.0
                else
                    TableDT[i]=TableDT[i]+dt
                end
                if TableDT[i]>2.0 then
                    -- check if we really should enable this car
                    -- ac.iterateCars.ordered() - ordered by distance
                    if not TableCars[i].isInPit or TableCars[i].isInPitlane then
                    for j, carNear in ac.iterateCars.ordered() do
                        if  carNear.index ~= TableCars[i].index and
                            carNear.position:distance(TableCars[i].position())<2.0  -- less than 2 meters?
                        then
                            -- reset ghost timer for car
                            TableDT[i]=0.0
                            break
                        end
                        -- stop after 4 cars, not sure how much that should be
                        if j>4 then break end
                    end end

                    -- still above 2 secs?
                    if TableDT[i]>2.0 then
                        -- car no longer ghosted
                        ac.debug('collision re-enabled' , 'car '..TableCars[i].index)
                        if TableCars[i].index>0 then
                            SetCarVisible(TableCars[i], true)
                            if alsoGhostPlayerCar then
                                physics.disableCarCollisions(TableCars[i].index, false)
                            end
                        else
                            physics.disableCarCollisions(TableCars[i].index, false)
                        end
                        table.remove(TableDT, i)
                        table.remove(TableCars, i)
                        table.remove(TableSimpleCollider, i)
                        break  -- must do because tables changed
                    end
                end
            else
                -- reset ghost timer for car
                if (TableCars[i].damage[0]>100.0 or
                    TableCars[i].damage[1]>100.0 or
                    TableCars[i].damage[2]>100.0 or
                    TableCars[i].damage[3]>100.0 or
                    TableCars[i].damage[4]>100.0)
                    and
                    TableCars[i].index>0
                then
                    physics.teleportCarTo(TableCars[i].index, ac.SpawnSet.Pits)
                else
                    TableDT[i]=0.0
                end
            end
        end
    end
end


local surfacesFile = ac.getFolder(ac.FolderID.CurrentTrackLayout) .. "/data/surfaces.ini"
local surfacesBackupFile = ac.getFolder(ac.FolderID.CurrentTrackLayout) .. "/data/surfaces_original_GHOSTCOLL.bak"
local surfacesData = ac.INIConfig.load(surfacesFile, ac.INIFormat.Default)
local changed = false
local backupexists = io.fileExists(surfacesBackupFile)
local msg = ""

local function RestoreOriginal()
    local copied = io.copyFile(surfacesBackupFile, surfacesFile, false)
    if copied then
        io.deleteFile(surfacesBackupFile)
        changed = true
        msg="Backup File Restored!"
    end
end

local function EnableThePhysics()
    --ac.log("Track does not have physics access, creating backup")
    if io.fileExists(surfacesBackupFile) then
        surfacesBackupFile = surfacesBackupFile..'.bak'
        while io.fileExists(surfacesBackupFile) do
            surfacesBackupFile = surfacesBackupFile..'.bak'
        end
    end
    local copied = io.copyFile(surfacesFile, surfacesBackupFile, false)
    if copied then
        surfacesData:setAndSave("SURFACE_0", "WAV_PITCH", "extended-0")
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_APPS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_TOOLS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_TRACK_SCRIPTS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_DISPLAY_SCRIPTS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_NEW_MODE_SCRIPTS", 1)
        changed = true
        msg = "'surfaces.ini': created backup, inserted Extended Physics!"
    else
        msg = "'surfaces.ini': could not make backup of\n"..surfacesFile
    end
end


function script.windowSettings(dt)
    if physics.allowed() then
        -- ui.text("physics.allowed(): " .. tostring(physics.allowed()))
        ui.sameLine(0,0)
        ui.text("Ghost cars available.")
        -- ui.sameLine(0,10)
        if not changed then
            if ui.checkbox("ON                   color:", bON) then
                bON = not bON
                if not bON then
                    resetGhostedCars()
                end
                settitle()
                ConfigFile = ac.INIConfig.load(ac.getFolder(ac.FolderID.ACApps) .. "/lua/GhostCollisions/" .. "settings.ini", ac.INIFormat.Default)
                ConfigFile:setAndSave("SETTINGS", "ON", bON)
            end
            ui.sameLine(ui.availableSpaceX()-50)
            -- local srgb = GhostColor
            -- local colchange = ui.colorButton('Ghost-Color', srgb, ui.ColorPickerFlags.PickerHueBar)
            -- if colchange then
            if ui.colorButton('Ghost-Color', GhostColor, ui.ColorPickerFlags.PickerHueBar) then
                --ac.debug("came ghost", GhostColor)
                ConfigFile = ac.INIConfig.load(ac.getFolder(ac.FolderID.ACApps) .. "/lua/GhostCollisions/" .. "settings.ini", ac.INIFormat.Default)
                ConfigFile:setAndSave("SETTINGS", "GhostColor", (tostring(GhostColor.r)..","..tostring(GhostColor.g)..","..tostring(GhostColor.b)))
            end

            if ui.checkbox("Ghost myself", alsoGhostPlayerCar) then
                alsoGhostPlayerCar = not alsoGhostPlayerCar
                if not alsoGhostPlayerCar then
                    resetGhostedCars()
                end
                ConfigFile = ac.INIConfig.load(ac.getFolder(ac.FolderID.ACApps) .. "/lua/GhostCollisions/" .. "settings.ini", ac.INIFormat.Default)
                ConfigFile:setAndSave("SETTINGS", "alsoGhostPlayerCar", alsoGhostPlayerCar)
            end
            if backupexists then
                --ui.setCursorY(60*ac.getUI().uiScale)
                if ui.button("Click to restore original 'surfaces.ini'\nfor this track (needs restart)") then
                    RestoreOriginal()
                end
            end
        else
            ui.text(msg)
            if ui.button("Click to restart AC") then
                ac.restartAssettoCorsa()
            end
        end
    end

end

function script.windowMain()

    if physics.allowed() and bON then
        ui.text("Ghosted cars: ".. #TableCars)
        if #TableCars>0 then
            ui.sameLine(0,10)
            if ui.button("goto last") then
                ac.focusCar(TableCars[#TableCars].index)
            end
            ui.sameLine(0,10)
            if ui.button("reset") then
                resetGhostedCars()
            end
        end
    else
        ui.sameLine(0)
        if physics.allowed() then
            ui.text("Ghosting available, but off.")
        else
            ui.sameLine(0)
            ui.text("Ghosting NOT possible!")
            if not changed then
                if ui.button("Click to enable Extended Physics \nfor this track (needs restart)") then
                    EnableThePhysics()
                end
            else
                ui.text(msg)
                if ui.button("Click to restart AC") then
                    ac.restartAssettoCorsa()
                end
            end
        end
    end
end

ui.onExclusiveHUD(function (mode)
    --     --if mode == 'game' then
    --     -- @param callback fun(mode: 'menu'|'pause'|'results'|'replay'|'game'): 'debug'|boolean? @Callback function.
    if mode == 'pause' then
        bPaused = true
    else
        bPaused = false
    end
end
)

if ac.hasTrackSpline() then
CreateBorders() end
