-- variables not availabe in UI
local gracetime         = 2.0   -- 3 secs might be better
local minspeedGhost     = 10.0  -- 20?
local minspeedRejoin    = 20.0  -- or more?
local maxwheelsoutValid = 2     --
local mindistance       = 2.0   -- 2m might be too close?
local carstocheck       = 4     -- or 6?


-- 0.1.79  2144  has ui.onExclusiveHUD()
-- 0.2.0  2651  has ui.onExclusiveHUD()
-- 0.2.3  3044  has this as shader param: gWhiteRefPoint


local description = [[
-only on tracks with ExtendedPhysics
-should work in race/trackday/weekend modes
-invalidates laptime for any ghosted car, not the player laptime (you can turn that ON)
-Ghosting cars (disable collider) based on:
--speed<10
--wheelsout>2
--car direction more than +-90° against ai line direction
--2 seconds grace time
--before enabling collider again, it will check for 4 nearest cars if too close, then resets grace timer
--cars with more than 100% damage on any of the 5 damage parts will be sent back to pits
-otherwise there is still AC logic in place for sending them to pits
v1.1
-fixed for qualify/race if started w practice
v1.2 - 13 mar 2025
-fixed not resetting on Session restart
-added option to not do anything visual when ghosting ("use color" off)
-added option to also use transparent color for player car
-added arrow marker and timer display
-added alpha as option
v1.3 - 13 may 2025
-more immediate change on own car for testing
-minimum CSP version: 0.2.0 (before: 0.2.3)
]]


local ConfigFile = ac.INIConfig.load(ac.getFolder(ac.FolderID.ACApps) .. "/lua/GhostCollisions/" .. "settings.ini", ac.INIFormat.Default)
---- variables availabe in UI
local bON                = ConfigFile:get("SETTINGS", "ON", 1) == 1
local bUseColor          = ConfigFile:get("SETTINGS", "UseColor", 1) == 1
local bGhostMyself       = ConfigFile:get("SETTINGS", "GhostMyself", 0) == 1
local bColorMyself       = ConfigFile:get("SETTINGS", "ColorMyself", 0) == 1
local bShowTimer         = ConfigFile:get("SETTINGS", "ShowTimer", 0) == 1
local bShowArrow         = ConfigFile:get("SETTINGS", "ShowArrow", 0) == 1
local GhostAlpha         = tonumber(ConfigFile:get("SETTINGS", "GhostAlpha", 4))

-- overwritten below
local ColorGhost         = rgbm( 0   ,   0,   1, 0.5 )
local ColorTimer         = rgbm( 1   ,   0,   0, 0.5 )
local ColorArrow         = rgbm( 1   ,   1,   1, 1 )

local ghostcol = string.split(  ConfigFile:get("SETTINGS", "GhostColor", "") , ",")
if ghostcol and #ghostcol==3 then
    ColorGhost         = rgbm( tonumber(ghostcol[1]), tonumber(ghostcol[2]), tonumber(ghostcol[3]), 0.5 )
end
local timercol = string.split(  ConfigFile:get("SETTINGS", "TimerColor", "") , ",")
if timercol and #timercol==3 then
    ColorTimer         = rgbm( tonumber(timercol[1]), tonumber(timercol[2]), tonumber(timercol[3]), 0.5 )
end
local arrowcol = string.split(  ConfigFile:get("SETTINGS", "ArrowColor", "") , ",")
if arrowcol and #arrowcol==3 then
    ColorArrow         = rgbm( tonumber(arrowcol[1]), tonumber(arrowcol[2]), tonumber(arrowcol[3]), 0.5 )
end

local function settitle()
    if physics.allowed() and bON then
        ac.setWindowTitle('main', "Ghost Collisions v1.3" .. " - Ghosting ON.")
    else
        ac.setWindowTitle('main', "Ghost Collisions v1.3" .. " - Ghosting OFF!")
    end
end
settitle()


local sim = ac.getSim()
local car = ac.getCar(0)
local SessionSwitched = true
local previousSessionStartTimer = sim.sessionTimeLeft-0.002

local upd2 = 0.2
local vUp = vec3(0, 1, 0)
local bPaused = false

local surfacesFile = ac.getFolder(ac.FolderID.CurrentTrackLayout) .. "/data/surfaces.ini"
local surfacesBackupFile = ac.getFolder(ac.FolderID.CurrentTrackLayout) .. "/data/surfaces_original_GHOSTCOLL.bak"
local surfacesData = ac.INIConfig.load(surfacesFile, ac.INIFormat.Default)
local changed = false
local backupexists = io.fileExists(surfacesBackupFile)
local msg = ""

local TableDir = {}
local TableCars = {}
local TabH = {}
local TableSimpleCollider = {}
local TableDT = {}

local replaydone=true
local gray = rgbm(0.1,0.1,0.1,0.75)
local uix = (sim.windowWidth *1/ac.getUI().uiScale)/2
local uiy = (sim.windowHeight*1/ac.getUI().uiScale)/3*2
local uiw = (sim.windowHeight*1/ac.getUI().uiScale)/10
local exposureCar = 1.0  -- (math.max(0.1, ac.getSim().whiteReferencePoint/10))
local exposureLines = 1.0  -- (math.max(0.1, ac.getSim().whiteReferencePoint/10))
local lastWhiteRef = -1.0



local function RestoreOriginal()
    local copied = io.copyFile(surfacesBackupFile, surfacesFile, false)
    if copied then
        io.deleteFile(surfacesBackupFile)
        changed = true
        msg="Backup File Restored!"
    end
end

local function EnableThePhysics()
    --ac.log("Track does not have physics access, creating backup")
    if io.fileExists(surfacesBackupFile) then
        surfacesBackupFile = surfacesBackupFile..'.bak'
        while io.fileExists(surfacesBackupFile) do
            surfacesBackupFile = surfacesBackupFile..'.bak'
        end
    end
    local copied = io.copyFile(surfacesFile, surfacesBackupFile, false)
    if copied then
        surfacesData:setAndSave("SURFACE_0", "WAV_PITCH", "extended-0")
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_APPS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_TOOLS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_TRACK_SCRIPTS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_DISPLAY_SCRIPTS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_NEW_MODE_SCRIPTS", 1)
        changed = true
        msg = "'surfaces.ini': created backup, inserted Extended Physics!"
    else
        msg = "'surfaces.ini': could not make backup of\n"..surfacesFile
    end
end



local function Ghost_ReadAILine()
    table.clear(TableDir)
    local cSpline2 = 1.0 - 1/sim.trackLengthM
    local p2 = ac.trackProgressToWorldCoordinate(cSpline2)
    cSpline2 = 0.0
    local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    while cSpline2 < 1.0 do
        -- local roll = -math.deg( math.atan2(p1.x-p2.x, p1.z-p2.z) )
        local dir = math.atan2(p1.z-p2.z, p1.x-p2.x)
        table.insert(TableDir, 90-(-math.deg(dir)-90) )   -- -- minus fest -- --
        p1:copyTo(p2)
        cSpline2 = cSpline2 + 1/sim.trackLengthM
        p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    end -- while
end


local function SetCarVisible(carl, vis)
    ac.findNodes('carRoot:'..carl.index):findMeshes("?"):setVisible(vis)
    ac.setDriverVisible(carl.index, vis)
end

--ac.getCar(i)

local function ResetGhostedCars()
    if physics.allowed() then
        for i=0, sim.carsCount-1 do
            SetCarVisible(ac.getCar(i), true)
            if i>0 or bGhostMyself then
                physics.disableCarCollisions(i, false)
            end
        end
        TableSimpleCollider = {}
        TableCars = {}
        TabH = {}
        TableDT = {}
    end
end



local function GetSimpleCarmesh(carl)
    if ac.getPatchVersionCode()>=3044 then
        return {
        mesh = ac.SimpleMesh.carShape(carl.index, false),
        transform = carl.bodyTransform,
        textures = { },
        values = {col=ColorGhost/exposureCar, alpha=GhostAlpha},
        shader = [[
            float4 main(PS_IN pin) {
            float g = dot(normalize(pin.NormalW), normalize(pin.PosC));
            return float4 ( gWhiteRefPoint * 0.5 * float3(col.r,col.g,col.b), pow(abs(1-abs(g)), alpha));
        }]]
        }
    else
        return {
        mesh = ac.SimpleMesh.carShape(carl.index, false),
        transform = carl.bodyTransform,
        textures = { },
        values = {col=ColorGhost/exposureCar, alpha=GhostAlpha},
        shader = [[
            float4 main(PS_IN pin) {
            float g = dot(normalize(pin.NormalW), normalize(pin.PosC));
            return float4 ( 0.5 * float3(col.r,col.g,col.b), pow(abs(1-abs(g)), alpha));
        }]]
        }
    end

    -- return float4 ( float3( saturate(-g), saturate(g), 1) * gWhiteRefPoint*0.5, pow(1 - abs(g), 2));
-- return float4(pin.Tex.x, pin.Tex.y, 0, 1);
-- return float4(float3(0.5,0,1), 0.5);
end



local function resetMyGhostedCar()
    if physics.allowed() then
        for i = 1, #TableSimpleCollider do
            TableSimpleCollider[i] = GetSimpleCarmesh(TableCars[i])
            -- if TableSimpleCollider[i].index==0 then
            --     SetCarVisible(ac.getCar(i), true)
            --     if i>0 or bGhostMyself then
            --         physics.disableCarCollisions(i, false)
            --     end
            --     table.remove(TableSimpleCollider, i)
            --     table.remove(TableCars, i)
            --     table.remove(TabH, i)
            --     table.remove(TableDT, i)
            --     return
            -- end
        end
        -- for i=0, sim.carsCount-1 do
        --     SetCarVisible(ac.getCar(i), true)
        --     if i>0 or bGhostMyself then
        --         physics.disableCarCollisions(i, false)
        --     end
        -- end
    end
end

function IsAngledRight(carl)
    local id = math.floor(carl.splinePosition*#TableDir)
    if id>0 and id<=#TableDir then
        -- if carl.index==0 then
        --     local aidir  = 90 + math.deg( -TableDir[id] )
        --     local cardir = 180 + math.deg(math.atan2(carl.look.z, carl.look.x) )
        --     local diff   = math.abs(aidir-cardir)
        --     ac.debug("direction ailine", aidir )
        --     ac.debug("direction car"   , cardir)
        --     ac.debug("direction diff"  , diff)
        --     ac.debug("comp"   , cardir > aidir-90 and cardir < aidir+90)
        -- end
        local diff = math.abs(
            TableDir[id] -
            (180 + math.deg(math.atan2(carl.look.z, carl.look.x) ))
        )
        return diff<90 or diff>270
    else
        return true
    end
end

function CheckForStalledAI()
    for i=0, sim.carsCount-1 do
        local carl = ac.getCar(i)
        if carl and
           not carl.isInPit and
           not carl.isInPitlane and
           not table.contains(TableCars, carl)
        then
            if  (not carl.isRemote and
                (carl.isAIControlled and (bGhostMyself or carl.index>0))
                or bGhostMyself or bColorMyself or carl.index>0 )
                and
                (carl.speedKmh      < minspeedGhost or  -- speed
                 carl.wheelsOutside > maxwheelsoutValid  or  -- wheelsoutside
                 not IsAngledRight(carl))   -- facing wrong > than 90 degrees
            then
                ac.debug('collision disabled' , 'car '..carl.index)
                upd2=0.2 -- reset timer for more visual feedback

                -- ac.debug("aabbH", aabbH)
                table.insert(TableSimpleCollider, GetSimpleCarmesh(carl)) -- draw3d
                table.insert(TableCars, carl)
                table.insert(TabH, carl.aabbSize.y + 0.25)
                table.insert(TableDT, 0.0) -- grace timer
                if bGhostMyself or carl.index>0 then
                    physics.disableCarCollisions(i, true)
                end
                if (bUseColor and carl.index>0) or
                   (carl.index==0 and
                   (bColorMyself or (bColorMyself and bGhostMyself)) )
                then
                    SetCarVisible(carl, false)
                end
            end
        end
    end
end


local function CheckForToBeEnabled(dt)
    -- check ghosted cars to be re-enabled
    for i = 1, #TableCars do
        if  TableCars[i].isInPit or
            TableCars[i].isInPitlane or
          ((TableCars[i].wheelsOutside<maxwheelsoutValid+1 and
            TableCars[i].speedKmh>minspeedRejoin) and
            IsAngledRight(TableCars[i]))
        then
            if TableCars[i].isInPit or TableCars[i].isInPitlane then
                -- will disable ghosting imediately in pits
                TableDT[i]=gracetime + 1.0
            else
                TableDT[i]=TableDT[i]+dt
            end
            if TableDT[i]>gracetime then
                -- check if we really should enable this car
                -- ac.iterateCars.ordered() - ordered by distance
                if not TableCars[i].isInPit or TableCars[i].isInPitlane then
                for j, carNear in ac.iterateCars.ordered() do
                    -- stop after 6 cars, not sure how much that should be
                    if j>carstocheck then break end

                    -- reset ghost timer for car
                    if  carNear.index ~= TableCars[i].index and
                        carNear.position:distance(TableCars[i].position())<mindistance  -- less than 2 meters?
                    then
                        TableDT[i]=0.0
                        break
                    end
                end end

                -- still above 2 secs?
                if TableDT[i]>gracetime then
                    -- car no longer ghosted
                    ac.debug('collision re-enabled' , 'car '..TableCars[i].index)
                    SetCarVisible(TableCars[i], true)
                    physics.disableCarCollisions(TableCars[i].index, false)
                    table.remove(TableDT, i)
                    table.remove(TableCars, i)
                    table.remove(TableSimpleCollider, i)
                    break  -- must do because tables changed
                end
            end
        else
            if (TableCars[i].damage[0]>100.0 or
                TableCars[i].damage[1]>100.0 or
                TableCars[i].damage[2]>100.0 or
                TableCars[i].damage[3]>100.0 or
                TableCars[i].damage[4]>100.0)
                and
                TableCars[i].index>0
            then
                -- send car to pits
                physics.teleportCarTo(TableCars[i].index, ac.SpawnSet.Pits)
            else
                -- reset ghost timer for car
                TableDT[i]=0.0
            end
        end
    end
end


local dx = 0
local p1 = vUp
local p2 = vUp

function script.Draw3D(dt)
    if physics.allowed() then
        for i = 1, #TableSimpleCollider do
            if (TableCars[i].index>0) then
                -- render ghost
                if bUseColor then
                    render.mesh(TableSimpleCollider[i])
                end
                SetCarVisible(TableCars[i], not bUseColor)
            elseif TableCars[i].index==0 then
                -- so that checkboxes work live
                if bColorMyself then
                    -- render own ghost
                    render.mesh(TableSimpleCollider[i])
                end
                SetCarVisible(TableCars[i], not bColorMyself)
            end

            if bShowTimer then
                dx = (gracetime-math.round(TableDT[i], 1))/2.0
                -- draw colored bar, width based on gracetimer
                p1 = TableCars[i].position +vUp*(TabH[i]-0.06) +TableCars[i].side/2.0
                p2 = TableCars[i].position +vUp*(TabH[i]-0.06) +TableCars[i].side/2.0-TableCars[i].side*dx
                -- render.debugLine(p1, p2, rgbm.colors.red*2)
                render.quad(p1, p2, p2+vUp*0.05, p1+vUp*0.05, ColorTimer*exposureLines/2)

                p1 = TableCars[i].position +vUp*TabH[i] -TableCars[i].side*0.5
                p2 = TableCars[i].position +vUp*TabH[i] +TableCars[i].side*0.5
                render.debugLine(p1, p2, ColorArrow*exposureLines)

                -- render.debugText(TableCars[i].position+vUp*1.7, tostring(dx.."s", rgbm.colors.white, 2)
            end

            if bShowArrow then
                render.debugArrow(
                    TableCars[i].position+vUp*(TabH[i]+0.75),
                    TableCars[i].position+vUp*TabH[i], 0.1,
                    ColorArrow*exposureLines)
            end
        end
    end
end


function UICallback()
    if #TableCars>0 then
        for i = 1, #TableCars do
            if TableCars[i].index==0 and sim.focusedCar==0 then
                -- draw message on screen when player car is ghosted
                -- ui.drawRectFilled(                      vec2(uix-uiw, uiy-uiw/6*8), vec2(uix+uiw, uiy-uiw/6), gray, 8, ui.CornerFlags.All)
                ui.drawRectFilled(                      vec2(uix-uiw, uiy-uiw/6*2), vec2(uix+uiw, uiy+uiw/6/2), gray, 8, ui.CornerFlags.All)
                ui.dwriteDrawTextClipped("ghosted", 18, vec2(uix-uiw, uiy-uiw+uiw/4)  , vec2(uix+uiw, uiy+uiw/2)  , ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))
                break
            end
        end
    end
end


-- main update
function script.update(dt)
    if previousSessionStartTimer < sim.sessionTimeLeft then
        -- clear ghosted cars
        SessionSwitched = true
        ResetGhostedCars()
    elseif SessionSwitched then
        SessionSwitched = false
    end
    previousSessionStartTimer = sim.sessionTimeLeft-0.002

    if bON and sim.isReplayActive and not replaydone and not bPaused then
        -- unhide cars in replay
        replaydone=true
        for i=1, #TableCars do
            SetCarVisible(TableCars[i], true)
        end
    end

    if lastWhiteRef ~= ac.getSim().whiteReferencePoint then
        lastWhiteRef = ac.getSim().whiteReferencePoint
        exposureCar = (math.max(0.1, ac.getSim().whiteReferencePoint/4))
        exposureLines = (math.max(3, ac.getSim().whiteReferencePoint))
        resetMyGhostedCar()
    end

    if  bON and
        not bPaused and
        physics.allowed() and
        -- sim.carsCount > 1 and
        -- car.distanceDrivenSessionKm > 0.1 and
        car.lapTimeMs > 5000 and
        not sim.isReplayActive and
        (sim.raceSessionType==ac.SessionType.Practice or
         sim.raceSessionType==ac.SessionType.Hotlap or
         sim.raceSessionType==ac.SessionType.Race or
         sim.raceSessionType==ac.SessionType.Qualify)
    then
        if replaydone then replaydone=false end
        if  #TableCars>0 and #TableDir>0 then
            CheckForToBeEnabled(dt)
        end
        upd2 = upd2 - dt
        if upd2<0.0 and #TableDir>0 then
            upd2 = 0.2
            -- main check for AI cars every 0.2 secs
            CheckForStalledAI()
        end
    end

end


-- settings
function script.windowSettings(dt)
    ui.beginOutline()
    if physics.allowed() then
        --ui.text("physics.allowed(): " .. tostring(physics.allowed()))
        --ui.text("distanceDrivenSessionKm " .. tostring(car.distanceDrivenSessionKm))
        ui.sameLine(0,50)
        ui.text("Ghost cars available.")
        -- ui.sameLine(0,10)
        if not changed then

            ui.pushFont(ui.Font.Title)
            if ui.checkbox("ON", bON) then
                bON = not bON
                if not bON then
                    ResetGhostedCars()
                end
                settitle()
                ConfigFile:setAndSave("SETTINGS", "ON", bON)
            end
            ui.sameLine(120)
            ui.pushFont(ui.Font.Main)
            if ui.checkbox("use color", bUseColor) then
                bUseColor=not bUseColor
                ConfigFile:setAndSave("SETTINGS", "UseColor", bUseColor)
            end

            ui.sameLine(220)
            local col1 = ColorGhost:clone()
            ui.colorButton('Ghost-Color', col1, ui.ColorPickerFlags.PickerHueBar)
            if col1~=ColorGhost then
                -- ac.debug("save", col1)
                ColorGhost = col1:clone()
                ConfigFile:setAndSave("SETTINGS", "GhostColor", (tostring(ColorGhost.r)..","..tostring(ColorGhost.g)..","..tostring(ColorGhost.b)))
                resetMyGhostedCar()
            end

            ui.newLine()
            ui.sameLine(120)
            ui.setNextItemWidth(120)
            ui.pushFont(ui.Font.Tiny)
            ui.setCursorY(ui.getCursorY()-10)
            GhostAlpha, chang = ui.slider("##ALPHA", GhostAlpha, 0, 20, "ALPHA: %.1f" % (GhostAlpha/10))
            if chang then
                GhostAlpha = GhostAlpha
                --resetGhostedCars()
                resetMyGhostedCar()
                ConfigFile:setAndSave("SETTINGS", "GhostAlpha", GhostAlpha)
            end

            ui.pushFont(ui.Font.Main)

            if ui.checkbox("ghost Player", bGhostMyself) then
                bGhostMyself = not bGhostMyself
                ConfigFile:setAndSave("SETTINGS", "GhostMyself", bGhostMyself)
                if not bGhostMyself then
                    --resetGhostedCars()
                    for i=1, #TableCars do
                        if TableCars[i].index==0 then
                            table.remove(TableCars, i)
                            table.remove(TableSimpleCollider, i)
                            table.remove(TableDT, i)
                            return
                        end
                    end
                end
            end

            ui.sameLine(120)
            if ui.checkbox("colored too", bColorMyself) then
                bColorMyself = not bColorMyself
                if not bColorMyself then ResetGhostedCars() end
                ConfigFile:setAndSave("SETTINGS", "ColorMyself", bColorMyself)
            end
            if ui.itemHovered() then
                ui.tooltip(function () ui.text("when off, a text message will be shown") end )
            end

            ui.newLine(-5)
            ui.text("Show")
            ui.sameLine(0)
            if ui.checkbox("arrow", bShowArrow) then
                bShowArrow = not bShowArrow
                ConfigFile:setAndSave("SETTINGS", "ShowArrow", bShowArrow)
            end
            ui.sameLine(0)
            local col2 = ColorArrow:clone()
            ui.colorButton('Arrow-Color', col2, ui.ColorPickerFlags.AlphaBar + ui.ColorPickerFlags.PickerHueBar)
            if col2~=ColorArrow then
                ColorArrow = col2:clone()
                ConfigFile:setAndSave("SETTINGS", "ArrowColor", (tostring(ColorArrow.r)..","..tostring(ColorArrow.g)..","..tostring(ColorArrow.b)))
            end

            ui.sameLine(0)
            if ui.checkbox("timer", bShowTimer) then
                bShowTimer = not bShowTimer
                ConfigFile:setAndSave("SETTINGS", "ShowTimer", bShowTimer)
            end
            ui.sameLine(0)
            local col3 = ColorTimer:clone()
            ui.colorButton('Timer-Color', col3, ui.ColorPickerFlags.AlphaBar + ui.ColorPickerFlags.PickerHueBar)
            if col3~=ColorTimer then
                ColorTimer = col3:clone()
                ConfigFile:setAndSave("SETTINGS", "TimerColor", (tostring(ColorTimer.r)..","..tostring(ColorTimer.g)..","..tostring(ColorTimer.b)))
            end

            if backupexists then
                --ui.setCursorY(60*ac.getUI().uiScale)
                if ui.button("Click to restore original 'surfaces.ini'\nfor this track (needs restart)") then
                    RestoreOriginal()
                end
            end

        else
            ui.text(msg)
            if ui.button("Click to restart AC") then
                ac.restartAssettoCorsa()
            end
        end
    else
        ui.text("options not available")
    end
    ui.endOutline(rgbm.colors.black, 1)
end


-- main window has not much goin on
function script.windowMain()
    if physics.allowed() and bON then
        ui.text("Ghosted cars: ".. #TableCars)  -- .. " / " .. tostring(sim.carsCount))
        if #TableCars>0 then
            ui.sameLine(0,10)
            if ui.button("goto last") then
                ac.focusCar(TableCars[#TableCars].index)
            end
            ui.sameLine(0,10)
            if ui.button("reset") then
                ResetGhostedCars()
            end
        end
    else
        ui.sameLine(0)
        if physics.allowed() then
            ui.text("Ghosting available, but off.")
        else
            ui.sameLine(0)
            ui.text("Ghosting NOT possible!")
            if sim.isOnlineRace then
                ui.sameLine()
                ui.text("Online Race!")
            else
                if not changed then
                    if ui.button("Click to enable Extended Physics \nfor this track (needs restart)") then
                        EnableThePhysics()
                    end
                else
                    ui.text(msg)
                    if ui.button("Click to restart AC") then
                        ac.restartAssettoCorsa()
                    end
                end
            end
        end
    end
end

-- csp 0.1.79 does not have  ui.onExclusiveHUD()
if ac.getPatchVersionCode()>=2651 then
ui.onExclusiveHUD(function (mode)
    --     --if mode == 'game' then
    --     -- @param callback fun(mode: 'menu'|'pause'|'results'|'replay'|'game'): 'debug'|boolean? @Callback function.
    if mode == 'pause' then
        uix = (sim.windowWidth *1/ac.getUI().uiScale)/2
        uiy = (sim.windowHeight*1/ac.getUI().uiScale)/3*2
        uiw = (sim.windowHeight*1/ac.getUI().uiScale)/10
        bPaused = true
    else
        bPaused = false
    end
end)
end

if ac.hasTrackSpline() then
Ghost_ReadAILine() end
ResetGhostedCars()
