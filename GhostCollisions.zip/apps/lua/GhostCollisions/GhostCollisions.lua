-- variables not availabe in UI
local maxwheelsoutValid = 2     --
local carstocheck       = 4     -- around player car - higher might be better, like 6?
local gracetime         = 2.0   -- 3 secs might be better
local mindistance       = 2.0   -- 2m might be too close?


-- 0.1.79  2144
-- 0.2.0  2651  has ui.onExclusiveHUD()
-- 0.2.3  3044  has this as shader param: gWhiteRefPoint


local description = [[
-only on tracks with ExtendedPhysics
-should work in race/trackday/weekend modes
-invalidates laptime for any ghosted car, not the player laptime (you can turn that ON)
-Ghosting cars (disable collider) based on:
--speed<10
--wheelsout>2
--car direction more than +-90° against ai line direction
--2 seconds grace time
--before enabling collider again, it will check for 4 nearest cars if too close, then resets grace timer
--cars with more than 100% damage on any of the 5 damage parts will be sent back to pits
-otherwise there is still AC logic in place for sending them to pits
v1.1
-fixed for qualify/race if started w practice
v1.2 - 13 mar 2025
-fixed not resetting on Session restart
-added option to not do anything visual when ghosting ("use color" off)
-added option to also use transparent color for player car
-added arrow marker and timer display
-added alpha as option
v1.3 - 13 may 2025
-more immediate change on own car for testing
-minimum CSP version: 0.2.0 (before: 0.2.3)
v1.4 - 5 july 2025
-fixed not hiding some parts of cars that should be hidden
-second upload:
-fixed performance
v1.5 - 14 oct 2025
-added options to tighten restrictions for ghosting
v1.6 - 9 mar 2026
-initial scan of cars is done in background for smoother loading
]]


local ConfigFile = ac.INIConfig.load(ac.getFolder(ac.FolderID.ACApps) .. "/lua/GhostCollisions/" .. "settings.ini", ac.INIFormat.Default)

---- variables availabe in UI
local bON                = ConfigFile:get("SETTINGS", "ON", 1) == 1
local bUseColor          = ConfigFile:get("SETTINGS", "UseColor", 1) == 1
local bGhostMyself       = ConfigFile:get("SETTINGS", "GhostMyself", 0) == 1
local bColorMyself       = ConfigFile:get("SETTINGS", "ColorMyself", 0) == 1
local bShowTimer         = ConfigFile:get("SETTINGS", "ShowTimer", 0) == 1
local bShowArrow         = ConfigFile:get("SETTINGS", "ShowArrow", 0) == 1
local GhostAlpha         = tonumber(ConfigFile:get("SETTINGS", "GhostAlpha"    , 4))
local angleThreshold     = tonumber(ConfigFile:get("SETTINGS", "angleThreshold", 45))
local speedThreshold     = tonumber(ConfigFile:get("SETTINGS", "speedThreshold", 30))
local speedRejoin        = tonumber(ConfigFile:get("SETTINGS", "speedRejoin"   , 30))

-- overwritten below
local ColorGhost         = rgbm( 0   ,   0,   1, 0.5 )
local ColorTimer         = rgbm( 1   ,   0,   0, 0.5 )
local ColorArrow         = rgbm( 1   ,   1,   1, 1 )

local ghostcol = string.split(  ConfigFile:get("SETTINGS", "GhostColor", "") , ",")
if ghostcol and #ghostcol==3 then
    ColorGhost         = rgbm( tonumber(ghostcol[1]), tonumber(ghostcol[2]), tonumber(ghostcol[3]), 0.5 )
end
local timercol = string.split(  ConfigFile:get("SETTINGS", "TimerColor", "") , ",")
if timercol and #timercol==3 then
    ColorTimer         = rgbm( tonumber(timercol[1]), tonumber(timercol[2]), tonumber(timercol[3]), 0.5 )
end
local arrowcol = string.split(  ConfigFile:get("SETTINGS", "ArrowColor", "") , ",")
if arrowcol and #arrowcol==3 then
    ColorArrow         = rgbm( tonumber(arrowcol[1]), tonumber(arrowcol[2]), tonumber(arrowcol[3]), 0.5 )
end

local function settitle()
    if physics.allowed() and bON then
        ac.setWindowTitle('main', "Ghost Collisions v1.5" .. " - Ghosting ON.")
    else
        ac.setWindowTitle('main', "Ghost Collisions v1.5" .. " - Ghosting OFF!")
    end
end
settitle()


local sim = ac.getSim()
local car = ac.getCar(0)
local SessionSwitched = true
local previousSessionStartTimer = sim.sessionTimeLeft-0.002

local upd2 = 0.2
local vUp = vec3(0, 1, 0)
local bPaused = false

local surfacesFile = ac.getFolder(ac.FolderID.CurrentTrackLayout) .. "/data/surfaces.ini"
local surfacesBackupFile = ac.getFolder(ac.FolderID.CurrentTrackLayout) .. "/data/surfaces_original_GHOSTCOLL.bak"
local surfacesData = ac.INIConfig.load(surfacesFile, ac.INIFormat.Default)
local changed = false
local backupexists = io.fileExists(surfacesBackupFile)
local msg = ""

local TableDir = {}
local TableCars = {}
local TabH = {}
local TableSimpleCollider = {}
local TableDT = {}
local HiddenMeshes = {}
local HM = {}

local replaydone=true
local gray = rgbm(0.1,0.1,0.1,0.75)
local uix = (sim.windowWidth *1/ac.getUI().uiScale)/2
local uiy = (sim.windowHeight*1/ac.getUI().uiScale)/3*2
local uiw = (sim.windowHeight*1/ac.getUI().uiScale)/10
local exposureCar = 1.0  -- (math.max(0.1, ac.getSim().whiteReferencePoint/10))
local exposureLines = 1.0  -- (math.max(0.1, ac.getSim().whiteReferencePoint/10))
local lastWhiteRef = -1.0






local function RestoreOriginal()
    local copied = io.copyFile(surfacesBackupFile, surfacesFile, false)
    if copied then
        io.deleteFile(surfacesBackupFile)
        changed = true
        msg="Backup File Restored!"
    end
end

local function EnableThePhysics()
    --ac.log("Track does not have physics access, creating backup")
    if io.fileExists(surfacesBackupFile) then
        surfacesBackupFile = surfacesBackupFile..'.bak'
        while io.fileExists(surfacesBackupFile) do
            surfacesBackupFile = surfacesBackupFile..'.bak'
        end
    end
    local copied = io.copyFile(surfacesFile, surfacesBackupFile, false)
    if copied then
        surfacesData:setAndSave("SURFACE_0", "WAV_PITCH", "extended-0")
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_APPS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_TOOLS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_TRACK_SCRIPTS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_DISPLAY_SCRIPTS", 1)
        surfacesData:setAndSave("_SCRIPTING_PHYSICS", "ALLOW_NEW_MODE_SCRIPTS", 1)
        changed = true
        msg = "'surfaces.ini': created backup, inserted Extended Physics!"
    else
        msg = "'surfaces.ini': could not make backup of\n"..surfacesFile
    end
end





-- local function GetDirFromSplinePos(carL)
--     -- 1st point on spline
--     local p1 = ac.trackProgressToWorldCoordinate(carL.splinePosition)

--     -- add 1 meter for 2nd point to find direction
--     local spline2 = carL.splinePosition + 1/sim.trackLengthM
--     -- make sure we hit a valid value
--     if spline2 > 1.0 then spline2 = 0.0 end

--     -- 2nd point on spline
--     local p2 = ac.trackProgressToWorldCoordinate(spline2)

--     local dir = -math.atan2(p1.z-p2.z, p1.x-p2.x) - math.rad(90)
--     ac.debug("angle in deg:", math.deg(dir) )

--     return dir -- rads
-- end






local function Ghost_ReadAILine()
    table.clear(TableDir)
    local cSpline2 = 1.0 - 1/sim.trackLengthM
    local p2 = ac.trackProgressToWorldCoordinate(cSpline2)
    cSpline2 = 0.0
    local p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    while cSpline2 < 1.0 do
        -- local roll = -math.deg( math.atan2(p1.x-p2.x, p1.z-p2.z) )
        local dir = math.atan2(p1.z-p2.z, p1.x-p2.x)
        table.insert(TableDir, 90-(-math.deg(dir)-90) )   -- -- minus fest -- --
        p1:copyTo(p2)
        cSpline2 = cSpline2 + 1/sim.trackLengthM
        p1 = ac.trackProgressToWorldCoordinate(cSpline2)
    end
end






-- local nc = 0

local function CheckNode(node, level)
    if ac.getPatchVersionCode() < 3396 then
        ac.debug("not supported", "in this CSP version")
        return
    end

    -- if level==0 then
    --     ac.debug("root nodes: "..tostring(num), #node:getChildren())
    --     ac.debug("root nodes: "..tostring(num), #node:getChildren())
    --     return
    -- end

    -- loop children
    local num = #node:getChildren()
    for i=1, num do

        -- -- for debug -- show dumpShaderReplacements
        -- nc=nc+1
        -- ac.debug(nc .. " object: " .. nsub:name().." dump", initrack)
        -- -- -- for one mesh only
        -- --  if string.find(nsub:name(), "flagman") then
        -- --      ac.debug(nc.." 1 " .. nsub:name()        , tostring(renderable) .. " - " .. tostring(mattrack))
        -- --      ac.debug(nc.." 1 " .. nsub:name().."dump", initrack)
        -- --  end

        local nsub = node:getChild(i) ---@sceneReference
        local renderable = nsub:isActive()
        local propC = nsub:getMaterialPropertiesCount()

        local inicar = ac.INIConfig.parse(nsub:dumpShaderReplacements())
        local matcount_ini = 0
        for k, v in pairs(inicar.sections) do
            matcount_ini = matcount_ini + 1
        end

        -- if level==0 then
            -- ac.debug(tostring(level).." node "..tostring(i).." "..tostring(nc), nsub:name().." "..tostring(renderable))
            -- nc=nc+1
        -- end

        -- find mesh in fbx.ini, if CSP version allows it
        if ac.getPatchVersionCode() >= 3396 and
           propC>0
        --    and nsub:getChildren()==0
        then
            if not renderable then
                -- ac.debug(tostring(nc).." - "..nsub:name())
                -- ac.debug(tostring(level).." node "..tostring(i).." "..tostring(nc), nsub:name().." "..tostring(renderable))
                -- nc=nc+1
                -- table.insert(HM, nsub:name())
                table.insert(HM, nsub)
            end
        end

        if #nsub:getChildren() > 0 then
            -- loop childs children recursive
            CheckNode(nsub, level+1)
        end
    end
end




local function CheckAllCarNodes(carl)
    HM = {}
    if carl then
        local carid = ac.getCarID(carl.index)
        for j=0, #HiddenMeshes-1 do
            if HiddenMeshes[j]['carid']==carid then
                return
            end
        end
        if ac.getPatchVersionCode() >= 3044 then
            local carroot = ac.findNodes('carRoot:'..tostring(carl.index))
            if carroot then
                -- ac.debug( "root"..tostring(carl.index) , tostring(carroot:getChildren()) )
                CheckNode(carroot, 0)
            end
        end
        -- ac.debug("car"..i, carroot)

        table.insert(HiddenMeshes, #HiddenMeshes, {['carid']=carid, ['meshes']=table.clone(HM)})
    end
end




local function SetCarVisible(carl, vis)

    -- (un)hide everything
    ac.findNodes('carRoot:'..carl.index):findMeshes("?"):setVisible(vis)
    ac.setDriverVisible(carl.index, vis)

    -- hide stuff that was hidden before
    if vis then
        for j=0, #HiddenMeshes-1 do
            -- if HiddenMeshes[j]['carindex']==carl.index then
            if HiddenMeshes[j]['carid']==ac.getCarID(carl.index) then
                for i=1, #HiddenMeshes[j]['meshes'] do
                    -- ac.debug("hide  -  "..HiddenMeshes[j]['meshes'][i], "yes")
                    -- ac.findNodes('carRoot:'..tostring(carl.index)):findMeshes(HiddenMeshes[j]['meshes'][i]):setVisible(false)
                    HiddenMeshes[j]['meshes'][i]:setVisible(false)
                end
                break
            end
        end

        -- TESTING VErSION 1.7 --- remove outline
        -- local m = ac.findNodes('carRoot:'..carl.index):findMeshes('?'):getChild(0)
        -- local m = ac.findNodes('carRoot:'..carl.index):findMeshes('?') [0] -- :getChild(0)
        -- m:setOutline()
        -- m:setOutline(rgbm.colors.green)

    end
end





local function GetSimpleCarmesh(carl)
    ac.debug("came here", "ss")
    if ac.getPatchVersionCode()>=3044 then
        return {
        mesh = ac.SimpleMesh.carShape(carl.index, false),
        transform = carl.bodyTransform,
        textures = { },
        values = {col=ColorGhost/exposureCar, alpha=GhostAlpha},
        shader = [[
            float4 main(PS_IN pin) {
            float g = dot(normalize(pin.NormalW), normalize(pin.PosC));
            return float4 ( gWhiteRefPoint * 0.5 * float3(col.r,col.g,col.b), pow(abs(1-abs(g)), alpha));
        }]]
        }
    else
        return {
        mesh = ac.SimpleMesh.carShape(carl.index, false),
        transform = carl.bodyTransform,
        textures = { },
        values = {col=ColorGhost/exposureCar, alpha=GhostAlpha},
        shader = [[
            float4 main(PS_IN pin) {
            float g = dot(normalize(pin.NormalW), normalize(pin.PosC));
            return float4 ( 0.5 * float3(col.r,col.g,col.b), pow(abs(1-abs(g)), alpha));
        }]]
        }
    end

    -- return float4 ( float3( saturate(-g), saturate(g), 1) * gWhiteRefPoint*0.5, pow(1 - abs(g), 2));
-- return float4(pin.Tex.x, pin.Tex.y, 0, 1);
-- return float4(float3(0.5,0,1), 0.5);
end






local seen = {}
local function ScanCars()
    co = coroutine.create( function ()
        -- ac.perfBegin("initial scan")
        for i=1, sim.carsCount do
            local carl = ac.getCar(i)
            if carl then
                coroutine.yield()

                -- get all hidden meshes per car, so we can hide them again later
                CheckAllCarNodes(carl)

                if not table.contains(seen, carl.name) then
                    table.insert(seen, carl.name)
                    -- pre load carmesh so it wont stutter first time car is Ghosted
                    local scm = GetSimpleCarmesh(carl)
                end

                -- debug ghost all just at the start --
                -- if false then
                -- -- if true then
                --     upd2=0.2 -- reset timer for more visual feedback
                --     table.insert(TableCars, carl) --
                --     table.insert(TableSimpleCollider, GetSimpleCarmesh(carl)) -- simple carmesh for draw3d
                --     table.insert(TabH, carl.aabbSize.y + 0.25) -- car height for timer
                --     table.insert(TableDT, 0.0) -- grace timer

                --     if bGhostMyself or carl.index>0 then
                --         physics.disableCarCollisions(i, true)
                --     end

                --     -- if (bUseColor and carl.index>0) or
                --     --    (carl.index==0 and
                --     --    (bColorMyself or (bColorMyself and bGhostMyself)) )
                --     -- then
                --     if (bON and bGhostMyself and carl.index==0) or (bON and carl.index>0) then
                --         SetCarVisible(carl, false)
                --     end
                -- end

                -- ac.debug("aabbH", carl.aabbSize.y)

            end
        end
    end
)
end



local function SetGhosted(carl)
    table.insert(TableCars, carl) --
    table.insert(TableSimpleCollider, GetSimpleCarmesh(carl)) -- simple carmesh for draw3d
    table.insert(TabH, carl.aabbSize.y + 0.25) -- car height for timer
    table.insert(TableDT, 0.0) -- grace timer
end










local function ResetGhostedCars()
    if physics.allowed() then
        for i=0, sim.carsCount-1 do
            SetCarVisible(ac.getCar(i), true)
            if i>0 or bGhostMyself then
                physics.disableCarCollisions(i, false)
            end
        end
        TableSimpleCollider = {}
        TableCars = {}
        TabH = {}
        TableDT = {}
        HiddenMeshes = {}
    end
end


local function resetMyGhostedCar()
    if physics.allowed() then
        for i = 1, #TableSimpleCollider do
            TableSimpleCollider[i] = GetSimpleCarmesh(TableCars[i])
            if TableSimpleCollider[i].index==0 then
                 SetCarVisible(ac.getCar(i), true)
                if i>0 or bGhostMyself then
                    physics.disableCarCollisions(i, false)
                end
                table.remove(TableSimpleCollider, i)
                table.remove(TableCars, i)
                table.remove(TabH, i)
                table.remove(TableDT, i)
                return
            end
        end
        for i=0, sim.carsCount-1 do
            SetCarVisible(ac.getCar(i), true)
            if i>0 or bGhostMyself then
                physics.disableCarCollisions(i, false)
            end
        end
    end
end

local anglediff = 0.0

function IsAngledRight(carl)
    if carl then
        local id = math.floor(carl.splinePosition*#TableDir)
        if id>0 and id<=#TableDir then
            anglediff = math.abs(
                TableDir[id] -
                (180 + math.deg(math.atan2(carl.look.z, carl.look.x) ))
            )
            -- if carl.index==0 then
            --     local aidir  = 90 + math.deg( -TableDir[id] )
            --     local cardir = 180 + math.deg(math.atan2(carl.look.z, carl.look.x) )
            --     local diff   = math.abs(aidir-cardir)
            --     ac.debug("direction ailine", aidir )
            --     ac.debug("direction car"   , cardir)
            --     ac.debug("comp"   , cardir > aidir-90 and cardir < aidir+90)
            -- end
            if anglediff>180 then
                anglediff = 360-anglediff
            end
            -- return anglediff<90-angleThreshold or anglediff>270+angleThreshold
            -- if not (anglediff<angleThreshold) then
            --     ac.debug("direction diff trigger"  , anglediff)
            -- end

            return anglediff<angleThreshold
        else
            return true
        end
    end
end

function CheckForStalledAI()
    for i=0, sim.carsCount-1 do
        local carl = ac.getCar(i)
        if carl and
           not carl.isInPit and
           not carl.isInPitlane and
           not table.contains(TableCars, carl)
        then
            if -- not IsAngledRight(carl)
                (not carl.isRemote and
                (carl.isAIControlled and (bGhostMyself or carl.index>0))
                or bGhostMyself or bColorMyself or carl.index>0 )
                and
                (carl.speedKmh      < speedThreshold or  -- speed
                 carl.wheelsOutside > maxwheelsoutValid  or  -- wheelsoutside
                 not IsAngledRight(carl))   -- facing wrong > than 90 degrees
            then
                ac.debug('collision disabled' , 'car '..carl.index)
                upd2=0.2 -- reset timer for more visual feedback

                if bGhostMyself or carl.index>0 then
                    physics.disableCarCollisions(i, true)
                end

                if (bON and bGhostMyself and carl.index==0) or (bON and carl.index>0) then
                    SetGhosted(carl)
                    if (bColorMyself and carl.index==0 and bGhostMyself) or (bUseColor and carl.index>0) then
                        SetCarVisible(carl, false)
                    end
                end

                -- TESTING VErSION 1.7 --- setting outline
                -- local m = ac.findNodes('carRoot:0'):getChild(1):setVisible(false)
                -- local m = ac.findNodes('carRoot:'..carl.index):findMeshes('?') [0] -- :getChild(0)
                -- m:setOutline(rgbm.colors.red*10)
                --:findMeshes('?')
                --m
                -- m:setVisible(true)
                -- m:setVisible(true)
                --(1) : setVisible(0)

                -- ac.debug("aabbH", aabbH)
                --     -- if (bUseColor and carl.index>0) or
                --     --    (carl.index==0 and
                --     --    (bColorMyself or (bColorMyself and bGhostMyself)) )
                --     -- then

            end
        end
    end
end


local function CheckForToBeEnabled(dt)
    -- check ghosted cars to be re-enabled
    for i = 1, #TableCars do
        if  TableCars[i].isInPit or
            TableCars[i].isInPitlane or
          ((TableCars[i].wheelsOutside<maxwheelsoutValid+1 and
            TableCars[i].speedKmh>speedRejoin) and
            IsAngledRight(TableCars[i]))
        then
            if TableCars[i].isInPit or TableCars[i].isInPitlane then
                -- will disable ghosting imediately in pits
                TableDT[i]=gracetime + 1.0
            else
                TableDT[i]=TableDT[i]+dt
            end
            if TableDT[i]>gracetime then
                -- check if we really should enable this car
                -- ac.iterateCars.ordered() - ordered by distance
                if not TableCars[i].isInPit or TableCars[i].isInPitlane then
                for j, carNear in ac.iterateCars.ordered() do
                    -- stop after 6 cars, not sure how much that should be
                    if j>carstocheck then break end

                    -- reset ghost timer for car
                    if  carNear.index ~= TableCars[i].index and
                        carNear.position:distance(TableCars[i].position())<mindistance  -- less than 2 meters?
                    then
                        TableDT[i]=0.0
                        break
                    end
                end end

                -- still above 2 secs?
                if TableDT[i]>gracetime then
                    -- car no longer ghosted
                    ac.debug('collision re-enabled' , 'car '..TableCars[i].index)
                    SetCarVisible(TableCars[i], true)
                    physics.disableCarCollisions(TableCars[i].index, false)
                    table.remove(TableDT, i)
                    table.remove(TableCars, i)
                    table.remove(TableSimpleCollider, i)
                    break  -- must do because tables changed
                end
            end
        else
            if TableCars[i].index>0
               and
               (TableCars[i].damage[0]>=99.0 or
                TableCars[i].damage[1]>=99.0 or
                TableCars[i].damage[2]>=99.0 or
                TableCars[i].damage[3]>=99.0 or
                TableCars[i].damage[4]>=99.0)
            then
                -- send car to pits
                physics.teleportCarTo(TableCars[i].index, ac.SpawnSet.Pits)
            else
                -- reset ghost timer for car
                TableDT[i]=0.0
            end
        end
    end
end


local dx = 0
local p1 = vUp
local p2 = vUp

function script.Draw3D(dt)
    if physics.allowed() then
        for i = 1, #TableSimpleCollider do
            if (TableCars[i].index>0) then
                -- render ghost
                if bUseColor then
                    render.mesh(TableSimpleCollider[i])
                end
                SetCarVisible(TableCars[i], not bUseColor)
            elseif TableCars[i].index==0 then
                -- so that checkboxes work live
                if bColorMyself then
                    -- render own ghost
                    render.mesh(TableSimpleCollider[i])
                end
                SetCarVisible(TableCars[i], not bColorMyself)
            end

            if bShowTimer then
                dx = (gracetime-math.round(TableDT[i], 1))/2.0
                -- draw colored bar, width based on gracetimer
                p1 = TableCars[i].position +vUp*(TabH[i]-0.06) +TableCars[i].side/2.0
                p2 = TableCars[i].position +vUp*(TabH[i]-0.06) +TableCars[i].side/2.0-TableCars[i].side*dx
                -- render.debugLine(p1, p2, rgbm.colors.red*2)
                render.quad(p1, p2, p2+vUp*0.05, p1+vUp*0.05, ColorTimer*exposureLines/2)

                p1 = TableCars[i].position +vUp*TabH[i] -TableCars[i].side*0.5
                p2 = TableCars[i].position +vUp*TabH[i] +TableCars[i].side*0.5
                render.debugLine(p1, p2, ColorArrow*exposureLines)

                -- render.debugText(TableCars[i].position+vUp*1.7, tostring(dx.."s", rgbm.colors.white, 2)
            end

            if bShowArrow then
                render.debugArrow(
                    TableCars[i].position+vUp*(TabH[i]+0.75),
                    TableCars[i].position+vUp*TabH[i], 0.1,
                    ColorArrow*exposureLines)
            end
        end
    end
end


function UICallback()
    if #TableCars>0 then
        for i = 1, #TableCars do
            if TableCars[i].index==0 and sim.focusedCar==0 then
                -- draw message on screen when player car is ghosted
                -- ui.drawRectFilled(                      vec2(uix-uiw, uiy-uiw/6*8), vec2(uix+uiw, uiy-uiw/6), gray, 8, ui.CornerFlags.All)
                ui.drawRectFilled(                      vec2(uix-uiw, uiy-uiw/6*2), vec2(uix+uiw, uiy+uiw/6/2), gray, 8, ui.CornerFlags.All)
                ui.dwriteDrawTextClipped("ghosted", 18, vec2(uix-uiw, uiy-uiw+uiw/4)  , vec2(uix+uiw, uiy+uiw/2)  , ui.Alignment.Center, ui.Alignment.Center, false, rgbm(1,1,1,1))
                break
            end
        end
    end
end


-- main update

-- local startDone = false
-- local SessionSwitched = true
-- local previousSessionStartTimer = sim.sessionTimeLeft-0.002


-- function script.update(dt)

--     -- do only once after racestart
--     if not startDone and sim.timeToSessionStart<=0.0 then
--         startDone = true
--         -- do your stuff here
--         if physics.allowed() then
--            physics.engageGear(0, 1)
--            ac.debug("gear", "for this car")
--         else
--           ac.debug("Extendend Physics not enabled", "for this car")
--         end
--     end

--     -- to reset
--     if previousSessionStartTimer < sim.sessionTimeLeft then
--         startDone = false
--         SessionSwitched = true
--     elseif SessionSwitched then
--         SessionSwitched = false
--     end
--     previousSessionStartTimer = sim.sessionTimeLeft-0.002
--     -- ac.debug("sim.timeToSessionStart", sim.timeToSessionStart)


function script.update(dt)

    if previousSessionStartTimer < sim.sessionTimeLeft then
        -- clear ghosted cars
        SessionSwitched = true
        ResetGhostedCars()
    elseif SessionSwitched then
        SessionSwitched = false
    end
    previousSessionStartTimer = sim.sessionTimeLeft-0.002


    if bON and sim.isReplayActive and not replaydone and not bPaused then
        -- unhide cars in replay
        replaydone=true
        for i=1, #TableCars do
            SetCarVisible(TableCars[i], true)
        end
    end

    if lastWhiteRef ~= ac.getSim().whiteReferencePoint then
        lastWhiteRef = ac.getSim().whiteReferencePoint
        exposureCar = (math.max(0.1, ac.getSim().whiteReferencePoint/4))
        exposureLines = (math.max(3, ac.getSim().whiteReferencePoint))
        resetMyGhostedCar()
    end

    if  bON and
        not bPaused and
        physics.allowed() and
        -- sim.carsCount > 1 and
        -- car.distanceDrivenSessionKm > 0.1 and
        car.lapTimeMs > 5000 and
        not sim.isReplayActive and
        (sim.raceSessionType==ac.SessionType.Practice or
         sim.raceSessionType==ac.SessionType.Hotlap or
         sim.raceSessionType==ac.SessionType.Race or
         sim.raceSessionType==ac.SessionType.Qualify)
    then
        if replaydone then replaydone=false end
        if  #TableCars>0 and #TableDir>0 then
            CheckForToBeEnabled(dt)
        end
        upd2 = upd2 - dt
        if upd2<0.0 and #TableDir>0 then
            upd2 = 0.2
            -- main check for AI cars every 0.2 secs
            CheckForStalledAI()
        end
    end

end


-- settings
function script.windowSettings(dt)
    ui.beginOutline()

    -- if car then
    --     -- local id = math.floor(car.splinePosition*#TableDir)
    --     -- anglediff = math.abs(
    --     --     TableDir[id] -
    --     --     (180 + math.deg(math.atan2(car.look.z, car.look.x) ))
    --     -- )
    --     ui.text("direction diff " .. tostring(math.round(anglediff,1)) )
    --     ui.newLine()
    -- end

    if physics.allowed() then
        --ui.text("physics.allowed(): " .. tostring(physics.allowed()))
        --ui.text("distanceDrivenSessionKm " .. tostring(car.distanceDrivenSessionKm))
        ui.sameLine(0,50)
        ui.text("Ghost cars available.")
        -- ui.sameLine(0,10)
        if not changed then

            ui.pushFont(ui.Font.Title)
            if ui.checkbox("ON", bON) then
                bON = not bON
                if not bON then
                    ResetGhostedCars()
                end
                settitle()
                ConfigFile:setAndSave("SETTINGS", "ON", bON)
            end
            ui.sameLine(120)
            ui.pushFont(ui.Font.Main)
            if ui.checkbox("use color", bUseColor) then
                bUseColor=not bUseColor
                ConfigFile:setAndSave("SETTINGS", "UseColor", bUseColor)
            end

            ui.sameLine(220)
            local col1 = ColorGhost:clone()
            ui.colorButton('Ghost-Color', col1, ui.ColorPickerFlags.PickerHueBar)
            if col1~=ColorGhost then
                -- ac.debug("save", col1)
                ColorGhost = col1:clone()
                ConfigFile:setAndSave("SETTINGS", "GhostColor", (tostring(ColorGhost.r)..","..tostring(ColorGhost.g)..","..tostring(ColorGhost.b)))
                -- resetMyGhostedCar()
                ResetGhostedCars()
            end

            local chang = false
            ui.newLine()
            ui.sameLine(120)
            ui.setNextItemWidth(120)
            ui.pushFont(ui.Font.Tiny)
            ui.setCursorY(ui.getCursorY()-10)
            GhostAlpha, chang = ui.slider("##ALPHA", GhostAlpha, 0, 20, "ALPHA: %.1f" % (GhostAlpha/10))
            if chang then
                GhostAlpha = GhostAlpha
                ConfigFile:setAndSave("SETTINGS", "GhostAlpha", GhostAlpha)
                ResetGhostedCars()
                -- resetMyGhostedCar()
            end

            ui.pushFont(ui.Font.Main)



            if ui.checkbox("ghost Player", bGhostMyself) then
                bGhostMyself = not bGhostMyself
                ConfigFile:setAndSave("SETTINGS", "GhostMyself", bGhostMyself)
                if not bGhostMyself then
                    ResetGhostedCars()
                    for i=1, #TableCars do
                        if TableCars[i].index==0 then
                            table.remove(TableCars, i)
                            table.remove(TableSimpleCollider, i)
                            table.remove(TableDT, i)
                            return
                        end
                    end
                end
            end

            ui.sameLine(120)
            if ui.checkbox("colored too", bColorMyself) then
                bColorMyself = not bColorMyself
                if not bColorMyself then ResetGhostedCars() end
                ConfigFile:setAndSave("SETTINGS", "ColorMyself", bColorMyself)
            end
            if ui.itemHovered() then
                ui.tooltip(function () ui.text("when off, a text message will be shown") end )
            end

            ui.newLine(-5)
            ui.text("Show")
            ui.sameLine(0)
            if ui.checkbox("arrow", bShowArrow) then
                bShowArrow = not bShowArrow
                ConfigFile:setAndSave("SETTINGS", "ShowArrow", bShowArrow)
            end
            ui.sameLine(0)
            local col2 = ColorArrow:clone()
            ui.colorButton('Arrow-Color', col2, ui.ColorPickerFlags.AlphaBar + ui.ColorPickerFlags.PickerHueBar)
            if col2~=ColorArrow then
                ColorArrow = col2:clone()
                ConfigFile:setAndSave("SETTINGS", "ArrowColor", (tostring(ColorArrow.r)..","..tostring(ColorArrow.g)..","..tostring(ColorArrow.b)))
            end

            ui.sameLine(0)
            if ui.checkbox("timer", bShowTimer) then
                bShowTimer = not bShowTimer
                ConfigFile:setAndSave("SETTINGS", "ShowTimer", bShowTimer)
            end
            ui.sameLine(0)
            local col3 = ColorTimer:clone()
            ui.colorButton('Timer-Color', col3, ui.ColorPickerFlags.AlphaBar + ui.ColorPickerFlags.PickerHueBar)
            if col3~=ColorTimer then
                ColorTimer = col3:clone()
                ConfigFile:setAndSave("SETTINGS", "TimerColor", (tostring(ColorTimer.r)..","..tostring(ColorTimer.g)..","..tostring(ColorTimer.b)))
            end


            --- --- options --- ---


            angleThreshold, chang = ui.slider("##angle", angleThreshold, 20, 90, "trigger angle: %.0f°" % (angleThreshold))
            if chang then
                angleThreshold = angleThreshold
                --resetGhostedCars()
                resetMyGhostedCar()
                ConfigFile:setAndSave("SETTINGS", "angleThreshold", angleThreshold)
            end
            if ui.itemHovered() then ui.tooltip(function () ui.text("difference of angle from car VS ai line") end ) end

            speedThreshold, chang = ui.slider("##speedThreshold", speedThreshold, 0, 150, "minimum speed: %.0fkm/h" % (speedThreshold))
            if chang then
                speedThreshold = speedThreshold
                --resetGhostedCars()
                resetMyGhostedCar()
                ConfigFile:setAndSave("SETTINGS", "speedThreshold", speedThreshold)
            end
            if ui.itemHovered() then ui.tooltip(function () ui.text("min speed of car, under which ghosting will be considered") end ) end

            speedRejoin, chang = ui.slider("##speedRejoin", speedRejoin, 0, 150, "rejoin speed: %.0fkm/h" % (speedRejoin))
            if chang then
                speedRejoin = speedRejoin
                --resetGhostedCars()
                resetMyGhostedCar()
                ConfigFile:setAndSave("SETTINGS", "speedThreshold", speedRejoin)
            end
            if ui.itemHovered() then ui.tooltip(function () ui.text("min speed of car for rejoin after being ghosted") end ) end




            if backupexists then
                --ui.setCursorY(60*ac.getUI().uiScale)
                ui.newLine()
                if ui.button("Click to restore original 'surfaces.ini'\nfor this track (needs restart)") then
                    RestoreOriginal()
                end
            end

        else
            ui.text(msg)
            if ui.button("Click to restart AC") then
                ac.restartAssettoCorsa()
            end
        end
    else
        ui.text("options not available")
    end
    ui.endOutline(rgbm.colors.black, 1)
end


-- main window has not much goin on
function script.windowMain()
    if physics.allowed() and bON then
        ui.text("Ghosted cars: ".. #TableCars)  -- .. " / " .. tostring(sim.carsCount))
        if #TableCars>0 then
            ui.sameLine(0,10)
            if ui.button("goto last") then
                ac.focusCar(TableCars[#TableCars].index)
            end
            ui.sameLine(0,10)
            if ui.button("reset") then
                ResetGhostedCars()
            end
        end
    else
        ui.sameLine(0)
        if physics.allowed() then
            ui.text("Ghosting available, but off.")
        else
            ui.sameLine(0)
            ui.text("Ghosting NOT possible!")
            -- if sim.isOnlineRace then
            --     ui.sameLine()
            --     ui.text("Online Race!")
            -- else
                if not changed then
                    if ui.button("Click to enable Extended Physics \nfor this track (needs restart)") then
                        EnableThePhysics()
                    end
                else
                    ui.text(msg)
                    if ui.button("Click to restart AC") then
                        ac.restartAssettoCorsa()
                    end
                end
            -- end
        end
    end
end

-- csp 0.2.0  2651  has ui.onExclusiveHUD()
if ac.getPatchVersionCode()>=2651 then
ui.onExclusiveHUD(function (mode)
    if mode == 'pause' then
        uix = (sim.windowWidth *1/ac.getUI().uiScale)/2
        uiy = (sim.windowHeight*1/ac.getUI().uiScale)/3*2
        uiw = (sim.windowHeight*1/ac.getUI().uiScale)/10
        bPaused = true
    else
        bPaused = false
    end
end)
end

if ac.hasTrackSpline() then
Ghost_ReadAILine() end
ScanCars()

-- local w = worker { ScanCars() }
-- w:

-- ac.startBackgroundWorker(ScanCars(), nil)
-- ac.startBackgroundWorker(script, data, callback)

ResetGhostedCars()





-- local a = 1
-- while true do
--     local name, _ = debug.getlocal(1, a)
--     if not name then break end
--     a = a + 1
-- end
-- ac.debug('  NUM VARIABLES:', tostring(a) .. ' / 200')





-- local LED_lut = ac.DataLUT21.load("RPM_Default.2Dlut")
-- local LED = {}
-- local LEDColor = {}
-- local Colors = {
-- 	Blue = rgbm(0,0.25,1,1),
-- 	Green = rgbm(0,1,0,1),
-- 	Yellow = rgbm(1,1,0,1),
-- 	Red = rgbm(10,0,0),
-- 	Orange = vec3(10,2.5,0),
-- 	Off = vec3(0,0,0)
-- }
-- if car then
--     for i = 0,5 do
--         LED[i] = ac.findNodes("carRoot:" .. 0):findMeshes("LED_"..i)
--         LED[i]:setMaterialProperty("ksEmissive", rgbm.colors.orange*100)
--         ac.debug("LED"..i, LED)
--     end
-- end

-- ac.debug("LED", LED)


-- local basenode = ac.findNodes("sceneRoot:yes")

-- local x = ac.findNodes("trackRoot:yes"):findMeshes("1GRASS_38")









-- local x = ac.findNodes("carRoot:0"):findMeshes("GEO_Steer_SUB0")
-- local x = ac.findNodes("carRoot:0"):findMeshes("LED_0")
-- x:setOutline(rgbm.colors.white*2)
-- x:setMaterialProperty("ksAmbient", 0.1)
--x:setMaterialProperty("ksEmissive", rgbm.colors.white*10)

-- ac.debug("x", x)
