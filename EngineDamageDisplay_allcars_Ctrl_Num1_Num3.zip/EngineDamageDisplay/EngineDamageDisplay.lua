--You can edit these values while the game is running, saving the file will update the app.--
--Toggle last lap damage display--
showDamageLastLap = true
--Change font size--
fontSize = 16
--Change background transparency level (0-1)
background_opacity = 0.2
--Engine icon size, 0 will remove it--
engineIconSize = 50
--Move engine icon left or right--
engineIconX = 12
--Move engine icon up or down--
engineIconY = 0
--Move current damage text left or right--
currentDamageText_X = -13
--Move current damage  text up or down--
currentDamageText_Y = 6
--Current damage background width--
eng_life_bg_width = 300
--Current damage background height--
eng_life_bg_height = 300
--Last lap damage icon size, 0 will remove it--
lastLapIconSize =32

--Move last lap damage icon left or right--
lastIconX = 73

--Move last lap damage icon up or down--
lastIconY = 9


--Move last lap damage text left or right--
lastLapDamageText_X = 41

--Move last lap damage text up or down--
lastLapDamageText_Y = 6


--Last lap damage background width--
dmg_last_bg_width = 61

--Last lap damage background height--
dmg_last_bg_height = 70
------------------------------------------------------------
--------------------------------------------------------------

local sim = ac.getSim()
local CAR = ac.getCar(0)

local Cursor = vec2(0,0)
local dmgLastLap = 0
local stateLastLap = 1000
local Lap_count = 0
local carInPitlane = false
local carPitted = false

function script.windowMain(dt)

    CAR = ac.getCar(sim.focusedCar)
	ShowBgRectangle()

	Cursor.x = 50 --currentDamageText_X
    Cursor.y = currentDamageText_Y
    ui.setCursor(Cursor)

	ui.pushDWriteFont("Outfit:resources/Outfit-Bold.ttf")
    ui.pushFont(ui.Font.Title)
	ui.text(
          "engLive: "..math.round(math.floor(CAR.engineLifeLeft)/10) .. " %"
          .. "\n" ..
          "gearb : "..math.round(CAR.gearboxDamage).." %"
          .. "\n" ..
          "suspF : "..math.round(CAR.wheels[0].suspensionDamage).." %  "..math.round(CAR.wheels[1].suspensionDamage).." %"
          .. "\n" ..
          "suspR : "..math.round(CAR.wheels[2].suspensionDamage).." %  "..math.round(CAR.wheels[3].suspensionDamage).." %"
          .. "\n" ..
          "dam0  : "..math.round(CAR.damage[0]).." %"
          .. "\n" ..
          "dam1/2: "..math.round(CAR.damage[1]).." %  "..math.round(CAR.damage[2]).." %"
          .. "\n" ..
          "dam3/4: "..math.round(CAR.damage[3]).." %  "..math.round(CAR.damage[4]).." %"
          .. "\n" ..
          "wear1/2: "..math.round(CAR.wheels[0].tyreWear*100,2).." %  "..math.round(CAR.wheels[1].tyreWear*100,2).." %"
          .. "\n" ..
          "wear3/4: "..math.round(CAR.wheels[2].tyreWear*100,2).." %  "..math.round(CAR.wheels[3].tyreWear*100,2).." %"
          .. "\n" ..
          "fuel: "..math.round(CAR.fuel,1).."L"
          )

	if showDamageLastLap and dmgLastLap>0 then
    	ShowBgRectangle2()
		Cursor.x = lastLapDamageText_X
        Cursor.y = lastLapDamageText_Y
        ui.setCursor(Cursor)
		ui.dwriteTextAligned(math.round(dmgLastLap, 0)/10 .." %",fontSize,0,0,vec2(120,150),false,rgbm(0.8,0.8,0.8,1))
	end


    if CAR.isInPit == true then
		carPitted = true
	end

	if CAR.lapCount < Lap_count then
	    restartCount()
	end

	if CAR.lapCount > Lap_count then
	    LapUpdate()
	end

	if CAR.isInPitlane == false then

        carInPitlane = false
    else
        if CAR.isInPitlane == true then
            carInPitlane = true
    	end
	end

	if carInPitlane and carPitted then
		if CAR.engineLifeLeft > stateLastLap then
			stateLastLap = 1000
		else
			carPitted = false
		end
	end
end


eng_life_bg1 = 12
eng_life_bg2 = 0

dmg_last_bg1 = 120
dmg_last_bg2 = 0

function ShowBgRectangle()
	Cursor.x = engineIconX
    Cursor.y = engineIconY
    ui.setCursor(Cursor)
	ui.image("resources/engine.png", engineIconSize,rgbm.colors.white, nil, vec2(0, 0), vec2( 1, 1 ))
	ui.drawRectFilled(vec2(eng_life_bg1,eng_life_bg2),vec2(eng_life_bg_width,eng_life_bg_height), rgbm(0,0,0,background_opacity), 0)
end

function ShowBgRectangle2()
	Cursor.x = lastIconX
    	Cursor.y = lastIconY
    	ui.setCursor(Cursor)

	ui.image("resources/last.png", lastLapIconSize,rgbm.colors.white, nil, vec2(0, 0), vec2( 1, 1 ), ui.ImageFit.Stretch)

	Cursor.x = 80
    	Cursor.y = 40
    	ui.setCursor(Cursor)
	ui.drawRectFilled(vec2(dmg_last_bg1,dmg_last_bg2),vec2(dmg_last_bg_width,dmg_last_bg_height), rgbm(0,0,0,background_opacity), 0)

end

function LapUpdate()
	if CAR.lapCount >=1   then
        dmgLastLap=stateLastLap-CAR.engineLifeLeft
        stateLastLap=CAR.engineLifeLeft
        Lap_count = Lap_count+1
	end
end


function restartCount()
	stateLastLap = 1000
	dmgLastLap = 0
	Lap_count = 0
end


-- function script.Draw3D(dt)

--     for carIndex = 0, ac.getSim().carsCount - 1 do
--         local car = ac.getCar(carIndex)
--         if car then
--             local suspensions = ac.INIConfig.carData(i, 'suspensions.ini')
--             local wheelBase = suspensions:get('BASIC', 'WHEELBASE', 2)
--             local cgLocation = suspensions:get('BASIC', 'CG_LOCATION', 0.5)
--             for i, s in ipairs({ 'FRONT', 'REAR' }) do
--                 local frontBaseY = suspensions:get(s, 'BASEY', 0)
--                 local frontTrack = suspensions:get(s, 'TRACK', 1)
--                 local rimOffset = suspensions:get(s, 'RIM_OFFSET', 0)
--                 local wheelPosLR = {
--                     vec3(frontTrack / 2 - rimOffset, frontBaseY, wheelBase * (i == 1 and 1 - cgLocation or -cgLocation)),
--                     vec3(-frontTrack / 2 + rimOffset, frontBaseY, wheelBase * (i == 1 and 1 - cgLocation or -cgLocation))
--                 }
--                 local wheelLR = {
--                     car.wheels[i == 1 and 0 or 2],
--                     car.wheels[i == 1 and 1 or 3]
--                 }
--                 -- render.on('main.root.transparent', function ()
--                 for j = 1, 2 do
--                     local computedPosW = car.transform:transformPoint(wheelPosLR[j])
--                     local distanceToGround = physics.raycastTrack(computedPosW, vec3(0, -1, 0), 1)
--                     computedPosW.y = computedPosW.y + (wheelLR[j].tyreRadius - distanceToGround) * 0.8
--                     if wheelLR[j].position:closerToThan(computedPosW, 0.004) then
--                         -- if within 4 mm of proper position, draw a green cross
--                         render.debugCross(computedPosW, 0.05, rgbm.colors.green)
--                     else
--                         -- otherwise, draw a red arrow showing an offset that will occur online
--                         render.debugArrow(wheelLR[j].position, computedPosW)
--                         render.debugPoint(computedPosW, 3, rgbm.colors.red)
--                     end
--                 end
--                 -- end)
--             end
--         end
--     end
-- end
