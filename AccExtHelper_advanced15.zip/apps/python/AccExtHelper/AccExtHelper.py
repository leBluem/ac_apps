joystickid                = -1
joystickbuttonreset       = 9
joystickbuttonstepback    = 11

# for AUTO recording with traffic-ai-lines set this to 2.0
LenDiv = 1.0
# LenDiv = 2.0
PREV_back = 50
PREV_forw = 150
HEIGHT_mult = 2
HEIGHT_steps = 5
USERYOFFSET = -30
bDrawBlocks = True
#bDrawBlocks = False

# for recording TIME ATTACK "overlays.ini" - size of banners:
iCheckpointHeight   = 2.0   # meters
iBannerHeight       = 1.5   # meters
iBannerWidth        = 15.0  # meters
everyMeters         = 500.0 # atm unused i believe :)
bGenerateCSV        = False
initdone = False
s_AI_CAR_dirs = 0.0
dataupdateTime=0.05
justPressed= False

import ac, acsys
import configparser, sys, os.path, platform, traceback, threading, time, io, math, struct, string, random
from shutil import copyfile
from extlibs import win32con

# ctypes is different for 32/64bit
sysdir=os.path.dirname(__file__)+'/stdlib'
if platform.architecture()[0] == '64bit':
    sysdir=os.path.dirname(__file__)+'/stdlib64'
sys.path.insert(0, sysdir)
os.environ['PATH'] = os.environ['PATH'] + ';.'
import ctypes, ctypes.wintypes
from accexsim_info import info # also needs ctypes

user32 = ctypes.windll.user32
buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
hWnd = -1
achWnd = -1

gEnableHotKeys = False
gModifier = 'CTRL+SHIFT'
hotKeyFOVminusminus = "2"
hotKeyFOVminus      = "3"
hotKeyFOVplus       = "4"
hotKeyFOVplusplus   = "5"
hotKeyReset         = "R"
hotKeyStepBack      = "S"
hotKeyDriver        = "D"
hotKeyDoor          = "F"
hotKeyCopy          = "V"

app = 0

YOFFSET = -100
label = 0
btnResetCar = 0
btnSetBackCar = 0
vaoToggleButton = 0
vaoDebugButton = 0
lightsDebugButton = 0
copyCameraCoordsButton = 0
copyCameraCoordsButton2 = 0
doorToggleButton = 0
driverToggleButton = 0
isVaoActive = True
currentVaoDebugMode = 0
isLightsDebugOn = False
areDoorsOpen = False
isDriverVisible = True
bButtons = True
bTelemetry = False
btimerMsg = True
error = 0
timer = 0.0
timer2 = 0.0
timerMsg = 5.0
camCount = 0
lastPoT = 0.5
gAppsize = 1.0
lastFrom = ''
appMsg  =''
sVer = ''
firstCamPos = ''
firstOrientation = ''
firstOrientationALT = ''
checkpointC = 0
sCameras = ''
currPoTCalced = 0.0
currAltitude = 0.0
lastAltitude = 0.0

###############
sTrack =''
sLayout =''
sFileOverlay =''
sFileCameras =''
bRecordTimeAttack=False
bRecordCameras=False
bWrittenOverlaysINI=False
bWrittenCamerasINI=False
sOVERLAYS_INI = ''
sCamCoords = ''
sOrientationFORW = ''
sOrientationFORWtimeattack = ''
sOrientationUP = ''
sCSVspline = ''
previousSector = -1
currentSector = 0

btnTimeAttack = 0
btnCameraAdd = 0
btnCameraAuto = 0
btnToggleDetail = 0
btnToggleTelemetry = 0
btnFOVplus = 0
btnFOVminus = 0
btnFOVplusplus = 0
btnFOVminusminus = 0
hotKeyListener = 0

# global variables
btnResetStats = 0
tick_counter = 0
max_tick = 360
# frames/second variables
frame_counter = 0
frame_buffer = 20
time_elapsed = 0
current_fps = 0
# min max counter
MAX_fps = 0
MIN_fps = 5000
MAX_lights = 0
MIN_lights = 100000
odd = True
lx = 0.0
ly = 0.0
lz = 0.0
csvx = 0.0
csvy = 0.0
csvz = 0.0
slMinfov=0
slMaxfov=0
cbFixed=0
isFixed=0
lastTime = -1.0
lastLap = -2
lastSessonTime = -1
currentSector = 0
currCar = 0
cams=[]
BORDER_RIGHT = []
BORDER_LEFT  = []
AI_LINE_LENGTH = 0.0
AI_LINE = []
AI_LINE_dist = []
AI_LINE_DIR = []
lastCSVidx = 0
bAutoCam   = False
bAutoCamON = False
passedRoadLen = 0.0

# distances for IN_POINT/OUT_POINT
spdistIN = 250
spdistOUT = 200
# add random height btw those:
spMinHeight=1
spMaxHeigth=5

#####################################################################

class ExtGL:
    CULL_MODE_FRONT = 0
    CULL_MODE_BACK = 1
    CULL_MODE_NONE = 2
    CULL_MODE_WIREFRAME = 4
    CULL_MODE_WIREFRAME_SMOOTH = 7
    BLEND_MODE_OPAQUE = 0
    BLEND_MODE_ALPHA_BLEND = 1
    BLEND_MODE_ALPHA_TEST = 2
    BLEND_MODE_ALPHA_ADD = 4
    BLEND_MODE_MULTIPLY_BOTH = 5
    FONT_ALIGN_LEFT = 0
    FONT_ALIGN_RIGHT = 1
    FONT_ALIGN_CENTER = 2

class FontMeasures:
    def __init__(self, name, italic, bold, size, ratio, distance, heightCompensation, widthCompensation):
        self.n = name					#font name
        self.i = italic					#font italic
        self.b = bold					#font bold
        self.s = size					#font multiplier for one pixel height
        self.r = ratio					#font width compared to height
        self.d = distance				#font distance between the leftmost point of one letter and another, avareage
        self.h = heightCompensation		#font height offset to put it centered vertically
        self.w = widthCompensation		#font width offset to put it centered horizontally
        self.f = 0						#font object to be used in rendering
        return

def appFixedChange(name,value):
    global isFixed
    isFixed=value

def appSetPositions():
    global app, bButtons, bTelemetry, btnToggleDetail, btnToggleTelemetry, btnResetStats, label
    global driverToggleButton, doorToggleButton, copyCameraCoordsButton, copyCameraCoordsButton2, vaoToggleButton
    global vaoDebugButton, lightsDebugButton, btnFOVminusminus, btnFOVminus, btnFOVplus, btnFOVplusplus, btnResetCar, btnSetBackCar, btnTimeAttack, btnCameraAdd, btnCameraAuto
    global spdistIN, spdistOUT, spMinHeight, spMaxHeigth, bAutoCam, gAppsize
    try:
        # settingsParser = None
        # if os.path.isfile("apps/python/AccExtHelper/settings/settings.ini"):
        #     settingsParser = configparser.ConfigParser(empty_lines_in_values=True, inline_comment_prefixes=(";","/","#","\\"), strict=False)
        #     settingsParser.optionxform = str
        #     with open("apps/python/AccExtHelper/settings/settings.ini", "r", encoding="utf-8", errors="ignore") as F:
        #         settingsParser.read_string(F.read().encode('ascii', 'ignore').decode('ascii'))
        #
        #    gAppsize = float(getSettingsValue(settingsParser, 'GENERAL', "APPSIZE", "1.0", False))

        dy=20
        dx=140
        fntsize=12
        mult=1.0
        if gAppsize>=0.1 and gAppsize<=4.0:
            mult=gAppsize
            dx=dx*mult
            dy=dy*mult
            fntsize=fntsize*mult
        dxh=dx/2
        dxt=dx/3
        dxf=dx/4

        if bAutoCam and not bRecordTimeAttack:
            ac.setText(app, "\n\n\n\n         IN         dist\n         OUT         dist\n         min z\n         max z")
            ac.setPosition(spdistIN               , 20, 5 + 4 * dy)
            ac.setPosition(spdistOUT              , 20, 5 + 5 * dy)
            ac.setPosition(spMinHeight            , 20, 5 + 6 * dy)
            ac.setPosition(spMaxHeigth            , 20, 5 + 7 * dy)
            ac.setSize(spdistIN                   , dx, dy-4)
            ac.setSize(spdistOUT                  , dx, dy-4)
            ac.setSize(spMinHeight                , dx, dy-4)
            ac.setSize(spMaxHeigth                , dx, dy-4)
            ac.setFontSize(app                    , fntsize*1.25)
            ac.setFontSize(spdistIN               , fntsize)
            ac.setFontSize(spdistOUT              , fntsize)
            ac.setFontSize(spMinHeight            , fntsize)
            ac.setFontSize(spMaxHeigth            , fntsize)
        else:
            ac.setText(app, "")
            ac.setPosition(spdistIN               , -20000, 0)
            ac.setPosition(spdistOUT              , -20000, 0)
            ac.setPosition(spMinHeight            , -20000, 0)
            ac.setPosition(spMaxHeigth            , -20000, 0)
        #ac.setPosition(copyCameraCoordsButton2, 150, 25)
        #ac.setPosition(btnToggleDetail        , 165, 25)
        ac.setPosition(copyCameraCoordsButton2, 35+dxt*2+dxt/4*3      , dy+5)
        ac.setPosition(btnToggleDetail        , 190*gAppsize-dxt/3  -5, dy+55)
        ac.setPosition(btnToggleTelemetry     , 190*gAppsize-dxt/3  -5, dy+75)

        if bTelemetry:
            ac.setText(btnToggleTelemetry, "T")
        else:
            ac.setText(btnToggleTelemetry, "t")

        if bButtons:
            # appWriteCFGValue('apps/python/AccExtHelper/settings/settings.ini', 'GENERAL', 'DETAILS', 'True', True)

            ac.setTitle(app, "  Shaders Patch Debug adv")
            ac.setIconPosition(app, 0, 0)
            if bTelemetry:
                ac.setSize(app, 200*gAppsize, 440*gAppsize)
            else:
                ac.setSize(app, 200*gAppsize, 280*gAppsize)

            ac.setText(btnToggleDetail, "^")

            ac.setPosition(btnResetStats          , 180*gAppsize-dxt/3-1, 5+dy*2)
            ac.setPosition(label                  ,  5       , 5+dy*8)
            ac.setPosition(driverToggleButton     ,  20      , 5+dy)
            ac.setPosition(doorToggleButton       ,  20+dxt  , 5+dy)
            ac.setPosition(copyCameraCoordsButton ,  20+dxt*2, 5+dy)

            ac.setPosition(vaoToggleButton        ,  20      , 5+dy*2)
            ac.setPosition(vaoDebugButton         ,  20+dxt  , 5+dy*2)
            ac.setPosition(lightsDebugButton      ,  20+dxt*2, 5+dy*2)

            ac.setPosition(btnFOVminusminus       ,  20      , 5+dy*3)
            ac.setPosition(btnFOVminus            ,  20+dxf  , 5+dy*3)
            ac.setPosition(btnFOVplus             ,  20+dxf*2, 5+dy*3)
            ac.setPosition(btnFOVplusplus         ,  20+dxf*3, 5+dy*3)

            ac.setPosition(btnCameraAdd           ,  20      ,5+dy*4)
            ac.setPosition(btnCameraAuto          ,  20      ,5+dy*5)
            ac.setPosition(btnTimeAttack          ,  20      ,5+dy*6)
            ac.setPosition(btnResetCar            ,  20      ,5+dy*7)
            ac.setPosition(btnSetBackCar          ,  20+dxh  ,5+dy*7)

        else:
            # appWriteCFGValue('apps/python/AccExtHelper/settings/settings.ini', 'GENERAL', 'DETAILS', 'False', True)

            ac.setTitle(app, "")
            ac.setIconPosition(app, -20000, 0)
            if bTelemetry:
                ac.setSize(app, 185*gAppsize, 150*gAppsize)
            else:
                ac.setSize(app, 185*gAppsize, 65*gAppsize)
            ac.drawBorder(app, 0)

            ac.setPosition(label, 5, -10)
            ac.setText(btnToggleDetail, "v")

            # hide buttons by moving off screen
            ac.setPosition(btnResetStats         , -20000, 0)
            ac.setPosition(driverToggleButton    , -20000, 0)
            ac.setPosition(doorToggleButton      , -20000, 0)
            ac.setPosition(copyCameraCoordsButton, -20000, 0)
            ac.setPosition(vaoToggleButton       , -20000, 0)
            ac.setPosition(vaoDebugButton        , -20000, 0)
            ac.setPosition(lightsDebugButton     , -20000, 0)
            ac.setPosition(btnFOVminusminus      , -20000, 0)
            ac.setPosition(btnFOVminus           , -20000, 0)
            ac.setPosition(btnFOVplus            , -20000, 0)
            ac.setPosition(btnFOVplusplus        , -20000, 0)
            ac.setPosition(btnResetCar           , -20000, 0)
            ac.setPosition(btnSetBackCar         , -20000, 0)
            ac.setPosition(btnTimeAttack         , -20000, 0)
            ac.setPosition(btnCameraAdd          , -20000, 0)
            ac.setPosition(btnCameraAuto         , -20000, 0)

        ac.setSize(driverToggleButton      , dxt         , dy)
        ac.setSize(doorToggleButton        , dxt         , dy)
        ac.setSize(copyCameraCoordsButton  , dxt         , dy)
        ac.setSize(copyCameraCoordsButton2 , dxt/4*2     , dy)
        ac.setSize(vaoToggleButton         , dxt         , dy)
        ac.setSize(vaoDebugButton          , dxt         , dy)
        ac.setSize(lightsDebugButton       , dxt         , dy)
        ac.setSize(btnResetStats           , 24*gAppsize , dy)
        ac.setSize(btnFOVminusminus        , dxh/2       , dy)
        ac.setSize(btnFOVminus             , dxh/2       , dy)
        ac.setSize(btnFOVplus              , dxh/2       , dy)
        ac.setSize(btnFOVplusplus          , dxh/2       , dy)
        ac.setSize(btnResetCar             , dxh         , dy)
        ac.setSize(btnSetBackCar           , dxh         , dy)
        ac.setSize(btnTimeAttack           , dx          , dy)
        ac.setSize(btnCameraAdd            , dx          , dy)
        ac.setSize(btnCameraAuto           , dx          , dy)
        ac.setSize(btnToggleDetail         , 10*gAppsize , dy)
        ac.setSize(btnToggleTelemetry      , 10*gAppsize , dy)

        ac.setFontSize(label                  , fntsize)
        ac.setFontSize(doorToggleButton       , fntsize+fntsize/10)
        ac.setFontSize(lightsDebugButton      , fntsize+fntsize/10)
        ac.setFontSize(driverToggleButton     , fntsize)
        ac.setFontSize(copyCameraCoordsButton , fntsize)
        ac.setFontSize(copyCameraCoordsButton2, fntsize)
        ac.setFontSize(vaoToggleButton        , fntsize)
        ac.setFontSize(vaoDebugButton         , fntsize)
        ac.setFontSize(btnResetCar            , fntsize)
        ac.setFontSize(btnSetBackCar          , fntsize)
        ac.setFontSize(btnTimeAttack          , fntsize)
        ac.setFontSize(btnCameraAdd           , fntsize)
        ac.setFontSize(btnCameraAuto          , fntsize)
        ac.setFontSize(btnToggleDetail        , fntsize)
        ac.setFontSize(btnToggleTelemetry     , fntsize)
        ac.setFontSize(btnResetStats          , fntsize)
        ac.setFontSize(btnFOVminusminus       , fntsize-fntsize/10)
        ac.setFontSize(btnFOVminus            , fntsize-fntsize/10)
        ac.setFontSize(btnFOVplus             , fntsize-fntsize/10)
        ac.setFontSize(btnFOVplusplus         , fntsize-fntsize/10)
    except:
        ac.log("AccExtHelper: " + traceback.format_exc())

def createSpinner(appWindow, text, value, x, y, width, height, rangeMin, rangeMax, step, visible = False):
    newSpinner = ac.addSpinner(appWindow, text)
    ac.setFontSize(newSpinner, 10)
    ac.setPosition(newSpinner, x, y)
    ac.setSize(newSpinner, width, height)
    ac.setRange(newSpinner, rangeMin, rangeMax)
    ac.setStep(newSpinner, step)
    ac.setValue(newSpinner, value)
    ac.setVisible(newSpinner, visible)
    return newSpinner

def createCheckbox(appWindow, text, value, x, y, width, height, visible = False):
    newCB = ac.addCheckBox(appWindow, text)
    ac.setFontSize(newCB, 10)
    ac.setPosition(newCB, x, y)
    ac.setSize(newCB, width, height)
    ac.setValue(newCB, value)
    ac.setVisible(newCB, visible)
    return newCB

def acMain(ac_version):
    global app, label, btnSetBackCar, error, sVer
    global vaoToggleButton, vaoDebugButton, lightsDebugButton, copyCameraCoordsButton, copyCameraCoordsButton2
    global doorToggleButton, driverToggleButton, bButtons, bTelemetry, btnResetCar, btnResetStats
    global sTrack, sLayout, sFileOverlay, sFileCameras, btnTimeAttack, btnCameraAdd, btnToggleDetail, btnCameraAuto, btnToggleTelemetry
    global btnFOVplus, btnFOVminus, btnFOVplusplus, btnFOVminusminus, gEnableHotKeys
    global slMinfov, slMaxfov, cbFixed, isFixed
    global spdistIN, spdistOUT, spMinHeight, spMaxHeigth, bAutoCam, gAppsize
    global f, joystickid, joystickbuttonreset, joystickbuttonstepback

    ac.initFont(0, "Arial", 0, 1)
    try:
        f = FontMeasures("Arial", 0, 0, 1.25, 0.69, 0.629, 0.616, 0.066)
        f.f = ac.ext_glFontCreate(f.n, f.s, f.i, f.b)
    except:
        ac.log('AccExtHelper: CustomShadersPatch not active., some features disabled.')

    app = ac.newApp("Shaders Patch Debug") # for the icon to be found
    ac.setTitle(app, "  Shaders Patch Debug adv")
    ac.setFontAlignment(app, 'left')
    # ac.addRenderCallback(app, onFormRender)

    label = ac.addLabel(app, "") # label for all the output
    ac.setFontSize(label, 12)
    sTrack = ac.getTrackName(0)
    sLayout = ac.getTrackConfiguration(0)
    ReadAILine()

    try:
        sVer = str(ac.ext_patchVersion()).replace('preview', 'prev')
        sVer = sVer + " (" + str(ac.ext_patchVersionCode()) + ")"
    except:
        sVer = 'CSP not installed'

    try:
        settingsParser = None
        if os.path.isfile("apps/python/AccExtHelper/settings/settings.ini"):
            settingsParser = configparser.ConfigParser()
            settingsParser.optionxform = str
            with open("apps/python/AccExtHelper/settings/settings.ini", "r", encoding="utf-8", errors="ignore") as F:
                settingsParser.read_string(F.read().encode('ascii', 'ignore').decode('ascii'))
            gEnableHotKeys = getSettingsValue(settingsParser, "SHORTCUTS", "EnableHotKeys"    , gEnableHotKeys, True)
            bButtons       = getSettingsValue(settingsParser, 'GENERAL', 'BUTTONS', bButtons, True)
            bTelemetry     = getSettingsValue(settingsParser, 'GENERAL', 'TELEMETRY', bTelemetry, True)
            gAppsize = float(getSettingsValue(settingsParser, 'GENERAL', "APPSIZE", "1.0", False))
            # WHEELBUTTONS
            joystickid             = int(getSettingsValue(settingsParser, 'WHEELBUTTONS', 'joyDevice'        , joystickid, False))
            joystickbuttonreset    = int(getSettingsValue(settingsParser, 'WHEELBUTTONS', 'joyButtonReset'   , joystickbuttonreset, False))
            joystickbuttonstepback = int(getSettingsValue(settingsParser, 'WHEELBUTTONS', 'joyButtonStepBack', joystickbuttonstepback, False))

        if not 'ext_isJoystickButtonPressed' in dir(ac):
            joystickid = -1
        else:
            if gEnableHotKeys:
                setHotKeys(settingsParser)

        # if patch not active: try fails, all down here will be skipped
        # and except-part only will be done
        i = ac.ext_getLightsVisible()   # fails if patch not present


        driverToggleButton = ac.addButton(app, "Driver")
        doorToggleButton = ac.addButton(app, "🚪")
        copyCameraCoordsButton = ac.addButton(app, "Copy")
        copyCameraCoordsButton2 = ac.addButton(app, "c")
        vaoToggleButton = ac.addButton(app, "V +/−")
        vaoDebugButton = ac.addButton(app, "V o/N")
        lightsDebugButton = ac.addButton(app, "🔦")
        btnResetStats = ac.addButton(app, "r")
        btnFOVminusminus = ac.addButton(app, "fov--")
        btnFOVminus = ac.addButton(app, "fov-")
        btnFOVplus  = ac.addButton(app, "fov+")
        btnFOVplusplus  = ac.addButton(app, "fov++")
        btnResetCar = ac.addButton(app, "Reset    Car")
        btnSetBackCar = ac.addButton(app, "Step back")
        btnTimeAttack = ac.addButton(app, "record overlays.ini")
        btnCameraAdd = ac.addButton(app, "auto 'cameras.ini'")
        btnCameraAuto = ac.addButton(app, "add current to 'cameras.ini'")
        btnToggleDetail = ac.addButton(app, "^")
        btnToggleTelemetry = ac.addButton(app, "t")
        slMinfov = createSpinner(app, "MIN_FOV" ,   10, 10, 130, 150, 20, 1, 180, 1)
        slMaxfov = createSpinner(app, "MAX_FOV" ,   30, 10, 170, 150, 20, 1, 180, 1)
        cbFixed  = createCheckbox(app, "IS_FIXED (red is ON)", isFixed, 10, 210, 150, 18)
        #                                                                                min max stp
        spdistIN    = createSpinner(app, "", 250,1,1,40,20, 25,500, 25,True)
        spdistOUT   = createSpinner(app, "", 250,1,1,40,20, 25,500, 25,True)
        spMinHeight = createSpinner(app, "",  1,1,1,40,20,  0,100,  1,True)
        spMaxHeigth = createSpinner(app, "",  5,1,1,40,20,  0,100,  1,True)

        ac.addOnCheckBoxChanged(cbFixed, appFixedChange)
        ac.addOnClickedListener(driverToggleButton, driverToggle)
        ac.addOnClickedListener(doorToggleButton, doorToggle)
        ac.addOnClickedListener(copyCameraCoordsButton, copyCameraCoords)
        ac.addOnClickedListener(copyCameraCoordsButton2, copyCameraCoords2)
        ac.addOnClickedListener(vaoToggleButton, vaoToggle)
        ac.addOnClickedListener(vaoDebugButton, vaoDebug)
        ac.addOnClickedListener(lightsDebugButton, lightsDebug)
        ac.addOnClickedListener(btnResetStats, doReset)
        ac.addOnClickedListener(btnFOVminusminus, appFOVminusminus)
        ac.addOnClickedListener(btnFOVminus, appFOVminus)
        ac.addOnClickedListener(btnFOVplus, appFOVplus)
        ac.addOnClickedListener(btnFOVplusplus, appFOVplusplus)
        ac.addOnClickedListener(btnResetCar, onresetCar)
        ac.addOnClickedListener(btnSetBackCar, takeAStepBack)
        ac.addOnClickedListener(btnTimeAttack, appRecordTimeAttack)
        ac.addOnClickedListener(btnCameraAdd, appCameraAdd)
        ac.addOnClickedListener(btnCameraAuto, appCameraAuto)
        ac.addOnClickedListener(btnToggleDetail, appToggleDetail)
        ac.addOnClickedListener(btnToggleTelemetry, appToggleTelemetry)

        ac.setCustomFont(doorToggleButton, "Segoe UI Symbol; Weight=UltraLight", 0, 0)
        ac.setCustomFont(btnResetCar, "Segoe UI; Weight=UltraBlack", 0, 0)
        ac.setCustomFont(btnSetBackCar, "Segoe UI; Weight=UltraBlack", 0, 0)

        sFileOverlay = 'content/tracks/' + sTrack+'/'
        if sLayout=='':
            if not os.path.isfile(sFileOverlay + 'data/overlays.ini'):
                sFileOverlay = sFileOverlay + 'data/overlays.ini'
            else:
                sFileOverlay = sFileOverlay + 'data/overlays_new.ini'
            sFileCameras = appGetNumberedFilename('content/tracks/' + sTrack+'/'+'data/cameras', '.ini')
        else:
            if not os.path.isfile(sFileOverlay + sLayout+'/data/overlays.ini'):
                sFileOverlay = sFileOverlay + sLayout+'/data/overlays.ini'
            else:
                sFileOverlay = sFileOverlay + sLayout+'/data/overlays_new.ini'
            sFileCameras = appGetNumberedFilename('content/tracks/' + sTrack+'/'+sLayout+'/data/cameras', '.ini')
        ac.setText(btnCameraAdd, "new '" + os.path.basename(sFileCameras) + "'")
        ac.setText(btnCameraAuto, "new auto '" + os.path.basename(sFileCameras) + "'")
        ac.log("AccExtHelper potential overlay.ini: " + sFileOverlay)
        ac.log("AccExtHelper potential cameras_x.ini: " + sFileCameras)

        appSetPositions()
    except:
        ac.log("AccExtHelper: CustomShadersPatch NOT installed or active! Only fps counter will work.")
        ac.setSize(app, 180, 100)
        ac.setPosition(label, 5, 35)
        error = 20
    return "AccExtHelper"

def appToggleDetail(*args):
    global bButtons, btnToggleDetail
    bButtons = not bButtons
    if bButtons:
        ac.setText(btnToggleDetail, "^")
        appWriteCFGValue('apps/python/AccExtHelper/settings/settings.ini', 'GENERAL', 'BUTTONS', 'True', True )
    else:
        ac.setText(btnToggleDetail, "v")
        appWriteCFGValue('apps/python/AccExtHelper/settings/settings.ini', 'GENERAL', 'BUTTONS', 'False', True )
    appSetPositions()

def appToggleTelemetry(*args):
    global bTelemetry, btnToggleTelemetry
    bTelemetry = not bTelemetry
    if bTelemetry:
        ac.setText(btnToggleTelemetry, "T")
        appWriteCFGValue('apps/python/AccExtHelper/settings/settings.ini', 'GENERAL', 'TELEMETRY', 'True', True )
    else:
        ac.setText(btnToggleTelemetry, "t")
        appWriteCFGValue('apps/python/AccExtHelper/settings/settings.ini', 'GENERAL', 'TELEMETRY', 'False', True )
    appSetPositions()

def appGetNumberedFilename(sBase, sExt):
    try:
        newname=sBase + sExt
        i=1
        while os.path.isfile(newname) and i<20:
            newname = sBase + '_' + str(i) + sExt
            i+=1
        if i>=20:
            return ''
        return newname
    except:
        ac.log("AccExtHelper: " + traceback.format_exc())


#####################################################################

def str2bool(v):
    try:
        return str(v).strip().lower() in ("yes", "true", "t", "1")
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

def bool2str(v):
    return 'on' if v else 'off'

def getSettingsValue(parser, section, option, value, boolean = False):
    if parser.has_option(str(section), str(option)):
        if boolean:
            return parser.getboolean(str(section), option)
        else:
            return parser.get(str(section), str(option))
    else:
        if boolean:
            return str2bool(str(value))
        else:
            return str(value)

def setHotKeys(settingsParser):
    global hotKeyListener
    global gEnableHotKeys, hotKeyFOVminus, hotKeyFOVplus, hotKeyFOVplusplus, hotKeyFOVminusminus, gModifier, hotKeyReset, hotKeyStepBack, hotKeyDriver, hotKeyDoor, hotKeyCopy
    try:
        if gEnableHotKeys==True:
            if settingsParser!=None:
                gModifier          = str(getSettingsValue(settingsParser, "SHORTCUTS", "uiModifier"           , gModifier       , False)).strip().upper()
                hotKeyFOVminusminus= str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyFOVminusminus"  , hotKeyFOVminusminus , False)).strip().upper()
                hotKeyFOVminus     = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyFOVminus"       , hotKeyFOVminus , False)).strip().upper()
                hotKeyFOVplus      = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyFOVplus"        , hotKeyFOVplus , False)).strip().upper()
                hotKeyFOVplusplus  = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyFOVplusplus"    , hotKeyFOVplusplus , False)).strip().upper()
                hotKeyReset        = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyReset"          , hotKeyReset , False)).strip().upper()
                hotKeyStepBack     = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyStepBack"       , hotKeyStepBack , False)).strip().upper()
                hotKeyDriver       = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyDriver"         , hotKeyDriver , False)).strip().upper()
                hotKeyDoor         = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyDoor"           , hotKeyDoor , False)).strip().upper()
                hotKeyCopy         = str(getSettingsValue(settingsParser, "SHORTCUTS", "hotKeyCopy"           , hotKeyCopy , False)).strip().upper()
            else:
                ac.log('settingsParser empty' )

            hotKeyListener = threading.Thread(target=listen_key)
            hotKeyListener.daemon = True
            hotKeyListener.start()
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())
        ac.console('AccExtHelper error: ' + traceback.format_exc())

def listen_key():
    global gModifier, hotKeyFOVminus, hotKeyFOVplus, hotKeyFOVplusplus, hotKeyFOVminusminus, hotKeyStepBack, hotKeyReset, hotKeyDriver, hotKeyDoor, hotKeyCopy
    try:
        byref = ctypes.byref
        user32 = ctypes.windll.user32
        lMod = 0
        if 'ALT' in gModifier:
            lMod = lMod | win32con.MOD_ALT
        if 'CTRL' in gModifier:
            lMod = lMod | win32con.MOD_CONTROL
        if 'SHIFT' in gModifier:
            lMod = lMod | win32con.MOD_SHIFT
        if 'WIN' in gModifier:
            lMod = lMod | win32con.MOD_WIN

        def handle_1():
            appFOVminus()
        def handle_2():
            appFOVplus()
        def handle_3():
            appFOVminusminus()
        def handle_4():
            appFOVplusplus()
        def handle_5():
            onresetCar()
        def handle_6():
            takeAStepBack()
        def handle_7():
            driverToggle()
        def handle_8():
            doorToggle()
        def handle_9():
            copyCameraCoords()

        HOTKEY_ACTIONS = {}
        HOTKEYS = {}
        if hotKeyFOVminus != '':
            HOTKEYS[1 ] =  (ord(hotKeyFOVminus), lMod)
            HOTKEY_ACTIONS[1] = handle_1
        if hotKeyFOVplus != '':
            HOTKEYS[2 ] =  (ord(hotKeyFOVplus), lMod)
            HOTKEY_ACTIONS[2] = handle_2
        if hotKeyFOVminusminus != '':
            HOTKEYS[3 ] =  (ord(hotKeyFOVminusminus), lMod)
            HOTKEY_ACTIONS[3] = handle_3
        if hotKeyFOVplusplus != '':
            HOTKEYS[4 ] =  (ord(hotKeyFOVplusplus), lMod)
            HOTKEY_ACTIONS[4] = handle_4
        if hotKeyReset != '':
            HOTKEYS[5 ] =  (ord(hotKeyReset), lMod)
            HOTKEY_ACTIONS[5] = handle_5
        if hotKeyStepBack != '':
            HOTKEYS[6 ] =  (ord(hotKeyStepBack), lMod)
            HOTKEY_ACTIONS[6] = handle_6
        if hotKeyDriver != '':
            HOTKEYS[7 ] =  (ord(hotKeyDriver), lMod)
            HOTKEY_ACTIONS[7] = handle_7
        if hotKeyDoor != '':
            HOTKEYS[8 ] =  (ord(hotKeyDoor), lMod)
            HOTKEY_ACTIONS[8] = handle_8
        if hotKeyCopy != '':
            HOTKEYS[9 ] =  (ord(hotKeyCopy), lMod)
            HOTKEY_ACTIONS[9] = handle_9

        try:
            sok=''
            sfail=''
            #ac.log('hotkeys: ' + str(len(HOTKEYS.items())))
            for id, (vk, modifiers) in HOTKEYS.items():
                if not user32.RegisterHotKey(None, id, modifiers, vk):
                    sfail += "  " + str(gModifier) + '+' + chr(vk)
                    #break
                else:
                    sok   += "  " + str(gModifier) + '+' + chr(vk)
            if sok!='':
                ac.console("AccExtHelper registered Hotkeys: " + sok)
                ac.log("AccExtHelper registered Hotkeys: " + sok)
            if sfail!='':
                ac.console("AccExtHelper Hotkeys NOT registered: " + sfail)
                ac.log("AccExtHelper Hotkeys NOT registered: " + sfail)

            global hWnd, buf, achWnd
            msg = ctypes.wintypes.MSG()
            while user32.GetMessageA(byref(msg), None, 0, 0) != 0:
                hWnd = user32.GetForegroundWindow(None) # Once you have the HWND you can call
                if achWnd == -1:
                    s = user32.GetWindowTextW(hWnd,buf,ctypes.wintypes.MAX_PATH)
                    if "Assetto Corsa" in buf.value:
                        achWnd = hWnd
                if hWnd == achWnd and msg.message == win32con.WM_HOTKEY:
                    action_to_take = HOTKEY_ACTIONS.get(msg.wParam)
                    if action_to_take:
                        action_to_take()
                user32.TranslateMessage(byref(msg))
                user32.DispatchMessageA(byref(msg))
                #time.sleep(0.05)
                time.sleep(0.126)
        except:
            ac.log("AccExtHelper error: " + traceback.format_exc())
            ac.console('AccExtHelper error: ' + traceback.format_exc())
        finally:
            for id in HOTKEYS.keys():
                user32.UnregisterHotKey(None, id)
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())
        ac.console('AccExtHelper error: ' + traceback.format_exc())

def doorToggle(*args):
    global areDoorsOpen
    try:
        areDoorsOpen = not areDoorsOpen
        ac.ext_setDoorsOpen(areDoorsOpen)
        ac.ext_setTrackConditionInput('CAR_DOORS_OPENED', 1.0 if areDoorsOpen else 0.0)
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

def driverToggle(*args):
    global isDriverVisible
    try:
        isDriverVisible = not isDriverVisible
        ac.ext_setDriverVisible(isDriverVisible)
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

def vaoToggle(*args):
    global isVaoActive, currentVaoDebugMode
    try:
        isVaoActive = not isVaoActive
        currentVaoDebugMode = 0
        ac.ext_setVaoActive(isVaoActive)
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

def vaoDebug(*args):
    global isVaoActive, currentVaoDebugMode
    try:
        isVaoActive = False
        if currentVaoDebugMode == 1:
            ac.ext_vaoNormalDebug()
            currentVaoDebugMode = 2
        else:
            ac.ext_vaoOnly()
            currentVaoDebugMode = 1
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

class LightsDebugMode:
    Off = 0
    Outline = 1
    BoundingBox = 2
    BoundingSphere = 4
    Text = 8

def lightsDebug(*args):
    global isLightsDebugOn
    try:
        isLightsDebugOn = not isLightsDebugOn
        if isLightsDebugOn:
            lightsDebugCount = 20
            lightsDebugDistance = 200.0
            lightsDebugMode = LightsDebugMode.Outline | LightsDebugMode.BoundingBox
            # | LightsDebugMode.Text
            ac.ext_debugLights("?", lightsDebugCount, lightsDebugDistance, lightsDebugMode)
        else:
            ac.ext_debugLights("?", 0, 0, 0)
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

def takeAStepBack(*args):
    global timerMsg, btimerMsg, app
    try:
        timerMsg = 1.25
        btimerMsg = True
        ac.setTitle(app, "  STEP BACK - 'New AI Behaviour' on?")
        ac.ext_takeAStepBack(300)
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

def onresetCar(*args):
    global timerMsg, btimerMsg, app
    try:
        ac.ext_resetCar()
        timerMsg = 2.0
        btimerMsg = True
        ac.setTitle(app, "  RESET - 'New AI Behaviour' on?")
    except:
        ac.log("AccExtHelper error:" + traceback.format_exc())

def __init__():
    global tick_counter, max_tick, frame_counter, frame_buffer, time_elapsed, current_fps, MAX_fps, MIN_fps, MAX_lights, MIN_lights
    global bWrittenOverlaysINI, bRecordTimeAttack, previousSector, bWrittenCamerasINI, appMsg, bRecordCameras, firstCamPos, firstOrientation, firstOrientationALT
    global lastPoT, camCount, checkpointC
    global btnResetCar, btnSetBackCar, btnTimeAttack, btnCameraAdd
    global slMinfov, slMaxfov, cbFixed
    global sLayout, bAutoCamON, bAutoCam, sOVERLAYS_INI

    try:
        #ac.log('exthelper init')
        bWrittenCamerasINI = False
        bRecordCameras = False
        bRecordTimeAttack = False
        bAutoCamON = False
        bAutoCam = False
        firstCamPos = ''
        firstOrientation = ''
        firstOrientationALT = ''
        lastPoT=0.5
        camCount=0
        sOVERLAYS_INI = ''

        tick_counter = 0
        max_tick = 360
        frame_counter = 0
        frame_buffer = 20
        time_elapsed = 0
        current_fps = 0
        MAX_fps = 0
        MIN_fps = 5000
        MAX_lights = 0
        MIN_lights = 100000
        previousSector = -1
        checkpointC = 0
        if btnResetCar!=0:
            ac.setVisible(btnResetCar   , True)
            ac.setVisible(btnSetBackCar , True)
            ac.setVisible(btnTimeAttack , True)
            ac.setVisible(btnCameraAdd  , True)
            ac.setVisible(btnCameraAuto , True)
            ac.setVisible(slMinfov, False)
            ac.setVisible(slMaxfov, False)
            ac.setVisible(cbFixed , False)
            # build new filename
            if sLayout=='':
                sFileCameras = appGetNumberedFilename('content/tracks/' + sTrack+            '/data/cameras', '.ini')
            else:
                sFileCameras = appGetNumberedFilename('content/tracks/' + sTrack+'/'+sLayout+'/data/cameras', '.ini')
            if sFileCameras!='':
                ac.setText(btnCameraAdd, "new '" + os.path.basename(sFileCameras) + "'")
                ac.setText(btnCameraAuto, "new auto '" + os.path.basename(sFileCameras) + "'")
    except:
        ac.log("AccExtHelper: " + traceback.format_exc())

def doReset(*args):
    __init__()
    appSetPositions()

def get_frames_per_second(deltaT):
    global tick_counter, max_tick, frame_counter, frame_buffer, time_elapsed, current_fps, MAX_fps, MIN_fps, MAX_lights, MIN_lights
    frame_counter += 1
    time_elapsed += deltaT
    if frame_counter == frame_buffer:
        # calculating frames per second
        current_fps = frame_buffer / time_elapsed
        if current_fps>MAX_fps:
            MAX_fps=current_fps
        if current_fps<MIN_fps:
            MIN_fps=current_fps
        # calculating max_tick for animations
        # number of fps multiplied by 3 seconds
        max_tick = current_fps * 3 if current_fps * 3 > 30 else 30
        # reseting counters
        frame_counter = 0
        time_elapsed = 0


def acUpdate(delta_t):
    global error, timer, timer2, appMsg, label, timerMsg, btimerMsg, app
    global tick_counter, max_tick, frame_counter, frame_buffer, time_elapsed, current_fps, MAX_fps, MIN_fps, MAX_lights, MIN_lights
    global odd, lx, ly, lz, lastFrom, sVer, currentSector, sCamCoords, sOrientationFORW, checkpointC, bButtons, sOrientationFORWtimeattack
    global previousSector, sOVERLAYS_INI, sFileOverlay, bWrittenOverlaysINI, bRecordTimeAttack, iCheckpointHeight, bWrittenCamerasINI, bRecordCameras, sFileCameras
    global slMinfov, slMaxfov, cbFixed, bAutoCamON, bAutoCam, camCount
    global btnResetCar, btnSetBackCar, btnTimeAttack, btnCameraAdd, btnCameraAuto, lastSessonTime, lastLap, lastTime
    global currPoTCalced, passedRoadLen, LenDiv, lastPoT, currCar, sOrientationUP, sCSVspline
    global lastAltitude, currAltitude, initdone
    global s_AI_CAR_dirs, dataupdateTime, joystickid, joystickbuttonreset, justPressed, joystickbuttonstepback
    try:
        timer += delta_t
        #timer2 += delta_t
        get_frames_per_second(delta_t)
        # if timer2 > 0.05:
        #     timer2 = 0.0

        if btimerMsg:
            timerMsg -= delta_t
            if timerMsg<=0.0:
                btimerMsg = False
                if bButtons:
                    ac.setTitle(app, "  Shaders Patch Debug adv")
                else:
                    ac.setTitle(app, "")

        if timer > dataupdateTime:
            timer = 0.0
            currCar = ac.getFocusedCar()
            currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)

            if bButtons:
                ac.drawBorder(app, 0)
                ac.setBackgroundOpacity(app, 1)
            else:
                ac.drawBorder(app, 0)
                ac.setBackgroundOpacity(app, 0)

            # CheckDriverAgainstAIline(currCar)

            #if  and not justPressed and not btimerMsg:
            # if ac.ext_isJoystickButtonPressed(joystickid,joystickbuttonreset):
            if  joystickid>-1 and not justPressed and error<2:
                if ac.ext_isJoystickButtonPressed(joystickid,joystickbuttonreset):
                    justPressed = True
                    onresetCar()
                elif ac.ext_isJoystickButtonPressed(joystickid,joystickbuttonstepback):
                    justPressed = True
                    takeAStepBack()
                else:
                    justPressed = False



            if error<1:
                campos = ', '.join(str(round(x, 2)) for x in ac.ext_getCameraPos())
                camposXYZ = campos.split(',')
                dx = round(lx-float(camposXYZ[0]),2)
                dy = round(ly-float(camposXYZ[1]),2)
                dz = round(lz-float(camposXYZ[2]),2)
                dist = math.pow( dx*dx+dy*dy+dz*dz, 0.5)
                if dist>75000:
                    dist=0

                currentSector = int(info.graphics.currentSectorIndex)
                if currentSector-1 != previousSector and not bRecordTimeAttack and not bRecordCameras:
                    previousSector = currentSector

                xw, yw, zw = ac.getCarState(currCar, acsys.CS.WorldPosition)
                camview1 = ', '.join(str(round(x, 2)) for x in ac.ext_getCameraView()) # 4x4 float values
                camview = camview1.split(',')
                # FORWARD
                # sOrientationFORW    = str(round(-float(camview[2]), 3) ) + ", " + str(round(-float(camview[6]), 3)) + ", " + str(round(-float(camview[10]), 3))
                sOrientationFORW           = str(round(float(camview[2]), 2) ) + ", " + str(round(float(camview[6]), 2)) + ", " + str(round(float(camview[10]), 2))
                sOrientationFORW           = sOrientationFORW.replace('--','')     ####   lol   (-1)*(-1) = 1
                sOrientationFORWtimeattack = str(round(-float(camview[2]), 2) ) + ", " + str(round(-float(camview[6]), 2)) + ", " + str(round(-float(camview[10]), 2))
                sOrientationFORWtimeattack = sOrientationFORW.replace('--','')     ####   lol   (-1)*(-1) = 1
                # UP
                sOrientationUP = str( round(float(camview[1]), 2)) + ", " + str( round(float(camview[5]), 2)) + ", " + str( round(float(camview[ 9]), 2))

                lastAltitude = currAltitude
                currAltitude = ac.ext_getAltitude(0)
                cammode  = ac.getCameraMode()
                lightscars = ac.ext_getCarLightsNum()
                lightstrack = ac.ext_getTrackLightsNum()
                lightsvis = ac.ext_getLightsVisible()
                if lightsvis>MAX_lights:
                    MAX_lights=lightsvis
                if lightsvis<MIN_lights:
                    MIN_lights=lightsvis

                if bButtons:

                    sLabel = ("CSP v" + sVer
                            + "\nFPS     (" + str(int(MIN_fps)) + "˅ ˄" + str(int(MAX_fps)) + "):    " + str(round(current_fps,2))
                            + "\nLights trk/cars/mirr: " + str(lightstrack) + ' / ' + str(lightscars) + ' / ' + str(ac.ext_getLightsMirrorVisible() )
                            + "\n  🔦 visible (" + str(int(MIN_lights)) + "˅˄" + str(int(MAX_lights)) + "):   -   " + str(int(lightsvis))
                            + "\nFOV: " + str(int(ac.ext_getCameraFov()))
                            + "\nPoT: " + str(round(currPoT,5))
                            + "\n⌻ Cam:  " + campos
                            # + "\n" + s_AI_CAR_dirs

                            # all 16 camview values in one line
                            #+ "\ncamera view: " +  ', '.join(str(round(x, 4)) for x in ac.ext_getCameraView())

                            # camview values in 4 lines
                            #+ "\n" + str(camview[ 0]).strip() + "    " + str(camview[ 1]).strip() + "    " + str(camview[ 2]).strip() + "    " + str(camview[ 3]).strip()
                            #+ "\n" + str(camview[ 4]).strip() + "    " + str(camview[ 5]).strip() + "    " + str(camview[ 6]).strip() + "    " + str(camview[ 7]).strip()
                            #+ "\n" + str(camview[ 8]).strip() + "    " + str(camview[ 9]).strip() + "    " + str(camview[10]).strip() + "    " + str(camview[11]).strip()
                            #+ "\n" + str(camview[12]).strip() + "    " + str(camview[13]).strip() + "    " + str(camview[14]).strip() + "    " + str(camview[15]).strip()

                            #+ "\ncamera matr: " +  ', '.join(str(round(x, 4)) for x in ac.ext_getCameraMatrix())
                            #+ "\ncamera proj: " +  ', '.join(str(round(x, 4)) for x in ac.ext_getCameraProj())
                    )
                    if bTelemetry:
                        sLabel = (sLabel
                            + "\n   Cam Fwd:  " + sOrientationFORW
                            + "\n   Cam Up :  " + sOrientationUP
                            + "\nrel2car: " + ', '.join(str(round(x, 2)) for x in ac.ext_getCameraPositionRelativeToCar())
                            # + "\n" + str(camview[0]).strip() + ", " + str(camview[1]).strip() + ", " + str(camview[2]).strip() + ", " + str(camview[3]).strip() + ", " + str(camview[4]).strip() + ", " + str(camview[5]).strip()  + ", " + str(camview[6]).strip() + ", " + str(camview[7]).strip() + ", " + str(camview[8]).strip()+ ", " + str(camview[9]).strip()
                            # same + "\nORIENTATION: " + str(round(camview[8], 8)) + str(round(camview[6], 8)) + str(round(camview[10], 8))
                            + "\n-xyz-diff : " + str(round(dx,1)) + " | " + str(round(dy,1)) + " | "+ str(round(dz,1))
                            + "\n-dist2last cam: " + str(round(dist,4))
                            + "\nCar xyz:   " + str(round(xw,1)) + ' | ' + str(round(yw,1)) + ' | ' + str(round(zw,1))
                            + "\n--dist. traveled in m: " + str(round(info.graphics.distanceTraveled,2))
                            # + "\nCentric force:" + str(round(ac.ext_getAngleSpeed(), 3))
                            + "\n--baseAltitude in m: " + str(round(ac.ext_getBaseAltitude(0), 1))
                            + "\n--Altitude in m: " + str(round(currAltitude, 1))
                            + "\nAmbient darkness: " + str(round(ac.ext_getAmbientMult(), 5))
                            # + "\n" + s_AI_CAR_dirs
                            # + "\ntyres vkm: " + str(round(ac.ext_getTyreVirtualKM(), 3))
                            #+ "\ntyre flatspots:  "            + str(round(ac.ext_getTyreFlatSpot(0, 0)*100, 3)) + ' -f- ' + str(round(ac.ext_getTyreFlatSpot(0, 1)*100, 3))
                            #+ "\n                        "     + str(round(ac.ext_getTyreFlatSpot(0, 2)*100, 3)) + ' -r- ' + str(round(ac.ext_getTyreFlatSpot(0, 3)*100, 3))
                            #+ "\ntyre blister:     "           + str(round(ac.ext_getTyreBlister (0, 0)*100, 3)) + ' -f- ' + str(round(ac.ext_getTyreBlister (0, 1)*100, 3))
                            #+ "\n                        "     + str(round(ac.ext_getTyreBlister (0, 2)*100, 3)) + ' -r- ' + str(round(ac.ext_getTyreBlister (0, 3)*100, 3))
                            #+ "\ntyre grain:       "           + str(round(ac.ext_getTyreGrain   (0, 0)*100, 3)) + ' -f- ' + str(round(ac.ext_getTyreGrain   (0, 1)*100, 3))
                            #+ "\n                        "     + str(round(ac.ext_getTyreGrain   (0, 2)*100, 3)) + ' -r- ' + str(round(ac.ext_getTyreGrain   (0, 3)*100, 3))
                            #+ "\nsector: " + str(info.static.sectorCount)
                            #+ "\nmaxtorque: " + str(info.static.maxTorque)
                            #+ "\nturbo: " + str(info.static.maxTurboBoost)
                            # + "\ntyre pressure: " + str(round(acsys.CS.DynamicPressure, 4))
                            # + "\nfinalFF: " + str(round(info.physics.finalFF, 2))
                            # + "\nperfMtr: " + str(round(info.physics.performanceMeter, 2))
                            # + "\ncamtype: " + str(cammode)
                            # + "\ntrack - " + sTrack
                            # + "\nlayout - " + sLayout
                            # + "\nbrakeBias: " + str(round(brakebias,2))
                            #+ "\nairDensity: " + str(airDensity)
                            #+ "\nturboBoost: " + str(turboBoost)
                            #+ "\nsessTime: " + str(info.graphics.sessionTimeLeft)
                            #+ "\nlapTime: " + str(ac.getCarState(currCar, acsys.CS.LapTime))
                            #+ "\nfinished: " + str(ac.getCarState(currCar, acsys.CS.RaceFinished))
                            #+ "\nsector: " + str(currentSector) + " - last: " + str(previousSector)   + " - " + str(info.graphics.split)  #  + " - lastsplit: " + str(lastSplit)
                            # + "\n" + sCurrCam
                        )
                else:
                    campos = ', '.join(str(round(x, 2)) for x in ac.ext_getCameraPos())
                    sLabel = (""
                        + "\n🔦 " + str(lightsvis) + " (" + str(lightstrack+lightscars) + ")  FPS (" + str(int(MIN_fps)) + ") " + str(round(current_fps,2))
                        + "\n⌻ Cam:  " + campos
                        + "\nCurr PoT:   "                 + str(round(currPoT,5))
                    )
                    if bTelemetry:
                        sLabel = (sLabel
                            # + "\ntyre pressure: " + str(round(acsys.CS.DynamicPressure, 4))
                            # + "\nfinalFF: " + str(round(info.physics.finalFF, 2))
                            # + "\nperfMtr: " + str(round(info.physics.performanceMeter, 2))
                            # + "\n" + str(camview[0]).strip() + ", " + str(camview[1]).strip() + ", " + str(camview[2]).strip() + ", " + str(camview[3]).strip() + ", " + str(camview[4]).strip() + ", " + str(camview[5]).strip()  + ", " + str(camview[7]).strip() + ", " + str(camview[9]).strip()
                            # + "\ncamtype: " + str(cammode)
                            # + "\ntrack: " + sTrack + "  - layout: " + sLayout
                            # + "\nbrakeBias: " + str(round(brakebias,2))
                            #+ "\nairDensity: " + str(airDensity)
                            #+ "\nturboBoost: " + str(turboBoost)
                            + "\ntyre flatspots:  "            + str(round(ac.ext_getTyreFlatSpot(0, 0)*100, 3)) + ' -f- ' + str(round(ac.ext_getTyreFlatSpot(0, 1)*100, 3))
                            + "\n                        "     + str(round(ac.ext_getTyreFlatSpot(0, 2)*100, 3)) + ' -r- ' + str(round(ac.ext_getTyreFlatSpot(0, 3)*100, 3))
                            + "\ntyre blister:     "           + str(round(ac.ext_getTyreBlister (0, 0)*100, 3)) + ' -f- ' + str(round(ac.ext_getTyreBlister (0, 1)*100, 3))
                            + "\n                        "     + str(round(ac.ext_getTyreBlister (0, 2)*100, 3)) + ' -r- ' + str(round(ac.ext_getTyreBlister (0, 3)*100, 3))
                            + "\ntyre grain:       "           + str(round(ac.ext_getTyreGrain   (0, 0)*100, 3)) + ' -f- ' + str(round(ac.ext_getTyreGrain   (0, 1)*100, 3))
                            + "\n                        "     + str(round(ac.ext_getTyreGrain   (0, 2)*100, 3)) + ' -r- ' + str(round(ac.ext_getTyreGrain   (0, 3)*100, 3))
                        )

                if bAutoCam and not bRecordTimeAttack:
                    currentSessonTime = info.graphics.sessionTimeLeft
                    currentTime = ac.getCarState(currCar, acsys.CS.LapTime)

                    # if lastLap < currentLap and currentTime > 0.05 and lastTime > currentTime:
                    if currentTime > lastTime and currentTime > 0.05:
                        # new lap # before running above s/f timer is not started
                        # lastLap = currentLap
                        if not bAutoCamON:
                            bAutoCamON = True

                    if bAutoCamON:   #  and currPoT*LenDiv > lastPoT:
                        if lastTime < currentTime:
                            appCheckAILine(currPoT)
                        else:
                            # finish auto cameras.ini
                            ac.log('new lap - auto: ' + str(bAutoCamON) )
                            bAutoCamON = False
                            bWrittenCamerasINI = True
                            if camCount>0:
                                with io.open(sFileCameras, 'w', encoding='utf-8') as f:
                                    f.write(sCameras)
                                appWriteCFGValue(sFileCameras, 'HEADER', 'CAMERA_COUNT', str(camCount) )
                                appWriteCFGValue(sFileCameras, 'CAMERA_'+str(camCount-1), 'OUT_POINT', '1.0' )

                                #### temporary fix ####
                                config = configparser.ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","#","/",), comment_prefixes=(";","#","/",), strict=False, allow_no_value=True)
                                config.optionxform = str   # keep Case
                                with open(sFileCameras, "r", encoding="utf-8", errors="ignore") as F:
                                    config.read_string(F.read().encode('ascii', 'ignore').decode('ascii'))

                                sval=str(round( 1- (1-float( config['CAMERA_'+str(camCount-2)]['IN_POINT'] ))/2 , 5))
                                # ac.log(sval)
                                config['CAMERA_'+str(camCount-2)]['OUT_POINT'] =sval
                                config['CAMERA_'+str(camCount-1)]['IN_POINT' ] =sval
                                config['CAMERA_'+str(camCount-1)]['OUT_POINT'] ='1.0'
                                with open(sFileCameras, 'w') as configfile:
                                    config.write(configfile, space_around_delimiters=False)
                                #### temporary fix ####

                                __init__()
                                appSetPositions()
                    else:
                        lastPoT = currPoT # when recording its calc'ed in appCheckAILine()

                    lastTime = currentTime

                elif bRecordTimeAttack:
                    sCamCoords = str(round(xw,5)) + ', ' + str(round(yw,5)) + ', ' + str(round(zw,5))
                    currentLap        = ac.getCarState(currCar, acsys.CS.LapCount)
                    currentTime       = ac.getCarState(currCar, acsys.CS.LapTime)
                    currentSessonTime = info.graphics.sessionTimeLeft
                    # currentLap      = info.graphics.numberOfLaps

                    # if currentTime < lastTime and lastLap > currentLap:
                    if currentSessonTime > lastSessonTime:
                        # new session
                        lastLap = -1
                        lastTime = -1.0
                    lastSessonTime = currentSessonTime

                    if bAutoCamON:
                        if info.static.sectorCount>1:
                            if currentSector!=previousSector:
                                if currentSector>0:
                                    appCameraAuto() # in auto mode adds checkpoint
                                previousSector = currentSector
                        else:
                            if currPoT>0.33333 and checkpointC==1:
                                appCameraAuto() # in auto mode adds checkpoint
                            if currPoT>0.66666 and checkpointC==2 and not bWrittenOverlaysINI:
                                appCameraAuto() # in auto mode adds checkpoint

                                # finish auto overlays.ini
                                sOVERLAYS_INI = ("[MAIN]\nOVERLAYS_COUNT=" + str(int(checkpointC)) + sOVERLAYS_INI)
                                currDir = os.path.dirname(os.path.realpath(__file__)).lower().replace('\\','/').replace('/apps/python/accexthelper','') + '/'
                                with io.open(currDir + sFileOverlay, 'w', encoding='utf-8') as f:
                                    f.write(sOVERLAYS_INI)
                                __init__() # reset all , bRecordTimeAttack too
                                appSetPositions()
                                bWrittenOverlaysINI=True
                                bAutoCam=False
                                bAutoCamON=False
                                bRecordTimeAttack=False

                    # if lastLap < currentLap and currentTime > 0.05 and lastTime>currentTime:
                    if currentTime > 0.025 and lastTime>currentTime and lastLap < currentLap:
                        lastLap = currentLap
                        if checkpointC==0:
                            bAutoCamON=True
                            appCameraAuto() # in auto mode adds checkpoint
                        elif info.static.sectorCount>1 and checkpointC == info.static.sectorCount:
                            # finish auto overlays.ini
                            sOVERLAYS_INI = ("[MAIN]\nOVERLAYS_COUNT=" + str(int(checkpointC)) + sOVERLAYS_INI)
                            currDir = os.path.dirname(os.path.realpath(__file__)).lower().replace('\\','/').replace('/apps/python/accexthelper','') + '/'
                            with io.open(currDir + sFileOverlay, 'w', encoding='utf-8') as f:
                                f.write(sOVERLAYS_INI)
                            __init__() # reset all , bRecordTimeAttack too
                            appSetPositions()
                            bWrittenOverlaysINI=True
                            bAutoCam=False
                            bAutoCamON=False
                            bRecordTimeAttack=False

                    lastTime = currentTime


                if bRecordTimeAttack==True:
                    ac.setText(label, "--- recording Checkpoints ---"
                        + "\n  cam-pos & time-gate based"
                        + "\n\nCheckPoints added: " + str(checkpointC) + ' - ' + str(currentSector)
                        + "\n\nplease finish a lap now!"
                        + "\n\nworks best with bumper camera\nyou can use CTRL+C to let AI drive\nfile to be written:\n" + sFileOverlay
                        + "\n" + str(len(sCSVspline)) #+ "\n" + sOVERLAYS_INI
                        )
                elif bRecordCameras==True:
                    ac.setText(label, "\n\n\n\n\nFOV: " + str(int(ac.ext_getCameraFov()))
                        + "\n--- MANUAL recording Cameras ---"
                        + "\n\nCameras added: " + str(camCount)
                        + "\n\ngoto desired cam position, pause replay..."
                        + "\n...when car is about to vanish from view"
                        + "\nthen click button to add this cam"
                        # + "\n\nworks best in REPLAY + free cam mode"
                        + "\n\nfinishes after car is over S/F again (or 'r')"
                        + "\nfile to be written:\n" + sFileCameras
                        + "\n" + str(len(sCSVspline)) #+ "\n" + sOVERLAYS_INI
                        )
                elif bAutoCam==True and not bAutoCamON==True:
                    ac.setText(label, "\n--- AUTO recording Cameras ---"
                        + "\n\nWaiting for S/F line..."
                        + "\n\nfile to be written:\n" + sFileCameras
                        + "\npassed " + str(passedRoadLen)
                        + "\nc pot " + str(currPoT)
                        + "\nl pot " + str(lastPoT)
                        + "\ncalced " + str(currPoTCalced)
                        + "\n" + str(len(sCSVspline)) #+ "\n" + sOVERLAYS_INI
                        )
                elif bAutoCam==True and bAutoCamON==True:
                    ac.setText(label, "\n--- AUTO recording Cameras ---"
                        + "\n\nCameras added: " + str(camCount+1)
                        + "\nfile to be written:\n" + sFileCameras
                        + "\npassed: " + str(passedRoadLen)
                        + "\nc pot " + str(currPoT)
                        + "\nl pot " + str(lastPoT)
                        + "\ncalced " + str(currPoTCalced)
                        + "\n" + str(len(sCSVspline)) #+ "\n" + sOVERLAYS_INI
                        )
                else:
                    if bWrittenOverlaysINI==True:
                        ac.setText(label, appMsg + ' written "' + sFileOverlay + '" !\n\n---Remove "_new" to use in TimeAttack mode !---\n---You already have a "ideal_line.ai" ?\n\n' + sLabel)
                    elif bWrittenCamerasINI==True:
                        ac.setText(label, appMsg + ' written "' + sFileCameras + '" !\n\n' + sLabel)
                    else:
                        ac.setText(label, appMsg + sLabel)

            else:
                ac.setText(label,"FPS (" + str(int(MIN_fps)) + "˅ - ˄" + str(int(MAX_fps)) + "):    " + str(round(current_fps,2)) + "\ncurr PoT:   " + str(round(currPoT,5))
                    + "\n" + str(round(info.graphics.distanceTraveled/1000.0,2)) + ' km'
                    + "  -  csp not active"
                    )

    except:
        ac.log("AccExtHelper: " + traceback.format_exc())
        ac.setText(label,"FPS (" + str(int(MIN_fps)) + "˅ - ˄" + str(int(MAX_fps)) + "):    " + str(round(current_fps,2)) + "\nCSP not active.\n\n" + traceback.format_exc() )
        if error < 10:
            error+=1

    try:
        if (info.graphics.status != 2) and (info.graphics.status != 1):
            if not initdone:
                __init__()  # same as DoReset() pause (= if not live or replay)
                initdone = True
        else:
            initdone = False
    except:
        if error < 10:
            error+=1

def appBuildNextCheckPoint(checkpointC, sCamCoords, sOrientationFORWtimeattack):
    global iCheckpointHeight, iBannerHeight, iBannerWidth, sOrientationUP
    sss = ( "\n\n[CHECKPOINT_" + str(int(checkpointC)) + "]"
          + "\nWORLD_POSITION=" + sCamCoords
          + "\nORIENTATION=" + sOrientationFORWtimeattack
          + "\nOFFSET=0, "  + str(iCheckpointHeight) + ", 0"
          + "\nWIDTH=" + str(iBannerWidth)
          + "\nHEIGHT="+ str(iBannerHeight)
        )
    return sss

def appRecordTimeAttack(*args):
    global bRecordTimeAttack, bWrittenOverlaysINI, previousSector, sTrack, sLayout
    global sOVERLAYS_INI, sCamCoords, sOrientationFORW, currentSector, checkpointC, appMsg
    global btnResetCar, btnSetBackCar, btnTimeAttack, btnCameraAdd, btnCameraAuto

    if bRecordTimeAttack==False:
        # start recording
        ac.setVisible(btnResetCar   , False)
        ac.setVisible(btnSetBackCar, False)
        ac.setVisible(btnTimeAttack , False)
        ac.setVisible(btnCameraAdd , False)
        ac.setVisible(btnCameraAuto , False)
        # ac.setText(btnCameraAuto, "add Checkpoint here")
        bRecordTimeAttack = True
        bWrittenOverlaysINI = False
        previousSector = -1
        # if not there copy /ai/fast_lane.ai to "/data/ideal_line.ai"
        sideal_lineai = 'content/tracks/' + sTrack+'/'
        sfast_laneai = 'content/tracks/' + sTrack+'/'
        if sLayout=='':
            sideal_lineai = sideal_lineai + '/data/ideal_line.ai'
        else:
            sideal_lineai = sideal_lineai + sLayout+'/data/ideal_line.ai'
        if not os.path.isfile(sideal_lineai):
            if sLayout=='':
                sfast_laneai = sfast_laneai + '/ai/fast_lane.ai'
            else:
                sfast_laneai = sfast_laneai + sLayout+'/ai/fast_lane.ai'
            if os.path.isfile(sfast_laneai):
                copyfile(sfast_laneai, sideal_lineai)
                appMsg = "Copied fast_lane.ai to ideal_line.ai"
    else:
        # turn off recording
        bRecordTimeAttack = False
        bWrittenOverlaysINI = False
        previousSector = -1
        sOVERLAYS_INI = ""
        # manually add checkpoint at random pos by user click
        # lol doesnt work
        #sOVERLAYS_INI = (sOVERLAYS_INI + appBuildNextCheckPoint(checkpointC, sCamCoords, sOrientationFORW) )
        #checkpointC+=1
        #ac.ext_pauseFsWatching()
        #with io.open(sFileOverlay, 'w', encoding='utf-8') as f:
        #    f.write(sOVERLAYS_INI)
        #ac.ext_resumeFsWatching()
        #previousSector = currentSector

def acShutdown(*args):
    global camCount, sFileCameras, bWrittenCamerasINI
    if os.path.isfile(sFileCameras) and camCount>0 and not bWrittenCamerasINI:
        # appFinishCamerasINI()
        # os.remove(sFileCameras)
        appWriteCFGValue(sFileCameras, 'HEADER', 'CAMERA_COUNT', str(camCount) )
        appWriteCFGValue(sFileCameras, 'CAMERA_'+str(camCount-1), 'OUT_POINT', '1.0' )
        if os.path.isfile(sFileCameras + '_unfinished.txt'):
            # remove if already there or else renaming could fail
            os.remove(sFileCameras + '_unfinished.txt')
        os.rename(sFileCameras, sFileCameras + '_unfinished.txt')
        ac.log('AccExtHelper: renamed unfinished camera file to \n '+ sFileCameras + '_unfinished.txt')
    return

def appCameraAuto(*args):
    global bAutoCam, appMsg, AI_LINE, sOVERLAYS_INI
    global slMinfov, slMaxfov, cbFixed, btnResetCar, btnSetBackCar, btnTimeAttack, LenDiv, bRecordTimeAttack, sCamCoords, sOrientationFORW, checkpointC
    global lastPoT, currPoT, currCar, lastTime, lastSessonTime, sOrientationFORWtimeattack
    if bRecordTimeAttack:
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        lastPoT = currPoT
        # lastTime       = ac.getCarState(currCar, acsys.CS.LapTime)
        # lastSessonTime = info.graphics.sessionTimeLeft
        sOVERLAYS_INI = (sOVERLAYS_INI + appBuildNextCheckPoint(checkpointC, sCamCoords, sOrientationFORWtimeattack) )
        checkpointC += 1
    else:
        if len(AI_LINE)/LenDiv > 0:
            bAutoCam=True
            ac.setVisible(slMinfov, False)
            ac.setVisible(slMaxfov, False)
            ac.setVisible(cbFixed , False)
            ac.setVisible(btnResetCar   , False)
            ac.setVisible(btnSetBackCar, False)
            ac.setVisible(btnTimeAttack , False)
            ac.setVisible(btnCameraAdd , False)
            ac.setVisible(btnCameraAuto , False)
            appSetPositions()
        else:
            appMsg="NO '/data/fast_lane.ai' found or broken\n"

def appCameraAdd(*args):
    global sTrack, sLayout, sFileCameras, camCount, lastPoT, firstCamPos, firstOrientation, firstOrientationALT, firstFOV, bRecordCameras
    global slMinfov, slMaxfov, cbFixed, currCar
    global btnResetCar, btnSetBackCar, btnTimeAttack, btnCameraAdd, btnCameraAuto, bWrittenCamerasINI, sOrientationUP
    try:
        if bRecordCameras==False:
            bWrittenCamerasINI = False
            bRecordCameras=True
            camCount = 0
            ac.setText(btnCameraAdd, "add S/F camera")
            ac.setVisible(slMinfov, True)
            ac.setVisible(slMaxfov, True)
            ac.setVisible(cbFixed , True)
            ac.setVisible(btnResetCar   , False)
            ac.setVisible(btnSetBackCar, False)
            ac.setVisible(btnTimeAttack , False)
        else:
            sFOV = str(int(ac.ext_getCameraFov()))
            currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
            s = ", ".join(str(round(x, 5)) for x in ac.ext_getCameraPos())
            sf = s.split(",")
            x = sf[0]
            y = sf[1]
            z = sf[2]
            dx = round(lx-float(sf[0]),5)
            dy = round(ly-float(sf[1]),5)
            dz = round(lz-float(sf[2]),5)
            camview1 = ', '.join(str(round(x, 5)) for x in ac.ext_getCameraView())
            camview = camview1.split(',')
            sOrientationFORW    = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
            # sOrientationFORW    = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
            sOrientationFORW    = sOrientationFORW.replace('--','')     ####   lol   (-1)*(-1) = 1
            sOrientationUP = str( float(camview[1])) + ", " + str( float(camview[5])) + ", " + str( float(camview[ 9]))

            if float(lastPoT) > float(currPoT) and camCount>0:
                # now we gone over s/f again, finish up cameras.ini
                sCameras = ''
                try:
                    with io.open(sFileCameras, 'r', encoding='utf-8') as f:
                        sCameras = f.read()
                    sCameras = sCameras + '\n'
                except:
                    ac.log("AccExtHelper error: " + traceback.format_exc())
                ac.ext_pauseFsWatching()
                with io.open(sFileCameras, 'w', encoding='utf-8') as f:
                    f.write(sCameras + buildCameraEntry(camCount, s, sOrientationFORW, sOrientationUP, sFOV, lastPoT, 1.0)  )

                # finish cameras.ini
                appWriteCFGValue(sFileCameras, 'HEADER', 'CAMERA_COUNT', str(camCount+1) )

                ac.ext_resumeFsWatching()

                appMsg = "Finished '" + os.path.basename(sFileCameras) + "' written with " + str(camCount) + " cameras"
                bWrittenCamerasINI = True
                bRecordCameras=False
                camCount = 0
                # build new filename
                if sLayout=='':
                    sFileCameras = appGetNumberedFilename('content/tracks/' + sTrack+'/'+'data/cameras','.ini')
                else:
                    sFileCameras = appGetNumberedFilename('content/tracks/' + sTrack+'/'+sLayout+'/data/cameras', '.ini')
                ac.setText(btnCameraAdd, "new '" + os.path.basename(sFileCameras) + "'")

                ac.setVisible(slMinfov, False)
                ac.setVisible(slMaxfov, False)
                ac.setVisible(cbFixed , False)
                ac.setVisible(btnResetCar, True)
                ac.setVisible(btnSetBackCar, True)
                ac.setVisible(btnTimeAttack, True)
                firstCamPos = ''
                firstOrientation = ''
                firstOrientationALT = ''
                lastPoT=0.0
                camCount=0
            else:

                ac.ext_pauseFsWatching()
                sCameras=''
                if os.path.isfile(sFileCameras): # read whats already there
                    try:
                        with io.open(sFileCameras, 'r', encoding='utf-8') as f:
                            sCameras = f.read()
                        sCameras = sCameras + '\n'
                    except:
                        ac.log("AccExtHelper error: " + traceback.format_exc())
                else:
                    sCameras = '[HEADER]\nVERSION=3\nCAMERA_COUNT=0\nSET_NAME=' + os.path.basename(sFileCameras) + '\n\n'
                with io.open(sFileCameras, 'w', encoding='utf-8') as f:
                    f.write(sCameras + buildCameraEntry(camCount, s, sOrientationFORW, sOrientationUP, sFOV, lastPoT, currPoT)  )
                ac.ext_resumeFsWatching()

                if firstCamPos=='':
                    firstCamPos = s
                    firstOrientation = sOrientationFORW
                    firstOrientationALT = sOrientationUP
                    firstFOV = sFOV
                appMsg = "Added " + str(camCount) + " camera(s)"
                camCount = camCount + 1
                ac.setText(btnCameraAdd, "add camera #" + str(camCount+1) )
                lastPoT = currPoT

    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

#######################################################

def isASCII(data):
    try:
        data.encode('ascii', 'ignore').decode('ascii').strip()
    except UnicodeDecodeError:
        return False
    else:
        return True

def find_str(s, char):
    index = 0
    if len(char)>0 and char in s:
        c = char[0]
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index
            index += 1
    return -1

def appWriteCFGValue(path, section, valname, value, createNonExistant=False):
    global lbChng
    try:
        if not os.path.isfile(path) and createNonExistant:
            with io.open(path, 'w', encoding='utf-8') as f:
                f.write('; created by AccExtHelper app\n['+section+']\n'+valname+'='+str(value)+'\n')
                # ac.log('settings cleaned')
            return
        if os.path.isfile(path):
            with io.open(path, 'r', encoding='utf-8') as f:
                s=f.read()
            #ac.log('first: \n' + s + '\n\n\n\n\n')
            currsection = ''
            t = ''
            idx = -1
            sectid = -1
            found = False
            sEqual = ' = ' if '.lua' in str(path).lower() else '='
            ss = str(s).split('\n')
            for sss in ss:
                idx+=1
                if find_str(sss, '--')!=0 and find_str(sss, ';')!=0 and find_str(sss, '#')!=0:
                    if find_str(sss, '[')==0 and (']' in sss):
                        currsection = sss.split('[')[1].split(']')[0]
                    if find_str(sss, '['+section+']')==0:
                        sectid = idx
                    if find_str(sss, valname)==0 and currsection==section:
                        # ss[idx] = valname + ' = ' + str(value)
                        iFound=0
                        if '--' in sss:
                            iFound = find_str(sss,'--')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        elif ';' in sss:
                            iFound = find_str(sss,';')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        elif '#' in sss:
                            iFound = find_str(sss,'#')
                            if iFound<=len(sss):
                                ss[idx] = valname + sEqual + str(value) + ' '+ sss[int(iFound):]   # slice sss
                        else:
                            ss[idx] = valname + sEqual + str(value)
                        vname = sss[int(iFound):].split('=')[0]
                        if vname == valname:
                            found = True

                else:
                    ss[idx] = sss
                t = t + ss[idx] + '\n'
            if found == False and sectid>=0:
                # insert
                found = True
                # t = t[:sectid+1] + valname + sEqual + str(value)+'\n' + t[sectid+1:]
                ss=t.split('\n')
                ss.insert(sectid+1, valname + sEqual + str(value))
                t= '\n'.join(s for s in ss)
            elif found == False:
                # append
                found = True
                t = t[sectid+1:].strip() + '\n\n[' + section + ']\n' + valname + sEqual + str(value)+'\n'
            if found == True:
                # changed -> write
                f=io.open(path, 'w', encoding='utf8')
                f.write(t.strip()+'\n')
                f.close()
        else:
            ac.log('! no ' + str(path))
        # ac.log('second: \n' + t + '\n')

        # ac.log('AccExtHelperApp : \n' + str(path) + ' - ' + str(section)+'\n'+str(valname) + ' - ' + str(value) )
    except:
        ac.log("AccExtHelperApp error: " + section + ' - ' + valname+'\n'+ str(path) + '\n' + traceback.format_exc())
        ac.log(section + ' - ' + valname+'\n'+str(path) + '\n' + traceback.format_exc())

#######################################################

def setFOVvals(currFOV):
    global slMinfov, slMaxfov
    vminFov  = ac.getValue(slMinfov)
    vmaxFov  = ac.getValue(slMaxfov)
    if vminFov>currFOV:
        ac.setValue(slMinfov, currFOV)
    if vmaxFov<currFOV:
        ac.setValue(slMaxfov, currFOV)

def appFOVplus(*args):
    try:
        global app
        # should we set freecam mode, to be able to change FOV itself?
        # ac.setCameraMode(6)    #   nonononono, not now
        currFOV = ac.ext_getCameraFov()
        currFOV = currFOV + 0.1
        if currFOV>180:
            currFOV = 180
        ac.ext_setCameraFov(currFOV)
        setFOVvals(currFOV)
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

def appFOVplusplus(*args):
    try:
        global app
        # first set freecam mode, to be able to set camera itself
        # ac.setCameraMode(6)
        currFOV = ac.ext_getCameraFov()
        #normal
        currFOV = currFOV + 3
        if currFOV>180:
            currFOV = 180
        ac.ext_setCameraFov(currFOV)
        setFOVvals(currFOV)
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

def appFOVminus(*args):
    try:
        global app
        # should we set freecam mode, to be able to change FOV itself?
        # ac.setCameraMode(6)    #   nonononono, not now
        currFOV = ac.ext_getCameraFov()
        currFOV = currFOV - 0.1
        if currFOV<1:
            currFOV = 1
        ac.ext_setCameraFov(currFOV)
        setFOVvals(currFOV)
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

def appFOVminusminus(*args):
    try:
        global app
        # first set freecam mode, to be able to set camera itself
        # ac.setCameraMode(6)
        currFOV = ac.ext_getCameraFov()
        currFOV = currFOV - 3
        if currFOV<1:
            currFOV = 1
        ac.ext_setCameraFov(currFOV)
        setFOVvals(currFOV)
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

def buildCameraEntry(cCount, fCamPos, fOrientation, fOrientationUP, ssFOV, lPoT, cPoT):
    global slMinfov, slMaxfov, isFixed
    vminFov = ac.getValue(slMinfov)
    vmaxFov = ac.getValue(slMaxfov)
    return ('[CAMERA_' + str(cCount) + ']'
            + '\nNAME=Camera ' + str(cCount)
            + '\nPOSITION=' + fCamPos
            + '\nFORWARD=' + fOrientation
            + '\nUP=' + fOrientationUP
            + '\nMIN_FOV=' + str(vminFov)
            + '\nMAX_FOV=' + str(vmaxFov)
            + '\nIN_POINT=' + str(round(lPoT,5))
            + '\nOUT_POINT=' + str(round(cPoT,5))
            + '\nSHADOW_SPLIT0=50'
            + '\nSHADOW_SPLIT1=250'
            + '\nSHADOW_SPLIT2=1350'
            + '\nNEAR_PLANE=0.1'
            + '\nFAR_PLANE=10000'
            + '\nMIN_EXPOSURE=0.35'
            + '\nMAX_EXPOSURE=0.55'
            + '\nDOF_FACTOR=1'
            + '\nDOF_RANGE=100'
            + '\nDOF_FOCUS=0'
            + '\nDOF_MANUAL=0'
            + '\nSPLINE='
            + '\nSPLINE_ROTATION=0'
            + '\nFOV_GAMMA=0.5'
            + '\nSPLINE_ANIMATION_LENGTH=0'
            + '\nIS_FIXED=' + str(isFixed) + '\n')

def appCheckAILine(currPoT):
    global sFileCameras, odd, AI_LINE, AI_LINE_dist, BORDER_LEFT, BORDER_RIGHT
    global camCount, sCameras, passedRoadLen, lx, ly, lz, lastPoT
    global bAutoCam, bAutoCamON, bWrittenCamerasINI
    global spdistIN, spdistOUT, spMinHeight, spMaxHeigth, gAppsize, currPoTCalced, LenDiv
    global csvx, csvy, csvz, bRecordTimeAttack, sOrientationFORW, sOrientationFORWtimeattack, sOVERLAYS_INI, checkpointC, everyMeters, sCSVspline, lastCSVidx
    global bGenerateCSV

    try:
        #
        distIN    = ac.getValue(spdistIN) # 250
        distOUT   = ac.getValue(spdistOUT) # 200
        # add random height btw those:
        MinHeight = ac.getValue(spMinHeight) # 1
        MaxHeigth = ac.getValue(spMaxHeigth) # 5

        baseIdx = int( float(len(AI_LINE)/LenDiv) * currPoT*LenDiv )
        idx     = baseIdx
        lastIdx = int( float(len(AI_LINE)/LenDiv) * lastPoT )
        passedRoadLen = 0.0
        if idx>lastIdx and lastIdx>=0.0:
            for i in range(lastIdx, idx):
                passedRoadLen += distance(AI_LINE[i-1], AI_LINE[i])
        # ac.log( str(lastIdx) + ' - ' + str(idx) + ' - ' + str(passedRoadLen) )

        csvx += BORDER_RIGHT[baseIdx][0] - BORDER_RIGHT[lastIdx][0]   ### BORDER_RIGHT[lastCSVidx][0] -
        csvy += BORDER_RIGHT[baseIdx][1] - BORDER_RIGHT[lastIdx][1]   ### BORDER_RIGHT[lastCSVidx][1] -
        csvz += BORDER_RIGHT[baseIdx][2] - BORDER_RIGHT[lastIdx][2]   ### BORDER_RIGHT[lastCSVidx][2] -
        sCSVspline += str(csvx)+', '+str(csvy)+', '+str(csvz)+'\n'   # z <-> y
        lastCSVidx = baseIdx

        #
        if passedRoadLen >= distIN:
            # write csvline
            if bGenerateCSV:
                sFileCSV = 'content/tracks/' + sTrack
                if sLayout=='':
                    sFileCSV = sFileCSV +             '/data/csv_'+str(camCount)+'.csv'
                else:
                    sFileCSV = sFileCSV + '/'+sLayout+'/data/csv_'+str(camCount)+'.csv'
                with io.open(sFileCSV, 'w', encoding='utf-8') as f:
                    f.write(sCSVspline)

            # reset CS spline
            sCSVspline = ''
            csvx = 0
            csvy = 0
            csvz = 0
            lastCSVidx = 0

            # now give some more way to follow car a bit
            # add up distances btw ai-line verts until enough
            while passedRoadLen < distIN + distOUT:
                idx += 1
                if idx>=int(len(AI_LINE)/LenDiv):
                    idx = 1
                passedRoadLen += distance(AI_LINE[idx-1], AI_LINE[idx])
            currPoTCalced = float( idx / len(AI_LINE)/LenDiv )


            ### never reached, already done in acUpdate()
            if float(lastPoT) > float(currPoT) and camCount>0:
            # if lastPoT > currPoTCalced or currPoT < lastPoT:
                # new lap, finish auto cameras.ini
                ac.log('new lap AI line finish ')
                with io.open(sFileCameras, 'w', encoding='utf-8') as f:
                    f.write(sCameras)

                config = configparser.ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","#","/",), comment_prefixes=(";","#","/",), strict=False, allow_no_value=True)
                config.optionxform = str   # keep Case
                with open(sFileCameras, "r", encoding="utf-8", errors="ignore") as F:
                    config.read_string(F.read().encode('ascii', 'ignore').decode('ascii'))

                sval=str(round( 1- (1-float( config['CAMERA_'+str(camCount-1)]['IN_POINT'] ))/2 , 5))
                ac.log(sval)
                config['CAMERA_'+str(camCount-2)]['OUT_POINT']=sval
                config['CAMERA_'+str(camCount-1)]['IN_POINT'] =sval
                config['CAMERA_'+str(camCount-1)]['IN_POINT'] ='1.0'
                config['HEADER']['CAMERA_COUNT'] = str(camCount)

                # appWriteCFGValue(sFileCameras, 'CAMERA_'+str(camCount-1), 'OUT_POINT', '1.0' )
                # appWriteCFGValue(sFileCameras, 'HEADER', 'CAMERA_COUNT', str(camCount) )
                with open(sFileCameras, 'w') as configfile:
                    config.write(configfile, space_around_delimiters=False)

                __init__()
                appSetPositions()
                bWrittenCamerasINI = True
                return

            sFOV = str(int(ac.ext_getCameraFov()))
            s = ", ".join(str(round(x, 4)) for x in ac.ext_getCameraPos())
            sf = s.split(",")
            dx = round(lx-float(sf[0]),5)
            dy = round(ly-float(sf[1]),5)
            dz = round(lz-float(sf[2]),5)
            csvx += dx
            csvy += dy
            csvz += dz

            camview1 = ', '.join(str(round(x, 5)) for x in ac.ext_getCameraView())
            camview = camview1.split(',')
            # sOrientationFORW  = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
            sOrientationFORW  = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
            sOrientationFORW  = sOrientationFORW.replace('--','')     ####   lol   (-1)*(-1) = 1
            sOrientationUP    = str(float(camview[1])) + ", " + str( float(camview[5])) + ", " + str(float(camview[ 9]))

            distL = distance(BORDER_LEFT [baseIdx], AI_LINE[baseIdx] )
            distR = distance(BORDER_RIGHT[baseIdx], AI_LINE[baseIdx] )
            if distL > distR: # use left side cam if ai line is on the left at this point
                x =  BORDER_LEFT [baseIdx][0]
                y =  BORDER_LEFT [baseIdx][1]
                z = -BORDER_LEFT [baseIdx][2]
            else:
                x =  BORDER_RIGHT[baseIdx][0]
                y =  BORDER_RIGHT[baseIdx][1]
                z = -BORDER_RIGHT[baseIdx][2]
            # ac.setTitle(app, "L " + str(distL) + " - R " + str(distR))
            xcar = float(sf[0])
            ycar = float(sf[1]) + random.randrange(MinHeight,MaxHeigth)   # +5.0
            zcar = float(sf[2])
            s = str(round(x,5))+" ,"+str(round(ycar,5))+" ,"+str(round(-y,5))
            if sCameras=='':
                sCameras = '[HEADER]\nVERSION=3\nCAMERA_COUNT=0\nSET_NAME=' + os.path.basename(sFileCameras) + '\n\n'
            sCameras = sCameras + buildCameraEntry(camCount, s, sOrientationFORW, sOrientationUP, sFOV, lastPoT, currPoTCalced) + '\n'
            camCount += 1
            lastPoT = currPoTCalced   # currPoT

            odd = not odd # unused atm, could be used for variations?

    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

def appDrawLine(x1,y1,x2,y2,width=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1        ,y1)
    ac.glVertex2f(x2-width/2,y2)
    ac.glVertex2f(x2        ,y2)
    ac.glVertex2f(x1+width/2,y1)
    ac.glEnd()

def appDrawLine3(x1,y1,x2,y2,height=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1         )
    ac.glVertex2f(x2,y2-height/2)
    ac.glVertex2f(x2,y2         )
    ac.glVertex2f(x1,y1+height/2)
    ac.glEnd()

def appDrawText(t, r, g, b, a, x, y, sz):
    global f
    ac.ext_glFontColor(f.f, r, g, b, a)
    ac.ext_glFontUse(f.f, t, x, y, sz, ExtGL.FONT_ALIGN_LEFT)

### inactive
def onFormRender(deltaT):
    try:
        global bDrawBlocks, lastAltitude, currAltitude, AI_LINE_LENGTH, AI_LINE, YOFFSET, PREV_back, PREV_forw, USERYOFFSET, HEIGHT_mult, HEIGHT_steps

        # todo: a2b tracks
        ## ac.log(str(AI_LINE_LENGTH) + ' - ' + str(len(AI_LINE)))
        ### or curr=1000, we want  980
        ### ie curr=20  , we need 2480 from 2500
        if len(AI_LINE)>0:
            lix=0
            liy=0
            currPoT = ac.getCarState(ac.getFocusedCar(), acsys.CS.NormalizedSplinePosition)
            currAIid = int( len(AI_LINE) * currPoT )
            AIid = currAIid - PREV_back
            if AIid<0:
                AIid = len(AI_LINE)-1 + AIid
            i1=0
            i2=PREV_back + PREV_forw
            YOFFSET = AI_LINE[currAIid][2] * HEIGHT_mult + USERYOFFSET
            marked = False
            ldM = 0.0
            while i1 < i2:
                ix = i1
                iy = 0
                if AIid<len(AI_LINE):
                    iy = -AI_LINE[AIid][2]*HEIGHT_mult+YOFFSET + USERYOFFSET
                    # draw the height profile
                    r=1.0
                    g=1.0
                    b=1.0
                    if i1 > 0:
                        #appDrawLine(lix, liy, ix, iy)
                        if AIid!=0:
                            #xc = distance(AI_LINE[AIid-1], AI_LINE[AIid])
                            xa = distance2d(AI_LINE[AIid-1], AI_LINE[AIid])
                            xb = AI_LINE[AIid-1][2] - AI_LINE[AIid][2]
                        else:
                            #xc = distance(AI_LINE[0], AI_LINE[1])
                            xa = distance2d(AI_LINE[0], AI_LINE[1])
                            xb = AI_LINE[0][2] - AI_LINE[1][2]

                        #dM = -math.degrees(math.atan(xb/xa))
                        dM = xb / xa * 2
                        # ldM = dM
                        ldM = (ldM + dM ) * 0.5
                        if abs(ldM) > 0.01:
                            if dM>0.0:
                                r=0.5-abs(ldM/2)
                                g=0.5+abs(ldM/2)
                                b=r
                            else:
                                r=0.5+abs(ldM/2)
                                g=0.5-abs(ldM/2)
                                b=g
                        if AIid % (HEIGHT_steps) == 0:
                            # now actually draw one part
                            #ac.glColor4f(r,g,b,0.5+abs(ldM/2))
                            ac.glColor4f(r,g,b,1)
                            if bDrawBlocks:
                                appDrawLine(ix, USERYOFFSET, ix+HEIGHT_steps, USERYOFFSET+iy, HEIGHT_steps*2)
                            else:
                                appDrawLine3(lix, liy, ix+HEIGHT_steps, iy)

                    # position marker once
                    if i1 >= PREV_back and not marked:
                        marked = True
                        # appDrawText(0.2,str(int(AI_LINE[AIid][2]))+'m', ix-5, iy+23, 12)
                        # ac.glColor4f(1,1,1,1)
                        if lastAltitude > currAltitude:
                            sAdd='▽ '
                            if abs(ldM) > 0.01:
                                r=0.75
                                g=1
                                b=0.75
                        else:
                            sAdd='△ '
                            if abs(ldM) > 0.01:
                                r=1
                                g=0.75
                                b=0.75
                        appDrawLine(ix-2, iy-10, ix, iy+10, 4)
                        appDrawText(sAdd + str(round(ldM,1)) +'%  |  '+ str(round(currAltitude, 1)) +'m', r, g, b, 1, ix+10, USERYOFFSET+1, 12)
                    lix = ix
                    liy = iy-4

                i1 += 1 # HEIGHT_steps
                AIid += 1 # HEIGHT_steps
                if AIid>=len(AI_LINE):
                    AIid = 0
    except:
        ac.log('tyre_app_ext: ' + traceback.format_exc() )

###

def copyCameraCoords(*args):
    global odd, lx, ly, lz, lastFrom, currCar
    global timerMsg, btimerMsg, sOrientationUP
    try:
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        s = ", ".join(str(round(x, 5)) for x in ac.ext_getCameraPos())
        sf = s.split(",")
        x = sf[0]
        y = sf[1]
        z = sf[2]
        dx = round(lx-float(sf[0]),5)
        dy = round(ly-float(sf[1]),5)
        dz = round(lz-float(sf[2]),5)
        dist = math.pow( dx*dx+dy*dy+dz*dz, 0.5)

        sCarXYZrelative = ' , '.join(str(round(x, 5)) for x in ac.ext_getCameraPositionRelativeToCar())
        camview1 = ', '.join(str(round(x, 5)) for x in ac.ext_getCameraView())
        camview = camview1.split(',')

        sOrientationFORW    = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
        sOrientationFORW    = sOrientationFORW.replace('--','')     ####   lol   (-1)*(-1) = 1
        sOrientationUP = str( float(camview[1])) + ", " + str( float(camview[5])) + ", " + str( float(camview[ 9]))
        sadd = ""
        if lastFrom!='':
            sadd = "\nLINE_FROM = " + lastFrom
        sadd = sadd + "\nLINE_TO = " + s
        if lastFrom!='':
            sadd = sadd + "\nSTREAM_EDGE_... = " + lastFrom + ", " + s
        if lastFrom!='':
            sadd = sadd +'\n; STREAM_POINT_... = ' + str(lastFrom) + '  ;last'
        sadd = sadd + "\nSTREAM_POINT_... = " + s

        ac.ext_setClipboardData( # lastFrom +
            "POSITION=" + s +
            "\nFORWARD=" + sOrientationFORW +
            "\nUP=" + sOrientationUP +
            "\ncurrPoT = " + str(round(currPoT,5)) +
            "\nxyz-diff = " + str(dx) + ", " + str(dy) + ", " + str(-dz) +
            "\ndist2last = " + str(dist) +
            "\nxyzRel2Car = " + sCarXYZrelative +
            sadd
            )
        lastFrom = s
        odd = not odd
        lx = float(sf[0])
        ly = float(sf[1])
        lz = float(sf[2])

        timerMsg = 1.25
        btimerMsg = True
        ac.setTitle(app, "copied to clipboard")

        # ac.ext_setCameraDirection(0.807184 ,-0.0169818 ,-0.590056)  # debug
        # ac.ext_setCameraPosition(float(0.0),float(0.0),float(0.0))
        # ac.setPpColorTemperatureK(2500)
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())

def copyCameraCoords2(*args):
    global odd, lx, ly, lz, lastFrom, bButtons, app
    global timerMsg, btimerMsg, currPoT
    try:
        p = ", ".join(str(round(x, 5)) for x in ac.ext_getCameraPos())
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        s = "POSITION=" + p
        s=s+"\ncurrPoT = " + str(round(currPoT,5))

        ac.ext_setClipboardData(s)
        timerMsg = 1.25
        btimerMsg = True
        ac.setTitle(app, "copied to clipboard")
    except:
        ac.log("AccExtHelper error: " + traceback.format_exc())


def distance(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2 )

def distance2d(point1, point2) -> float:
    return math.sqrt( (point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 )

def ReadAILine():
    global AI_LINE_DIR, sFileCameras, sTrack, sLayout, AI_LINE, AI_LINE_dist, BORDER_RIGHT, BORDER_LEFT, AI_LINE_LENGTH
    sFileAI     = 'content/tracks/' + sTrack+            '/ai/fast_lane.ai'
    if sLayout!='':
        sFileAI = 'content/tracks/' + sTrack+'/'+sLayout+'/ai/fast_lane.ai'
    if not os.path.isfile(sFileAI) or os.path.getsize(sFileAI)<=24:
        ac.log('No "fast_lane.ai" found')
        return
    try:
        data_ideal   = []
        data_detail  = []
        AI_LINE      = []
        AI_LINE_dist = []
        BORDER_RIGHT = []
        BORDER_LEFT  = []
        AI_LINE_LENGTH = 0.0
        AI_LINE_DIR = []
        with open(sFileAI, "rb") as buffer:
            # should be at start, but do it anyway
            buffer.seek(0)
            # read header, detailCount is number of data points available
            header, detailCount, u1, u2 = struct.unpack("4i", buffer.read(4 * 4))
            # read ideal-line data
            for i in range(detailCount):       # 4 floats, one integer
                data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
                x , z , y, dist, id = data_ideal[i]
                coordscurr = ( float(x), -float(y), float(z)  )
                if i>0:
                    AI_LINE_LENGTH += distance( coordscurr, coordslast )
                coordslast = coordscurr

            # read more details data
            for i in range(detailCount):        # 18 floats
                data_detail.append(struct.unpack("18f", buffer.read(4 * 18)))

            xl, z, yl, dist, id = data_ideal[len(data_ideal)-1]
            for i in range(len(data_ideal)):
                x, z, y, dist, id = data_ideal[i]
                coordsAI = ( float(x), -float(y), float(z)  )
                direction = ( -math.degrees( math.atan2(yl - y, x - xl)))
                ### add all directions to array
                AI_LINE_DIR.append(float(direction))
                yl = y
                xl = x
                _wallLeft  = data_detail[i][6]
                x          = x + math.cos((-direction + 90) * math.pi / 180) * _wallLeft
                y          = y - math.sin((-direction + 90) * math.pi / 180) * _wallLeft
                coordsL    = ( float(x), -float(y), float(z)  )
                _wallRight = data_detail[i][7]
                x          = x + math.cos((-direction - 90) * math.pi / 180) * _wallRight
                y          = y - math.sin((-direction - 90) * math.pi / 180) * _wallRight
                coordsR    = ( float(x), -float(y), float(z)  )
                #
                # ac.log( str(round(coordsL[0],6)) +','+str(round(coordsL[2],6)) +','+str(round(coordsL[1],6)))
                AI_LINE.append(coordsAI)
                AI_LINE_dist.append(dist)
                BORDER_LEFT.append(coordsL)
                BORDER_RIGHT.append(coordsR)
        # ac.log(sFileAI + " read: " + str(len(BORDER_LEFT)) + ' ' + str(len(BORDER_RIGHT)) )
        ac.log('AccExtHelper: AI line - ' + str(round(AI_LINE_LENGTH,3)) + 'm - ' + str(len(AI_LINE)) + ' points')
    except:
        data_ideal   = []
        data_detail  = []
        AI_LINE      = []
        AI_LINE_dist = []
        AI_LINE_DIR  = []
        BORDER_RIGHT = []
        BORDER_LEFT  = []
        ac.log("AccExtHelper error: " + traceback.format_exc())

def CheckDriverAgainstAIline(currCar):
    global s_AI_CAR_dirs, AI_LINE_DIR
    currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
    AIline_Idx = int( float(len(AI_LINE_DIR)) * currPoT )
    if len(AI_LINE_DIR)>0:
        ### current nearest ai line point direction normalized to 0°...360°
        AI_dir = AI_LINE_DIR[AIline_Idx] -90
        if AI_dir < -180:
            AI_dir = AI_LINE_DIR[AIline_Idx] - 90 + 180
        if AI_dir < 0:
            AI_dir = 180 + AI_dir
        AI_dir = AI_dir + 180

        ### current car direction normalized to 0°...360°
        CAR_dir = math.degrees(info.physics.heading)
        CAR_dir = 360 + CAR_dir
        if CAR_dir>360:
            CAR_dir = CAR_dir-180
        s_AI_CAR_dirs = ''
        # s_AI_CAR_dirs = ('ai dir    ' + str(int(AI_dir))
        #             +'° \ncar dir  '  + str(int(CAR_dir)) + '°'
        #           #+  '\nbare     ' + str(int(math.degrees(info.physics.heading)))
        #               )
