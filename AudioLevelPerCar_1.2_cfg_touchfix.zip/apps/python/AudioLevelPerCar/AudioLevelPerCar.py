'''
AudioLevelPerCar App 1.2 for Assetto Corsa
'''

SecondsToWait = 2.5
# after Session start before applying
# saved Master Volume for a particular car
# increase if not working for you
# dont set below 1, will be set to that 1.0 otherwise


import ac, acsys
import os, traceback
from configparser import ConfigParser

configfile = os.path.join(os.path.dirname(__file__), 'carsMasterLevel.ini')

appWindow = 0
timer = 0.0
lastLevel = 0.0
firstLevel = 0.0
bFirst = True
if SecondsToWait<=0.0:
    SecondsToWait = 1.0

def acMain(ac_version):
    global appWindow, configfile, firstLevel
    appWindow = ac.newApp("AudioLevelPerCar")
    ac.setSize(appWindow, 400, 50)

    if not 'ext_setAudioVolume' in dir(ac):
        ac.setTitle(appWindow, "AudioLevelPerCar" + "\ncsp not active, cant set audio level")
        ac.log('AudioLevelPerCar: csp not active, cant set audio level"')

    return "AudioLevelPerCar"


def findInSubdirectory(filename, subdirectory=''):
    if subdirectory:
        path = subdirectory
    else:
        path = os.getcwd()
    for root, dirs, names in os.walk(path):
        if filename in names:
            return os.path.join(root, filename)
    return ''

carpath2                = os.path.abspath('extension/config/cars/')

def acUpdate(deltaT):
    global lastLevel, configfile, timer, bFirst, firstLevel, appWindow, SecondsToWait

    timer += deltaT
    if timer > SecondsToWait:
        timer = 0.0
        if bFirst and ac.isAcLive():
            bFirst=False
            if 'ext_setAudioVolume' in dir(ac):
                config = ConfigParser()
                config.optionxform = str
                config.read(configfile)
                car = ac.getCarName(0)
                if config.has_section('LEVELS'):
                    if config.has_option('LEVELS', car):
                        lastLevel = ac.ext_getAudioVolume()
                        ac.log('AudioLevelPerCar : reading curr Level = ' + str(round(lastLevel*10,1)))
                        firstLevel = float(config['LEVELS'][car])
                        ac.log('AudioLevelPerCar : setting firstLevel = ' + str(round(firstLevel*10,1))  + ' (' + car + ')')
                        ac.ext_setAudioVolume(firstLevel)

                        # touch config
                        if config.has_section('TOUCHCONFIG'):
                            if config.has_option('TOUCHCONFIG', 'ENABLED'):
                                bOn = config['TOUCHCONFIG']['ENABLED']
                                if bOn=='1':
                                    sFileCar = os.path.abspath('content/cars/'+car+'/extension/ext_config.ini') # from car folder itself
                                    if not os.path.isfile(sFileCar):
                                        sFileCar = findInSubdirectory(car+'.ini', carpath2) # from ac\ext\cfg\cars
                                    if os.path.isfile(sFileCar):
                                        with open(sFileCar, 'r', errors='ignore') as f:
                                            content = f.read()
                                        if content!='':
                                            with open(sFileCar, 'w', errors='ignore') as f:
                                                f.write(content)

        else:
            if 'ext_getAudioVolume' in dir(ac):
                car = ac.getCarName(0)
                lastLevel = ac.ext_getAudioVolume()
                sAdd='  -  curr: ' + str(round(lastLevel*100,1)) + '%'
                ac.setTitle(appWindow, "AudioLevelPerCar" + sAdd + "\n'" + car + "' - master level will be saved on exit")


def acShutdown(*args):
    global configfile, lastLevel
    if 'ext_getAudioVolume' in dir(ac):
        car = ac.getCarName(0)
        config = ConfigParser()
        config.optionxform = str
        config.read(configfile)
        if not config.has_section('LEVELS'):
            config.add_section('LEVELS')
        ### somehow audiolevel is always 0.0 here in acShutdown() :(
        ### so we need to keep track of it in acUpdate()
        config['LEVELS'][car] = str(round(lastLevel,6))
        with open(configfile, 'w') as f:
            config.write(f)
        ac.log('AudioLevelPerCar : saving lastLevel = ' + str(round(lastLevel,6))  + ' (' + car + ')')
