IniReader v0.2
==============
-added simple string filter on "control" tab, affecting directory names
-fixed some errors


AC Cars+Tracks TecSpecs ExcelScanner v4.5 - 2026 feb 23
=======================================================

"Assetto Corsa" Cars+Tracks Technical Data Scanner (Excel97/2003 w/macros for any directory)

Based on the awesome "AC Cars and Tracks Technical Data (Excel 2013) 1.11", I made my own with some vba stuff. Have fun.

These Excel files DO NOT contain ANY data at first. You have to feed it a "\cars" directory. It works on click of a button, is reasonably fast and contains some macros. For inspection, the macros are included as textfiles too.

Paste cars/tracks dir or browse for it on the "control"-sheet and click on "scan". Anyway if the directory is not valid, you will be asked to browse for it. By providing any cars/tracks directory with valid AC json files in it you can also scan directories with turned-off- OR backup-cars.

To get more detailed information (in particular col "E", the drive+gears info), you must ensure the ".acd" datafile is already extracted for the desired cars - the only way to determine if the car is AWD/AWD2/RWD/FWD, as tags from "ui_car.json" are not always reliable. If available, drive-info from "\data\drivetrain.ini" will be used, the tag from "ui_car.json" wil be omitted.

If some data is not showing up, a second scan may magically help sometimes, especialy after changing preview-size.

Features:
-lists data from files out of cars "\data"-dir if available
NOTE: a second hardcoded temp-dir one can use is "content\cars\examplecar\datadir" (where I extract my .acd files)
-lists data from all found "ui_car.json" and "ui_track.json" files
-Simple "mp/h" and "mph" -> "km/h" conversion for topspeed and track length (fails sometimes)
-wpratio is calculated, old value as cell-comment
-preview: none or small/medium/big/huge
-large preview on mouse over small one
-info about gear ratios as comment on column "drive" or "E"
- .(dot) is decimal-separator
-Made in 1080 res
-Dark+Light design available
-readonly: it doesnt change anything on your system

The following files will be read:
ui\ui_car.json
ui\ui_track.json
data\drivetrain.ini
data\brakes.ini
data\electronics.ini
data\engine.ini
data\tyres.ini
data\fuel_cons.ini
data\Flames.ini
data\car.ini
data\wing_animations.ini
skins\*\preview.jpg     ' only the first one
*\map.png               ' for tracks

Warning:
-you have to allow macros in Excel, to let it do its work
-can be painly slow, if you have a lot of cars
-saved excel file can be painly big (>50MB), if you have a lot of cars
-with large preview-sizes, the control-buttons get somewhat lost...
-its not aware of unicode, so funny names are normal
-dont rename the sheets, or the macros get confused

.rar file contains:
\ACTecSpecs\ACTecSpecs_xx.xlsm
\ACTecSpecs\ACTecSpecs_xx.xls
\ACTecSpecs\ACTecSpecs_readme.txt
\ACTecSpecs\src\AssettoCorsaScanner.bas
\ACTecSpecs\src\FormProgress.frm
\ACTecSpecs\src\FormProgress.frx

ps: Got a bad Trackmap? Delete
\trackX\data\map.ini
\trackX\map.png         or
\trackX\layout1\map.png
\trackX\layout2\map.png (if there are more layouts)
AC recreates them on first start, but crashes. Next start will work!

changelog:
v0.1 - 2018-02-11
-----------------
-intitial version

v0.2 - 2018-02-12
-----------------
-fixed 64bit compatibility for dll imports
-fixed a preview-size issue
-added gear-info (for cars with unpacked data-dir) as hover-comment for "drive" column (E)
-added Assetto Corsa Tracks

v0.3 - 2018-02-13
-----------------
-finished "Tracks"-sheet
-fixed some other errors
-added car wpratio calculation
-added clear table button

v1.0 - 2018-02-20
-----------------
-added more car data columns and a checkbox to disable them
(this reads some files from the "data" dir of a car, or a special hard-coded "datadir" where I extracted .acd files)
-fixed some errors
-preview images now stick to cell border

v1.1 - 2018-02-20
-----------------
-added version info to author/url column on both cars and tracks
-added Kunos original detection

v1.2 - 2018-02-20
-----------------
-fixed very small issue with new flag: "1w" is now "w" only
 but still 1 animated wing for this car

v1.3 - 2018-02-20
-----------------
-fixed sorting, no sticking to cell border
-fixed Kunos detection
-fixed readme
-added directory-timestamp

v2.0 - 2018-02-21
-----------------
-made the track-preview-picture (not the map) an option
-fixed some errors
-added city+year for tracks
-its not aware of unicode, so funny names are normal

v2.1 - 2018-02-25
-----------------
-fixed 64bit compatibility again

v2.5 - 2018-03-11
-----------------
-unicode support
-moved controls to a third excelsheet
-added dir size+description column
-added some track-layouts recognition
-added auto-discovery of AC-dir (through AC-log-file in userdir)
-added correct awd/rwd/fwd info, when "data\drivetrain.ini" exists ("data.acd" file is unpacked) - there are more AWDs than you think!
 because tags from "ui_car.json" are not always reliable

v2.6 - 2018-03-11
-----------------
-fixed autodetection of AC-dir

v2.7 - 2018-03-11
-----------------
-fixed browsing for directory and autodection again

v3.0 - 2018-03-28
-----------------
-this update adds more data for cars with unpacked .acd-files ("data"-dir, or alternativly "datadir")
-added version info for these .INI files: drivetrain,brakes,engine,car,wing_animations,aero,ai,drs,ers,lights,susp
-added check for correctly named car-sfx-file (marked with * in the timestamp-column if not)
-added check for correctly named track-kn5-files from "models_*.INI" (marked with * in the timestamp-column if not)

If some data is not showing up, a second scan may magically help sometimes, espaccially after changing preview-size.

v3.1 - 2018-04-03
-----------------
-fixed tracks not scanning (macro-name behind "scan" track button was wrong)

v3.3 - 2020-01-02
-----------------
-added "tags" column

v3.4 - 2020-07-21
-----------------
-added more tyre info
-added simple string filter on "control" tab, affecting directory names
-"tags" column is sorted now

v3.5 - 2020-07-22
-----------------
-fixed preview images
-fixed tyre info

v3.6 - 2020-08-11
-----------------
-added filtering by comma separated list
-added check for "race" or "street" tags exist for cars
-included again: excel 97 version

v3.7 - 2020-08-30
-----------------
-fixed some "type mismatch" errors for some people, never had them myself

v3.8 - 2021-02-06
-----------------
-fixed ers/kers info and tyre data
-added note in tyre-column if "default tyreindex wrong"
-made scanning for foldersizes optional (faster when disabled)

again as v3.8 - 2021-02-17
-----------------
-fix div by zero in cases

v4.0 - 2022-02-7
-----------------
-fixes
-added feature to unpack "data.acd" on the fly
 +for that you need the included "acd_file.exe" right beside this excel-file

-added feature to open all the "data\...ini" files of a car in a new Excel file
 +also adds simple LUT-diagrams
 +either use one of two new big buttons
 +or do a scan and click on the car-name column
 (you will be asked to open "data\...ini" files in a new spreadsheet)

-all sources included, a scan of the binary on jotti:
https://virusscan.jotti.org/de-DE/filescanjob/ypy4kzpu5p


v4.1 - 2022-02-8
-----------------
-hopefully fixed for 64bit office


v4.2 - 2022-02-09
-----------------
-fixed overflow (for bad (?) data)


v4.3 - 2022-02-09
-----------------
-forgot to disable "unpack ACD" by default and filter wasnt empty....


v4.4 - 2024-11-29
-----------------
-hopefully fixed for 64bit office again
-added 2 ways to update tags in "ui\ui_car.json"
--for single cars by clicking in the "tags update column"
--for multiple cars by selecting the wider "tags" column, when the first row with the description is selected, you will be asked to confirm that (gif)
--warning: no guarantee formatting of resulting JSON is correct!
--a backup copy is always made

v4.5 - 2026-02-23
-----------------
-hopefully fixed for newer Office versions than 2010
-fixed handling of tyres ini
-fixed potential div by 0 error
-fixed scanner running two times
-added proper json utf reading/writing
-fixed browsing for AC foldersizes
