Attribute VB_Name = "INIReaderMacros"
Option Explicit

' var for Progressbar in "FormProgress", exactly 100 pipes
Const ProgressString = "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"

Dim filenameSearch As String
Dim bDataInRows As String
Dim bShortSummary As String
Dim bLightMode As Boolean
Dim bFileByFile As Boolean
Dim bSectNumbers2X As Boolean
Dim bDoSort As Boolean
Dim cFile As Long
Dim DirFilter As String
Dim StartFolderLen As Integer
Dim cFilesOverall As Long
Dim cFoldersOverall As Long

''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' --- all needed API-declarations vor browsing --- '
Dim cnstNull As String * 1         ' NULL-string
Const OFN_FILEMUSTEXIST = &H1000
Const OFN_PATHMUSTEXIST = &H800
Const OFN_HIDEREADONLY = &H4
Const OFN_READONLY = &H1
Const OFN_OVERWRITEPROMPT = &H2
Const GW_HWNDFIRST = 0

' open-file-dialog-struct
#If VBA7 Then
    Private Type OPENFILENAME
        lStructSize As Long
        hwndOwner As LongPtr
        hInstance As LongPtr
        lpstrFilter As String
        lpstrCustomFilter As String
        nMaxCustFilter As Long
        nFilterIndex As Long
        lpstrFile As String
        nMaxFile As Long
        lpstrFileTitle As String
        nMaxFileTitle As Long
        lpstrInitialDir As String
        lpstrTitle As String
        flags As Long
        nFileOffset As Integer
        nFileExtension As Integer
        lpstrDefExt As String
        lCustData As LongPtr
        lpfnHook As LongPtr
        lpTemplateName As String
    End Type
    Private Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As LongPtr)
    Private Declare PtrSafe Function GetWindow Lib "USER32" (ByVal hWnd As LongPtr, ByVal wCmd As Long) As LongPtr
    Private Declare PtrSafe Function GetOpenFileName Lib "comdlg32.dll" Alias "GetOpenFileNameA" (pOpenfilename As OPENFILENAME) As Long
#Else
    Private Type OPENFILENAME
      lStructSize As Long            ' L�nge des Datentyps OPENFILENAME
      hwndOwner As Long              ' Fenster, unter dem Dialog erscheint
      hInstance As Long              ' nicht verwendet
      lpstrFilter As String          ' Zeichenkette von Anzeigenfiltern im Dialog
      lpstrCustomFilter As String    ' nicht verwendet
      nMaxCustFilter As Long         ' nicht verwendet
      nFilterIndex As Long           ' 1 zum Benutzen des ersten Filters, 2 zum zweiten usw.
      lpstrFile As String            ' String, der ausgew�hlte Datei bekommt
      nMaxFile As Long               ' L�nge von lpstrFile
      lpstrFileTitle As String       ' Dateiname ohne Pfad (kann auch mit VBA ermittelt werden, also weglassen)
      nMaxFileTitle As Long          ' nicht verwendet
      lpstrInitialDir As String      ' Ordner, in dem Dialog sich zuerst befinden soll
      lpstrTitle As String           ' Titel des eigentlichen Dialogfensters
      flags As Long                  ' verschiedene Optionen, die durch Konstanten eingestellt werden
      nFileOffset As Integer         ' nicht verwendet
      nFileExtension As Integer      ' nicht verwendet
      lpstrDefExt As String          ' Erweiterung, die genommen wird, wenn keine eingegeben wurde
      lCustData As Long              ' nicht verwendet
      lpfnHook As Long               ' nicht verwendet
      lpTemplateName As Long         ' nicht verwendet
    End Type
    Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
    Private Declare Function GetWindow Lib "USER32" (ByVal hWnd As Long, ByVal wCmd As Long) As Long
    Private Declare Function GetOpenFileName Lib "comdlg32.dll" Alias "GetOpenFileNameA" (pOpenfilename As OPENFILENAME) As Long
#End If
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Function sColLtr(lngCol As Long) As String
    Dim vArr
    vArr = Split(Cells(1, lngCol).Address(True, False), "$")
    sColLtr = vArr(0)
End Function

' main function
Sub RunINIScanner()
    Dim irow As Long
    Dim icol As Long
    Dim FirstPath  As String
    Dim s_filename As String

    DirFilter = Sheets("control").Cells(4, 1).Text
    FirstPath = Sheets("control").Cells(2, 1).Text
    If (FirstPath = "") Or (Not DirExists(FirstPath)) Then
        s_filename = "[ignored]"  ' browse for it
        s_filename = GetADirOrFile(FirstPath, s_filename, "Browse for directory to scan")
        If (s_filename = "") Or (s_filename = "Falsch") Or s_filename = "False" Then
            'MsgBox ("Canceled.")
            Exit Sub
        End If
        FirstPath = Mid(s_filename, 1, InStrRev(s_filename, "\"))
        Sheets("control").Cells(2, 1).Text = FirstPath
    End If

    Sheets("INIdata").Select ' in case were debuging
    Application.ScreenUpdating = False
    Call CleanUpSheet(Sheets("INIdata"))
    Range("A1").Select
    Columns("A:A").ColumnWidth = 60
    Rows("1:1").RowHeight = 300
    Sheets("INIdata").Select ' in case were debuging
    Rows("1:1").Orientation = 90
    Rows("1:1").ReadingOrder = xlContext

    filenameSearch = Worksheets("control").Shapes("filenameSearch").OLEFormat.Object.value
    filenameSearch = Worksheets("control").Cells(1 + CInt(filenameSearch), 3)
    bShortSummary = False
    bShortSummary = Worksheets("control").Shapes("cbConsolidate").OLEFormat.Object.value = 1
    bDataInRows = True
    bDataInRows = Worksheets("control").Shapes("optA").OLEFormat.Object.value = 1
    bFileByFile = False
    bFileByFile = Worksheets("control").Shapes("optC").OLEFormat.Object.value = 1
    bSectNumbers2X = False
    bSectNumbers2X = Worksheets("control").Shapes("cbSectNumbers2X").OLEFormat.Object.value = 1
    bDoSort = False
    bDoSort = Worksheets("control").Shapes("cbDoSort").OLEFormat.Object.value = 1
    
    Application.ScreenUpdating = True
    DoEvents
    FormProgress.Show
    FormProgress.lbCurrDir = ""
    FormProgress.lbLastFound = ""
    
    cFilesOverall = 0
    cFoldersOverall = 0
    cFile = 0
    irow = 2
    Application.ScreenUpdating = False
    StartFolderLen = Len(FirstPath)
    Call ScanDirectory(FirstPath, True, True, True, irow)

    If (FormProgress.Visible = True) Then
        If bFileByFile Then
            Cells(1, 1) = CStr(cFile) + " files, " + CStr(irow) + " rows"
            Cells(1, 1).Orientation = 0
        ElseIf bDataInRows Then
            icol = irow
            irow = 1
            Do
                irow = irow + 1
                If Cells(irow, 1) = "" And Cells(irow + 1, 1) <> "" Then
                    ' delete next empty row (if mostnext is non empty)
                    Rows(irow).Delete Shift:=xlDown
                End If
            Loop Until Cells(irow, 1) = ""
            Cells(1, 1) = CStr(irow) + " distinct [sect]+names  - " + CStr(icol) + " files"
            Cells(1, 1).Orientation = 0
            If bDoSort Then: _
            Call DoSort(CStr(irow), CStr(icol), sColLtr(icol))
        Else
            icol = 1
            Do
                icol = icol + 1
                If Cells(1, icol) = "" And Cells(1, icol + 1) <> "" Then
                    ' delete next empty col (if mostnext is non empty)
                    Columns(icol).Delete Shift:=xlToLeft
                End If
            Loop Until Cells(1, icol) = ""
            Cells(1, 1) = CStr(irow) + " files  -  " + CStr(icol) + " distinct [sect]+names"
            Cells(1, 1).Orientation = 0
            If bDoSort Then: _
            Call DoSort(CStr(irow), CStr(icol), sColLtr(icol))
            'Call mySort
        End If
        If (bShortSummary = True) Then
          Call DataConsolidate
        End If
    End If
    FormProgress.Hide
    Application.ScreenUpdating = True
End Sub

Sub DoSort(sRow As String, scol As String, sColLtr As String)
    Cells.Select
    ActiveWorkbook.Worksheets("INIdata").Sort.SortFields.Clear
    ActiveWorkbook.Worksheets("INIdata").Sort.SortFields.Add _
        Key:=Range("A1:A" + scol), _
        SortOn:=xlSortOnValues, Order:=xlAscending, DataOption:=xlSortNormal
    With ActiveWorkbook.Worksheets("INIdata").Sort
        .SetRange Range("A1:" + sColLtr + sRow)
        .Header = xlYes
        .MatchCase = False
        .Orientation = xlTopToBottom
        .SortMethod = xlPinYin
        .Apply
    End With
    With Selection
        .HorizontalAlignment = xlLeft
    End With
    Cells(1, 1).Select
End Sub

' scrub together, deleting empty columns
Sub DataConsolidate()
    Dim r As Long, c As Long
    Dim iEmpty As Long
    Dim s1 As String, s2 As String

    r = 2
    c = 2
    Do
        c = 2
        iEmpty = 2
        Do
            If Cells(r, c) = "" Then
                iEmpty = c
                Do
                    c = c + 1
                    If Cells(r, c) <> "" Then
                        s1 = Cells(r, iEmpty)
                        s2 = Cells(r, c)
                        If InStr(s1, s2) < 1 Then
                            Cells(r, iEmpty) = Cells(r, c)
                        End If
                        Cells(r, c) = ""
                        iEmpty = iEmpty + 1
                    End If
                Loop Until Cells(1, c) = ""

            End If
            c = c + 1
        Loop Until Cells(1, c) = ""
        r = r + 1
        If Cells(1, r) = "" And Cells(1, r + 1) <> "" Then
            ' delete next empty row (if mostnext is non empty)
            Columns(r).Delete Shift:=xlToLeft
        End If
    Loop Until Cells(r, 1) = ""
End Sub

' -------------------------------------------------------------------
' dir-scanner
Private Function ScanDirectory(FirstPath As String, bCountonly As Boolean, bPreview As Boolean, bTracks As Boolean, row As Long) As Long
    Dim objFSO As Object, objFolder As Object, objSubFolder As Object
    Dim objFSO2 As Object, objFolder2 As Object, objSubFolder2 As Object
    Dim objSubFile As Object
    Dim i As Long, proz As Long
    Dim sDataFile As String, stmp As String
    Dim lastrow As Long
    Dim startrow As Long
    Dim trackLocations As Long
    Dim trackLayouts As Long
    Dim l1 As Long, l As Long
    Dim l2 As Long
    Dim dirname As String
    Dim dirname2 As String
    Dim cnt As Long

    trackLocations = 0
    trackLayouts = 0
    ScanDirectory = 0
    proz = 0
    startrow = row

    On Error GoTo ENDE  ' just set to row we got as param
    
    'Create an instance of the FileSystemObject
    Set objFSO = CreateObject("Scripting.FileSystemObject")
    'Get the folder object
    Set objFolder = objFSO.GetFolder(FirstPath)
    
    If Len(FirstPath) <> StartFolderLen Then
        dirname = Mid(FirstPath, StartFolderLen + 1, Len(FirstPath) - StartFolderLen - 1)
    Else
        dirname = Mid(objFolder.path, InStrRev(objFolder.path, "\"), Len(objFolder.path))
        dirname2 = Mid(objFolder.path, 1, InStrRev(objFolder.path, "\") - 1)
        dirname2 = Mid(dirname2, InStrRev(dirname2, "\"), Len(dirname2))
        dirname = dirname2 + dirname
    End If

    ' loop through each folder
    For Each objSubFolder In objFolder.subfolders
        
        cFoldersOverall = cFoldersOverall + 1
        FormProgress.lbCurrDir = CStr(cFoldersOverall) + " folders " + CStr(cFilesOverall) + " files" + Chr(10) + Chr(13) + objFolder.path + "\"
        If cFoldersOverall Mod 200 = 0 Then
            Application.ScreenUpdating = True
            FormProgress.Repaint
            DoEvents
            ' check if progress window was closed
            If Not FormProgress.Visible Then: Exit For
            If Not FormProgress.Enabled Then: Exit For
            Application.ScreenUpdating = False
        End If
        
        Call ScanDirectory(objSubFolder.path + "\", True, False, True, row)
    Next objSubFolder

    ' loop through each file in this folder
    For Each objSubFile In objFolder.Files
        sDataFile = objSubFile.name
        
        FormProgress.lbCurrDir = CStr(cFoldersOverall) + " folders " + CStr(cFilesOverall) + " files" + Chr(10) + Chr(13) + objFolder.path + "\"
        cFilesOverall = cFilesOverall + 1
        If cFilesOverall Mod 200 = 0 Then
            Application.ScreenUpdating = True
            FormProgress.Repaint
            DoEvents
            ' check if progress window was closed
            If Not FormProgress.Visible Then: Exit For
            If Not FormProgress.Enabled Then: Exit For
            Application.ScreenUpdating = False
        End If
        
        l = Len(sDataFile)
        If Len(sDataFile) > 4 Then
            If InStr(UCase(sDataFile), UCase(filenameSearch)) > 0 Then
                If FileExists(objFolder.path + "\" + sDataFile) Then
                    If (DirFilter = "") Or (InStr(UCase(objFolder.path), UCase(DirFilter)) > 0) Then
                        row = ScanFileINI(objFolder.path + "\" + sDataFile, dirname + "\" + sDataFile, row + 1)
                        cFile = cFile + 1
                        FormProgress.lbLastFound = "found " + CStr(cFile) + " files, last: " + Chr(10) + Chr(13) + objFolder.path + "\" + sDataFile
                        FormProgress.Repaint
                    End If
                End If
                DoEvents
            End If
        End If
    Next objSubFile
ENDE:
    ScanDirectory = row
End Function

' scan the file
Private Function ScanFileINI(sDataFile As String, sname As String, row As Long) As Long
    Dim s As String, ss As String, surl As String, sver As String, sauthor As String
    Dim dpow As Double, dwei As Double
    Dim lines() As String
    Dim linesC As Long, i As Long
    Dim isKunos As Boolean
    Dim sDescription As String * 1024
    Dim sect As String
    Dim name As String
    Dim sComment As String
    Dim sCommentLast As String
    Dim val As String
    Dim col As Long

    ScanFileINI = row

    surl = ""
    sauthor = ""
    sver = ""
    sDescription = ""

    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If (linesC <= 0) And (lines(0) = "") Then: Exit Function

    If bFileByFile Then
    ElseIf bDataInRows Then
        If sname = "" Then
            Cells(1, row) = "unknown"
        Else
            Cells(1, row) = "'" + sname
            If Cells(1, row) = "" Then
                Cells(1, row) = "text"
            End If
        End If
    Else
        If sname = "" Then
            Cells(row, 1) = "unknown"
        Else
            Cells(row, 1) = "'" + sname
            If Cells(row, 1) = "" Then
                Cells(row, 1) = "text"
            End If
        End If
    End If
    
    sCommentLast = ""

    If linesC = 0 Then: linesC = linesC + 1
    i = 0
    While i <= linesC
        On Error GoTo ENDE
        s = lines(i)
        ss = LCase(s)
        If InStr(ss, "[") = 1 And InStr(ss, "]") > 3 Then
            sect = Trim(Mid(s, 2, InStr(ss, "]") - 2))

            If bSectNumbers2X Then
                ' replace numbers with "_X"
                If IsNumeric(Mid(sect, Len(sect), 1)) Then
                    sect = Mid(sect, 1, Len(sect) - 1)
                    If IsNumeric(Mid(sect, Len(sect), 1)) Then
                        sect = Mid(sect, 1, Len(sect) - 1)
                        If IsNumeric(Mid(sect, Len(sect), 1)) Then
                            sect = Mid(sect, 1, Len(sect) - 1)
                        End If
                    End If
                    sect = sect + "X"
                End If
            End If

            Do
                i = i + 1
                If i >= linesC Then
                    Exit Do                  ' EOF
                End If
                s = Trim(lines(i))
                ss = LCase(s)
                If InStr(ss, "[") = 1 Then
                    i = i - 1
                    Exit Do                  ' on next sect
                End If
                
                If InStr(ss, ";") Then
                  sCommentLast = Trim(Mid(ss, InStr(ss, ";"), Len(ss)))
                End If
                If InStr(ss, "#") Then
                  sCommentLast = Trim(Mid(ss, InStr(ss, "#"), Len(ss)))
                End If
                
                If InStr(Trim(ss), "#") <> 1 And InStr(Trim(ss), ";") <> 1 Then
                   
                    If InStr(ss, "=") > 1 Then
                        name = Trim(Mid(s, 1, InStr(s, "=") - 1))
                        val = Mid(s, InStr(s, "=") + 1, Len(s) - InStr(s, "="))
                        If InStr(val, ";") Then
                          sComment = Trim(Mid(val, InStr(val, ";"), Len(val)))
                          val = Trim(Mid(val, 1, InStr(val, ";") - 1))
                        End If
                        If InStr(val, "#") Then
                          sComment = Trim(Mid(val, InStr(val, "#"), Len(val)))
                          val = Trim(Mid(val, 1, InStr(val, "#") - 1))
                        End If
                        
                        If (sComment <> "" And sCommentLast = "") Then
                            sCommentLast = sComment
                        End If
                        
                        If bFileByFile Then
                            Cells(row, 1) = sname
                            Cells(row, 2) = "[" + sect + "]"
                            Cells(row, 3) = s
                            'Cells(row , 3) = name
                            'Cells(row , 4) = "'="
                            'Cells(row , 5) = val
                            row = row + 1
                        Else
                            
                            'If bShortSummary Then
                            col = IsThere("[" + sect + "]  -  " + name, val, row, sCommentLast)
                            'row = row + 1
                            'row = row + 1
                            'End If
                            If col > 0 Then
                                'Cells(1, col) = sect + ";" + name
                                'Cells(row, col) = val
                                'Exit Do
                            End If
                        End If
                        
                       
                    End If
                
                End If
            Loop Until i >= linesC
        End If
        i = i + 1
    Wend
    ScanFileINI = row
    Exit Function
ENDE:
    ScanFileINI = row
    Cells(row, 1) = sname
    Cells(row, 2) = "'Empty"
End Function

' check if that "[section] - name" already exists,
' if not write that data to new row/column
Function IsThere(sectname As String, val As String, row As Long, comment As String) As Long
    Dim i As Long
    Dim s As String
    IsThere = -1
    i = 1
    If bDataInRows Then
        Do
            If Cells(i, 1) = sectname Then
                IsThere = i
                s = Cells(i, row)
                If (s <> "") Then: val = s + " | " + val
                Cells(i, row) = val
                Exit Do
            End If
            i = i + 1
        Loop Until Cells(i, 1) = ""
        ' limit to 10000
        If (i < 10000) Then
            Cells(i, 1) = sectname
            Cells(i, 2) = "'="
            s = ""
            
            If (comment <> "") And Not InStr(comment, Cells(i + 1, 2)) Then
                comment = Cells(i + 1, 2) + " - " + comment
                Cells(i + 1, 2) = comment
            End If
            If bShortSummary Then: s = Cells(i, row).Text
            If val <> "" And InStr(s, val) < 1 And Len(s) < 128 Then
                'On Error GoTo cleanup
                If (s <> "") Then: val = s + " | " + val
                Cells(i, row) = val
            End If
        End If
    Else
        Do
            If Cells(1, i) = sectname Then
                IsThere = i
                s = Cells(row, i)
                If (s <> "") Then: val = s + " | " + val
                Cells(row, i) = val
                Exit Do
            End If
            i = i + 1
        Loop Until Cells(1, i) = ""
        ' limit to 10000
        If (i < 10000) Then
            Cells(1, i) = sectname
            ' Cells(1, 2) = "'="
            s = ""
            'If (comment <> "") And Not InStr(comment, Cells(row + 1, 2)) Then
            '    comment = Cells(2, row + 1) + " - " + comment
            '    Cells(row + 1, 2) = comment
            'End If
            If bShortSummary Then: s = Cells(row, i).Text
            If val <> "" And InStr(s, val) < 1 And Len(s) < 128 Then
                'On Error GoTo cleanup
                If (s <> "") Then: val = s + " | " + val
                Cells(row, i) = val
            End If
        End If
    End If

    IsThere = i
    Exit Function
cleanup:
    IsThere = -1
    If bDataInRows Then
        Cells(i, row) = "'!binary"
    Else
        Cells(row, i) = "'!binary"
    End If
End Function




'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' helper functions
Sub RunGetDirCars()
    Dim FirstPath As String, startdir As String
    Dim DirCount As Long, NumFiles As Long
    Dim s_filename As String

    ' \CARS-directory
    FirstPath = Sheets("control").Cells(2, 1).Text
    If FirstPath = "" Then
        FirstPath = GetACDirAutomatic()
        If FirstPath <> "" Then
            If MsgBox("Found AC in " + FirstPath + ". Use it?", vbYesNo) = vbYes Then
                FirstPath = FirstPath + "\cars"
            End If
        End If
    Else
        startdir = FirstPath
        FirstPath = ""
    End If

    If FirstPath = "" Then
        s_filename = "[ignored]"  ' browse for it
        s_filename = GetADirOrFile(FirstPath, s_filename, "Browse for directory to scan")
        If (s_filename = "") Or (s_filename = "Falsch") Or s_filename = "False" Then
            'MsgBox ("Canceled.")
            Exit Sub
        End If
        FirstPath = Mid(s_filename, 1, InStrRev(s_filename, "\"))
    End If

    Sheets("control").Cells(2, 1) = FirstPath
    Sheets("control").Activate
    Sheets("control").Cells(2, 1).Select
End Sub

Private Sub DeleteComments()
    Dim c As Long
    Dim cmt As comment
    ' delete comments
    c = 1
    For c = 1 To 1000
        Set cmt = Cells(c, 5).comment
        If cmt Is Nothing Then
        Else
            Cells(c, 5).ClearComments
        End If
        Set cmt = Cells(c, 11).comment
        If cmt Is Nothing Then
        Else
            Cells(c, 11).ClearComments
        End If
    Next c
End Sub

Private Function CleanUpSheet(sheet As Object) As Boolean
    Dim Pic As Object
    Dim i As Long, c As Long, proz As Long
    CleanUpSheet = False
    sheet.Cells.Clear
    ' sheet.Cells.UsedRange.ClearContents
    sheet.UsedRange.ClearContents
End Function

Function ScanFileUTF8(FileName As String) As String()
    Dim objStream, strData
    Set objStream = CreateObject("ADODB.Stream")
    objStream.Charset = "utf-8"
    objStream.Open
    objStream.LoadFromFile (FileName)
    strData = objStream.ReadText()
    objStream.Close
    Set objStream = Nothing
    If strData <> "" Then
        strData = Replace$(strData, vbCr, vbCrLf)
        strData = Replace$(strData, vbLf, vbCrLf)
        strData = strData + vbCrLf
        Dim lines() As String: lines = Split(strData, vbCrLf)
        If UBound(lines) < 2 Then  ' all in one line compressed js style, split to lines
            lines = Split(strData, ", ")
        End If
        If UBound(lines) < 2 Then  ' all in one line compressed js style, split to lines
            lines = Split(strData, ",")
        End If
        ScanFileUTF8 = lines ' result!
    Else
        ReDim ScanFileUTF8(0)
    End If
End Function

Private Function IsNumeric2(s As String) As Boolean
    IsNumeric2 = False
    If (s = ".") Or (s = ",") Or IsNumeric(s) Then
        IsNumeric2 = True
    End If
End Function

Private Function GetFileDate(file As String, row As Long, col As Long) As String
    Dim fileModDate As String
    Dim fs As Object, f As Object
    GetFileDate = " -!- "
    On Error Resume Next
    If DirExists(file) Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        Set f = fs.GetFolder(file)
        Cells(row, col) = f.Size
        GetFileDate = "  " + Format(f.DateLastModified, "yyyy-mm-dd")
    ElseIf FileExists(file) Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        Set f = fs.GetFile(file)
        Cells(row, col) = f.Size
        GetFileDate = "  " + Format(f.DateLastModified, "yyyy-mm-dd")
    End If
End Function

Private Function GetString(sline As String, skey As String, row As Long, col As Long) As String
    Dim s As String, ss As String
    Dim i As Long, l As Long, lkey As Long, p As Long, p2 As Long
    p = InStr(LCase(sline), LCase(skey))
    GetString = ""
    If p > 0 Then
        i = 1
        l = Len(sline)
        lkey = Len(skey)
        sline = Mid(sline, p + lkey, l - p + lkey)
        l = Len(sline)
        s = LCase(Mid(sline, i, 1)) ' try to find the start of the string
        While (i < l) And ((s = """") Or (s = " ") Or (s = Chr(9)) Or (s = ":"))
            i = i + 1
            s = LCase(Mid(sline, i, 1))
        Wend
        p = i
        i = i + 1
        s = LCase(Mid(sline, i, 1))  ' try to find the end of the string
        While (i <= l) And Not ((s = """") Or ((s = ",") And (i - p > 3)) Or (s = Chr(13)) Or (s = Chr(10)) Or (s = Chr(9)) Or (s = Chr(8)))
            i = i + 1
            s = LCase(Mid(sline, i, 1))
        Wend
        p2 = i
        s = Mid(sline, p, p2 - p) ' copy from right pos
        'ss = Cells(row, col)
        'If ss <> s And s <> "null" Then
        '    s = ss + " " + s
        'End If
        If s = "," Then: s = ""
        If s = "." Then: s = ""
        If s = "null" Then: s = ""
        If s = "falsch" Then: s = ""
        If s = "false" Then: s = ""
        GetString = s
    End If
End Function

''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Function GetACDirAutomatic() As String
    Dim logfile As String
    Dim i As Long
    Dim s As String, ss As String
    GetACDirAutomatic = ""
    ' open last AC-log file to find AC-dir
    logfile = Environ("USERPROFILE") + "\Documents\Assetto Corsa\logs\launcher.log"
    If FileExists(logfile) Then
        Dim lines() As String
        Dim linesC As Long
        lines = ScanFileUTF8(logfile)
        linesC = UBound(lines())
        If linesC <= 0 Then: Exit Function
        i = 0
        While i <= linesC
            s = lines(i)
            ss = LCase(s)
            If InStr(ss, "searching for .config at: assettocorsa.exe -> ") > 0 Then
                ss = GetString(ss, "searching for .config at: assettocorsa.exe -> ", 0, 0)
                ss = Mid(ss, 1, InStrRev(ss, "\")) + "content"
                GetACDirAutomatic = ss
                Exit Function
            End If
            i = i + 1
        Wend
    End If
End Function

''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' browse for a dir (API-calls)
Public Function GetADirOrFile(InitDir As String, InitName As String, msg As String, Optional bDirNeeded As Boolean = True) As String
    Dim myFilter, s_filename As String
    Dim OpenDlg As OPENFILENAME
#If VBA7 Then
    Dim hWnd As LongPtr ' 64bit
#Else
    Dim hWnd As Long ' 32bit
#End If
    On Error GoTo Error_GetAFile
    myFilter = "*.*" + cnstNull
    If Len(InitName) <> 0 Then
      s_filename = InitName + String$(512 - Len(InitName), 0)
    Else
      s_filename = String$(512, 0)
    End If

    hWnd = GetWindow(Application.hWnd, GW_HWNDFIRST)
    With OpenDlg
       If bDirNeeded Then
          .flags = OFN_PATHMUSTEXIST
       Else
          .flags = OFN_FILEMUSTEXIST Or OFN_PATHMUSTEXIST
       End If
       .flags = OFN_PATHMUSTEXIST ' directory needed
       .lpstrFilter = myFilter
       .lStructSize = Len(OpenDlg)
       .hInstance = 0
       .hwndOwner = 0 ' hWnd
       .nFilterIndex = 1
       .lpstrFile = s_filename
       .nMaxFile = 512
       .lpstrInitialDir = InitDir
       .lpstrTitle = msg
       .lpstrDefExt = cnstNull
       If GetOpenFileName(OpenDlg) <> 0 Then  ' success
          s_filename = Left$(.lpstrFile, InStr(.lpstrFile, cnstNull) - 1)
          GetADirOrFile = s_filename
       Else
          s_filename = ""
          GetADirOrFile = s_filename
       End If
    End With
Exit_GetAFile:
    Exit Function
Error_GetAFile:
    MsgBox Error$, , "Error_GetADirOrFile Sub"
    Resume Exit_GetAFile
End Function

Public Function FileExists(ByVal FileName As String) As Boolean
    Dim fso As Object
    FileExists = False
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FileExists(FileName) Then: FileExists = True
End Function

Public Function DirExists(ByVal FileName As String) As Boolean
    Dim fso As Object
    DirExists = False
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(FileName) Then: DirExists = True
End Function

