Attribute VB_Name = "AssettoCorsaScanner"
Option Explicit

' var for Progressbar in "FormProgress", exactly 100 pipes
Const ProgressString = "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"

Const CommentPopupWidth = 640
Const CommentPopupHeight = 512

Dim previewWidth As Integer   ' = 10
Dim previewHeight As Integer    ' = 32
Dim bLightMode As Boolean
Dim bExtraInfo As Boolean
Dim bCountSize As Boolean

Dim doTrackMapPreviewOnly As Boolean   ' without preview-picture of the track
Dim DoSingleFolder As Boolean
Dim iPreviewSize As Integer
Dim DirFilter As String
Dim xlsDirectory As String
Dim doUnpackACDs As Boolean
Dim isACDexeThere As Boolean

Const files = "car.ini,engine.ini,drivetrain.ini,suspensions.ini,tyres.ini,aero.ini,ai.ini,lods.ini,setup.ini,brakes.ini,ers.ini,analog_instruments.ini,ambient_shadows.ini,blurred_objects.ini,cameras.ini,colliders.ini,damage.ini,dash_cam.ini,digital_instruments.ini,driver3d.ini,electronics.ini,escmode.ini,flame_presets.ini,flames.ini,fuel_cons.ini,lights.ini,mirrors.ini,proview_nodes.ini,sounds.ini,suspension_graphics.ini,wing_animations.ini"
'Const files = "car.ini"
'Const files = "engine.ini"
'Const files = "analog_instruments.ini"

Const doShortSummary = True

''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' --- all needed API-declarations for file browsing --- '
Dim cnstNull As String * 1         ' NULL-string

' browse for a dir (API-calls)
Public Function GetADirOrFile(InitDir As String, InitName As String, msg As String, Optional bDirNeeded As Boolean = True) As String
    'getadirorfolder2 = ""
    Dim objFileDialog As Office.FileDialog
    If bDirNeeded Then
        Set objFileDialog = Application.FileDialog(MsoFileDialogType.msoFileDialogFolderPicker)
        With objFileDialog
            .InitialFileName = InitDir
            .AllowMultiSelect = False
            .ButtonName = msg
            .Title = msg
            If (.Show > 0) Then
            End If
            If (.SelectedItems.Count > 0) Then
                GetADirOrFile = .SelectedItems(1)
            End If
        End With
    Else
        Set objFileDialog = Application.FileDialog(MsoFileDialogType.msoFileDialogFilePicker)
        With objFileDialog
            .AllowMultiSelect = False
            .InitialFileName = InitDir
            .ButtonName = msg
            .Title = msg
            If (.Show > 0) Then
            End If
            If (.SelectedItems.Count > 0) Then
                GetADirOrFile = .SelectedItems(1)
            End If
        End With
    End If
End Function

Public Function FileExists(ByVal FileName As String) As Boolean
    Dim fso As Object
    FileExists = False
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FileExists(FileName) Then
        FileExists = True
        'fso.Close
    End If
End Function

Public Function DirExists(ByVal FileName As String) As Boolean
    Dim fso As Object
    DirExists = False
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(FileName) Then
        DirExists = True
        'fso.Close
    End If
End Function



Public Function ScanFileUTF8_1(FileName As String) As String()
    Dim objStream, strData
    Set objStream = CreateObject("ADODB.Stream")
    objStream.Charset = "utf-16"
    objStream.Open
    objStream.LoadFromFile (FileName)
    'objStream.
    'strData = objStream.ReadText(-2)
    strData = objStream.ReadText()
    objStream.Close
    Set objStream = Nothing
    If strData <> "" Then
        strData = Replace$(strData, vbLf, vbCrLf)
        Dim lines() As String: lines = Split(strData, vbCrLf)
        If UBound(lines) < 2 Then  ' all in one line compressed js style, split to lines
            lines = Split(strData, ", ")
        End If
        If UBound(lines) < 2 Then  ' all in one line compressed js style, split to lines
            lines = Split(strData, ",")
        End If
        
        Dim linesC As Integer: linesC = UBound(lines())
        If linesC > 0 Then
            Dim lastL As String, s As String
            Dim I As Integer, j As Integer
            I = 1
            lastL = lines(0)
            While I < linesC - 1
                s = CleanTrim(lines(I))
                If (lastL = "" And Left(s, 1) <> "[") Or (lastL = "" And s = "") Then
                    Call RemoveLine(lines, linesC, I - 1)
                    lastL = CleanTrim(lines(I - 1))
                ElseIf (s = "" And Left(lastL, 1) = "[") Then
                    Call RemoveLine(lines, linesC, I)
                    lastL = CleanTrim(lines(I))
                Else
                    lastL = s
                    I = I + 1
                End If
                lines(I - 1) = lastL
            Wend
        End If
        ScanFileUTF8_1 = lines  ' result!
    Else
        ReDim ScanFileUTF8_1(0)
    End If
End Function




Public Function ScanFileUTF8(FileName As String) As String()
    Dim abString()  As Byte
    Dim sDecoded    As String
    Dim hFile       As Integer
    Dim newdim As Integer
    Dim l As Integer
  
    'Debug.Print "---- ReadNotepadTextFile() in a byte array and convert to UTF8:"
    'Debug.Print "[File: " & psFileName & "]"
    
    hFile = FreeFile
    Open FileName For Binary Access Read As #hFile
    On Error GoTo exitsub
    newdim = LOF(hFile)
    ReDim abString(newdim)
    Get #hFile, 1, abString
    Close hFile
  
    'ScanFileUTF8 = UTF8DecodeByteArrayToString(abString)
    ScanFileUTF8 = ScanFileUTF8_1(FileName)
    l = UBound(ScanFileUTF8)
    If l = 0 Then
        ' ScanFileUTF8 = ScanFileUTF8_1(FileName)
        ScanFileUTF8 = UTF8DecodeByteArrayToString(abString)
    End If
exitsub:
End Function
  
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Sub RunACScannerCarsClear()
    Call ReadVarsFromControlSheet
    Sheets("Cars").Select ' in case were debuging
    Call AssettoCorsaScanner(False, True)
End Sub

Sub RunACScannerCars() ' Add
    Call ReadVarsFromControlSheet
    Sheets("Cars").Select ' in case were debuging
    Call AssettoCorsaScanner(False, False)
End Sub

Sub RunACScannerTracksClear()
    Call ReadVarsFromControlSheet
    Sheets("Tracks").Select ' in case were debuging
    Call AssettoCorsaScanner(True, True)
End Sub

Sub RunACScannerTracks() ' Add
    Call ReadVarsFromControlSheet
    Sheets("Tracks").Select ' in case were debuging
    Call AssettoCorsaScanner(True, False)
End Sub

Sub RunACDeleteAll() ' clear all sheets
    Dim FirstPath As String, SecondPath As String
    FirstPath = Sheets("control").Cells(2, 1).Text
    SecondPath = Sheets("control").Cells(2, 2).Text
    Application.ScreenUpdating = False
    Call CleanUpSheet(Sheets("Tracks"))
    Call CleanUpSheet(Sheets("Cars"))
    Call RunACDeletePreviews
    Call DeleteComments
    Application.ScreenUpdating = False
    Call RefillValuesCars(FirstPath, SecondPath)
    Call RefillValuesTracks
    Sheets("control").Select
    Application.ScreenUpdating = True
End Sub

Sub RunACDeletePreviews()
    FormProgress.Show
    FormProgress.Tag = 0
    FormProgress.lbProgress = ""
    FormProgress.lbCurrDir = "cleanup..."
    FormProgress.Repaint
    Application.ScreenUpdating = False

    Sheets("Cars").Select
    Call CleanUpPictures(Sheets("Cars"))
    Sheets("Tracks").Select
    Call CleanUpPictures(Sheets("Tracks"))
    Application.ScreenUpdating = True
    Unload FormProgress
    Sheets("control").Select
End Sub


Sub RunGetDirCars()
    Dim FirstPath As String, startdir As String
    Dim DirCount As Integer, NumFiles As Integer
    Dim s_filename As String
    
    ' \CARS-directory
    FirstPath = Sheets("control").Cells(2, 1).Text
    If FirstPath = "" Then
        FirstPath = GetACDirAutomatic2()
        If FirstPath <> "" Then
            If MsgBox("Found AC in " + FirstPath + ". Use it?", vbYesNo) = vbYes Then
                FirstPath = FirstPath + "\cars"
            End If
        End If
    Else
        startdir = FirstPath
        FirstPath = ""
    End If
    
    
    If FirstPath = "" Then
        s_filename = "[ignored]"  ' browse for it
        s_filename = GetADirOrFile(startdir, s_filename, "Browse for AssettoCorsa '\cars' directory")
        If (s_filename = "") Or (s_filename = "Falsch") Or s_filename = "False" Then
            'MsgBox ("Canceled.")
            Exit Sub
        End If
        FirstPath = Mid(s_filename, 1, InStrRev(s_filename, "\") - 1)
    End If
    Sheets("control").Cells(2, 1) = FirstPath
End Sub

Sub RunGetDirTrack()
    Dim SecondPath As String, startdir As String
    Dim DirCount As Integer, NumFiles As Integer
    Dim s_filename As String
    
    ' \TRACK-directory
    SecondPath = Sheets("control").Cells(2, 2).Text
    If SecondPath = "" Then
        SecondPath = GetACDirAutomatic2()
        If SecondPath <> "" Then
            If MsgBox("Found AC in " + SecondPath + ". Use it?", vbYesNo) = vbYes Then
                SecondPath = SecondPath + "\tracks"
            End If
        End If
    Else
        startdir = SecondPath
        SecondPath = ""
    End If
    
    If SecondPath = "" Then
        s_filename = "[ignored]"  ' browse for it
        s_filename = GetADirOrFile(startdir, s_filename, "Browse for AssettoCorsa '\tracks' directory")
        If (s_filename = "") Or (s_filename = "Falsch") Or s_filename = "False" Then
            'MsgBox ("Canceled.")
            Exit Sub
        End If
        SecondPath = Mid(s_filename, 1, InStrRev(s_filename, "\") - 1)
    End If
    Sheets("control").Cells(2, 2) = SecondPath
End Sub


Private Sub DeleteComments()
    Dim c As Integer
    Dim cmt As Comment
    ' delete comments
    c = 1
    For c = 1 To 5000
        Set cmt = Cells(c, 4).Comment
        If cmt Is Nothing Then
        Else
            Cells(c, 4).ClearComments
        End If
        Set cmt = Cells(c, 5).Comment
        If cmt Is Nothing Then
        Else
            Cells(c, 5).ClearComments
        End If
        Set cmt = Cells(c, 11).Comment
        If cmt Is Nothing Then
        Else
            Cells(c, 11).ClearComments
        End If
        Set cmt = Cells(c, 41).Comment
        If cmt Is Nothing Then
        Else
            Cells(c, 41).ClearComments
        End If
    Next c
End Sub
    
Private Sub CommentsFromContent(col)
    Dim r As Integer
    Dim cmt As Comment
    ' delete comments
    r = 2
    While Cells(r, 1) <> ""
        If Trim(Cells(r, col).Text) <> "" Then
            Set cmt = Cells(r, col).Comment
            If cmt Is Nothing Then
                Cells(r, col).AddComment ' description of flags
                Cells(r, col).Comment.Visible = False
                Cells(r, col).Comment.Shape.Width = 200
                Cells(r, col).Comment.Shape.Height = 140
                Cells(r, col).WrapText = True
            End If
            Cells(r, col).Comment.Text Text:=Cells(r, col).Text
        End If
        r = r + 1
    Wend
End Sub
    
Private Function CleanUpPictures(sheet As Object)
    ' attention "FormProgress" not present when running this procedure alone in debug
    Dim Pic As Object
    Dim I As Integer, c As Integer, proz As Long
    Dim cmt As Comment
        
    CleanUpPictures = False
    c = 1
    Application.ScreenUpdating = True
    
    For Each Pic In sheet.Pictures
        If Not FormProgress.Visible Then: Exit For
        If Not FormProgress.Enabled Then: Exit For
        DoEvents
        
       
        FormProgress.lbCurrDir = "counting " + CStr(c) + " pics"
        FormProgress.Repaint
        c = c + 1
    Next Pic
    Application.ScreenUpdating = False
    
    ' attention "FormProgress" not present when running this procedure alone in debug
    If Not FormProgress.Visible Then: Exit Function
    If Not FormProgress.Enabled Then: Exit Function
    
    c = 2
    While sheet.Cells(c, 2) <> "" Or sheet.Cells(c, 3) <> ""
        Set cmt = sheet.Cells(c, 1).Comment
        If cmt Is Nothing Then
        Else
            Cells(c, 1).ClearComments
        End If
        With Cells(c, 1).Interior
            .Pattern = xlNone
            .TintAndShade = 0
            .PatternTintAndShade = 0
        End With
        c = c + 1
    Wend
    
    I = 1
    For Each Pic In sheet.Pictures
        ' check if progress window was closed
        If Not FormProgress.Visible Then: Exit For
        If Not FormProgress.Enabled Then: Exit For
        If I Mod 5 = 0 Then
            proz = Fix(CDbl(I) / CDbl(c) * 100#)
            FormProgress.Caption = "preview " + CStr(I) + " of " + CStr(c) + "  -  " + CStr(proz) + "%"
            FormProgress.lbProgress = Mid(ProgressString, 1, proz)
            FormProgress.lbCurrDir = "delete '" + Pic.Name + "'"
            FormProgress.Repaint
        End If
        Pic.Delete
        I = I + 1
    Next Pic
    If I > 0 And c > 1 Then: CleanUpPictures = True
End Function

Private Function CleanUpSheet(sheet As Object) As Boolean
    Dim Pic As Object
    Dim I As Integer, c As Integer, proz As Integer
    CleanUpSheet = False
    CleanUpSheet = CleanUpPictures(sheet)
    sheet.Cells.Clear
    ' sheet.Cells.UsedRange.ClearContents
    sheet.UsedRange.ClearContents
End Function

Sub ReadVarsFromControlSheet()
    bLightMode = Worksheets("control").Shapes("cbLightmode").OLEFormat.Object.Value = 1
    bExtraInfo = Worksheets("control").Shapes("cbExtrainfo").OLEFormat.Object.Value = 1
    bCountSize = Worksheets("control").Shapes("cbCountSize").OLEFormat.Object.Value = 1
    doTrackMapPreviewOnly = Worksheets("control").Shapes("cbTrackPreview").OLEFormat.Object.Value = 1
    doUnpackACDs = Worksheets("control").Shapes("cbUnpackACD").OLEFormat.Object.Value = 1
End Sub

Sub cbLightmode_Klicken() ' toggle dark/light mode
    Dim oTbl As ListObject
    Dim myRange As String
    Dim CurrSheet As Object
    Call ReadVarsFromControlSheet
    If bLightMode Then
        ActiveWorkbook.Theme.ThemeColorScheme.Colors(msoThemeHyperlink) = RGB(64, 64, 255)
    Else
        ActiveWorkbook.Theme.ThemeColorScheme.Colors(msoThemeHyperlink) = RGB(128, 128, 255)
    End If
    Sheets("Tracks").Select
    For Each oTbl In ActiveSheet.ListObjects
        If oTbl.Name = "tmpTableStyle2" Then
            If bLightMode Then
                Sheets("Tracks").ListObjects("tmpTableStyle2").TableStyle = "TableStyleLight1"
            Else
                Sheets("Tracks").ListObjects("tmpTableStyle2").TableStyle = "TableStyleDark1"
            End If
        End If
    Next oTbl
    Sheets("Cars").Select
    For Each oTbl In ActiveSheet.ListObjects
        If oTbl.Name = "tmpTableStyle1" Then
            If bLightMode Then
                ActiveSheet.ListObjects("tmpTableStyle1").TableStyle = "TableStyleLight1"
            Else
                ActiveSheet.ListObjects("tmpTableStyle1").TableStyle = "TableStyleDark1"
            End If
        End If
    Next oTbl
    Sheets("control").Select
End Sub

Private Sub RefillValuesCars(FirstPath As String, SecondPath As String)
    ' deleted all infos, recreate!
    Sheets("control").Columns("A:B").ColumnWidth = 80
    Sheets("control").Columns("C:C").ColumnWidth = 60
    Sheets("control").Columns("D:G").ColumnWidth = 20
    
    Sheets("control").Cells(1, 1) = "Assetto Corsa '\cars' directory to use:"
    Sheets("control").Cells(2, 1) = FirstPath
    Sheets("control").Cells(1, 2) = "Assetto Corsa '\tracks' directory to use:"
    Sheets("control").Cells(2, 2) = SecondPath
    Sheets("control").Cells(1, 3) = "Options for both Car- and Track-Scanner:"
    Sheets("control").Rows("1:2").RowHeight = 40
   
    'sheets("control").Columns("A:F").VerticalAlignment = xlCenter
    Sheets("control").Range("A1:F1").VerticalAlignment = xlTop
    Sheets("control").Range("A1:F1").WrapText = True
    Sheets("control").Cells(1, 7) = "previewSize items"
    Sheets("control").Cells(2, 7) = "none"
    Sheets("control").Cells(3, 7) = "small"
    Sheets("control").Cells(4, 7) = "medium"
    Sheets("control").Cells(5, 7) = "large"
    Sheets("control").Cells(6, 7) = "extra large"
    
    Sheets("Cars").Rows("1:1").RowHeight = 50
    'Sheets("Cars").Columns("A:AO").VerticalAlignment = xlCenter
    Sheets("Cars").Range("A1:AO1").VerticalAlignment = xlTop
    Sheets("Cars").Range("A1:AO1").WrapText = True
    Sheets("Cars").Range("A1:AO1").WrapText = True
    Sheets("Cars").Range("AB1:AN1").HorizontalAlignment = xlGeneral
    Sheets("Cars").Range("AB1:AN1").Orientation = 90
    Sheets("Cars").Range("AA:AA").WrapText = True
    Sheets("Cars").Columns("AA:AN").HorizontalAlignment = xlLeft
    Sheets("Cars").Range("AA:AO").VerticalAlignment = xlTop
   
    Sheets("Cars").Range("D1:M1").HorizontalAlignment = xlRight
    Sheets("Cars").Columns("D:W").HorizontalAlignment = xlCenter ' numbers centered
    Sheets("Cars").Columns("H:H").HorizontalAlignment = xlRight
    Sheets("Cars").Columns("AB:AO").ColumnWidth = 3 ' INIversions
    'Sheets("Cars").Columns("AB:AN").HorizontalAlignment = xlCenter ' numbers centered
    'Sheets("Cars").Columns("AB:AN").VerticalAlignment = xlCenter

'    sheets("Cars").Range("A1:AO1").Font.Size = 10
    Sheets("Cars").Range("A1:AO1").Font.Bold = True
    
    ' input zone emphasis on "dir to use" description
    With Sheets("control").Range("A2:B2").Font
'        .Size = 14
        .Bold = True
        .Color = -4165632
        .TintAndShade = 0
    End With
    With Sheets("control").Range("A2:B2").Font
'        .Size = 12
        .Bold = True
        .Color = -4165632
        .TintAndShade = 0
    End With
    
    Sheets("Cars").Cells(1, 1) = "Car"
    Sheets("Cars").Cells(1, 2) = "Brand"
    Sheets("Cars").Cells(1, 3) = "Name  -  CLICK this coulmn to open cars data files in new excel file"
    Sheets("Cars").Cells(1, 4) = "Class"
    Sheets("Cars").Cells(1, 5) = "drive/gears * .acd packed"
    Sheets("Cars").Cells(1, 6) = "power in bhp"
    Sheets("Cars").Cells(1, 7) = "torque in Nm"
    Sheets("Cars").Cells(1, 8) = "weight in kg"
    Sheets("Cars").Cells(1, 9) = "topspeed in km/h"
    Sheets("Cars").Cells(1, 10) = "0-100 kmh in secs"
    Sheets("Cars").Cells(1, 11) = "wpratio in kg/bhp"
    Sheets("Cars").Cells(1, 12) = "range in km"
    Sheets("Cars").Cells(1, 13) = "MaxBrakeTorque in Nn"
    Sheets("Cars").Cells(1, 14) = "ABS"
    Sheets("Cars").Cells(1, 15) = "TC"
    Sheets("Cars").Cells(1, 16) = "MaxRPM"
    ' torque motor brake
    Sheets("Cars").Cells(1, 17) = "Turbo"
    Sheets("Cars").Cells(1, 18) = "tyreVersion"
    Sheets("Cars").Cells(1, 19) = "liter/100km"
    Sheets("Cars").Cells(1, 20) = "flags"
    
    Sheets("Cars").Cells(1, 21) = "Country"
    Sheets("Cars").Cells(1, 22) = "Year"
    Sheets("Cars").Cells(1, 23) = "Author -Version (url)"
    Sheets("Cars").Cells(1, 24) = "timestamp *sfx diff"
    
    Sheets("Cars").Cells(1, 25) = "dir"
    Sheets("Cars").Cells(1, 26) = "size in bytes"
    Sheets("Cars").Cells(1, 27) = "Description"
    
    ' Sheets("Cars").Cells(1, 28) = "INI versions"
    ' cells(1,iColStartOfDefinies) ' s.o. = iColStartOfDefinies
    Sheets("Cars").Cells(1, 28) = "drivetrain"
    Sheets("Cars").Cells(1, 29) = "brakes"
    Sheets("Cars").Cells(1, 30) = "engine"
    Sheets("Cars").Cells(1, 31) = "car.ini"
    Sheets("Cars").Cells(1, 32) = "wing_ani"
    Sheets("Cars").Cells(1, 33) = "aero"
    Sheets("Cars").Cells(1, 34) = "ai"
    Sheets("Cars").Cells(1, 35) = "drs"  ' DragReductionSystem
    Sheets("Cars").Cells(1, 36) = "ers"  ' (Kinetic)EnergyRecoverySystem
    Sheets("Cars").Cells(1, 37) = "lights"
    Sheets("Cars").Cells(1, 38) = "susp"
    Sheets("Cars").Cells(1, 39) = "susp front"
    Sheets("Cars").Cells(1, 40) = "susp rear"
    If doShortSummary Then: Sheets("Cars").Cells(1, 41) = "shortdata"
    Sheets("Cars").Cells(1, 42) = "[GEARS]UP"
    Sheets("Cars").Cells(1, 43) = "DOWN"
    Sheets("Cars").Cells(1, 44) = "SLIP_THRESHOLD"
    Sheets("Cars").Cells(1, 45) = "GAS_CUTOFF_TIME"
    Sheets("Cars").Cells(1, 46) = "[PEDALS]GASGAIN"
    Sheets("Cars").Cells(1, 47) = "BRAKE_HINT"
    Sheets("Cars").Cells(1, 48) = "TRAIL_HINT"
    Sheets("Cars").Cells(1, 49) = "[STEER]STEER_GAIN"
    Sheets("Cars").Cells(1, 50) = "[LOOKAHEAD]BASE"
    Sheets("Cars").Cells(1, 51) = "SPEED_GAIN"
    Sheets("Cars").Cells(1, 52) = "GAS_BRAKE_LOOKAHEAD"
    Sheets("Cars").Cells(1, 53) = "[ULTRA_GRIP]Value"
    Sheets("Cars").Cells(1, 54) = "[DRAG]SLIP_RATIO_MAX"
    Sheets("Cars").Cells(1, 55) = "[PHYSICS_HINTS]AERO_HINT"
    Sheets("Cars").Cells(1, 57) = "tags - select last for JSON update"
    Sheets("Cars").Cells(1, 56) = "tags update"
    Sheets("Cars").Range("BD1:BD1").Orientation = 90
End Sub

Private Sub RefillValuesTracks()
    Sheets("Tracks").Select
    Sheets("Tracks").Columns("E:I").HorizontalAlignment = xlCenter
    Sheets("Tracks").Rows("1:1").RowHeight = 50
    Sheets("Tracks").Range("A1:O1").VerticalAlignment = xlTop
    Sheets("Tracks").Range("A1:O1").WrapText = True
    Sheets("Tracks").Range("O:O").WrapText = True

'    sheets("Tracks").Range("A1:O1").Font.Size = 10
    Sheets("Tracks").Range("A1:O1").Font.Bold = True
    
    Sheets("Tracks").Cells(1, 1) = "Track"
    Sheets("Tracks").Cells(1, 2) = "Name"
    Sheets("Tracks").Cells(1, 3) = "Layout"
    
    Sheets("Tracks").Cells(1, 4) = "Country"
    Sheets("Tracks").Cells(1, 5) = "City"
    Sheets("Tracks").Cells(1, 6) = "Year"
    
    Sheets("Tracks").Cells(1, 7) = "Lenght in m"
    Sheets("Tracks").Cells(1, 8) = "Road Width average"
    Sheets("Tracks").Cells(1, 9) = "Pitboxes"
    Sheets("Tracks").Cells(1, 10) = "Direction"
    Sheets("Tracks").Cells(1, 11) = "Author -Version (url)"
    Sheets("Tracks").Cells(1, 12) = "timestamp *kn5 diff"
    Sheets("Tracks").Cells(1, 13) = "dir"
    Sheets("Tracks").Cells(1, 14) = "size in bytes"
    Sheets("Tracks").Cells(1, 15) = "Description"
    Sheets("Tracks").Cells(1, 16) = "tags"
    Sheets("Tracks").Columns("P").ColumnWidth = 50
End Sub

Sub GetWorkbookFolder()
    xlsDirectory = ActiveWorkbook.FullName
    If Right$(xlsDirectory, 1) = "\" Then
        xlsDirectory = Mid(xlsDirectory, 1, Len(xlsDirectory) - InStrRev(xlsDirectory, "\") - 1)
    Else
        xlsDirectory = Mid(xlsDirectory, 1, InStrRev(xlsDirectory, "\"))
    End If
End Sub

' -------------------------------------------------------------------
' -----------------------main sub --------------------------
Private Sub AssettoCorsaScanner(bTracks As Boolean, bClearSheet As Boolean)
    Dim FirstPath As String, SecondPath As String, CurrDir As String
    Dim DirCount As Integer, NumFiles As Integer
    Dim s_filename As String
    Dim ss As String
    Dim bPreview As Boolean
    Dim CurrSheet As Object
    Dim dw As Double
    Dim row As Integer, lastRow As Integer
    Dim oTbl As ListObject
    Dim cmt As Comment
    Dim myRange As String, sDataFile As String
    
    Call GetWorkbookFolder
    DirFilter = UCase(Sheets("control").Cells(9, 3).Text)
    DirFilter = Replace(DirFilter, " ", "")
    
    If bLightMode Then
    ActiveWorkbook.Theme.ThemeColorScheme.Colors(msoThemeHyperlink) = RGB(64, 64, 255)
    Else
    ActiveWorkbook.Theme.ThemeColorScheme.Colors(msoThemeHyperlink) = RGB(192, 192, 255)
    End If
    
    ' read from A2 and A4
    FirstPath = Sheets("control").Cells(2, 1).Text
    SecondPath = Sheets("control").Cells(2, 2).Text
    If FirstPath <> "" Then
        If Mid(FirstPath, Len(FirstPath), 1) = "\" Then
            ' kill trailing \
            FirstPath = Mid(FirstPath, 1, Len(FirstPath) - 1)
            Sheets("control").Cells(2, 1) = FirstPath
        End If
    End If
    If SecondPath <> "" Then
        If Mid(SecondPath, Len(SecondPath), 1) = "\" Then
            ' kill trailing \
            SecondPath = Mid(SecondPath, 1, Len(SecondPath) - 1)
            Sheets("control").Cells(2, 2) = SecondPath
        End If
    End If
    
    CurrDir = FirstPath
    Set CurrSheet = Sheets("Cars") ' Sheets("Cars")
    If bTracks Then
        CurrDir = SecondPath
        Set CurrSheet = Sheets("Tracks") ' Sheets("Tracks")
    End If
    
    DoSingleFolder = False
    ' cars
    If Not bTracks Then
        sDataFile = FirstPath + "\ui\ui_car.json"
        If FileExists(sDataFile) Then
            DoSingleFolder = True
        End If
    Else
        sDataFile = SecondPath + "\ui\ui_track.json"
        If FileExists(sDataFile) Then
            DoSingleFolder = True
        End If
    End If
    
    CurrSheet.Activate
    If Not bTracks Then ' cars
        If Not DirExists(FirstPath) Then
            Call RunGetDirCars
            CurrDir = Sheets("control").Cells(2, 1).Text
            FirstPath = CurrDir
            If Sheets("control").Cells(2, 1) = "" Then
                Exit Sub
            End If
        End If
        For Each oTbl In ActiveSheet.ListObjects
            If oTbl.Name = "tmpTableStyle1" Then
                If bClearSheet Then
                    oTbl.Delete
                Else
                    ActiveSheet.ListObjects("tmpTableStyle1").TableStyle = ""
                    ActiveSheet.ListObjects("tmpTableStyle1").Unlist
                End If
            End If
        Next oTbl
    Else                ' tracks
        If Not DirExists(SecondPath) Then
            Call RunGetDirTrack
            SecondPath = Sheets("control").Cells(2, 2).Text
            CurrDir = SecondPath
            If Sheets("control").Cells(2, 2) = "" Then
                Exit Sub
            End If
        End If
        For Each oTbl In ActiveSheet.ListObjects
            If oTbl.Name = "tmpTableStyle2" Then
                If bClearSheet Then
                    oTbl.Delete
                Else
                    ActiveSheet.ListObjects("tmpTableStyle2").TableStyle = ""
                    ActiveSheet.ListObjects("tmpTableStyle2").Unlist
                End If
            End If
        Next oTbl
    End If
    
    bPreview = False ' no preview - "none" - default
    previewWidth = 3
    previewHeight = 16
    iPreviewSize = Worksheets("control").Shapes("comboSize").OLEFormat.Object.Value
    If iPreviewSize = 2 Then
        previewWidth = 10
        previewHeight = 32
        bPreview = True
    ElseIf iPreviewSize = 3 Then
        previewWidth = 21
        previewHeight = 65
        bPreview = True
    ElseIf iPreviewSize = 4 Then
        previewWidth = 42
        previewHeight = 128
        bPreview = True
    ElseIf iPreviewSize = 5 Then
        previewWidth = 85.5
        previewHeight = 256
        bPreview = True
    End If

    If DirExists(CurrDir) Then
        FormProgress.Show
        FormProgress.Tag = 0
        FormProgress.lbProgress = ""
        FormProgress.lbCurrDir = "cleanup..."
        FormProgress.Repaint
        
        row = 0
        If bClearSheet Then
            If Not CleanUpSheet(CurrSheet) Then: Exit Sub
            If Not bTracks Then
                Call DeleteComments
                Call RefillValuesCars(FirstPath, SecondPath)
            Else
                Call RefillValuesTracks
            End If
        Else
            row = 2
            While CurrSheet.Cells(row, 2) <> "" Or CurrSheet.Cells(row, 3) <> ""
                row = row + 1
            Wend
            row = row - 2
        End If
        
        Application.ScreenUpdating = True
        DoEvents
        FormProgress.Tag = 0
        Application.ScreenUpdating = False
        
        CurrSheet.Activate
        NumFiles = 0
        lastRow = row
        
        ' --- first count dirs ---
        NumFiles = ScanDirectory(CurrDir, True, bPreview, bTracks, row)
        
        If Not bTracks Then
            CurrSheet.Cells(1, 25) = "dir (" + CStr(NumFiles) + " found)"
        Else
            CurrSheet.Cells(1, 13) = "dir (" + CStr(NumFiles) + " found)"
        End If
        
        Application.ScreenUpdating = True
        CurrSheet.Activate
        DoEvents
        
        
        If FormProgress.Visible And FormProgress.Enabled Then
        
            ' FormProgress.Show
            FormProgress.Tag = NumFiles
            FormProgress.lbProgress = ""
            FormProgress.lbCurrDir = CurrDir
            FormProgress.Repaint
            Application.ScreenUpdating = False
            
            isACDexeThere = False
            If bTracks Then
                CurrSheet.Columns("A:A").ColumnWidth = previewWidth - 1
            Else
                CurrSheet.Columns("A:A").ColumnWidth = previewWidth
                If FileExists(xlsDirectory + "acd_file.exe") Then
                    isACDexeThere = True
                End If
            End If
            CurrSheet.Activate
            
            
            ' --- second do the work ---
            row = lastRow
            NumFiles = ScanDirectory(CurrDir, False, bPreview, bTracks, row)
            DoEvents
            
            
            ' format
            If NumFiles > 0 Then
                CurrSheet.Activate
                Application.ScreenUpdating = False
                'If doShortSummary Then
                '    myRange = "$A$1:$BD$"
                'Else
                '    myRange = "$A$1:$AN$"
                'End If
                If Not bTracks Then
                    myRange = "$A$1:$BE$"
                    CurrSheet.ListObjects.Add(xlSrcRange, Range(myRange + CStr(NumFiles + 1)), , xlYes).Name = "tmpTableStyle1"
                    If bLightMode Then ' cars named table
                        CurrSheet.ListObjects("tmpTableStyle1").TableStyle = "TableStyleLight1"
                    Else
                        CurrSheet.ListObjects("tmpTableStyle1").TableStyle = "TableStyleDark1"
                    End If
                Else
                    myRange = "$A$1:$P$"
                    CurrSheet.ListObjects.Add(xlSrcRange, Range(myRange + CStr(NumFiles + 1)), , xlYes).Name = "tmpTableStyle2"
                    If bLightMode Then ' tracks named table
                        CurrSheet.ListObjects("tmpTableStyle2").TableStyle = "TableStyleLight1"
                    Else
                        CurrSheet.ListObjects("tmpTableStyle2").TableStyle = "TableStyleDark1"
                    End If
                    Rows("2:" + CStr(NumFiles + 1)).VerticalAlignment = xlCenter
                    Columns(1).ColumnWidth = Columns(1).ColumnWidth '* 2
                End If
                
                If Not bTracks Then
                    Set cmt = Range("T1").Comment
                    If cmt Is Nothing Then
                        Range("T1").AddComment ' description of flags
                        Range("T1").Comment.Visible = False
                        Range("T1").Comment.Shape.Width = 400
                        Range("T1").Comment.Shape.Height = 440
                        Range("T1").WrapText = True
                        Range("T1").Comment.Text Text:= _
                          "  b= glowing Brakes" + Chr(10) + _
                          "  e= EDL electronic diff lock" + Chr(10) + _
                          "#f= #exaust Flames" + Chr(10) + _
                          "  s= animated Suspension" + Chr(10) + _
                          "#w= #animated Wings"
                    End If
    
                    'Columns("U:U").Cut
                    'Columns("Y:Y").Insert Shift:=xlToRight
                    CurrSheet.Columns("B:B").ColumnWidth = 15
                    CurrSheet.Columns("C:C").ColumnWidth = 25
                    CurrSheet.Columns("D:E").ColumnWidth = 10
                    CurrSheet.Columns("F:H").ColumnWidth = 8
                    CurrSheet.Columns("I:M").ColumnWidth = 6
                    CurrSheet.Columns("U:U").ColumnWidth = 14 ' country
                    CurrSheet.Columns("V:V").ColumnWidth = 7  ' year
                    CurrSheet.Columns("W:W").ColumnWidth = 25 ' author
                    CurrSheet.Columns("X:X").ColumnWidth = 11 ' dirtime
                    CurrSheet.Columns("Y:Y").ColumnWidth = 30 ' dir
                    CurrSheet.Columns("Z:Z").ColumnWidth = 12 ' size
                    CurrSheet.Columns("Z:Z").NumberFormat = "#,##0"
                    CurrSheet.Columns("AA:AA").ColumnWidth = 40 ' descr
                    
                    If bExtraInfo Then
                        CurrSheet.Columns("N:R").ColumnWidth = 3
                        CurrSheet.Columns("S:S").ColumnWidth = 4
                        CurrSheet.Columns("P:P").ColumnWidth = 5 ' maxrpm
                        CurrSheet.Columns("T:T").ColumnWidth = 8 ' flags
                        CurrSheet.Columns("AB:AL").ColumnWidth = 3 ' INIversions
                        CurrSheet.Columns("AM:AN").ColumnWidth = 5 ' INIversions
                        CurrSheet.Columns("AO:AO").ColumnWidth = 20 ' descr
                        CurrSheet.Columns("AP:BC").ColumnWidth = 8 ' INIversions
                    Else
                        CurrSheet.Columns("M:T").ColumnWidth = 0
                        CurrSheet.Columns("AB:AN").ColumnWidth = 0 ' INIversions
                    End If
                    Columns("R:R").Cut
                    Columns("AB:AB").Insert Shift:=xlToRight
                    
                    Columns("R:R").ColumnWidth = 5  ' litersper100km
                    Columns("U:U").ColumnWidth = 6  ' year
                    Columns("V:V").ColumnWidth = 15 ' author
                    Columns("W:W").ColumnWidth = 11 ' timestamp
                    Columns("X:X").ColumnWidth = 30 '
                    Columns("Y:Y").ColumnWidth = 12 ' size
                    Columns("AA:AB").ColumnWidth = 3 '
                    Range("AA:AA").VerticalAlignment = xlTop
                    Range("AA:AA").ColumnWidth = 5
                    Columns("AJ:AJ").ColumnWidth = 5 ' ers/kers info
                    Columns("AP").ColumnWidth = 8
                    Columns("BD").HorizontalAlignment = xlCenter
                    Columns("BE").ColumnWidth = 60
                    CommentsFromContent (41)
                    
                    Columns("C:C").Font.Bold = True
                    Columns("F:G").Font.Bold = True
                    '''''Selection.Font.Bold = True
                    '''''Columns("F:G").Select
                    '''''Selection.Font.Bold = False
                    '''''Selection.Font.Bold = True
                    
                    If bExtraInfo Then
                    Else
                        'CurrSheet.Columns("M:T").ColumnWidth = 0
                        CurrSheet.Columns("AP:BC").ColumnWidth = 2 ' INIversions
                    End If
                    

                Else
                    CurrSheet.Columns("B:B").ColumnWidth = 10 ' name
                    CurrSheet.Columns("C:C").ColumnWidth = 30 ' layout
                    CurrSheet.Columns("E:E").ColumnWidth = 14 ' country
                    CurrSheet.Columns("F:F").ColumnWidth = 7  ' year
                    CurrSheet.Columns("G:I").ColumnWidth = 8  ' length width pitboxes
                    CurrSheet.Columns("J:J").ColumnWidth = 14 ' direction
                    CurrSheet.Columns("K:K").ColumnWidth = 25 ' author
                    CurrSheet.Columns("L:L").ColumnWidth = 11 ' dirtime
                    CurrSheet.Columns("M:M").ColumnWidth = 30 ' dir
                    CurrSheet.Columns("N:N").ColumnWidth = 12 ' size
                    CurrSheet.Columns("N:N").NumberFormat = "#,##0"
                    CurrSheet.Columns("O:O").ColumnWidth = 40 ' descr
                End If
            Else
                If Not bTracks Then
                    CurrSheet.Cells(1, 25) = "no Cars found!"
                    Cells(1, 25).Font.Color = RGB(255, 64, 64)
                    CurrSheet.Cells(1, 25).Select
                Else
                    CurrSheet.Cells(1, 13) = "no Tracks found!"
                    Cells(1, 13).Font.Color = RGB(255, 64, 64)
                    CurrSheet.Cells(1, 13).Select
                End If
            End If
            
            Unload FormProgress
            Application.ScreenUpdating = True
            DoEvents
        End If
    End If
End Sub
' --------------------------main end---------------------------------
' -------------------------------------------------------------------

' dir-scanner
Private Function ScanDirectory(FirstPath As String, bCountonly As Boolean, bPreview As Boolean, bTracks As Boolean, row As Integer) As Integer
    Dim objFSO As Object, objFolder As Object, objSubFolder As Object
    Dim objFSO2 As Object, objFolder2 As Object, objSubFolder2 As Object
    Dim I As Integer, proz As Integer
    Dim sDataFile As String, stmp As String
    Dim lastRow As Integer
    Dim startrow As Integer
    Dim trackLocations As Integer
    Dim trackLayouts As Integer
    Dim l1 As Integer
    Dim l2 As Integer
    Dim skey As String
    
    trackLocations = 0
    trackLayouts = 0
    ScanDirectory = 0
    proz = 0
    startrow = row
    
    'Create an instance of the FileSystemObject
    Set objFSO = CreateObject("Scripting.FileSystemObject")
    'Get the folder object
    Set objFolder = objFSO.GetFolder(FirstPath)
    
    ' loop through each folder
    For Each objSubFolder In objFolder.SubFolders
        'objSubFolder.Path
        'objSubFolder.Name
        ' check if progress window was closed
        'FormProgress.Show
        
        If bCountonly Then
            FormProgress.lbCurrDir = "counting dirs: #" + CStr(row) + "  -  " + objSubFolder.path
            FormProgress.Repaint
            If row Mod 10 = 0 Then
                DoEvents
                If row > 0 And row Mod 20 = 0 Then
                    Application.ScreenUpdating = True
                    If Not FormProgress.Visible Then: Exit For
                    If Not FormProgress.Enabled Then: Exit For
                    Application.ScreenUpdating = False
                End If
            End If
            
            If Not bTracks Then
                If DoSingleFolder Then
                    sDataFile = FirstPath + "\ui\ui_car.json"
                Else
                    sDataFile = objSubFolder + "\ui\ui_car.json"
                End If
                
                If FileExists(sDataFile) And IsIncluded(sDataFile, DirFilter) Then
                    row = row + 1
                    ' insert dir as hyperlink
                    If DoSingleFolder Then
                        Cells(row + 1, 24) = GetFileDateAndSize(FirstPath, row + 1, 26)   ' dirdate+size
                        stmp = Mid(FirstPath, InStrRev(FirstPath, "\"), Len(FirstPath) - InStrRev(FirstPath, "\") + 1)
                        ActiveSheet.Hyperlinks.Add Anchor:=Cells(row + 1, 25), Address:=FirstPath, TextToDisplay:=stmp
                    Else
                        Cells(row + 1, 24) = GetFileDateAndSize(objSubFolder.path, row + 1, 26)   ' dirdate+size
                        stmp = Mid(objSubFolder, InStrRev(objSubFolder.path, "\"), Len(objSubFolder.path) - InStrRev(objSubFolder.path, "\") + 1)
                        ActiveSheet.Hyperlinks.Add Anchor:=Cells(row + 1, 25), Address:=objSubFolder.path, TextToDisplay:=stmp
                    End If
                    Cells(row + 1, 1) = CStr(row)
                    If DoSingleFolder Then
                        ScanDirectory = row
                        Exit Function
                    End If
                End If
            Else
                'Cells(row + 1, 22) = GetFileDateAndSize(objSubFolder.Path) ' dirdate+size
                row = row + 1
            End If
        Else
            
            If FormProgress.Visible And Not IsNull(FormProgress) And FormProgress.Tag <> "0" And FormProgress.Tag <> "" Then
                proz = Fix((CDbl(row - startrow) / CDbl(FormProgress.Tag)) * 100#)
                If bTracks Then
                    FormProgress.Caption = "scanning Location " + CStr(trackLocations) + " - Layout " + CStr(trackLayouts) + "  -  " + CStr(proz) + "%"
                    ' FormProgress.Tag -startrow
                    ' row -startrow
                Else
                    ' FormProgress.Caption = "scanning Car " + CStr(row - startrow) + " of " + CStr(FormProgress.Tag - startrow) + "  -  " + CStr(proz) + "%  total: " + CStr(FormProgress.Tag)
                    FormProgress.Caption = "scanning Car " + CStr(row - startrow) + " of " + CStr(FormProgress.Tag - startrow) + "  -  " + CStr(proz) + "%"
                End If
            End If
            FormProgress.lbProgress = Mid(ProgressString, 1, proz)
            FormProgress.lbCurrDir = objSubFolder.path
            FormProgress.Repaint
            If row Mod 10 = 0 Then
                DoEvents
                If row > 0 And row Mod 20 = 0 Then
                    Application.ScreenUpdating = True
                    If Not FormProgress.Visible Then: Exit For
                    If Not FormProgress.Enabled Then: Exit For
                    Application.ScreenUpdating = False
                End If
            End If
            
            If Not bTracks Then
            
                ' CarsCarsCarsCarsCarsCarsCarsCarsCars
                sDataFile = objSubFolder.path + "\ui\ui_car.json"
                If Not FileExists(sDataFile) Then
                    sDataFile = objSubFolder.path + "\ui_car.json"
                End If
                
                If FileExists(sDataFile) And IsIncluded(sDataFile, DirFilter) Then
                    row = row + 1
                    Rows(row + 1).RowHeight = previewHeight
                    Rows(row + 1).VerticalAlignment = xlCenter
                    
                    ' "ui_car.json"
                    Call ScanFileUICarJSON(sDataFile, row + 1)
                    
                    ' add preview
                    If bPreview And Not bCountonly Then
                        If DoSingleFolder Then
                            Call ScanFilePreview(objSubFolder.path + "\", "preview.png", row + 1, bTracks)
                        Else
                            Call ScanFilePreview(objSubFolder.path + "\skins\", "preview.png", row + 1, bTracks)
                        End If
                    End If

                    ' decrypt()
                    ' skey = generate_key(objSubFolder.Name)
                    
                    If doUnpackACDs And isACDexeThere And Not FileExists(objSubFolder.path + "\data\car.ini") Then
                        Call RunEXEAndWaitForClose(xlsDirectory + "acd_file.exe", objSubFolder.path)
                        'Call RunCMDAndWaitForClose(xlsDirectory + "acd_file.exe", objSubFolder.path + "\data.acd")
                        ' acd_file.exe
                    End If
                    
                    
                    ' scan drivetrain.ini
                    sDataFile = objSubFolder.path + "\data\drivetrain.ini" ' datadir; my tempdir for extracted acd's
                    If Not FileExists(sDataFile) Then: sDataFile = objSubFolder.path + "\datadir\drivetrain.ini"
                    If FileExists(sDataFile) Then
                        Call ScanFileDriveTrainINI(sDataFile, row + 1)
                    Else
                        Cells(row, 5) = "*" + Cells(row, 5)
                    End If

                    ' check sfx filename
                    sDataFile = objSubFolder.path + "\sfx\" + objSubFolder.Name + ".bank"
                    If Not FileExists(sDataFile) Then
                        Cells(row + 1, 24) = "*" + " sfx\" + objSubFolder.Name + ".bank missing " + Cells(row + 1, 24) ' wrong sound-file-name
                    End If
                    
                    sDataFile = objSubFolder.path + "\data\tyres.ini" ' datadir; my tempdir for extracted acd's
                    If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\tyres.ini"
                    If FileExists(sDataFile) Then: Call ScanFileTyresINI(sDataFile, row + 1)
                    
                    sDataFile = objSubFolder.path + "\data\lods.ini"
                    If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\lods.ini" ' winganimation
                    If FileExists(sDataFile) Then: Call ScanFileLODINI(sDataFile, row + 1, objSubFolder.path)

                    If bExtraInfo Then
                        sDataFile = objSubFolder.path + "\data\engine.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\engine.ini" ' turbo + maxrpm
                        If FileExists(sDataFile) Then: Call ScanFileEngineINI(sDataFile, row + 1)
    
                        sDataFile = objSubFolder.path + "\data\brakes.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then: sDataFile = objSubFolder.path + "\datadir\brakes.ini" ' max_brake_torque + disk_graphics
                        If FileExists(sDataFile) Then: Call ScanFileBrakesINI(sDataFile, row + 1)
    
                        sDataFile = objSubFolder.path + "\data\electronics.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\electronics.ini"
                        If FileExists(sDataFile) Then: Call ScanFileElectronicsINI(sDataFile, row + 1)
    
                        sDataFile = objSubFolder.path + "\data\fuel_cons.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\fuel_cons.ini"
                        If FileExists(sDataFile) Then: Call ScanFileFuelConsINI(sDataFile, row + 1)
    
                        sDataFile = objSubFolder.path + "\data\Flames.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\Flames.ini" ' Flames
                        If FileExists(sDataFile) Then: Call ScanFileFlamesINI(sDataFile, row + 1)
                        
                        sDataFile = objSubFolder.path + "\data\car.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\car.ini" ' use_animated_suspensions
                        If FileExists(sDataFile) Then: Call ScanFileCarINI(sDataFile, row + 1)
                        
                        sDataFile = objSubFolder.path + "\data\wing_animations.ini" ' datadir; my tempdir for extracted acd's
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\wing_animations.ini" ' winganimation
                        If FileExists(sDataFile) Then: Call ScanFileWingsINI(sDataFile, row + 1)

                        sDataFile = objSubFolder.path + "\data\aero.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\aero.ini" ' aero version
                        If FileExists(sDataFile) Then: Call ScanFileAEROINI(sDataFile, row + 1, objSubFolder.path)
                    
                        sDataFile = objSubFolder.path + "\data\ai.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\ai.ini" ' ai version
                        If FileExists(sDataFile) Then: Call ScanFileAIINI(sDataFile, row + 1, objSubFolder.path)
                    
                        sDataFile = objSubFolder.path + "\data\drs.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\drs.ini" ' drs version
                        If FileExists(sDataFile) Then: Call ScanFileDRSINI(sDataFile, row + 1, objSubFolder.path)
                    
                        sDataFile = objSubFolder.path + "\data\ers.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\ers.ini" ' ers version
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\data\kers.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\kers.ini" ' kers version
                        If FileExists(sDataFile) Then: Call ScanFileERSINI(sDataFile, row + 1, objSubFolder.path)
                    
                        sDataFile = objSubFolder.path + "\data\lights.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\lights.ini" ' lights version
                        If FileExists(sDataFile) Then: Call ScanFileLIGHTSINI(sDataFile, row + 1, objSubFolder.path)
                    
                        sDataFile = objSubFolder.path + "\data\suspensions.ini"
                        If Not FileExists(sDataFile) Then sDataFile = objSubFolder.path + "\datadir\suspensions.ini" ' suspensions version
                        If FileExists(sDataFile) Then: Call ScanFileSUSPENSIONSINI(sDataFile, row + 1, objSubFolder.path)
                    End If
               End If
            Else
                ' TracksTracksTracksTracksTracksTracksTracks
                sDataFile = objSubFolder.path + "\ui\ui_track.json"
                If Not FileExists(sDataFile) And IsIncluded(sDataFile, DirFilter) Then
                    If DirExists(objSubFolder.path + "\ui\") Then
                        
                        ' maybe "ui_track.json" in subdir for multiple tracklayouts
                        'Create an instance of the FileSystemObject
                        Set objFSO2 = CreateObject("Scripting.FileSystemObject")
                        'Get the folder object
                        Set objFolder2 = objFSO2.GetFolder(objSubFolder.path + "\ui\") ' the track-subdir
                        lastRow = -1
                        
                        For Each objSubFolder2 In objFolder2.SubFolders
                            ' ui\layoutx\ui_track.json
                            sDataFile = objSubFolder2.path + "\ui_track.json"
                            
                            If FileExists(sDataFile) And IsIncluded(sDataFile, DirFilter) Then
                                stmp = Mid(FirstPath, InStrRev(FirstPath, "\"), Len(FirstPath) - InStrRev(FirstPath, "\") + 1)
                                
                                ' size of dir with multiple layouts
                                If lastRow = -1 Then
                                    row = row + 1
                                    Rows(row + 1).RowHeight = previewHeight
                                    Cells(row + 1, 12) = GetFileDateAndSize(objSubFolder.path + "\", row + 1, 14)
                                    ActiveSheet.Hyperlinks.Add Anchor:=Cells(row + 1, 13), Address:=objSubFolder.path, TextToDisplay:=stmp + "\" + objSubFolder.Name + "\"
                                    lastRow = row + 1
                                End If
                                
                                trackLayouts = trackLayouts + 1
                                row = row + 1
                                Rows(row + 1).RowHeight = previewHeight
                                
                                ' insert sub-layout-dir as hyperlink
                                ' Cells(row + 1, 12) = GetFileDateAndSize(objSubFolder.path + "\" + objSubFolder2.Name + "\", row + 1, 14)
                                ActiveSheet.Hyperlinks.Add Anchor:=Cells(row + 1, 13), Address:=objSubFolder2.path, TextToDisplay:=stmp + "\" + objSubFolder.Name + "\" + objSubFolder2.Name + "\"
                                ' scan the "ui_track.json"
                                Call ScanFileUITrackJSON(sDataFile, row + 1)
                                
                                ' add preview
                                If bPreview Then
                                    If DoSingleFolder Then
                                        If doTrackMapPreviewOnly Then: _
                                        Call ScanFilePreview(objSubFolder.path + "\ui\" + objSubFolder2.Name, "preview.png", row + 1, bTracks) ' call as car, so preview-picture will be added
                                        Call ScanFilePreview(objSubFolder.path + "\" + objSubFolder2.Name, "map.png", row + 1, bTracks)
                                    Else
                                        If doTrackMapPreviewOnly Then: _
                                        Call ScanFilePreview(objSubFolder.path + "\ui\" + objSubFolder2.Name, "preview.png", row + 1, bTracks) ' call as car, so preview-picture will be added
                                        Call ScanFilePreview(objSubFolder.path + "\" + objSubFolder2.Name, "map.png", row + 1, bTracks)
                                    End If
                                End If
                                
                                ' check kn5 filename
                                sDataFile = objSubFolder.path + "\" + objSubFolder.Name + ".kn5"
                                If Not FileExists(sDataFile) Then
                                    ' check kn5 filename in "models_subdir.ini"
                                    sDataFile = objSubFolder.path + "\" + "models_" + objSubFolder2.Name + ".ini"
                                    If Not FileExists(sDataFile) Then
                                        Cells(row + 1, 12) = "*" + "models_" + objSubFolder2.Name + ".ini missing " + Cells(row + 1, 12) ' missing models_*.ini-file with kn5 names
                                    Else
                                        Call ScanFileTrakModelsINI(sDataFile, row + 1, objSubFolder.path)
                                    End If
                                End If
                            
                            End If
                        Next objSubFolder2
                        
                        'objFSO2.Close
                        
                        If lastRow > -1 Then ' correct locationname
                            trackLocations = trackLocations + 1
                            Cells(lastRow, 2) = Cells(lastRow + 1, 3)
                            l1 = Len(Cells(lastRow, 2))
                            l2 = Len(Cells(row + 1, 3))
                            I = 1
                            While I < l1 And I < l2 And Mid(Cells(lastRow, 2), I, 1) = Mid(Cells(row + 1, 3), I, 1)
                                I = I + 1
                            Wend
                            If I = l1 Then
                                I = l1 + 1
                            ElseIf I = l2 Then
                                I = l2 + 1
                            End If
                            Cells(lastRow, 2) = Mid(Cells(lastRow + 1, 3), 1, I - 1)
                        End If
                        
                    End If
                Else
                    ' location found directly, only one layout
                    If FileExists(sDataFile) And IsIncluded(sDataFile, DirFilter) Then
                        trackLayouts = trackLayouts + 1
                        trackLocations = trackLocations + 1
                        row = row + 1
                        Rows(row + 1).RowHeight = previewHeight
                        
                        ' insert dir as hyperlink
                        Cells(row + 1, 12) = GetFileDateAndSize(objSubFolder.path + "\", row + 1, 14)
                        stmp = Mid(FirstPath, InStrRev(FirstPath, "\"), Len(FirstPath) - InStrRev(FirstPath, "\") + 1)
                        ActiveSheet.Hyperlinks.Add Anchor:=Cells(row + 1, 13), Address:=objSubFolder.path, TextToDisplay:=stmp + "\" + objSubFolder.Name + "\"
                        Call ScanFileUITrackJSON(sDataFile, row + 1)
                        Cells(row + 1, 2) = Cells(row + 1, 3)
                        Cells(row + 1, 3) = ""
                        ' check kn5 filename
                        sDataFile = objSubFolder.path + "\" + objSubFolder.Name + ".kn5"
                        If Not FileExists(sDataFile) Then
                            ' Cells(row + 1, 12) = "*" + " " + objSubFolder.Name + ".kn5 missing " + Cells(row + 1, 12) ' wrong kn5-file-name
                            
                            ' check kn5 filenames in "models.ini"
                            sDataFile = objSubFolder.path + "\" + "models.ini"
                            If Not FileExists(sDataFile) Then
                                Cells(row + 1, 12) = "*" + objSubFolder.Name + ".kn5 or models.ini missing " + Cells(row + 1, 12) ' missing models_*.ini-file with kn5 names
                            Else
                                Call ScanFileTrakModelsINI(sDataFile, row + 1, objSubFolder.path)
                            End If
                        End If
                        
                        ' add preview
                        If bPreview Then
                            If doTrackMapPreviewOnly Then: _
                            Call ScanFilePreview(objSubFolder.path, "preview.png", row + 1, bTracks)  ' call as car, so preview-picture will be added
                            Call ScanFilePreview(objSubFolder.path, "map.png", row + 1, bTracks)
                        End If
                    End If
                End If
            End If
        End If
    Next objSubFolder
    
    'objFSO.Close
    
    If Not bCountonly Then
        If Not bTracks Then
            Cells(1, 25) = "dir - " + CStr(row) + " cars found in" + Chr(10) + Sheets("control").Cells(2, 1)
            Cells(1, 25).Select
        Else
            Cells(1, 13) = "dir - " + CStr(trackLocations) + " Locations with " + CStr(trackLayouts) + " layouts found in" + Chr(10) + Sheets("control").Cells(2, 2)
            Cells(1, 13).Select
        End If
    End If
    ScanDirectory = row
End Function

Private Function ScanFilePreview(thepath As String, sFile As String, row As Integer, bTrack As Boolean) As Boolean
    Dim objFSO As Object
    Dim objFolder As Object
    Dim objSubFolder As Object
    Dim imgFile As String
    
    Dim cell, shp As Shape, Target As Range
    Dim objPic As Object
    Dim sh As Shape
    Dim I As Integer

    imgFile = thepath + "\" + sFile
    ScanFilePreview = False
    
    ' maybe more than one skin with subdirs, so get first one from a subdir
    If Not FileExists(imgFile) And DirExists(thepath) Then
        'Create an instance of the FileSystemObject
        Set objFSO = CreateObject("Scripting.FileSystemObject")
        'Get the folder object
        Set objFolder = objFSO.GetFolder(thepath) ' the car-path
        For Each objSubFolder In objFolder.SubFolders
            imgFile = objSubFolder.path + "\" + sFile
            If FileExists(imgFile) Then
                If Not bTrack Then: Exit For
            End If
        Next objSubFolder
        'objFSO.Close
    End If
    
    If Not FileExists(imgFile) Then
        imgFile = Replace(imgFile, ".png", ".jpg")
    End If
    
    If FileExists(imgFile) Then
        ScanFilePreview = True
        ' insert preview of the car or track
        Set objPic = ActiveSheet.Pictures.Insert(imgFile)
        Set Target = ActiveSheet.Range("A" & CStr(row) + ":" + "A" & CStr(row))
        ' cell bg in black
        With Target.Interior
            .Pattern = xlSolid
            .PatternColorIndex = xlAutomatic
            .ThemeColor = xlThemeColorLight1
            .TintAndShade = 0
            .PatternTintAndShade = 0
        End With
        With objPic
            ' .ShapeRange.LockAspectRatio = msoTrue
            .ShapeRange.LockAspectRatio = msoFalse
            .Placement = xlMove
            .Top = Target.Top
            .Left = Target.Left
            .Height = Target.Height '  previewHeight
            .Width = Target.Width
            ' .Width = target.Width / 2
            If .Height > .Width Then
                .ShapeRange.Rotation = 90 ' rotate
            End If
            .Height = Target.Height '  previewHeight
        End With
        
        If Not bTrack Or (bTrack And sFile = "map.png") Then
            'Set target = ActiveSheet.Range("A" & CStr(row) + ":" + "A" & CStr(row))
            On Error Resume Next
            Target.AddComment
            Target.Comment.Visible = False
            ' comment bg in black
            With Target.Comment.Shape.Fill
                .Visible = msoTrue
                .ForeColor.RGB = 0
                .Solid
            End With
            Target.Comment.Shape.Fill.UserPicture imgFile
            If bTrack Then
                Target.Comment.Shape.LockAspectRatio = msoTrue ' False
                Target.Comment.Shape.Width = CommentPopupWidth
                'Target.Comment.Shape.Height = CommentPopupWidth * CommentPopupWidth / CommentPopupHeight
            Else
                Target.Comment.Shape.LockAspectRatio = msoFalse
                Target.Comment.Shape.Width = CInt(CommentPopupWidth * 0.85)
                Target.Comment.Shape.Height = CommentPopupHeight
            End If
            'Target.Comment.Shape.Top = 10
            'Target.IncrementTop = 100
            'Selection.ShapeRange.IncrementLeft 15.75
            'Selection.ShapeRange.IncrementTop 137.25
            
        End If
    End If
End Function

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Function CleanTrim(ByVal s As String, Optional ConvertNonBreakingSpace As Boolean = True) As String
  Dim x As Long, CodesToClean As Variant
  CodesToClean = Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, _
                       21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 127, 129, 141, 143, 144, 157)
  If ConvertNonBreakingSpace Then s = Replace(s, Chr(160), " ")
  For x = LBound(CodesToClean) To UBound(CodesToClean)
    If InStr(s, Chr(CodesToClean(x))) Then s = Replace(s, Chr(CodesToClean(x)), "")
  Next
  CleanTrim = WorksheetFunction.Trim(s)
End Function

Private Sub ScanFileUICarJSON(sDataFile As String, row As Integer)
    Dim s As String, ss As String, surl As String, sver As String, sauthor As String
    Dim dpow As Double, dwei As Double
    Dim lines() As String
    Dim linesC As Integer, I As Integer
    Dim isKunos As Boolean
    Dim sTags As String, sErg As String, sDescription As String * 1024
    Dim isTag As Boolean
    Dim arr As Variant
    Dim cmt As Comment
    
    ss = Left(sDataFile, Len(sDataFile) - Len("ui_car.json")) + "dlc_ui_car.json"
    isKunos = FileExists(ss)
    
    surl = ""
    sauthor = ""
    sver = ""
    sDescription = ""
    sTags = ""
    sErg = ""
    isTag = False
    
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        's = CleanTrim(lines(I))
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, """brand""") > 0 Then: Cells(row, 2) = GetString(s, """brand""", row, 2)
        If InStr(ss, """name""") > 0 Then: Cells(row, 3) = GetString(s, """name""", row, 3)
        If InStr(ss, """class""") > 0 Then: Cells(row, 4) = GetString(s, """class""", row, 4)
        
        If InStr(ss, """awd""") > 0 Then: Cells(row, 5) = "Awd*"  ' tags not reliable! see drivetrain.ini
        If InStr(ss, """4wd""") > 0 Then: Cells(row, 5) = "4wd*"  ' tags not reliable! see drivetrain.ini
        If InStr(ss, """fwd""") > 0 Then: Cells(row, 5) = "Fwd*"  ' tags not reliable! see drivetrain.ini
        If InStr(ss, """rwd""") > 0 Then: Cells(row, 5) = "Rwd*"  ' tags not reliable! see drivetrain.ini

        If InStr(ss, """bhp""") > 0 Then: Cells(row, 6) = GetStringVal(s, """bhp""", row, 6)
        If InStr(ss, """torque""") > 0 Then: Cells(row, 7) = GetStringVal(s, """torque""", row, 7)
        If InStr(ss, """weight""") > 0 Then: Cells(row, 8) = GetStringVal(s, """weight""", row, 8)
        If InStr(ss, """topspeed""") > 0 Then: Cells(row, 9) = GetStringVal(s, """topspeed""", row, 9)
        
        ' debug
        If InStr(ss, """acceleration""") > 0 And row = 84 Then
            row = row
        End If
        
        If InStr(ss, """acceleration""") > 0 Then: Cells(row, 10) = GetStringVal(s, """acceleration""", row, 10)
        If InStr(ss, """pwratio""") > 0 Then: Cells(row, 11) = GetStringVal(s, """pwratio""", row, 11)
        If InStr(ss, """range""") > 0 Then: Cells(row, 12) = GetStringVal(s, """range""", row, 12)
        
        If InStr(ss, """country""") > 0 Then: Cells(row, 21) = GetString(s, """country""", row, 21)
        If InStr(ss, """year""") > 0 Then: Cells(row, 22) = GetString(s, """year""", row, 22)
        If InStr(ss, """author""") > 0 Then: sauthor = GetString(s, """author""", row, 23)
        If InStr(ss, """url""") > 0 Then: surl = Trim(GetString(s, """url""", row, 23))
        If InStr(ss, """version""") > 0 Then: sver = GetString(s, """version""", row, 24)
        If InStr(ss, """description""") > 0 Then: sDescription = GetStringWithLinebreaks(s, """description""", row, 24)
        If InStr(ss, """tags""") > 0 Or isTag Then
            If InStr(s, """tags""") > 0 Then
                isTag = True
                s = Replace$(s, " ", "")
                s = Replace$(s, """tags"":[", "")
                s = Replace$(s, "],", "")
                s = Replace$(s, "]", "")
                s = Replace$(s, vbLf, "")
                s = Replace$(s, vbCrLf, "")
                s = Replace$(s, vbLf + vbCrLf, "")
                s = Replace$(s, vbCrLf + vbLf, "")
                s = CleanTrim(Replace$(s, vbTab, ""))
           
            End If
            ' sErg = GetStringWithLinebreaks2(s, "", row, 25)
            If s <> "" Then
                If sTags <> "" Then
                    sTags = Trim(sTags + ", " + s)
                Else
                    sTags = Trim(s)
                End If
            End If
            If isTag And InStr(ss, "]") > 0 Then
                isTag = False
            End If
        End If
        I = I + 1
    Wend
    
    Cells(row, 8).NumberFormat = "#,##0"
    Cells(row, 8).HorizontalAlignment = xlCenter
    
    s = sauthor
    If (isKunos And s = "Kunos") Or _
       (InStr(LCase(sDataFile), LCase("s\ks_")) > 1 And s = "") Then
        If (s = "" Or s = "Kunos") Then
            s = "Kunos"
            surl = "http://store.steampowered.com/app/244210/Assetto_Corsa/"
        End If
    End If

    If InStr(1, surl, "http") > 0 And surl <> "" And surl <> "nul" And s <> "" And s <> "Falsch" And s <> "False" Then
        ' insert hyperlink
        ActiveSheet.Hyperlinks.Add Anchor:=Cells(row, 23), Address:=surl, TextToDisplay:=s
    ElseIf s <> "" Then
        Cells(row, 23) = s
    End If
    If sver <> "" And sver <> "nul" And sver <> "False" And sver <> "FALSE" And sver <> sauthor Then
        sver = Replace(sver, "ver", "")
        sver = Replace(sver, "version", "")
        sver = Replace(sver, "v", "")
        Cells(row, 23) = Cells(row, 23) & " -v" & sver
    End If
    s = Cells(row, 11) ' pwratio = weight/bhp
    Cells(row, 11).NumberFormat = "0.00"
    If Cells(row, 6) <> "" And Cells(row, 8) <> "" And Cells(row, 8) <> Chr(10) And Cells(row, 8) <> Chr(13) _
                                                   And Cells(row, 6) <> Chr(10) And Cells(row, 6) <> Chr(13) Then
        dpow = CDbl(Cells(row, 6))
        dwei = CDbl(Cells(row, 8))
        If (Not IsEmpty(s)) And s <> "0" And s <> "" And s <> Chr(10) And s <> Chr(13) And IsNumeric(s) Then
            If CDbl(s) < Round((dwei / dpow) - 0.5, 2) Or CDbl(s) > Round((dwei / dpow) + 0.5, 2) Then
                Cells(row, 11).AddComment
                Cells(row, 11).Comment.Visible = False
                Cells(row, 11).Comment.Text Text:="calculated, orig: " + s
                Cells(row, 11).Comment.Shape.Width = 150
                Cells(row, 11).Comment.Shape.Height = 60
            End If
        End If
        If dpow = 0 Then
            dpow = 1
        End If
        Cells(row, 11) = CStr(Round(dwei / dpow, 2))
    End If
    If sDescription <> "" Then
        sDescription = Replace$(sDescription, vbLf, vbCrLf)
        sDescription = Replace$(sDescription, vbCrLf + vbCrLf, vbCrLf)
        With CreateObject("vbscript.regexp")
            .Pattern = "\<.*?\>"  ' filter html tags
            .Global = True
            sDescription = .Replace(sDescription, "")
        End With
        'sDescription = Replace$(sDescription, vbLf, vbCrLf)
        Cells(row, 27) = sDescription
    End If
    If sTags <> "" Then
        sTags = CleanTrim(Replace$(sTags, " ", ""))
        sTags = Replace$(sTags, ",,", ",")
        sTags = Replace$(sTags, ",],", "")
        sTags = Replace$(sTags, "],", "")
        With CreateObject("vbscript.regexp")
            .Pattern = "\<.*?\>"  ' filter html tags
            .Global = True
            sTags = .Replace(sTags, "")
        End With
        'sTags = Replace$(sTags, vbLf, vbCrLf)
        'arr = Split(sTags, ",")
        arr = Split(sTags, """,""")

        ' Call BubbleSort(arr)
        
        sTags = Join(arr, """,""")
        Cells(row, 56) = "click"
        Cells(row, 57) = sTags  ' tags tags tags
        sTags = sTags + Cells(row, 4)
        If (InStr(LCase(sTags), "street") <= 0) And (InStr(LCase(sTags), "race") <= 0) And Cells(row, 4) <> "" Then
            Set cmt = Cells(row, 4).Comment
            If cmt Is Nothing Then
            Else
                Cells(row, 4).ClearComments
            End If
            Cells(row, 4).AddComment
            Cells(row, 4).Comment.Visible = False
            Cells(row, 4).Comment.Text Text:="'street' or 'race' should be set!"
            Cells(row, 4).Comment.Shape.Width = 150
            Cells(row, 4).Comment.Shape.Height = 80
        End If
    End If
End Sub

Private Sub ScanFileUITrackJSON(sDataFile As String, row As Integer)
    Dim s As String, ss As String, sdd As String, unit As String, surl As String, sver As String, sauthor As String
    Dim dd As Double
    Dim I As Integer, l As Integer, lkey As Integer, p As Integer, p2 As Integer
    Dim sTags As String, sErg As String, sDescription As String * 1024
    
    Dim lines() As String
    Dim linesC As Integer
    Dim isTag As Boolean
    Dim arr As Variant
    
    surl = ""
    sauthor = ""
    sver = ""
    sDescription = ""
    sTags = ""
    sErg = ""
    isTag = False
    
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, """name""") > 0 Then: Cells(row, 3) = GetString(s, """name""", row, 3)
        If InStr(ss, """country""") > 0 Then: Cells(row, 4) = GetString(s, """country""", row, 4)
        If InStr(ss, """city""") > 0 Then: Cells(row, 5) = GetString(s, """city""", row, 5)
        If InStr(ss, """year""") > 0 Then: Cells(row, 6) = GetString(s, """year""", row, 6)
        If InStr(ss, """length""") > 0 Then: Cells(row, 7) = GetString(s, """length""", row, 7)
        If InStr(ss, """width""") > 0 Then: Cells(row, 8) = GetString(s, """width""", row, 8)
        If InStr(ss, """pitboxes""") > 0 Then: Cells(row, 9) = GetString(s, """pitboxes""", row, 9)
        If InStr(ss, """run""") > 0 Then: Cells(row, 10) = GetString(s, """run""", row, 10)
        If InStr(ss, """author""") > 0 Then: sauthor = GetString(s, """author""", row, 20)
        If InStr(ss, """url""") > 0 Then: surl = Trim(GetString(s, """url""", row, 11))
        If InStr(ss, """version""") > 0 Then: sver = GetString(s, """version""", row, 20)
        If InStr(ss, """description""") > 0 Then: sDescription = GetStringWithLinebreaks(s, """description""", row, 24)
        If InStr(ss, """tags""") > 0 Or isTag Then
            If InStr(s, """tags""") > 0 Then
                isTag = True
                s = Replace$(s, " ", "")
                s = Replace$(s, """tags"":[", "")
                s = Replace$(s, "],", "")
                s = Replace$(s, "]", "")
                s = Replace$(s, vbLf, "")
                s = Replace$(s, vbCrLf, "")
                s = Replace$(s, vbLf + vbCrLf, "")
                s = Replace$(s, vbCrLf + vbLf, "")
                s = CleanTrim(Replace$(s, vbTab, ""))
            End If
            ' sErg = GetStringWithLinebreaks2(s, "", row, 25)
            If s <> "" Then
                If sTags <> "" Then
                    sTags = Trim(sTags + ", " + s)
                Else
                    sTags = Trim(s)
                End If
            End If
            If isTag And InStr(ss, "]") > 0 Then
                isTag = False
            End If
        End If
        I = I + 1
    Wend
    
    ss = sauthor ' author
    If InStr(LCase(sDataFile), LCase("s\ks_")) > 1 And ss = "" Then
        If (ss = "" Or ss = "Kunos") Then
            ss = "Kunos"
            surl = "http://store.steampowered.com/app/244210/Assetto_Corsa/"
        End If
    End If
    If InStr(1, surl, "http") > 0 And surl <> "" And surl <> "nul" And ss <> "" Then
        ' insert hyperlink
        ActiveSheet.Hyperlinks.Add Anchor:=Cells(row, 11), Address:=surl, TextToDisplay:=ss
    ElseIf ss <> "" Then
        Cells(row, 11) = sauthor
    End If
    If sver <> "" And sver <> "nul" And sver <> "FALSCH" And sver <> "FALSE" And sver <> sauthor Then
        sver = Replace(sver, "ver", "")
        sver = Replace(sver, "version", "")
        sver = Replace(sver, "v", "")
        Cells(row, 11) = Cells(row, 11) & " -v" & sver
    End If
    
    Cells(row, 8) = Replace(Cells(row, 8), "m", "") + "m"
    Cells(row, 8) = Replace(Cells(row, 8), "m-", "-")
    Cells(row, 8) = Trim(Replace(Cells(row, 8), "m - ", "-"))
    If Cells(row, 8) = "m" Then: Cells(row, 8) = ""
    If Cells(row, 8) = "nul" Then: Cells(row, 8) = ""
    Cells(row, 10) = LCase(Cells(row, 10))
    Cells(row, 10) = Replace(Cells(row, 10), "!", "")
    Cells(row, 10) = Replace(Cells(row, 10), "-", " ")
    Cells(row, 10) = Replace(Cells(row, 10), "counter", "anti")
    Cells(row, 10) = Replace(Cells(row, 10), "anti ", "anti-")
    Cells(row, 10) = Replace(Cells(row, 10), "!", "")
    Cells(row, 10) = Replace(Cells(row, 10), "anticlock", "anti-clock")
    
    ' cleanup length of track
    s = LCase(Cells(row, 7))
    If s <> "" Then
        If row = 43 Then
          row = row
        End If
        
        unit = "m"
        If InStr(s, "km") > 0 Then
            unit = "km"
        ElseIf InStr(s, "ml") > 0 Or InStr(s, "mil") > 0 Then
            unit = "mls"
        End If
        If unit = "m" Then
            's = Replace(s, ".", "")
        Else
            s = Replace(s, ",", ".")
            ' s = Replace(s, ".", ",")
        End If
        
        I = 1
        l = Len(s)
        ss = Mid(s, 1, 1)
        While (I < l) And (Not IsNumeric2(ss)) ' eatup non-numerics
            I = I + 1
            ss = Mid(s, I, 1)
        Wend
        p = I
        I = I + 1
        ss = Mid(s, I, 1)
        While (I <= l) And (IsNumeric2(ss)) ' take numerics until something else
            I = I + 1
            ss = Mid(s, I, 1)
        Wend
        p2 = I
        
        sdd = Mid(s, p, p2 - p) ' copy the right value from line
        If IsNumeric(sdd) Then ' miles->km
            dd = CDbl(sdd)
            If (dd < 15000 And unit <> "m") Or (dd < 200) Then
                dd = dd * 1000#
            End If
            If unit = "mls" Then
                dd = dd / 0.62137119223733 ' 1.609344
            End If
            If dd > 150000 Then
                dd = dd / 1000
            End If
        End If
        If dd > 0# Then
            Cells(row, 7) = CStr(Round(dd, 0))   ' length formatted
        Else
            Cells(row, 7) = ""
        End If
    End If
    Cells(row, 7).NumberFormat = "#,##0"
    Cells(row, 7).HorizontalAlignment = xlRight
    If sDescription <> "" Then
        sDescription = Replace$(sDescription, vbLf, vbCrLf)
        sDescription = Replace$(sDescription, vbCrLf + vbCrLf, vbCrLf)
        With CreateObject("vbscript.regexp")
            .Pattern = "\<.*?\>"  ' filter html tags
            .Global = True
            sDescription = .Replace(sDescription, "")
        End With
        'sDescription = Replace$(sDescription, vbLf, vbCrLf)
        Cells(row, 15) = sDescription
    End If
    If sTags <> "" Then
        sTags = CleanTrim(Replace$(sTags, " ", ""))
        sTags = Replace$(sTags, ",,", ",")
        sTags = Replace$(sTags, ",],", "")
        sTags = Replace$(sTags, "],", "")
        sTags = Replace$(sTags, "," + vbCrLf + ",", "")
        ' sTags = Replace$(sTags, """,", "")
        sTags = Replace$(sTags, vbLf, "")
        sTags = Replace$(sTags, vbCrLf, "")
        sTags = Replace$(sTags, vbNewLine, "")
        With CreateObject("vbscript.regexp")
            .Pattern = "\<.*?\>"  ' filter html tags
            .Global = True
            sTags = .Replace(sTags, "")
        End With
        'sTags = Replace$(sTags, vbLf, vbCrLf)
        arr = Split(CleanTrim(sTags), ",")
        Call BubbleSort(arr)
        sTags = Join(arr, ",")
        Cells(row, 16) = sTags
    End If
End Sub

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' all the ini files

Private Sub ScanFileDriveTrainINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, gInfo As String, sDrive As String
    Dim I As Integer
    Dim gCount As String
    
    Dim lines() As String
    Dim linesC As Integer
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    gCount = ""
    sDrive = ""
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 28).NumberFormat = "@"
                    Cells(row, 28) = "v" & GetStringValINIstyle(ss, "version=", row, 28)
                    ' drvtrain version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        
        If InStr(ss, "type") Then: sDrive = GetString(ss, "type=", row, 5)
        If InStr(ss, "count=") = 1 Then
            gCount = GetStringValINIstyle(ss, "count", row, 2)
            gInfo = gInfo + gCount & " gears Total" & Chr(10)
        End If
        If InStr(ss, "gear_1=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_1", row, 2) & " - 1. gear" & Chr(10)
        If InStr(ss, "gear_2=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_2", row, 2) & " - 2. gear" & Chr(10)
        If InStr(ss, "gear_3=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_3", row, 2) & " - 3. gear" & Chr(10)
        If InStr(ss, "gear_4=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_4", row, 2) & " - 4. gear" & Chr(10)
        If InStr(ss, "gear_5=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_5", row, 2) & " - 5. gear" & Chr(10)
        If InStr(ss, "gear_6=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_6", row, 2) & " - 6. gear" & Chr(10)
        If InStr(ss, "gear_7=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_7", row, 2) & " - 7. gear" & Chr(10)
        If InStr(ss, "gear_8=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_8", row, 2) & " - 8. gear" & Chr(10)
        If InStr(ss, "gear_r=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "gear_r", row, 2) & " - Rev gear" & Chr(10)
        If InStr(ss, "final=") = 1 Then: gInfo = gInfo + GetStringValINIstyle(ss, "final", row, 2) & " - Final grt" & Chr(10)
        I = I + 1
    Wend
    
    If sDrive <> "" Then
        If InStr(sDrive, ";") Then
            sDrive = Mid(sDrive, 1, InStr(sDrive, ";") - 1)
        End If
        sDrive = Replace(sDrive, " ", "")
        ' sDrive = Replace(sDrive, ";", "")
        Cells(row, 5) = WorksheetFunction.Proper(sDrive)
        If doShortSummary Then: Cells(row, 41) = UCase(sDrive) + " - " + CStr(gCount) + " gears<br>"
        'sDrive = Mid(sDrive, 1, InStr(sDrive, " "))
    End If
    If gInfo <> "" Then
        Range("E" + CStr(row)) = Range("E" + CStr(row)) + " / " + gCount
        Range("E" + CStr(row)).AddComment
        Range("E" + CStr(row)).Comment.Visible = False
        Range("E" + CStr(row)).Comment.Text Text:=gInfo
        Range("E" + CStr(row)).Comment.Shape.Width = 350
        Range("E" + CStr(row)).Comment.Shape.Height = 20 + (gCount + 2) * 25
    End If
End Sub

Private Sub ScanFileBrakesINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "version=") = 1 Then
            Cells(row, 29).NumberFormat = "@"
            Cells(row, 29) = "v" & GetStringValINIstyle(ss, "version=", row, 29)
            ' brakes version
        End If
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 29).NumberFormat = "@"
                    Cells(row, 29) = "v" & GetStringValINIstyle(ss, "version=", row, 29)
                    ' brakes version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "max_torque=") = 1 Then
            ss = GetStringValINIstyle(ss, "max_torque=", row, 13)
            If Cells(row, 13) = "" Then
                Cells(row, 13) = ss
                If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "MaxBrakingTorque: " + ss + "Nm <br> "
            End If
        End If
        If InStr(ss, "discs_graphics") = 1 Then
            Cells(row, 20) = Cells(row, 20) + "b"   ' discs_graphics - glowing brakes
            If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "GlowingBrakes "
        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileElectronicsINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[abs]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "present=1") = 1 Then
                    Cells(row, 14) = "X" ' ABS is present
                    If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "ABS "
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[traction_control]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "present=1") = 1 Then
                    Cells(row, 15) = "X" ' Traction Control is present
                    If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "TrCtrl "
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[edl]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "present=1") = 1 Then
                    Cells(row, 20) = Cells(row, 20) + "e" ' electronic diff lock
                    If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "EDL "
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileEngineINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String, sTurbo As String
    Dim I As Integer, turboC As Integer
    Dim dBoost As Double
    turboC = 0
    
    Dim lines() As String
    Dim linesC As Integer
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    sTurbo = ""
    I = 0
    dBoost = 0#
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 30).NumberFormat = "@"
                    Cells(row, 30) = "v" & GetStringValINIstyle(ss, "version=", row, 30)
                    ' drvtrain version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[coast_ref]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "rpm=") = 1 Then
                    ss = GetStringValINIstyle(ss, "rpm", row, 13) ' maxrpm from engine.ini
                    If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "MaxRPM: " + ss + "<br>" ' maxRPM
                    Cells(row, 16) = ss
                End If
                If InStr(ss, "torque=") = 1 Then
                    ss = GetStringValINIstyle(ss, "torque", row, 13)
                    ' Cells(row, 14) = ss + "Nm" ' engine braking torque
                    If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "EngineBrake:" + ss + "Nm <br>" ' engine braking torque
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[turbo_") = 1 Then
            turboC = turboC + 1
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "max_boost=") = 1 Then
                    ss = GetStringValINIstyle(ss, "max_boost", row, 13) ' maxboost from engine.ini
                    sTurbo = sTurbo + "#" + CStr(turboC) + ": " + ss + Chr(10)
                    If IsNumeric(ss) Then
                        dBoost = dBoost + CDbl(ss)
                    End If
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        
        If InStr(ss, "[engine_data]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "limiter=") = 1 Then
                    ss = GetStringValINIstyle(ss, "limiter", row, 13) ' limiter from engine.ini
                    If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "Limiter: " + ss + "<br>" ' Limiter
                    Cells(row, 16).AddComment
                    Cells(row, 16).Comment.Visible = False
                    Cells(row, 16).Comment.Text Text:="Limiter: " + ss
                    Cells(row, 16).Comment.Shape.Width = 200
                    Cells(row, 16).Comment.Shape.Height = 100
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        
        I = I + 1
    Wend
    If turboC > 0 Then
        Cells(row, 17) = CStr(turboC) + "x"  ' turbo from engine.ini
        'If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "MaxBoost: " + ss + "<br>"
        ' TorqMax  = TorqNorm * (1.0 + dBoost)
        ' TorqNorm = TorqMax  / (1.0 + dBoost)
        sTurbo = "BHP     w/o Turbo: " + CStr(CInt(CDbl(Cells(row, 6)) / (1# + dBoost))) + Chr(10) + _
                 "Torque w/o Turbo: " + CStr(CInt(CDbl(Cells(row, 7)) / (1# + dBoost))) + Chr(10) + sTurbo
        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + CStr(turboC) + "x Turbo <br>"
        Cells(row, 17).AddComment
        Cells(row, 17).Comment.Visible = False
        Cells(row, 17).Comment.Text Text:=sTurbo
        Cells(row, 17).Comment.Shape.Width = 200
        Cells(row, 17).Comment.Shape.Height = 20 + (turboC + 2) * 25
    End If
End Sub

Private Sub ScanFileTyresINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String, sver As String
    Dim sTyresF As String, sTyresR As String
    Dim sTyreDimF As Double, sTyreDimR As Double
    Dim sTyreRADF As Double, sTyreRADR As Double
    Dim sTyreRimRADF As Double, sTyreRimRADR As Double
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    Dim tyreC As Integer
    Dim cmt As Comment
    Dim defSectF As String
    Dim defSectR As String
    Dim index As Integer
    Dim indexCount As Integer
    Dim errorINDEX As String
    errorINDEX = ""
        
    lines = ScanFileUTF8(sDataFile)
    
    On Error GoTo exitsub
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    sTyresF = ""
    sTyresR = ""
    sTyreDimF = 0#
    sTyreDimR = 0#
    sTyreRADF = 0#
    sTyreRADR = 0#
    sTyreRimRADF = 0#
    sTyreRimRADR = 0#
    defSectF = ""
    defSectR = ""
    tyreC = 0
    index = 0
    indexCount = 0
    
    defSectF = "[FRONT]"
    defSectR = "[REAR]"
    I = 0
    While I <= linesC
        s = LCase(lines(I))
        If InStr(s, "[front") > 0 Then
            indexCount = indexCount + 1
        End If
        If InStr(s, "[compound_default]") = 1 Then
            Do
                ss = LCase(lines(I + 1))
                If InStr(ss, "[") = 1 Then: Exit Do
                ss = Replace(ss, " ", "")
                If InStr(ss, "index=") = 1 Then
                    index = Val(GetStringValINIstyle(ss, "index=", row, 18))  ' tyres default
                    If index > 0 Then
                        defSectF = "[FRONT_" + CStr(index) + "]"
                        defSectR = "[REAR_" + CStr(index) + "]"
                    End If
                        I = linesC + 1
                    ' Exit Do
                End If
                I = I + 1
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
    
    I = 0
    While I <= linesC
        s = UCase(lines(I))
        If InStr(s, "[FRONT") > 0 Then
            indexCount = indexCount + 1
        End If
        I = I + 1
    Wend
    If index > indexCount + 1 Then
        errorINDEX = "def. tyreindex wrong! "
        index = 0
        defSectF = "[FRONT]"
        defSectR = "[REAR]"
        If index > 0 Then
            defSectF = "[FRONT_" + CStr(index) + "]"
            defSectR = "[REAR_" + CStr(index) + "]"
        End If
    End If
    
    I = 0
    While I <= linesC
        s = CleanTrim(Replace(lines(I), " ", ""))
        ss = LCase(s)
        
        If InStr(ss, "[") > 0 Then
            If ss = LCase(defSectF) Then
                ss = ss
            End If
        End If
        
        If InStr(ss, "[header]") = 1 Then
            If I <= linesC Then
              Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 18).NumberFormat = "@"
                    sver = GetStringValINIstyle(ss, "version", row, 18) ' tyres version
                    If sver <> "10" Then: sver = "0" + sver
                    Exit Do
                End If
              Loop Until I >= UBound(lines())
              s = CleanTrim(Replace(lines(I), " ", ""))
            End If
            ss = LCase(s)
        End If
        
        If InStr(LCase(s), "[front") = 1 Then
            Do
                I = I + 1
                ss = CleanTrim(Replace(LCase(lines(I)), " ", ""))
                If InStr(ss, "[") = 1 Then
                    I = I - 1
                    Exit Do
                End If
                
                If LCase(s) = LCase(defSectF) Then 's = previous line!
                    If InStr(ss, "width=") = 1 Then
                        res = GetStringValINIstyle(lines(I), "width=", row, 18)  ' tyre width
                        If IsNumeric(res) Then
                            sTyreDimF = CDbl(res)
                        Else
                            sTyreDimF = 0
                        End If
                    End If
                        
                    If InStr(ss, "radius=") = 1 Then
                        'rim radius in meters (use 1 inch more than nominal)
                        'so we substract that from value we got rad*2.0/2.45-2.45))
                        res = GetStringValINIstyle(lines(I), "radius=", row, 18)  ' tyre radius
                        If IsNumeric(res) Then
                            sTyreRADF = CDbl(res)
                        Else
                            sTyreRADF = 0
                        End If
                        ' sTyreRADF = sTyreRADF + " R" + CStr(Round(res * 0.2 / 2.45 - 2.45, 1)) + "''"
                    End If
                        
                    If InStr(ss, "rim_radius=") = 1 Then
                        res = GetStringValINIstyle(lines(I), "rim_radius=", row, 18) ' tyre radius
                        If IsNumeric(res) Then
                            sTyreRimRADF = CDbl(res)
                        Else
                            sTyreRimRADF = 0
                        End If
                    End If
                End If
                    
                If InStr(ss, "name=") = 1 Then
                    res = GetString(lines(I), "name=", row, 18) ' tyrename
                    sTyresF = sTyresF + res
                    tyreC = tyreC + 1
                End If
                If InStr(ss, "short_name=") = 1 Then
                    res = GetString(lines(I), "short_name=", row, 18) ' short tyrename
                    sTyresF = sTyresF + " " + res
                End If
                If InStr(ss, "pressure_static=") = 1 Then
                    res = GetStringValINIstyle(lines(I), "pressure_static=", row, 18) ' ideal pressure
                    sTyresF = sTyresF + " - static/ideal pressure: " + res
                End If
                If InStr(ss, "pressure_ideal=") = 1 Then
                    res = GetStringValINIstyle(lines(I), "pressure_ideal=", row, 18) ' ideal pressure
                    sTyresF = sTyresF + "/" + res + Chr(10)
                End If
            Loop Until I >= UBound(lines())
            's = CleanTrim(Replace(lines(i), " ", ""))
            'ss = LCase(s)
        End If
        
        If InStr(LCase(s), "[rear") = 1 Then
            Do
                I = I + 1
                ss = CleanTrim(Replace(LCase(lines(I)), " ", ""))
                If InStr(ss, "[") = 1 Then
                    I = I - 1
                    Exit Do
                End If
                
                If LCase(s) = LCase(defSectR) Then
                    If InStr(ss, "width=") = 1 Then
                        res = GetStringValINIstyle(lines(I), "width=", row, 18)  ' tyre width
                        If IsNumeric(res) Then
                            sTyreDimR = CDbl(res)
                        Else
                            sTyreDimR = 0
                        End If
                    End If
                    
                    If InStr(ss, "radius=") = 1 Then
                        res = GetStringValINIstyle(lines(I), "radius=", row, 18) ' wheel radius
                        If IsNumeric(res) Then
                            sTyreRADR = CDbl(res)
                        Else
                            sTyreRADR = 0
                        End If
                        '  = sTyreRADR + " R" + CStr(Round(res * 0.2 / 2.45 - 2.45, 1)) + "''"
                    End If
                    
                    If InStr(ss, "rim_radius=") = 1 Then
                        res = GetStringValINIstyle(lines(I), "rim_radius=", row, 18)  ' rim radius
                        If IsNumeric(res) Then
                            sTyreRimRADR = CDbl(res)
                        Else
                            sTyreRimRADR = 0
                        End If
                    End If
                End If
                
                If InStr(ss, "name=") = 1 Then
                    res = GetString(lines(I), "name=", row, 18) ' tyrename
                    sTyresR = sTyresR + res
                End If
                If InStr(ss, "short_name=") = 1 Then
                    res = GetString(lines(I), "short_name=", row, 18) ' short tyrename
                    sTyresR = sTyresR + " " + res
                End If
                If InStr(ss, "pressure_static=") = 1 Then
                    res = GetStringValINIstyle(lines(I), "pressure_static=", row, 18) ' ideal pressure
                    sTyresR = sTyresR + " - static/ideal pressure: " + res
                End If
                If InStr(ss, "pressure_ideal=") = 1 Then
                    res = GetStringValINIstyle(lines(I), "pressure_ideal=", row, 18) ' ideal pressure
                    sTyresR = sTyresR + "/" + res + Chr(10)
                End If

            Loop Until I >= UBound(lines())
            's = CleanTrim(Replace(lines(i), " ", ""))
            'ss = LCase(s)
        End If
        
        I = I + 1
    Wend

    On Error Resume Next
    
    If tyreC > 0 Then
        ' RIM_RADIUS=0.255 ; rim radius in meters (use 1 inch more than nominal), 1 inch = 2.54cm
        ' so we substract that from value we got?
        Dim ratioF As Double, ratioR As Double
        If sTyreDimF > 0# And sTyreDimR > 0# Then
            ' radius - (rimRadius + 0.0127)) / width
            On Error Resume Next
    
            ratioF = (sTyreRADF - (sTyreRimRADF + 0.0127)) / sTyreDimF * 100
            ratioR = (sTyreRADR - (sTyreRimRADR + 0.0127)) / sTyreDimR * 100
            defSectF = CStr(Round(sTyreDimF * 1000)) & " / " & CStr(Round(ratioF / 5) * 5) & " x R" & CStr(CInt(sTyreRimRADF * 100 / 2.54 * 2 - 1)) & "''"
            defSectR = CStr(Round(sTyreDimR * 1000)) & " / " & CStr(Round(ratioR / 5) * 5) & " x R" & CStr(CInt(sTyreRimRADR * 100 / 2.54 * 2 - 1)) & "''"
        Else
            defSectF = CStr(Round(sTyreDimF * 1000)) & " / " & " x R" & CStr(Round(sTyreRimRADF * 100 / 2.54 - 1, 1)) & "''"
            defSectR = CStr(Round(sTyreDimR * 1000)) & " / " & " x R" & CStr(Round(sTyreRimRADR * 100 / 2.54 - 1, 1)) & "''"
        End If
        
        If sTyreRADF <> 0 Then: sTyreRADF = (sTyreRimRADF / sTyreRADF) * 100#
        If sTyreRADR <> 0 Then: sTyreRADR = (sTyreRimRADR / sTyreRADR) * 100#
        
        If doShortSummary Then
            If defSectF = defSectR Or sTyreRimRADR = 0# Then
                Cells(row, 41) = errorINDEX + Cells(row, 41) + " - v" + sver + " TyresFront/Rear: " + defSectF + "<br> "
            Else
                Cells(row, 41) = errorINDEX + Cells(row, 41) + " - v" + sver + " TyresFront: " + defSectF + " TyresRear: " + defSectR + "<br> "
            End If
        End If
    
        ' delete comments
        Set cmt = Cells(row, 18).Comment
        If cmt Is Nothing Then
        Else
            Cells(row, 18).ClearComments
        End If
        Cells(row, 18).AddComment
        Cells(row, 18).Comment.Visible = False
        If defSectF = defSectR Or sTyreRimRADR = 0# Then
            Cells(row, 18).Comment.Text Text:=errorINDEX + "v" + sver + Chr(10) + "Tyres: " + defSectF + Chr(10) + CStr(tyreC) + " tyre(s) available: " + Chr(10) + sTyresF
        Else
            Cells(row, 18).Comment.Text Text:=errorINDEX + "v" + sver + Chr(10) + "Tyres Front: " + defSectF + Chr(10) + "        Rear: " + defSectR + Chr(10) + CStr(tyreC) + " tyre(s) available: " + Chr(10) + sTyresF + "Rear: " + Chr(10) + sTyresR + Chr(10)
        End If
        Cells(row, 18) = Cells(row, 18).Comment.Text
        Cells(row, 18).Comment.Shape.Width = 450
        If defSectF = defSectR Or sTyreRimRADR = 0# Then
            Cells(row, 18).Comment.Shape.Height = 20 + (tyreC + 1) * 50
        Else
            Cells(row, 18).Comment.Shape.Height = 20 + (tyreC * 3 + 1) * 50
        End If
    End If

exitsub:

End Sub


Private Sub ScanFileFuelConsINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "km_per_liter=") = 1 Then
            ss = GetStringValINIstyle(ss, "km_per_liter", row, 13)
            If ss <> "0" And ss <> "0.0" And IsNumeric(ss) Then
                ss = CStr(Round(100# / CDbl(ss) / 2#, 1))
            End If
            Cells(row, 19) = ss   ' fuel consupmtion
        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileFlamesINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String
    Dim I As Integer
    Dim flameC As Integer
    flameC = 0
    Dim lines() As String
    Dim linesC As Integer
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[flame_") = 1 Then
            flameC = flameC + 1
        End If
        I = I + 1
    Wend
    If flameC > 0 Then
        If flameC > 1 Then
        Cells(row, 20) = Cells(row, 20) + CStr(flameC) + "f"    ' - exaust flames
        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + CStr(flameC) + "x Flames "
        Else
        Cells(row, 20) = Cells(row, 20) + "f"   ' - exaust flames
        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "Flame "
        End If
    End If
End Sub

Private Sub ScanFileCarINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String, nameScreen As String, nameShort As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    Dim cmt As Comment
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    nameShort = ""
    nameScreen = ""
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 31).NumberFormat = "@"
                    Cells(row, 31) = "v" & GetStringValINIstyle(ss, "version=", row, 31)
                    ' Car version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "use_animated_suspensions=") = 1 Then
            Cells(row, 20) = Cells(row, 20) + "s"  '  use_animated_suspensions
            If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "SuspAni "  '  use_animated_suspensions
        End If
        I = I + 1
        If InStr(ss, "short_name=") = 1 Then
          nameShort = GetString(s, "short_name=", row, 3)
        End If
        If InStr(ss, "screen_name=") = 1 Then
          nameScreen = GetString(s, "screen_name=", row, 33)
        End If
        
    Wend
    
    ' delete comments
    Set cmt = Cells(row, 3).Comment
    If cmt Is Nothing Then
    Else
        Cells(row, 3).ClearComments
    End If
    Cells(row, 3).AddComment
    Cells(row, 3).Comment.Visible = False
    If nameShort = "" Then
        Cells(row, 3).Comment.Text Text:="missing 'SHORT_NAME'"
    Else
        Cells(row, 3).Comment.Text Text:="SHORT_NAME:" + Chr(10) + nameShort
    End If
    Cells(row, 3).Comment.Shape.Width = 150
    Cells(row, 3).Comment.Shape.Height = 60
End Sub

Private Sub ScanFileWingsINI(sDataFile As String, row As Integer)
    Dim s As String, ss As String, res As String
    Dim I As Integer
    Dim wingC As Integer
    wingC = 0
    Dim lines() As String
    Dim linesC As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 32).NumberFormat = "@"
                    Cells(row, 32) = "v" & GetStringValINIstyle(ss, "version=", row, 32)
                    ' Wing_animations version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[animation_") = 1 Then
            wingC = wingC + 1
        End If
        I = I + 1
    Wend
    If wingC > 0 Then
        If wingC > 1 Then
        Cells(row, 20) = Cells(row, 20) + CStr(wingC) + "w"    ' - animated wings
        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + CStr(wingC) + "xWingsAni "
        Else
        Cells(row, 20) = Cells(row, 20) + "w"   ' - animated wings
        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "WingAni "
        End If
        If Cells(row, 32) = "" Then
            Cells(row, 32) = "v1"
        End If
    End If
End Sub

Private Sub ScanFileLODINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String, res As String
    Dim I As Integer
    Dim lodC As Integer
    Dim lodCact As Integer
    Dim lines() As String
    Dim linesC As Integer
        
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    lodCact = 0
    lodC = 0
    res = 0
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[lod_") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' quit on next section
                If InStr(ss, "file=") = 1 Then
                    ss = GetString(ss, "file=", row, 13)
                    If Not FileExists(path + "\" + ss) Then
                        res = res + ss
                        lodC = lodC + 1
                    Else
                        lodCact = lodCact + 1
                    End If
                    ' add date of first KN5 file
                    'If lodCact = 1 Then
                    '    Cells(row, 24) = GetFileDateAndSize(path + "\" + ss, row, 26)  ' date and size of KN5
                    'End If
                
                End If
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
    If lodC > 0 Then
        Cells(row, 20) = "*" + res + " " + Cells(row, 20)
    End If
End Sub

Private Sub ScanFileAEROINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 33).NumberFormat = "@"
                    Cells(row, 33) = "v" & GetStringValINIstyle(ss, "version=", row, 33)
                    ' AERO version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileAIINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    I = 0
    While I <= linesC
        s = lines(I)
        ss = UCase(s)
        If InStr(ss, "[HEADER]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "VERSION=") = 1 Then
                    Cells(row, 34).NumberFormat = "@"
                    Cells(row, 34) = "v" & GetStringValINIstyle(s, "version=", row, 34)
                    ' AI version
                    'Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "UP") = 1 Then: Cells(row, 42) = GetStringValINIstyle(ss, "UP", 42, row)
        If InStr(ss, "DOWN") = 1 Then: Cells(row, 43) = GetStringValINIstyle(ss, "DOWN", 43, row)
        If InStr(ss, "SLIP_THRESHOLD") = 1 Then: Cells(row, 44) = GetStringValINIstyle(ss, "SLIP_THRESHOLD", 44, row)
        If InStr(ss, "GAS_CUTOFF_TIME") = 1 Then: Cells(row, 45) = GetStringValINIstyle(ss, "GAS_CUTOFF_TIME", 45, row)
        If InStr(ss, "GASGAIN") = 1 Then: Cells(row, 46) = GetStringValINIstyle(ss, "GASGAIN", 46, row)
        If InStr(ss, "BRAKE_HINT") = 1 Then: Cells(row, 47) = GetStringValINIstyle(ss, "BRAKE_HINT", 47, row)
        If InStr(ss, "TRAIL_HINT") = 1 Then: Cells(row, 48) = GetStringValINIstyle(ss, "TRAIL_HINT", 48, row)
        If InStr(ss, "STEER_GAIN") = 1 Then: Cells(row, 49) = GetStringValINIstyle(ss, "STEER_GAIN", 49, row)
        If InStr(ss, "BASE") = 1 Then: Cells(row, 50) = GetStringValINIstyle(ss, "BASE", 50, row)
        If InStr(ss, "SPEED_GAIN") = 1 Then: Cells(row, 51) = GetStringValINIstyle(ss, "SPEED_GAIN", 51, row)
        If InStr(ss, "GAS_BRAKE_LOOKAHEAD") = 1 Then: Cells(row, 52) = GetStringValINIstyle(ss, "GAS_BRAKE_LOOKAHEAD", 52, row)
        If InStr(ss, "VALUE") = 1 Then: Cells(row, 53) = GetStringValINIstyle(ss, "VALUE", 53, row)
        If InStr(ss, "SLIP_RATIO_MAX") = 1 Then: Cells(row, 54) = GetStringValINIstyle(ss, "SLIP_RATIO_MAX", 54, row)
        If InStr(ss, "AERO_HINT") = 1 Then: Cells(row, 55) = GetStringValINIstyle(ss, "AERO_HINT", 55, row)

'        If InStr(ss, "[header]") = 1 Then
'            Do
'                i = i + 1
'                ss = LCase(lines(i))
'                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
'                If InStr(ss, "version=") = 1 Then
'                    Cells(row, 42) = GetStringValINIstyle(ss, "=", row, 34)
'                    ' AI version
'                    'Exit Do
'                End If
'            Loop Until i >= UBound(lines())
'        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileDRSINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    Dim aCan As Integer
    Dim bCan As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    aCan = 0
    bCan = 0
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 35).NumberFormat = "@"
                    Cells(row, 35) = "v" & GetStringValINIstyle(ss, "version=", row, 35)
                    ' DRS version ------- drag reduction system on straights
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[wing_") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "angle=") = 1 Then: aCan = aCan + 1
                If InStr(ss, "effect=") = 1 Then: bCan = bCan + 1
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
    If (aCan > 0 Or bCan > 0) And Cells(row, 35) = "" Then
        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "DRS "
        Cells(row, 35).NumberFormat = "@"
        Cells(row, 35) = "v1"
    End If
    If (aCan = 0 And bCan = 0) Then
        Cells(row, 35) = ""
    End If
End Sub

Private Sub ScanFileERSINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 36).NumberFormat = "@"
                    ' ERS version -------- energy recovery system - boost on straights from braking
                    If InStr(LCase(sDataFile), "kers") > 0 Then
                        Cells(row, 36) = "v" & GetStringValINIstyle(ss, "version=", row, 6) & "kers"
                        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "KERS "
                    Else
                        Cells(row, 36) = "v" & GetStringValINIstyle(ss, "version=", row, 6) & "ers"
                        If doShortSummary Then: Cells(row, 41) = Cells(row, 41) + "ERS "
                    End If
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileLIGHTSINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' on next sect
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 37).NumberFormat = "@"
                    Cells(row, 37) = "v" & GetStringValINIstyle(ss, "version=", row, 37)
                    ' LIGHTS version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
End Sub

Private Sub ScanFileSUSPENSIONSINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String
    Dim I As Integer
    Dim lines() As String
    Dim linesC As Integer
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[header]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "version=") = 1 Then
                    Cells(row, 38).NumberFormat = "@"
                    Cells(row, 38) = "v" & GetStringValINIstyle(ss, "version=", row, 38) ' SUSPENSIONS version
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[front]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "type=") = 1 Then
                    Cells(row, 39).NumberFormat = "@"
                    Cells(row, 39) = GetString(ss, "type=", row, 39) ' front susp type
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        If InStr(ss, "[rear]") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do
                If InStr(ss, "type=") = 1 Then
                    Cells(row, 40).NumberFormat = "@"
                    Cells(row, 40) = GetString(ss, "type=", row, 40) ' rear suspension type
                    Exit Do
                End If
            Loop Until I >= UBound(lines())
        End If
        
'        If InStr(ss, "[basic]") = 1 Then
'            Do
'                i = i + 1
'                ss = LCase(lines(i))
'                If InStr(ss, "[") = 1 Then: Exit Do
'                If InStr(ss, "wheelbase=") = 1 Then
'                    Cells(row, 57).NumberFormat = "@"
'                    Cells(row, 57) = GetStringValINIstyle(ss, "wheelbase=", row, 57) ' SUSPENSIONS version
'                    Exit Do
'                End If
'            Loop Until i >= UBound(lines())
'        End If
        
        
        I = I + 1
    Wend
End Sub

Private Sub ScanFileTrakModelsINI(sDataFile As String, row As Integer, path As String)
    Dim s As String, ss As String, res As String
    Dim I As Integer
    Dim lodC As Integer
    Dim lines() As String
    Dim linesC As Integer
        
    linesC = -1
    lines = ScanFileUTF8(sDataFile)
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    lodC = 0
    res = ""
    I = 0
    While I <= linesC
        s = lines(I)
        ss = LCase(s)
        If InStr(ss, "[model_") = 1 Then
            Do
                I = I + 1
                ss = LCase(lines(I))
                If InStr(ss, "[") = 1 Then: Exit Do  ' quit on next section
                If InStr(ss, "file=") = 1 Then
                    ss = GetString(ss, "file=", row, 13)
                    If Not FileExists(path + "\" + ss) Then
                        res = res + ss + " "  ' kn5 files missing
                        lodC = lodC + 1
                    End If
                End If
            Loop Until I >= UBound(lines())
        End If
        I = I + 1
    Wend
    If lodC > 0 Then
        Cells(row, 12) = "*" + res + " " + Cells(row, 12) ' kn5 files missing
    End If
End Sub

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' --- helper functions
Private Function IsNumeric2(s As String) As Boolean
    IsNumeric2 = False
    If (s = ".") Or (s = ",") Or IsNumeric(s) Then
        IsNumeric2 = True
    End If
End Function

Private Function GetFolderSize(folder, refsize)
  Dim f As Object, fs As Object
  Dim file As Object, subfolder As Object
  On Error Resume Next
  Set fs = CreateObject("Scripting.FileSystemObject")
  Set f = fs.GetFolder(folder)
  For Each file In f.files
    refsize = refsize + file.Size
  Next
  For Each subfolder In f.SubFolders
    refsize = GetFolderSize(subfolder, refsize) 'recursive call
  Next
  GetFolderSize = refsize
  'fs.Close
End Function

Sub BubbleSort(arr)
  Dim strTemp As String
  Dim I As Long
  Dim j As Long
  Dim lngMin As Long
  Dim lngMax As Long
  lngMin = LBound(arr)
  lngMax = UBound(arr)
  For I = lngMin To lngMax - 1
    For j = I + 1 To lngMax
      If LCase(arr(I)) > LCase(arr(j)) Then
        strTemp = arr(I)
        arr(I) = arr(j)
        arr(j) = strTemp
      End If
    Next j
  Next I
End Sub
        
Function IsIncluded(s As String, seachfor As String)
    Dim arr, I
    IsIncluded = False
    If seachfor = "" Then
        IsIncluded = True
        Exit Function
    End If
    arr = Split(seachfor, ",")
    Dim lngMin As Long
    Dim lngMax As Long
    lngMin = LBound(arr)
    lngMax = UBound(arr)
    For I = lngMin To lngMax
        If InStr(UCase(s), UCase(Trim(arr(I)))) > 0 Then
            IsIncluded = True
            Exit For
        End If
    Next I
End Function

Public Function GetFileDateAndSize(file As String, row As Integer, col As Integer) As String
    Dim fileModDate As String
    Dim fs As Object, f As Object, localfsize As Long
    GetFileDateAndSize = " -!- "
    On Error Resume Next
    If DirExists(file) Then
        localfsize = 0
        If bCountSize Then
            localfsize = GetFolderSize(file, localfsize)
            Cells(row, col) = localfsize
        End If
        ' Cells(row, col) = f.size
        Set fs = CreateObject("Scripting.FileSystemObject")
        Set f = fs.GetFolder(file)
        GetFileDateAndSize = "  " + Format(f.DateLastModified, "yyyy-mm-dd")
        'fs.Close
    ElseIf FileExists(file) Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        Set f = fs.GetFile(file)
        If bCountSize Then
            Cells(row, col) = f.Size
        Else
            Cells(row, col) = CStr(CDbl(Cells(row, col)) + f.Size)
        End If
        GetFileDateAndSize = "  " + Format(f.DateLastModified, "yyyy-mm-dd")
        'fs.Close
    End If
End Function

Private Function GetStringValINIstyle(sline As String, skey As String, col As Integer, row As Integer) As String
    Dim s As String
    Dim I As Integer, l As Integer, lkey As Integer, p As Integer, p2 As Integer
    Dim dd As Double
    Dim orig As String
    Dim cmt As Comment
    orig = sline
    sline = LCase(sline)
    GetStringValINIstyle = ""
    p = InStr(sline, LCase(skey))
    If p > 0 Then
        I = 1
        l = Len(sline)
        lkey = Len(skey)
        sline = Trim(Mid(sline, p + lkey, l - p + lkey)) ' clean up before
        l = Len(sline)
        s = Mid(sline, I, 1)
        While (I < l) And (Not IsNumeric2(s)) ' eat up non-numerics from line
            I = I + 1
            s = Mid(sline, I, 1)
        Wend
        p = I
        I = I + 1
        s = Mid(sline, I, 1)
        While (I <= l) And (IsNumeric2(s)) ' take all numerics until something else
            I = I + 1
            s = Mid(sline, I, 1)
        Wend
        p2 = I
        s = Mid(sline, p, p2 - p) ' copy the right value from line
        If InStr(s, ";") Then
            s = Mid(s, 1, InStr(s, ";") - 1)
        End If
        If InStr(s, "0.0.") > 0 Then
            s = Replace(s, "0.0.", "0.0")
            ' todo error message
            
            Set cmt = Cells(row, 2).Comment
            If cmt Is Nothing Then
                Cells(col, 2).AddComment
                Cells(col, 2).Comment.Visible = False
                Cells(col, 2).Comment.Shape.Width = 150
                Cells(col, 2).Comment.Shape.Height = 60
            Else
                orig = Cells(col, 2).Comment.Text + orig
            End If
            Cells(col, 2).Comment.Text Text:="value error: " + orig
        
            Application.ScreenUpdating = True
            DoEvents
            FormProgress.Show
            FormProgress.Tag = 0
            Application.ScreenUpdating = False
        
        End If
        GetStringValINIstyle = s
    End If
End Function

Private Function GetStringVal(sline As String, skey As String, col As Integer, row As Integer)
    Dim s As String
    Dim I As Integer, l As Integer, lkey As Integer, p As Integer, p2 As Integer
    Dim dd As Double
    GetStringVal = ""
    p = InStr(sline, skey)
    If p > 0 Then
        I = 1
        l = Len(sline)
        lkey = Len(skey)
        sline = Trim(Mid(sline, p + lkey, l - p + lkey)) ' clean up before
        ' try to recognize "miles" per hour for "topspeed", others dont matter
        dd = 1#
        If skey = """topspeed""" Then
            If InStr(sline, "mph") > 0 Or InStr(sline, "mp") > 0 Then
                dd = 1.609344
            End If
        End If
        If InStr(sline, "0-60") > 0 Or InStr(sline, "0 - 60") > 0 Then
            sline = Replace(sline, "0 - 60", "")
            sline = Replace(sline, "0-60", "")
            If InStr(sline, "km") > 0 Then
                dd = dd * 100 / 60
            End If
        End If
        
        sline = Replace(sline, ": ", "")
        sline = Replace(sline, "0 - 100", "")
        sline = Replace(sline, "0-100", "")
        sline = Replace(sline, "mp/h", "")
        sline = Replace(sline, "km/h", "")
        sline = Replace(sline, "mph", "")
        sline = Replace(sline, "kmh", "")
        'sline = Replace(sline, ",", "")
        sline = Replace(sline, ":", "")
        
        l = Len(sline)
        s = Mid(sline, I, 1)
        While (I < l) And (Not IsNumeric2(s)) ' eat up non-numerics from line
            I = I + 1
            s = Mid(sline, I, 1)
        Wend
        p = I
        I = I + 1
        s = Mid(sline, I, 1)
        While (I <= l) And (IsNumeric2(s)) ' take all numerics until something else
            I = I + 1
            s = Mid(sline, I, 1)
        Wend
        p2 = I
        GetStringVal = Mid(sline, p, p2 - p) ' copy the right value from line
        
        ' clean up waste
        If skey <> """weight""" Then
            GetStringVal = Replace(GetStringVal, ",", ".")
        Else
            GetStringVal = Replace(GetStringVal, ".", "")
            GetStringVal = Replace(GetStringVal, ",", "")
        End If
        If GetStringVal = """" Then: GetStringVal = ""
        If GetStringVal = "null" Then: GetStringVal = ""
        If GetStringVal = "FALSCH" Then: GetStringVal = ""
        If GetStringVal = "." Then: GetStringVal = ""
        If GetStringVal = "-" Then: GetStringVal = ""
        If GetStringVal = "|" Then: GetStringVal = ""
        If GetStringVal = "l" Then: GetStringVal = ""
        If GetStringVal = "..." Then: GetStringVal = ""
        
        ' finally if its miles do the math
        If GetStringVal <> "" And skey = """topspeed""" And IsNumeric(GetStringVal) And _
           dd <> 1# Then
            GetStringVal = Fix(CStr(CDbl(GetStringVal) * CDbl(dd)))
        End If
    End If
End Function

Private Function GetStringWithLinebreaks(sline As String, skey As String, row As Integer, col As Integer) As String
    Dim s As String, ss As String, sLast As String
    Dim I As Integer, l As Integer, lkey As Integer, p As Integer, p2 As Integer
    p = InStr(sline, skey)
    GetStringWithLinebreaks = ""
    If p > 0 Then
        I = 1
        l = Len(sline)
        lkey = Len(skey)
        sline = Mid(sline, p + lkey, l - p + lkey)
        l = Len(sline)
        s = Mid(sline, I, 1) ' try to find the start of the string
        While (I < l) And ((s = """") Or (s = " ") Or (s = Chr(9)) Or (s = ":"))
            I = I + 1
            s = Mid(sline, I, 1)
        Wend
        p = I
        I = I + 1
        s = Mid(sline, I, 1) ' try to find the end of the string
        While (I <= l) And Not ((s = """") Or ((s + sLast = """,") And (I - p > 3)))
            I = I + 1
            sLast = s
            s = Mid(sline, I, 1)
        Wend
        p2 = I
        s = Mid(sline, p, p2 - p) ' copy from right pos
        'ss = Cells(row, col)
        'If ss <> s And s <> "null" Then
        '    s = ss + " " + s
        'End If
        If s = "," Then: s = ""
        If s = "." Then: s = ""
        If s = "null" Then: s = ""
        If s = "falsch" Then: s = ""
        If s = "false" Then: s = ""
        GetStringWithLinebreaks = s
    End If
End Function

Private Function GetStringWithLinebreaks2(sline As String, skey As String, row As Integer, col As Integer) As String
    Dim s As String, ss As String, sLast As String
    Dim I As Integer, l As Integer, lkey As Integer, p As Integer, p2 As Integer
    p = InStr(sline, skey)
    GetStringWithLinebreaks2 = ""
    If p > 0 Then
        I = 1
        l = Len(sline)
        lkey = Len(skey)
        sline = Mid(sline, p + lkey, l - p + lkey)
        l = Len(sline)
        s = Mid(sline, I, 1) ' try to find the start of the string
        While (I < l) And ((s = """") Or (s = " ") Or (s = Chr(9)) Or (s = ":"))
            I = I + 1
            s = Mid(sline, I, 1)
        Wend
        p = I
        I = I + 1
        s = Mid(sline, I, 1) ' try to find the end of the string
        While (I <= l) And (s <> "]") And Not ((s = """") Or ((s + sLast = """,") And (I - p > 3)))
            I = I + 1
            sLast = s
            s = Mid(sline, I, 1)
        Wend
        p2 = I
        s = Mid(sline, p, p2 - p) ' copy from right pos
        'ss = Cells(row, col)
        'If ss <> s And s <> "null" Then
        '    s = ss + " " + s
        'End If
        If s = "," Then: s = ""
        If s = "." Then: s = ""
        If s = "null" Then: s = ""
        If s = "falsch" Then: s = ""
        If s = "false" Then: s = ""
        GetStringWithLinebreaks2 = s
    End If
End Function

Private Function GetString(sline As String, skey As String, row As Integer, col As Integer) As String
    Dim s As String, ss As String
    Dim I As Integer, l As Integer, lkey As Integer, p As Integer, p2 As Integer
    p = InStr(LCase(sline), LCase(skey))
    GetString = ""
    If p > 0 Then
        I = 1
        l = Len(sline)
        lkey = Len(skey)
        sline = Mid(sline, p + lkey, l - p + lkey)
        l = Len(sline)
        s = LCase(Mid(sline, I, 1)) ' try to find the start of the string
        While (I < l) And ((s = """") Or (s = " ") Or (s = Chr(9)) Or (s = ":"))
            I = I + 1
            s = LCase(Mid(sline, I, 1))
        Wend
        p = I
        I = I + 1
        s = LCase(Mid(sline, I, 1))  ' try to find the end of the string
        While (I <= l) And Not ((s = """") Or ((s = ",") And (I - p > 3)) Or (s = Chr(13)) Or (s = Chr(10)) Or (s = Chr(9)) Or (s = Chr(8)))
            I = I + 1
            s = LCase(Mid(sline, I, 1))
        Wend
        p2 = I
        s = Mid(sline, p, p2 - p) ' copy from right pos
        'ss = Cells(row, col)
        'If ss <> s And s <> "null" Then
        '    s = ss + " " + s
        'End If
        If s = "," Then: s = ""
        If s = "." Then: s = ""
        If s = "null" Then: s = ""
        If s = "falsch" Then: s = ""
        If s = "false" Then: s = ""
        GetString = s
    End If
End Function

''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Function GetACDirAutomatic() As String
    Dim logfile As String
    Dim I As Integer
    Dim s As String, ss As String
    GetACDirAutomatic = ""
    ' open last AC-log file to find AC-dir
    logfile = Environ("USERPROFILE") + "\Documents\Assetto Corsa\logs\launcher.log"
    If FileExists(logfile) Then
        Dim lines() As String
        Dim linesC As Integer
        lines = ScanFileUTF8(logfile)
        linesC = UBound(lines())
        If linesC <= 0 Then: Exit Function
        I = 0
        While I <= linesC
            s = lines(I)
            ss = LCase(s)
            If InStr(ss, "searching for .config at: assettocorsa.exe -> ") > 0 Then
                ss = GetString(ss, "searching for .config at: assettocorsa.exe -> ", 0, 0)
                ss = Mid(ss, 1, InStrRev(ss, "\")) + "content"
                GetACDirAutomatic = ss
                Exit Function
            End If
            I = I + 1
        Wend
    End If
End Function

Function GetACDirAutomatic2() As String
    Dim shell As Object
    Dim fso As Object
    Dim steamPath As String
    Dim vdfPath As String
    Dim acPath As String
    Dim line As Variant
    Dim fileContent As String
    Dim parts() As String
    Dim currentLibraryPath As String
    
    Set shell = CreateObject("WScript.Shell")
    Set fso = CreateObject("Scripting.FileSystemObject")
    
    ' 1. Steam-Pfad aus der Registry auslesen (64-bit & 32-bit Support)
    On Error Resume Next
    ' Versuche zuerst den 64-bit Pfad (Wow6432Node f�r 32-bit Steam auf 64-bit Windows)
    steamPath = shell.RegRead("HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Valve\Steam\")
    If steamPath = "" Then
        ' Fallback auf Standard-Pfad
        steamPath = shell.RegRead("HKEY_LOCAL_MACHINE\SOFTWARE\Valve\Steam\InstallPath")
    End If
    On Error GoTo 0
    
    If steamPath = "" Then
        MsgBox "Steam Installationspfad konnte nicht in der Registry gefunden werden.", vbCritical
        Exit Function
    End If
    
    If fso.FileExists(steamPath & "\steamapps\common\assettocorsa\acs.exe") Then
        GetACDirAutomatic2 = steamPath & "\steamapps\common\assettocorsa\content"
        Exit Function
    Else
    
        ' 2. libraryfolders.vdf lokalisieren
        vdfPath = steamPath & "\steamapps\libraryfolders.vdf"
        
        If Not fso.FileExists(vdfPath) Then
            MsgBox "Die Datei libraryfolders.vdf wurde nicht gefunden unter: " & vdfPath, vbExclamation
            Exit Function
        End If
        
        ' 3. VDF Datei zeilenweise einlesen und nach Pfaden suchen
        fileContent = fso.OpenTextFile(vdfPath, 1).ReadAll
        fileContent = Replace$(fileContent, vbLf, vbCrLf)
        
        For Each line In Split(fileContent, vbCrLf)
            ' Suche nach der Zeile: "path" "C:\SteamLibrary"
            If InStr(1, line, """path""", vbTextCompare) > 0 Then
                ' Extrahiere den Pfad zwischen den Anf�hrungszeichen
                parts = Split(line, """")
                If UBound(parts) >= 3 Then
                    currentLibraryPath = parts(3)
                    ' Doppelte Backslashes korrigieren (VDF Standard)
                    currentLibraryPath = Replace(currentLibraryPath, "\\", "\")
                    
                    ' 4. Pr�fen, ob Assetto Corsa in dieser Library existiert
                    If fso.FileExists(currentLibraryPath & "\steamapps\common\assettocorsa\acs.exe") Then
                        GetACDirAutomatic2 = currentLibraryPath & "\steamapps\common\assettocorsa\content"
                        ' MsgBox "Assetto Corsa gefunden unter: " & acPath, vbInformation
                        ' Hier kannst du acPath weiterverwenden
                        Exit Function
                    End If
                End If
            End If
        Next line
    End If
    
    MsgBox "Assetto Corsa konnte in keiner Steam-Bibliothek gefunden werden.", vbExclamation
End Function

Sub RemoveLine(ByRef lines() As String, ByRef linesC As Integer, I As Integer)
    Dim j As Integer
    For j = I To linesC - 1
        lines(j) = lines(j + 1)
    Next
    linesC = linesC - 1
    ReDim Preserve lines(linesC)
End Sub
                    


Public Function IsLoaded(formName As String) As Boolean
    Dim frm As Object
    For Each frm In VBA.UserForms
        If frm.Name = formName Then
            IsLoaded = True
            Exit Function
        End If
    Next frm
    IsLoaded = False
End Function

Public Sub OpenLutFile(iFolder, iFile As String, sheet As Integer, colDest As Integer, source As String)
    Call ReadLut(ScanFileUTF8(iFolder + iFile), sheet, colDest, iFile)
End Sub

Public Function LutFromLine(s2 As String) As String()
    Dim col As Variant
    Dim linesC As Integer, I As Integer
    Dim lines() As String
    lines = Split(s2, "|")
    linesC = UBound(lines)
    If linesC <= 0 Then: Exit Function
    For I = 0 To linesC - 1
        lines(I) = Replace(lines(I), "=", "|")
    Next
    LutFromLine = lines
End Function

Public Sub ReadLut(lines() As String, sheet As Integer, colDest As Integer, source As String)
    Dim row As Integer, linesC As Integer, I As Integer
    Dim cols As Variant, cols2 As Variant
    Dim textline As String, s1 As String, s2 As String, s3 As String
    Dim rngx As Range, rngy As Range
    Dim inc As Integer
    
    linesC = UBound(lines())
    If linesC <= 0 Then: Exit Sub
    
    inc = -200 + colDest * 50
    row = 2
    I = 0
    Sheets(sheet).Cells(1, colDest) = source
    While I <= linesC
        textline = Application.WorksheetFunction.Clean(Trim(lines(I)))
        If textline = "" Or Left(textline, 1) = ";" Or Left(textline, 1) = "/" Or Left(textline, 1) = "\" Or Left(textline, 1) = "#" Or Left(textline, 1) = "[" Then
        Else
            If InStr(textline, "|") Then
                cols = Split(textline, "|", 2)
                s1 = cols(0)
                s2 = cols(1)
                If InStr(2, s2, ";") Or InStr(2, s2, "/") Or InStr(2, s2, "\") Or InStr(2, s2, "#") Then
                    If InStr(2, s2, ";") Then
                        cols2 = Split(s2, ";", 2)
                    ElseIf InStr(2, s2, "/") Then
                        cols2 = Split(s2, "/", 2)
                    ElseIf InStr(2, s2, "\") Then
                        cols2 = Split(s2, "\", 2)
                    ElseIf InStr(2, s2, "#") Then
                        cols2 = Split(s2, "#", 2)
                    End If
                    s2 = Application.WorksheetFunction.Clean(Trim(cols2(0)))
                End If
                
                Sheets(sheet).Cells(row, colDest) = s1
                Sheets(sheet).Cells(row, colDest + 1) = s2
                row = row + 1
            End If
        End If
        I = I + 1
    Wend
    
    Set rngx = Sheets(sheet).Range(Sheets(sheet).Cells(2, colDest + 1), Sheets(sheet).Cells(row - 1, colDest + 1))
    Set rngy = Sheets(sheet).Range(Sheets(sheet).Cells(2, colDest), Sheets(sheet).Cells(row - 1, colDest))
    
    Sheets(sheet).Range(rngx, rngy).Select
    
    ActiveSheet.Shapes.AddChart.Select
    ActiveChart.ChartType = xlXYScatterSmoothNoMarkers
    ActiveChart.SetSourceData Sheets(sheet).Range(rngx, rngy)
    
    ' switch x and y axis
    'ActiveChart.SeriesCollection(1).XValues = rngx
    'ActiveChart.SeriesCollection(1).Values = rngy
    
    ActiveChart.Legend.Select
    Selection.Delete
    ActiveSheet.Shapes(ActiveSheet.Shapes.Count).IncrementLeft inc
    ActiveSheet.Shapes(ActiveSheet.Shapes.Count).IncrementTop inc / 4
    
    Sheets(sheet).Range("A1").Select

End Sub

Public Sub OpenAFileInSheet(sheet As Integer, iFolder As String, iFile As String)
    Dim row As Integer, col As Integer, linesC As Integer, I As Integer
    Dim cols As Variant, cols2 As Variant
    Dim textline As String, s2 As String, s3 As String, currSection As String
    Dim lines() As String
    Dim lutColID As Integer, j As Integer
    Dim p As Integer
    Dim done As Boolean
    done = False
        
    If FileExists(iFolder + iFile) Then
        If sheet > 1 Then
            Sheets.Add After:=Worksheets(Worksheets.Count)
        End If
        sheet = Worksheets.Count
        Sheets(sheet).Name = iFile
        Sheets(sheet).Columns("A:A").ColumnWidth = 40
        Sheets(sheet).Columns("B:B").ColumnWidth = 5
        Sheets(sheet).Columns("C:C").ColumnWidth = 20
        Sheets(sheet).Columns("D:D").ColumnWidth = 40
        
        lines = ScanFileUTF8(iFolder + iFile)
        linesC = UBound(lines())
        If linesC <= 0 Then: Exit Sub
        
        Application.ScreenUpdating = False
        
        row = 1
        I = 0
        lutColID = 5
        While I < linesC
            textline = Application.WorksheetFunction.Clean(Trim(lines(I)))
            If Left(textline, 1) = ";" Or Left(textline, 1) = "/" Or Left(textline, 1) = "\" Or Left(textline, 1) = "#" Or Left(textline, 1) = "[" Then
                Sheets(sheet).Cells(row, 1) = textline
                If textline <> "" And Not Left(textline, 1) = "[" Then
                    ' comment
                    Sheets(sheet).Cells(row, 1).Font.Color = rgbDarkGray
                ElseIf Left(textline, 1) = "[" Then
                    ' section
                    p = InStr(2, textline, "]")
                    currSection = Mid(textline, 2, p - 2)
                    Sheets(sheet).Cells(row, 1).Font.Bold = True
                End If
            Else
                cols = Split(textline, "=", 2)
                If UBound(cols) > 0 Then
                    For col = LBound(cols) To UBound(cols)
                        s2 = cols(col)
                        s3 = ""
                        If InStr(2, s2, ";") Or InStr(2, s2, "/") Or InStr(2, s2, "\") Or InStr(2, s2, "#") Then
                            If InStr(2, s2, ";") Then
                                cols2 = Split(s2, ";", 2)
                            ElseIf InStr(2, s2, "/") Then
                                cols2 = Split(s2, "/", 2)
                            ElseIf InStr(2, s2, "\") Then
                                cols2 = Split(s2, "\", 2)
                            ElseIf InStr(2, s2, "#") Then
                                cols2 = Split(s2, "#", 2)
                            End If
                            
                            s2 = Application.WorksheetFunction.Clean(Trim(cols2(0)))
                            If cols2(1) <> "" Then
                                s3 = "; " + cols2(1)
                            End If
                        End If
                        ' =  Or Left(textline) = "/" Or Left(textline) = "\" Or Left(textline) = "#" Or Left(textline) = "[" Then
                        
                        If col = 0 And s2 <> "" Then
                            Sheets(sheet).Cells(row, col + 2) = "'="
                        End If
                        If Left(s2, 1) = "=" Then
                            If col = 0 Then
                                Sheets(sheet).Cells(row, col + 1) = "'" + s2
                            Else
                                If Left(s2, 1) = ";" Or Left(s2, 1) = "/" Or Left(s2, 1) = "\" Or Left(s2, 1) = "#" Then
                                    ' comment
                                    s3 = s2
                                    s2 = ""
                                Else
                                    Sheets(sheet).Cells(row, col + 2) = "'" + s2
                                End If
                            End If
                        Else
                            If col = 0 Then
                                Sheets(sheet).Cells(row, col + 1) = s2
                            Else
                                
                                If Left(s2, 1) = ";" Or Left(s2, 1) = "/" Or Left(s2, 1) = "\" Or Left(s2, 1) = "#" Then
                                    s3 = s2
                                    s2 = ""
                                Else
                                    Sheets(sheet).Cells(row, col + 2) = s2
                                    If FileExists(iFolder + s2) Then
                                        
                                        j = 0
                                        done = False
                                        While Not done And Sheets(sheet).Cells(1, 5 + j) <> "" Or Sheets(sheet).Cells(1, 5 + j + 1) <> ""
                                            If Sheets(sheet).Cells(1, 5 + j) = s2 Or Sheets(sheet).Cells(1, 5 + j + 1) = s2 Then
                                                done = True
                                            End If
                                            j = j + 1
                                        Wend
                                        If Not done Then
                                            Sheets(sheet).Cells(1, lutColID) = s2
                                            Call OpenLutFile(iFolder, s2, sheet, lutColID, iFile)
                                            lutColID = lutColID + 2
                                        End If
                                    ElseIf InStr(s2, "|") Then
                                        
                                        Call ReadLut(LutFromLine(Replace(Replace(s2, "(", ""), ")", "")), sheet, lutColID, currSection + "_" + Sheets(sheet).Cells(row, 1))
                                        lutColID = lutColID + 2
                                    End If
                                End If
                            End If
                        End If
                        If s3 <> "" And col > 0 Then
                            Sheets(sheet).Cells(row, col + 3) = s3
                            If s3 <> "" And Not Left(s3, 1) = "[" Then
                                ' comment
                                Sheets(sheet).Cells(row, col + 3).Font.Color = rgbDarkGray
                            End If
                        End If
                    Next
                Else
                    
                    Sheets(sheet).Cells(row, 1) = textline
                End If
            End If
            row = row + 1
            I = I + 1
        Wend
    Else
        Sheets(1).Rows(1).Insert Shift:=xlDown
        Sheets(1).Cells(1, 1) = "; not found: " + iFolder + iFile
    End If
    Application.ScreenUpdating = True
End Sub

Public Sub OpenCarFolder(carfoldername As String, carsfolder As String)
    Dim filesSplit As Variant
    Dim f As Long
    Dim currFile  As String
    
    FormProgress.Show
    FormProgress.Tag = 0
    FormProgress.lbProgress = ""
    FormProgress.lbCurrDir = carfoldername
    FormProgress.Repaint
        
    Workbooks.Add
    
    filesSplit = Split(files, ",")
    For f = 0 To UBound(filesSplit)
        DoEvents
        If Not FormProgress.Visible Then: Exit For
        If Not FormProgress.Enabled Then: Exit For
        
        currFile = filesSplit(f)
        FormProgress.Tag = f
        FormProgress.lbCurrDir = CStr(f) & " / " & CStr(UBound(filesSplit)) & " files - " & currFile
        FormProgress.Repaint
        
        Call OpenAFileInSheet(f + 1, carsfolder + carfoldername + "\data\", currFile)
    Next
    
    Unload FormProgress
    
    Sheets(1).Activate
    Sheets(1).Rows(1).Insert Shift:=xlDown
    'Rows("1:1").Select
    'Selection.Insert Shift:=xlDown
    Sheets(1).Cells(1, 1) = " ;" + carfoldername

End Sub

Public Sub OpenCarDataFolderOnly(carfoldername As String, carsfolder As String)
    Dim filesSplit As Variant
    Dim f As Long
    Dim currFile  As String
    
    FormProgress.Show
    FormProgress.Tag = 0
    FormProgress.lbProgress = ""
    FormProgress.lbCurrDir = carfoldername
    FormProgress.Repaint
    
    Workbooks.Add
    
    filesSplit = Split(files, ",")
    For f = 0 To UBound(filesSplit)
        DoEvents
        If Not FormProgress.Visible Then: Exit For
        If Not FormProgress.Enabled Then: Exit For
        
        currFile = filesSplit(f)
        FormProgress.Tag = f
        FormProgress.lbCurrDir = CStr(f) & " / " & CStr(UBound(filesSplit)) & " files - " & currFile
        FormProgress.Repaint
        
        Call OpenAFileInSheet(f + 1, carsfolder, currFile)
    Next
    
    Unload FormProgress
    
    Sheets(1).Activate
    Sheets(1).Rows(1).Insert Shift:=xlDown
    'Rows("1:1").Select
    'Selection.Insert Shift:=xlDown
    Sheets(1).Cells(1, 1) = " ;" + carfoldername

End Sub

Public Sub RunAC_Read_Car_Data_folder()
    Dim FirstPath As String, startdir As String
    Dim DirCount As Integer, NumFiles As Integer
    Dim s_filename As String, acdfolder As String
    
    Call GetWorkbookFolder
    
    startdir = ""
    ' \CARS-directory
    FirstPath = Sheets("control").Cells(2, 1).Text
    If FirstPath = "" Then
        FirstPath = GetACDirAutomatic2()
        If FirstPath <> "" Then
            If MsgBox("Found AC in " + FirstPath + ". Use it?", vbYesNo) = vbYes Then
                FirstPath = FirstPath + "\cars"
            End If
        End If
    Else
        startdir = FirstPath
        FirstPath = ""
    End If
    
    If FirstPath = "" Then
        s_filename = "[ignored]"  ' browse for it
        s_filename = GetADirOrFile(startdir, s_filename, "Browse for a car directory")
        If (s_filename = "") Or (s_filename = "Falsch") Or s_filename = "False" Then
            'MsgBox ("Canceled.")
            Exit Sub
        End If
        FirstPath = Mid(s_filename, 1, InStrRev(s_filename, "\"))
        s_filename = Left(FirstPath, Len(FirstPath) - 1)
        s_filename = Mid(FirstPath, InStrRev(s_filename, "\") + 1, Len(FirstPath) - InStrRev(s_filename, "\") - 1)
       
        FirstPath = Mid(FirstPath, 1, InStrRev(FirstPath, "\") - 1)
        FirstPath = Left(FirstPath, Len(FirstPath) - 1)
        FirstPath = Mid(FirstPath, 1, InStrRev(FirstPath, "\") - 1) + "\"
        
        If FileExists(FirstPath + s_filename + "\data\car.ini") Then
            Call OpenCarFolder(s_filename, FirstPath)
        Else
            If FileExists(xlsDirectory + "acd_file.exe") Then
                If MsgBox("No 'data\car.ini' found. Unpack " & s_filename & "\data.acd?", vbYesNo) = vbYes Then
                    Call RunEXEAndWaitForClose(xlsDirectory + "acd_file.exe", FirstPath + s_filename)
                    Call OpenCarFolder(s_filename, FirstPath)
                End If
            Else
                MsgBox "No 'data\car.ini' found. Unpack " & s_filename & "\data.acd!", vbInformation
            End If
        End If
    End If
    
End Sub


Public Sub RunAC_Read_DataONLY_folder()
    Dim FirstPath As String, startdir As String
    Dim DirCount As Integer, NumFiles As Integer
    Dim s_filename As String, desc As String
    Dim splitd() As String, acdfolder As String
    Dim res As VbMsgBoxResult
    
    Call GetWorkbookFolder
    
    startdir = ""
    ' \CARS-directory
    FirstPath = Sheets("control").Cells(2, 1).Text
    If FirstPath = "" Then
        FirstPath = GetACDirAutomatic2()
        If FirstPath <> "" Then
            If MsgBox("Found AC in " + FirstPath + ". Use it?", vbYesNo) = vbYes Then
                FirstPath = FirstPath + "\cars"
            End If
        End If
    Else
        startdir = FirstPath
        FirstPath = ""
    End If
    
    If FirstPath = "" Then
        s_filename = "[ignored]"  ' browse for it
        s_filename = GetADirOrFile(startdir, s_filename, "Browse for a car data 'only' directory")
        If (s_filename = "") Or (s_filename = "Falsch") Or s_filename = "False" Then
            'MsgBox ("Canceled.")
            Exit Sub
        End If
        FirstPath = Mid(s_filename, 1, InStrRev(s_filename, "\"))
        
        splitd = Split(FirstPath, "\")
        desc = splitd(UBound(splitd) - 2) + "_" + splitd(UBound(splitd) - 1)
        
        s_filename = Left(FirstPath, Len(FirstPath) - 1)
        s_filename = Mid(FirstPath, InStrRev(s_filename, "\") + 1, Len(FirstPath) - InStrRev(s_filename, "\") - 1)
       
        If FileExists(FirstPath + "\car.ini") Then
            Call OpenCarDataFolderOnly(desc, FirstPath)
        Else
            If FileExists(xlsDirectory + "acd_file.exe") Then
                res = MsgBox("No 'data\car.ini' found. Unpack data.acd?" & Chr(10) & Replace(desc, "_data", ""), vbYesNo)
                If res = vbYes Then
                    acdfolder = Replace(desc, "_data", "")
                    Call RunEXEAndWaitForClose(xlsDirectory + "acd_file.exe", Replace(FirstPath, "\data\", ""))
                    Call OpenCarDataFolderOnly(desc, FirstPath)
                End If
            Else
                MsgBox "No 'data\car.ini' found. Unpack " & s_filename & "\data.acd!", vbInformation
            End If
        End If
    End If
    
End Sub



Public Sub WriteJSONFile(carfoldername, carsfolder, row)
    Dim jsonFile As String, backupFile As String
    jsonFile = carsfolder + carfoldername + "\ui\ui_car.json"

    Dim s As String, ss As String, surl As String, sver As String, sauthor As String
    Dim dpow As Double, dwei As Double
    Dim lines() As String
    Dim ll As Variant
    Dim linesC As Integer, I As Integer
    Dim isKunos As Boolean
    Dim sTags As String, sErg As String, sDescription As String * 1024
    Dim isTag As Boolean
    Dim arr As Variant
    Dim cmt As Comment
    Dim ii As Integer
    Dim cc As Integer
    Dim c As Integer
    Dim fso As Object
    Dim out As Object
    
    ss = Left(jsonFile, Len(jsonFile) - Len("ui_car.json")) + "dlc_ui_car.json"
    isKunos = FileExists(ss)
    
    surl = ""
    sauthor = ""
    sver = ""
    sDescription = ""
    sTags = ""
    sErg = ""
    isTag = False
    I = 0
    
    lines = ScanFileUTF8(jsonFile)
    linesC = UBound(lines())
    If linesC <= 0 Then
        MsgBox ("Could not parse json file.")
        Exit Sub
    End If
    
    ' make backup
    backupFile = jsonFile + ".bak"
    c = 0
    While FileExists(backupFile)
        backupFile = jsonFile + CStr(c) + ".bak"
        c = c + 1
    Wend
    FileCopy jsonFile, backupFile
    
    
    
    'Open jsonFile For Output As #1
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set out = fso.CreateTextFile(jsonFile, True, True)
    
    While I <= linesC
        s = lines(I)
        s = Replace$(s, vbLf, "")
        s = Replace$(s, vbCr, "")
        s = Replace$(s, vbCrLf, "")
        
        ss = LCase(s)
        If InStr(ss, """tags""") > 0 Or isTag Then
            ' eat all old tags
            If InStr(ss, """tags""") > 0 Then
                If InStr(ss, "]") <= 0 Then
                    out.WriteLine (s)
                    'Print #1, s
                Else
                    'Print #1, "    ""tags"": ["
                    out.WriteLine ("    ""tags"": [")
                End If
                isTag = True
            End If
            
            If isTag And InStr(ss, "]") > 0 Then
                isTag = False
                ' write new tags
                sTags = Trim(Cells(row, 57).Text)
                On Error Resume Next
                sTags = Replace$(sTags, """, """, """,""")
                arr = Split(sTags, """,""")
                ii = 0
                cc = UBound(arr)
                For Each ll In arr
                    ll = Replace$(ll, """", "")
                    If ii < cc Then
                        'Print #1, "        " + ll + ","
                        out.WriteLine ("        """ + ll + """,")
                    Else
                        'Print #1, "        " + ll
                        out.WriteLine ("        """ + ll + """")
                    End If
                    ii = ii + 1
                Next ll
                If InStr(ss, "[") > 0 Then
                    'Print #1, "    ],"
                    out.WriteLine ("    ],")
                Else
                    'Print #1, s
                    out.WriteLine (s)
                End If
            End If
        
        Else
            If s <> "" Then
                'Print #1, s
                out.WriteLine (s)
            End If
        End If
        I = I + 1
    Wend
    ' Close #1
    
    out.Close
    
End Sub
