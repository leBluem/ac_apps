# default
# player1 = ac.getDriverName(0)
# change this...
player2 = "Andi"


# Name:       MultiLaps for Assetto Corsa
# Version:    v2.0 - 29.05.2026
# Anthor:     Sylvain Villet, leBluem (10 july 2024)
# Contact:    sylvain.villet@gmail.com
# Date:       01.05.2016
# Desc.:      This app provides a list of the last "N" laps
#             done, the current lap projection and performance
#             delta, and the total session time.
#             The deltas can be calculated from the best lap, the median
#             or the average time of the top 25, 50 or 75% laps.
#             The app can be fully configured from the MultiLaps_config widget.
#
# Thanks:     - Rombik for the sim_info module
#             - Rivali (OV1Info) and Fernando Deutsch (ferito-LiveCarTracker)
#             for the inspiration and example
#             - PanaRace970 for the Touristenfahrten workaround

import sys, os, configparser, traceback, time, platform, codecs, functools
import json
# import math
import struct
# from struct import *
import operator

if platform.architecture()[0] == "64bit":
    sysdir='apps/python/MultiLaps/MultiLaps_dll/stdlib64'
else:
    sysdir='apps/python/MultiLaps/MultiLaps_dll/stdlib'
sys.path.insert(0, sysdir)
os.environ['PATH'] = os.environ['PATH'] + ";."
import ctypes
from ctypes.wintypes import MAX_PATH
# if __name__ != '__main__':
import ac, acsys
from MultiLaps_lib.sim_infoMLaps import info

CSIDL_PERSONAL = 5 # My Documents
SHGFP_TYPE_CURRENT = 0 # Get current, not default value
buf = ctypes.create_unicode_buffer(MAX_PATH)
ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_PERSONAL, None, SHGFP_TYPE_CURRENT, buf)
userDir=''
userDir = buf.value # bingo, userdir/documents!
acpath = os.path.abspath(__file__).lower().replace('apps\\python\\multilaps\\multilaps.py','')
# ac.log('mlaps path ' + acpath)

playerid = 0
players = []
players.append(ac.getDriverName(0))
players.append(player2)

### ["car name", bestms, bestms, "player"]
pblaptimes = []

trackLength_int = 0
div1=0.99
div2=0.01
page = 0
pages = 0

ShowTime = 5.0   # time to show MultiLaps window on s/f
ShowTimer = 0.0
ShowWhenCrossingSF = True
ShowTimerON = False
bDoResetOnNewSession = False

customFont = "Consolas"
customFonts = [] # filled dynamically

alowedNumberOfTyresOut = 2
currentSessonTime = -1
lastSessonTime = -1
btn_options = 0
btn_laptimes = 0
btn_laptimes2 = 0
btn_toggleplayer = 0
sortid = 1
hidetimer = 0.0
btnLapsUp = 0
btnLapsDn = 0
ghosttime = 0


# https://bytes.com/topic/python/answers/839254-extracting-hte-font-name-truetype-font-file
# Here's the code to parse the spec.
def getTTFFontName(path, fname, fonts):
    try:
        f = open( os.path.join(path,fname), 'rb' )

        #header
        shead= struct.Struct( '>IHHHH' )
        fhead= f.read( shead.size )
        dhead= shead.unpack_from( fhead, 0 )

        #font directory
        stable= struct.Struct( '>4sIII' )
        ftable= f.read( stable.size* dhead[ 1 ] )
        for i in range( dhead[1] ): #directory records
            dtable= stable.unpack_from(ftable, i* stable.size )
            if str(dtable[0])== "b'name'": break

        #name table
        f.seek( dtable[2] ) #at offset
        fnametable = f.read( dtable[3] ) #length
        snamehead = struct.Struct( '>HHH' ) #name table head
        dnamehead = snamehead.unpack_from( fnametable, 0 )
        sname = struct.Struct( '>HHHHHH' )
        ss1=''
        ss2=''
        run = 0

        for i in range( dnamehead[1] ): #name table records
            if snamehead.size+ (i+1)* sname.size < len(fnametable):
                dname = sname.unpack_from(fnametable, snamehead.size + i*sname.size )
                # key==4 for fontname
                # 64 or 32 chars for fontname?

                if dname[3]==0 and run==0:
                    run += 1

                # s4  = struct.unpack_from('%is'% dname[4], fnametable, dnamehead[2]+ dname[5] )[0]
                # ss4 = codecs.decode(s4)
                # ss4 = str( ss4 ).replace('\x00', '')
                # print( 'offset ' + str(dname[3]) + ' - ' + fname + '  -  ' + ss4 )

                ### font name
                if (dname[3]==1 and run<2) or (dname[3]==4 and run>1) and dname[4] < 128:
                #if ss1=='' and dname[3]==4 and dname[4] < 64 and dnamehead[2]+ dname[5] + 64 < len(fnametable):
                # if dname[3]==4 and dname[4] < 64 and dnamehead[2]+ dname[5] + 64 < len(fnametable):
                #if dname[4] < 64 and dnamehead[2]+ dname[5] + 64 < len(fnametable):
                    s  = struct.unpack_from('%is'% dname[4], fnametable, dnamehead[2]+ dname[5] )[0]
                    ss1 = codecs.decode(s)
                    ss1 = str( ss1 ).replace('\x00', '')
                    # print( fname + '  -  ' + ss1 + ' - ' + str(dname[3]) )

                ### font name style
                if ss2=='' and dname[3]==2 and dname[4] < 16 and dnamehead[2]+ dname[5] + 16 < len(fnametable):
                # if ss2=='' and dname[3]==2 and dname[4] < 16 and dnamehead[2]+ dname[5] + 16 < len(fnametable):
                # if dname[3]==2 and dname[4] < 16 and dnamehead[2]+ dname[5] + 16 < len(fnametable):
                #if dname[4] < 64 and dnamehead[2]+ dname[5] + 64 < len(fnametable):
                    s  = struct.unpack_from('%is'% dname[4], fnametable, dnamehead[2]+ dname[5] )[0]
                    ss2 = codecs.decode(s)
                    ss2 = str( ss2 ).replace('\x00', '')
                    # print( fname + '  -  ' + ss2 + ' - ' + str(dname[3]) )

            if run>1 and ss1!='' and ss2!='':
                break

        lf = len(fonts)
        ss = str( ss1 ).replace('\x00', '')+' '+str( ss2 ).replace('\x00', '')
        #ss = str( ss ).replace(ss2, '')
        #if ( (lf==0)  or  (lf>0 and not fonts[lf-1] in ss) or ('mono' in ss.lower() and not fonts[lf-1] in ss and not ss in fonts[lf-1]) ) and not 'ingdings' in ss:
        if ( (lf==0)  or  (lf>0 and not ss in fonts[lf-1] and not fonts[lf-1] in ss) or ('mono' in ss.lower() and not fonts[lf-1] in ss and not ss in fonts[lf-1]) ) and not 'ingdings' in ss:
            # ss = ss.replace(' Negreta','').replace(' Cursiva','').replace(' Normal','').replace(' Regular','').replace(' Bold','').replace(' Medium','').replace(' Semibold','').replace(' Italic','').replace(' Light','').replace(' Black','').replace(' Semilight','')
            # # ac.log(fname + " - " + ss)
            # fonts.append( ss )

            # ss = ss.replace(' Italic Italic',' Italic').replace(' Negreta Negreta',' Negreta')
            # .replace(' Normal','').replace(' Regular','').replace(' Bold','').replace(' Medium','').replace(' Semibold','').replace(' Italic','').replace(' Light','').replace(' Black','').replace(' Semilight','')

            ss = ss.replace(' Extra','').replace(' Heavy','').replace(' Negreta','').replace(' Cursiva','').replace(' Normal','').replace(' Regular','').replace(' Bold','').replace(' Medium','').replace(' Semibold','').replace(' Italic','').replace(' Light','').replace(' Black','').replace(' Semilight','')

            add=True
            # if fonts.index(ss)<0:
            for sss in fonts:
                if sss==ss:
                    add=False
            if add:
                fonts.append(ss)
                # if __name__ == '__main__':
                #     print(ss)
                # else:
                #     ac.log(ss)

    except:
        if __name__ == '__main__':
            print("MultiLaps: Error in refreshAndWriteParameters: " + traceback.format_exc())
        else:
            ac.log("MultiLaps: Error in refreshAndWriteParameters: " + traceback.format_exc())

def findFonts(subdirectory, mask, fonts):
    for root, dirs, names in os.walk(subdirectory):
        for name in names:
            if mask in name:
                getTTFFontName(root, name, fonts)

# Parameters from config file
showHeader = 0
fontSize = 18
opacity = 50
showBorder = 0

lapDisplayedCount = 6
showDelta = 1
deltaColor = "white"
redAt = 500
greenAt = -500
showCurrent = 1
showReference = 1
reference = "median"
showTotal = 1
showWho = 1

updateTime = 100
logLaps = 1
logBest = "always"
lockBest = 0

# Objects
multiLapsApp = 0
config = 0
configApp = 0
laptimesApp = 0
lbLaptimes = 0

# Display global settings
spacing = 5
firstSpacing = 30
fontSizeConfig = 16
lapLabelCount = 50

# Global variable
lastUpdateTime = 0
useMyPerf = 1
trackName = ""
trackConf = ""
carName = ""
bestLapFile = ""

PIT_EXIT_STATE_IDLE         = 0
PIT_EXIT_STATE_IN_PIT_LANE  = 1
PIT_EXIT_STATE_THROTTLE     = 2
PIT_EXIT_STATE_BRAKE        = 3
PIT_EXIT_STATE_APPLY_OFFSET = 4

nurbTourist = False

def timeToString(time):
    try:
        if time == None or not time or time <= 0:
            return "-:--:---"
        else:
            return "{:d}:{:0>2d}:{:0>3d}".format(int(time/60000), int((time%60000)/1000), int(time%1000))
    except:
        ac.log("MultiLaps: Error in timeToString: " + traceback.format_exc())
        return "-:--.---"

def timeToStringCut(time):
    try:
        if time == None or not time or time <= 0:
            return "-:--.---"
        else:
            return "{:d}:{:0>2d}:{:0>2d}".format(int(time/60000), int((time%60000)/1000), int((time%1000)/100))
    except:
        ac.log("MultiLaps: Error in timeToString: " + traceback.format_exc())
        return "-:--.---"

def deltaToString(time):
    if not time:
        return "-:--:---"
    try:
        return "{:+.3f}".format(float(time)/1000)
    except:
        ac.log("MultiLaps: Error in deltaToString: " + traceback.format_exc())
        return "+0.000"

def yesOrNo(value):
    if value:
        return "Yes"
    else:
        return "No"


def getSetting(cfgdef, cfg, sect, value, valdef):
    res = valdef
    if cfgdef.has_option(sect, value):
        res = cfgdef[sect][value]
        if ';' in res:
            res = res.split(';')[0]
        if cfg.has_option(sect, value):
            res = cfg[sect][value]
            if ';' in res:
                res = res.split(';')[0]
        cfgdef[sect][value] = res
    return str(res)

def str2bool(v):
    return str(v).lower() in ("yes", "true", "t", "1")


def onbtnLapsUp(*a):
    global page
    if page>0:
        page -= 1
    UpdateLaptimes()

def onbtnLapsDn(*a):
    global page, pages
    if page<pages:
        page += 1
    UpdateLaptimes()

c=0
carNamesShort = []
carNamesLong = []
def GetCarname(car):
    try:
        global acpath
        global c, carNamesShort, carNamesLong
        if car.lower() in carNamesShort:
            return carNamesLong[carNamesShort.index(car.lower())]
        s=car.lower()
        carInfoPath = acpath + 'content/cars/' + s + '/ui/ui_car.json'
        #c+=1
        #ac.log(str(c) + carInfoPath)
        if os.path.isfile(carInfoPath):
            try:
                with open(carInfoPath, "r", encoding="utf-8", errors="ignore") as TL:
                    carUI = json.loads(TL.read().encode('ascii', 'ignore').decode('ascii'), strict=False)
                s = carUI["name"]
                carNamesShort.append(car.lower())
                carNamesLong.append(s)
            except:
                ac.log("MultiLaps: Error " + traceback.format_exc())
        else:
            carNamesShort.append(s)
            s = '!!!   ' + s
            carNamesLong.append(s)
        return s
    except:
        ac.log("MultiLaps: Error " + traceback.format_exc())

def findBestsThisTrack(subdirectory, mask, ext):
    global players, playerid, pblaptimes
    for root, dirs, files in os.walk(subdirectory):
        for f in files:
            if str(f).lower().startswith(mask) and str(f).lower().endswith(ext):
                lf = os.path.join(root, f)
                carl = str(f).replace(mask, '').replace(ext,'')
                mldata = configparser.ConfigParser()
                mldata.optionxform = str
                mldata.read(lf, encoding='utf-8')

                #pb = mldata.getint("TIME", "best")
                pbs = mldata.get("TIME", "best")
                Invalid = False
                if "†" in str(pbs):
                    Invalid = True
                    pb = int( str(pbs).partition("†")[0] )
                else:
                    pb = int( pbs )

                player = str(ac.getDriverName(0))
                if mldata.has_option("TIME", "player"):
                    player = mldata.get("TIME", "player")

                while len(player)<7:
                    player = player + "_"

                carl=str(GetCarname(carl))
                done = False
                i=0
                for s in pblaptimes:
                    if carl.lower() in s[0].lower():
                        pblaptimes[i][2]=pb
                        pblaptimes[i][3]=player
                        if Invalid:
                            pblaptimes[i][0] = pblaptimes[i][0] + " †"
                        done = True
                        break
                    i+=1
                if not done:
                    if Invalid:
                        pblaptimes.append([carl+" †", -1, pb, player])
                    else:
                        pblaptimes.append([carl     , -1, pb, player])



def ReadPersonalBests(file):
    try:
        global trackConf, lbLaptimes, pblaptimes, pages, carName, carNamesShort, carNamesLong
        global players, playerid
        pbdata = configparser.ConfigParser()
        pbdata.optionxform = str
        pbdata.read(file)

        sectTrack = "@" + trackName
        if trackConf != "":
            sectTrack = sectTrack + "-" + trackConf
        for sect in pbdata:
            if sect.endswith( sectTrack.upper() ):
                pb = pbdata.getint(sect, "TIME")
                car = sect.replace(sectTrack.upper(), "")
                carl = GetCarname(car)
                if car == carName.upper():
                    pblaptimes.append(["==>    " + carl, pb, -1, players[playerid]])
                else:
                    pblaptimes.append([            carl, pb, -1, players[playerid]])

        # if not carName in pblaptimes:
        #     carl = GetCarname(carName)
        #     if not carName.lower() in carNamesShort:
        #         carNamesShort.append(carName.lower())
        #         carNamesLong.append(carl.lower())
            #pblaptimes.append(["==> Multilaps best --  " + carl, -1, -1])

        pblaptimes = sorted(pblaptimes, key=operator.itemgetter(1))
        pages = int (len(pblaptimes) / 16)
        UpdateLaptimes()
        #ac.log(str(pblaptimes))
    except:
        ac.log("MultiLaps: Error " + traceback.format_exc())


def ReadUserName():
# race.ini
# [CAR_0]
# DRIVER_NAME=leBluem
    raceinipath      = userDir + "\\Assetto Corsa\\cfg\\race.ini"
    configdef = configparser.ConfigParser()
    configdef.optionxform = str
    configdef.read(raceinipath)
    if configdef.has_option('CAR_0', "DRIVER_NAME"):
        s=configdef.get('CAR_0', "DRIVER_NAME")
        return s
    return "Player1"



class MultiLaps:

    def __init__(self, name, headerName):
        self.headerName = headerName
        self.window = ac.newApp(name)

        self.lapNumberLabel = []
        self.timeLabel = []
        self.deltaLabel = []
        self.whoLabel = []
        self.lastLapDataRefreshed = -1
        self.lastLapViewRefreshed = 0
        self.total = 0
        self.bestLapAc = 0
        self.bestLapTimeSession = 0
        self.bestLapTimeSessionInvalid = 0
        self.bestLapTime = 0
        self.bestLapTimeLast = 0
        self.referenceTime = 0
        self.laps = []
        self.lapsInvalid = []
        self.lapsPlayer = []
        self.bestLapData = []
        self.bestLapPlayer = ""
        self.currentLapData = [(0.0,0.0)]
        self.sfCrossed = 0
        self.session = info.graphics.session   ###TimeLeft
        self.lastSession = self.session
        self.lapInvalidated = 0
        self.justCrossedSf = False
        self.position = 0
        self.lastPosition = 0
        self.currentTime = 0.0
        self.lastCurrentTime = 0.0
        self.pitExitState = 0
        self.pitExitDeltaOffset = 0
        self.pitExitLap = 0
        self.performance = 0
        self.projection = 0

        self.readBestLap()

        self.currLabelId = lapLabelCount
        self.refLabelId = lapLabelCount+1
        self.totalLabelId = lapLabelCount+2
        self.whoLabelId = lapLabelCount+3
        ### adjust here too for new options!!!
        for index in range(lapLabelCount+3):
            self.lapNumberLabel.append(ac.addLabel(self.window, "%d." % (index+1)))
            ac.setFontAlignment(self.lapNumberLabel[index], 'right')

            self.timeLabel.append(ac.addLabel(self.window, timeToString(0)))
            ac.setFontAlignment(self.timeLabel[index], 'right')

            self.deltaLabel.append(ac.addLabel(self.window, "-.---"))
            ac.setFontAlignment(self.deltaLabel[index], 'right')

            self.whoLabel.append(ac.addLabel(self.window, ""))
            ac.setFontAlignment(self.whoLabel[index], 'left')

        ac.setText(self.lapNumberLabel[self.currLabelId],  "Est.")
        ### ac.setText(self.lapNumberLabel[self.currLabelId],  "estimate")
        ac.setText(self.lapNumberLabel[self.totalLabelId], "Tot.")


    def refreshParameters(self):
        if 'DymoFont' in customFont:
            widthNumber     = fontSize*3*1.5
            widthTime       = fontSize*6*1.35
            widthDelta      = fontSize*6*1.35
            widthWho        = fontSize*4*1.35
            spacing = 5
        else:
            widthNumber     = fontSize*3
            widthTime       = fontSize*6
            widthDelta      = fontSize*6
            widthWho        = fontSize*4
            spacing = 5
            #widthNumber     = fontSize*2
            #widthTime       = fontSize*5
            #widthDelta      = fontSize*5

        ac.setSize(laptimesApp, fontSize*40, fontSize*2 + fontSize*22)

        ac.setFontSize(lbLaptimes , fontSize)
        ac.setPosition(lbLaptimes , fontSize*39, 60)

        ac.setPosition(btnLapsUp  ,  2, 50)
        ac.setPosition(btnLapsDn  ,  2, 90)
        ac.setSize(    btnLapsUp  , 20, 30)
        ac.setSize(    btnLapsDn  , 20, 30)

        ac.setIconPosition(self.window, -40000, -10000)
        if showHeader:
            ac.setTitle(self.window, self.headerName)
            #ac.setIconPosition(self.window, 0, 0)
            self.firstSpacing = firstSpacing
        else:
            ac.setTitle(self.window, "")
            #ac.setIconPosition(self.window, -10000, -10000)
            self.firstSpacing = 0

        self.width  = widthNumber + widthTime + widthDelta*showDelta + 2*spacing + widthWho
        self.height = self.firstSpacing + (fontSize + spacing)*(lapDisplayedCount + showCurrent + showTotal + showReference)

        ac.setCustomFont(lbLaptimes, customFont, 0, 0)

        ac.setSize(self.window, self.width, self.height)
        ac.setFontSize(self.window, fontSize)
        ### adjust here too for new options!!!
        for index in range(lapLabelCount+3):
            ac.setCustomFont(self.timeLabel[index], customFont, 0, 0)
            ac.setCustomFont(self.deltaLabel[index], customFont, 0, 0)
            ac.setCustomFont(self.whoLabel[index], customFont, 0, 0)

            ac.setFontSize(self.lapNumberLabel[index], fontSize)
            ac.setPosition(self.lapNumberLabel[index], spacing, self.firstSpacing + index*(fontSize+spacing))
            ac.setSize(self.lapNumberLabel[index], widthNumber, fontSize+spacing)

            ac.setFontSize(self.timeLabel[index], fontSize)
            ac.setPosition(self.timeLabel[index], spacing + widthNumber, self.firstSpacing + index*(fontSize+spacing))
            ac.setSize(self.timeLabel[index], widthTime, fontSize+spacing)

            ac.setFontSize(self.deltaLabel[index], fontSize)
            ac.setPosition(self.deltaLabel[index], spacing + widthNumber + widthTime, self.firstSpacing + index*(fontSize+spacing))
            ac.setSize(    self.deltaLabel[index], widthTime, fontSize+spacing)

            ac.setFontSize(self.whoLabel[index], fontSize-2)
            ac.setPosition(self.whoLabel[index], spacing + widthNumber + widthTime + widthDelta + fontSize, self.firstSpacing + index*(fontSize+spacing))
            ac.setSize(    self.whoLabel[index], widthWho, fontSize+spacing)

        for index in range(lapLabelCount+3):
            ac.setCustomFont(self.lapNumberLabel[index], customFont, 0, 0)
            ac.setCustomFont(self.timeLabel[index], customFont, 0, 0)
            ac.setCustomFont(self.deltaLabel[index], customFont, 0, 0)
            ac.setCustomFont(self.whoLabel[index], customFont, 0, 0)
            ac.setFontColor(self.timeLabel[index], 1, 1, 1, 1)
            if index < lapDisplayedCount:
                ac.setVisible(self.lapNumberLabel[index], 1)
                ac.setVisible(self.timeLabel[index], 1)
                ac.setVisible(self.deltaLabel[index], showDelta)
                ac.setVisible(self.whoLabel[index], showWho)
            else:
                ac.setVisible(self.lapNumberLabel[index], 0)
                ac.setVisible(self.timeLabel[index], 0)
                ac.setVisible(self.deltaLabel[index], 0)
                ac.setVisible(self.whoLabel[index], 0)

        rowIndex = lapDisplayedCount

        # Current time position
        ac.setCustomFont(self.lapNumberLabel[self.currLabelId], customFont, 0, 0)
        ac.setCustomFont(self.timeLabel[self.currLabelId], customFont, 0, 0)
        ac.setCustomFont(self.deltaLabel[self.currLabelId], customFont, 0, 0)
        ac.setCustomFont(self.whoLabel[self.currLabelId], customFont, 0, 0)

        ac.setPosition(self.lapNumberLabel[self.currLabelId], spacing, self.firstSpacing + rowIndex*(fontSize+spacing))
        ac.setPosition(self.timeLabel[self.currLabelId], spacing + widthNumber, self.firstSpacing + rowIndex*(fontSize+spacing))
        ac.setPosition(self.deltaLabel[self.currLabelId], spacing + widthNumber + widthTime, self.firstSpacing + rowIndex*(fontSize+spacing))
        ac.setPosition(self.whoLabel[self.currLabelId], spacing + widthNumber + widthTime+ + widthDelta, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setVisible(self.lapNumberLabel[self.currLabelId], showCurrent)
        ac.setVisible(self.timeLabel[self.currLabelId], showCurrent)
        ac.setVisible(self.deltaLabel[self.currLabelId], showCurrent and showDelta)
        ac.setVisible(self.whoLabel[self.currLabelId], showCurrent and showWho)

        rowIndex += showCurrent

        # Reference time name and position
        s="Best"
        if reference == "median":
            s="Med."
        elif reference == "top25":
            s="25%"
        elif reference == "top50":
            s="50%"
        elif reference == "top75":
            s="75%"
        ac.setText(      self.lapNumberLabel[self.refLabelId], s)

        ac.setCustomFont(self.lapNumberLabel[self.refLabelId], customFont, 0, 0)
        ac.setFontSize(  self.lapNumberLabel[self.refLabelId], fontSize)
        ac.setVisible(   self.lapNumberLabel[self.refLabelId], showReference)
        ac.setPosition(  self.lapNumberLabel[self.refLabelId], spacing, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setCustomFont(self.timeLabel[self.refLabelId], customFont, 0, 0)
        ac.setFontSize(  self.timeLabel[self.refLabelId], fontSize)
        ac.setVisible(   self.timeLabel[self.refLabelId], showReference)
        ac.setPosition(  self.timeLabel[self.refLabelId], spacing + widthNumber, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setCustomFont(self.deltaLabel[self.refLabelId], customFont, 0, 0)
        ac.setFontSize(  self.deltaLabel[self.refLabelId], fontSize)
        ac.setVisible(   self.deltaLabel[self.refLabelId], 0)
        ac.setPosition(  self.deltaLabel[self.refLabelId], spacing + widthNumber + widthTime, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setCustomFont(self.whoLabel[self.refLabelId], customFont, 0, 0)
        ac.setFontSize(  self.whoLabel[self.refLabelId], fontSize)
        ac.setVisible(   self.whoLabel[self.refLabelId], 0)
        ac.setPosition(  self.whoLabel[self.refLabelId], spacing + widthNumber + widthTime, self.firstSpacing + rowIndex*(fontSize+spacing))

        rowIndex += showReference

        # Total time position
        ac.setCustomFont(self.timeLabel[self.totalLabelId], customFont, 0, 0)
        ac.setFontSize(self.timeLabel[self.totalLabelId], fontSize)
        ac.setVisible(self.timeLabel[self.totalLabelId], showTotal)
        ac.setPosition(self.timeLabel[self.totalLabelId], spacing + widthNumber, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setCustomFont(self.lapNumberLabel[self.totalLabelId], customFont, 0, 0)
        ac.setFontSize(self.lapNumberLabel[self.totalLabelId], fontSize)
        ac.setVisible(self.lapNumberLabel[self.totalLabelId], showTotal)
        ac.setPosition(self.lapNumberLabel[self.totalLabelId], spacing, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setCustomFont(self.deltaLabel[self.totalLabelId], customFont, 0, 0)
        ac.setFontSize(self.deltaLabel[self.totalLabelId], fontSize)
        ac.setVisible(self.deltaLabel[self.totalLabelId], 0)
        ac.setPosition(self.deltaLabel[self.totalLabelId], spacing + widthNumber + widthTime, self.firstSpacing + rowIndex*(fontSize+spacing))

        ac.setCustomFont(self.whoLabel[self.totalLabelId], customFont, 0, 0)
        ac.setFontSize(  self.whoLabel[self.totalLabelId], fontSize)
        ac.setVisible(   self.whoLabel[self.totalLabelId], 0)
        ac.setPosition(  self.whoLabel[self.totalLabelId], spacing + widthNumber + widthTime + widthDelta, self.firstSpacing + rowIndex*(fontSize+spacing))


        # Force full refresh
        self.updateDataFast()
        self.updateDataRef()
        self.updateViewFast()
        self.updateViewNewLap()

    def updateData(self):
        global ShowWhenCrossingSF, ShowTime, ShowTimer, ShowTimerON
        self.updateDataFast()

        # Refresh on a new lap if we are not watching a replay
        if info.graphics.status != 1 and self.lastLapDataRefreshed != self.lapDone:
            # To be sure that the last lap has been updated, we wait for the 2nd refresh or 200ms
            if self.justCrossedSf or (self.currentTime > 200):
                self.updateDataNewLap()
                self.updateDataRef()
                self.justCrossedSf = False
                # show MultiLaps windows when s/f is crossed or slower than 50
                if ShowWhenCrossingSF and not ShowTimerON:
                    ShowTimer = ShowTime
                    ShowTimerON = True
                    ac.setVisible(self.window, 1)
            else:
                self.justCrossedSf = True

    def updateDataFast(self):

        try:

            global allowedNumberOfTyresOut, bDoResetOnNewSession, lastSessonTime
            global ShowTimerON, ShowWhenCrossingSF, ShowTimer, ShowTime, trackLength_int
            self.currentTime = ac.getCarState(0, acsys.CS.LapTime)

            if info.graphics.status == 1:
                self.projection = 0
                self.performance = 0
                return

            self.lapDone = ac.getCarState(0, acsys.CS.LapCount)
            self.currentPosition = ac.getCarState(0, acsys.CS.NormalizedSplinePosition)
            speed = ac.getCarState(0, acsys.CS.SpeedKMH)
            # avg_speed = ((avg_speed)*div1 + speed*div2)

            if showHeader and self.currentTime>0.0:
                kmdone = (  self.currentPosition) * trackLength_int/1000
                kmleft = (1-self.currentPosition) * trackLength_int/1000
                avg_speed = kmdone/(self.currentTime/60/60/1000)
                # v=s/t | t=s/v
                if avg_speed<1000:
                    ac.setTitle(self.window,''
                        + timeToStringCut(self.currentTime)
                        +'      '    + str(round(kmdone,3)) + 'km'
                        # +'      '    + str(  timeToStringCut(self.currentTime + (kmleft / avg_speed)*1000*60*60)  )
                        +'    Ø '     + str(int(avg_speed)) + 'km/h'
                        #+ ')'+ str(round(trackLength_int/1000,1))
                        #+ ')'+ str(round(info.static.trackSPlineLength/1000,1)) + ')'
                        )
                else:
                    ac.setTitle(self.window,''
                        + str(round(kmdone,3)) + 'km'
                        +'     ' + timeToStringCut(self.currentTime)
                        # +'    ?¿ '        + str(  timeToStringCut(self.currentTime + (kmleft / avg_speed)*1000*60*60)  )
                        +'    Ø '         + '---km/h')

            if ac.isCarInPitline(0):
                self.pitExitState = PIT_EXIT_STATE_IN_PIT_LANE
            elif self.pitExitState == PIT_EXIT_STATE_IN_PIT_LANE:
                self.pitExitLap = self.lapDone
                self.pitExitState = PIT_EXIT_STATE_THROTTLE
            elif self.pitExitState == PIT_EXIT_STATE_THROTTLE and info.physics.brake > 0.1:
                self.pitExitState = PIT_EXIT_STATE_BRAKE
            elif self.pitExitState == PIT_EXIT_STATE_BRAKE and info.physics.gas > 0.9:
                self.pitExitState = PIT_EXIT_STATE_APPLY_OFFSET
                self.pitExitDeltaOffset = self.performance
            elif self.pitExitState == PIT_EXIT_STATE_APPLY_OFFSET and self.lapDone > self.pitExitLap:
                self.pitExitState = PIT_EXIT_STATE_IDLE

            # correct pos for Nordschleife tourist setup
            if nurbTourist:
                if self.currentPosition > 0.9525: # bridge
                    self.currentPosition = self.currentPosition - 0.9525
                else:
                    self.currentPosition = self.currentPosition + 0.0475 # (1.0 - 0.9525)
                # normalize to 0.0 - 1.0
                self.currentPosition = self.currentPosition / 0.9165 # 1/(0.9690 + (1.0 - 0.9525))
                if self.currentPosition > 1.0:
                    self.currentPosition = 0.0

            if self.currentTime<=0.0:
                return


            #Filter AC's bullshits...
            if self.lastPosition > self.currentPosition and self.currentTime > self.lastCurrentTime and self.currentTime < (self.lastCurrentTime+1000):
                return

            #t1=time.time()
            self.lastCurrentTime = self.currentTime
            self.position = self.currentPosition
            self.lastPosition = self.currentPosition
            self.bestLapAc = ac.getCarState(0, acsys.CS.BestLap)

            self.session = info.graphics.session
            currentSessonTime = info.graphics.sessionTimeLeft

            # This will happend after a reset AND at the beginning of the first lap
                ### and ac.isAcLive() and \
            if (currentSessonTime > lastSessonTime):
                # and self.session > self.lastSession) :   ###and (self.currentTime < 500 and self.lapDone == 0):
                self.bestLapTimeSession = 0
                self.bestLapTimeSessionInvalid = 0
                self.total = 0
                self.referenceTime = self.bestLapTime
                self.lapInvalidated = False
                self.lastSession = self.session
                self.currentLapData = [(0.0,0.0)]
                if bDoResetOnNewSession:
                    self.writeSession()
                    self.laps = []
                    self.lapsPlayer = []
                    self.lapsInvalid = []
                if logBest == "never":
                    self.bestLapTime = 0
                    self.bestLapData = []
                    self.bestLapPlayer = ""

                # Check if the reset has put us behind the s/f line
                if self.position > 0.5:
                    self.sfCrossed = False

                # ac.log('Multilaps - session restart')
                ### ac.console('Multilaps - session restart')

            # ac.log('Multilaps updateDataFast0: ' + str(round(time.time()-t1,3))+'sec')
            lastSessonTime = currentSessonTime

            # Check if we have crossed the s/f line
            if not self.sfCrossed:
                #kmleft = (1-self.currentPosition) * trackLength_int/1000
                #self.projection = self.currentTime + (kmleft / avg_speed)*1000*60*60
                if self.position < 0.5:
                    self.sfCrossed = True
                    if ShowWhenCrossingSF:
                        ShowTimerON=True
                        ShowTimer=ShowTime
                        ac.setVisible(multiLapsApp.window, 1)
                else:
                    return

            #t1=time.time()

            # AC api not working: # self.lapInvalidated = ac.getCarState(0, acsys.CS.LapInvalidated)
            if info.physics.numberOfTyresOut > alowedNumberOfTyresOut or ac.getCarState(0, acsys.CS.LapInvalidated):
                self.lapInvalidated = True

            # added
            self.performanceAc = int(ac.getCarState(0, acsys.CS.PerformanceMeter) * 1000)
            if useMyPerf:
                # If the position has increased and we are not in replay, add the new position
                if self.position > self.currentLapData[len(self.currentLapData)-1][0]:
                    self.currentLapData.append((self.position, self.currentTime))

                # If there is a best lap, calculate the interpolation
                if len(self.bestLapData):

                    # Check where is our actual position in the best lap data
                    index = 0
                    while self.position > self.bestLapData[index][0]:
                        index += 1

                    if index == 0:
                        self.myPerformance = 0
                    else:
                        # Interpolation
                        bestLapDeltaPos  = self.bestLapData[index][0] - self.bestLapData[index-1][0]
                        bestLapDeltaTime = self.bestLapData[index][1] - self.bestLapData[index-1][1]
                        currentDeltaPos  = self.position - self.bestLapData[index-1][0]
                        currentDeltaTime = currentDeltaPos*bestLapDeltaTime/bestLapDeltaPos
                        self.myPerformance = self.currentTime - self.bestLapData[index-1][1] - currentDeltaTime
                else:
                    # No best lap, no performance delta.
                    self.myPerformance = 0

                self.projection = self.bestLapTime + self.myPerformance
                self.performance = self.myPerformance + (self.bestLapTime - self.referenceTime)*self.position
                #self.performance = self.performanceAc  # + (self.bestLapAc - self.referenceTime)*self.position

            else:
                self.projection = self.bestLapAc + self.performanceAc
                self.performance = self.performanceAc + (self.bestLapAc - self.referenceTime)*self.position

            #ac.log('Multilaps updateDataFast: ' + str(round(time.time()-t1,3))+'sec')
        except:
            ac.log("MultiLaps: Error in updatedatafast: " + traceback.format_exc())

    def updateDataNewLap(self):
        self.lastLapDataRefreshed = self.lapDone
        #ac.log('reset')
        # Reset
        if self.lapDone <= 0:
            return
        #t1=time.time()
        # ac.getCarState(0, acsys.CS.LastLap) doesn't work yet
        #lapTime = ac.getCarState(0, acsys.CS.LastLap)
        lapTime = info.graphics.iLastTime
        if lapTime <= 0:
            lastSplits = ac.getLastSplits(0)
            lapTime = 0
            for split in lastSplits:
                lapTime += split

        if self.bestLapTimeSession == 0 or lapTime < self.bestLapTimeSession:
            self.bestLapTimeSession = lapTime
            self.bestLapTimeSessionInvalid = self.lapInvalidated
            if ac.isAIControlled(0):
            # if info.physics.isAIControlled==1:
                self.bestLapPlayer = " _AI_"
            else:
                self.bestLapPlayer = players[playerid]

        if not lockBest and (self.bestLapTime == 0 or lapTime < self.bestLapTime):
            self.bestLapTimeLast = self.bestLapTime
            self.bestLapTime = lapTime
            self.currentLapData.append((1.0, lapTime))
            self.bestLapData = self.currentLapData
            if ac.isAIControlled(0):
                self.bestLapPlayer = " _AI_"
            else:
                self.bestLapPlayer = players[playerid]

            #ac.log("MultiLaps: New best lap time: {0} Data: {1}".format(timeToString(self.bestLapTime), str(self.bestLapData)))

        # Reset for the new lap
        self.currentLapData = [(0.0,0.0)]

        self.lapsInvalid.append(self.lapInvalidated)
        self.laps.append(lapTime)
        if ac.isAIControlled(0):
            self.lapsPlayer.append(" _AI_")
        else:
            self.lapsPlayer.append(players[playerid])
        self.total += lapTime
        self.lapInvalidated = False
        # ac.log('Multilaps reset: ' + str(round(time.time()-t1,3))+'sec')



    def updateDataRef(self):
        if reference == "best":
            if useMyPerf:
                self.referenceTime = self.bestLapTime
            else:
                self.referenceTime = self.bestLapAc
        elif len(self.laps) < 1:
            self.referenceTime = 0
        elif len(self.laps) == 1:
            self.referenceTime = self.laps[0]
        else:
            lapsSorted = sorted(self.laps)

            if reference == "median":
                if len(lapsSorted) %2 == 1:
                    self.median = lapsSorted[int(((len(lapsSorted)+1)/2)-1)]
                elif len(lapsSorted) %2 == 0:
                    self.median = float(sum(lapsSorted[int((len(lapsSorted)/2)-1):int((len(lapsSorted)/2)+1)]))/2.0
                self.referenceTime = self.median

            elif reference == "top25":
                self.referenceTime = self.getTopAvg(25, lapsSorted)

            elif reference == "top50":
                self.referenceTime = self.getTopAvg(50, lapsSorted)

            elif reference == "top75":
                self.referenceTime = self.getTopAvg(75, lapsSorted)

    def getTopAvg(self, topPercent, lapsSorted):
        count = int((len(lapsSorted) + len(lapsSorted)%2)*topPercent/100)
        if count:
            lapSum = 0
            for index in range(count):
                lapSum += lapsSorted[index]
            return lapSum/count
        else:
            return lapsSorted[0]

    def updateView(self):
        if self.justCrossedSf:
            return
        self.updateViewFast()

        # Refresh laps and total only on lap change and not replay
        if self.lastLapViewRefreshed != self.lastLapDataRefreshed and info.graphics.status != 1:
            self.updateViewNewLap()

    def updateViewNewLap(self):
        try:
            # refresh all the laps
            for index in range(lapDisplayedCount):
                lapIndex = index
                if len(self.laps) > lapDisplayedCount:
                    lapIndex += len(self.laps)-lapDisplayedCount

                # Refresh lap number
                if (self.pitExitLap > 0) and (self.pitExitLap <= lapIndex < self.lapDone):
                    ac.setText(self.lapNumberLabel[index], "{0}. ({1})".format(lapIndex+1, lapIndex-self.pitExitLap+1))
                else:
                    ac.setText(self.lapNumberLabel[index], "%d." % (lapIndex+1))

                # Refresh lap times and deltas
                if lapIndex < len(self.laps):
                    # Best lap in green
                    if self.lapsInvalid[lapIndex]:
                        ac.setText(self.timeLabel[index], "†" + timeToString(self.laps[lapIndex]) )
                        ac.setFontColor(self.timeLabel[index], 1, 0.47, 0.34, 1)
                        if round(self.laps[lapIndex] - self.referenceTime,1) == 0.0:
                            setDeltaColor(self.deltaLabel[index], self.laps[lapIndex] - self.laps[lapIndex-1], False)
                        else:
                            setDeltaColor(self.deltaLabel[index], self.laps[lapIndex] - self.referenceTime, False)

                        ac.setText(     self.whoLabel[index], self.lapsPlayer[lapIndex])
                        ac.setFontColor(self.whoLabel[index], 1, 0.47, 0.34, 1)

                    else:
                        if self.laps[lapIndex] == self.referenceTime and self.bestLapTimeLast>0.0 and self.referenceTime != self.bestLapTimeLast:
                            ac.setText(     self.timeLabel[index], '*' + timeToString(self.laps[lapIndex]))
                            ac.setFontColor(self.timeLabel[index], 0, 1, 0, 1)
                            # Refresh delta label
                            setDeltaColor(self.deltaLabel[index], self.referenceTime - self.bestLapTimeLast)
                            ac.setText(     self.whoLabel[index], self.lapsPlayer[lapIndex])
                            ac.setFontColor(self.whoLabel[index], 0, 1, 0, 1)

                        else:
                            ac.setText(self.timeLabel[index], timeToString(self.laps[lapIndex]))
                            ac.setFontColor(self.timeLabel[index], 1, 1, 1, 1)
                            # Refresh delta label
                            setDeltaColor(self.deltaLabel[index], self.laps[lapIndex] - self.referenceTime)

                            ac.setText(     self.whoLabel[index], self.lapsPlayer[lapIndex])
                            ac.setFontColor(self.whoLabel[index], 1, 1, 1, 1)


                else:
                    ac.setText(self.timeLabel[index], timeToString(0))
                    ac.setFontColor(self.timeLabel[index], 1, 1, 1, 1)
                    ac.setText(self.deltaLabel[index], "-.---")
                    ac.setFontColor(self.deltaLabel[index], 1, 1, 1, 1)
                    ac.setText(     self.whoLabel[index], "")
                    ac.setFontColor(self.whoLabel[index], 1, 1, 1, 1)

            # Refresh Total
            ac.setText(self.timeLabel[self.totalLabelId], timeToString(self.total))

            # Refresh reference
            if self.bestLapTimeSessionInvalid:
                ac.setText(     self.timeLabel[self.refLabelId], "†" + timeToString(self.referenceTime))
                ac.setFontColor(self.timeLabel[self.refLabelId], 1, 0.47, 0.34, 1)
            else:
                ac.setText(     self.timeLabel[self.refLabelId], timeToString(self.referenceTime))
                ac.setFontColor(self.timeLabel[self.refLabelId], 1, 1, 1, 1)

            ac.setText(     self.whoLabel[self.refLabelId], "---" + self.bestLapPlayer)
            ac.setFontColor(self.whoLabel[self.refLabelId], 1, 1, 1, 1)

            self.lastLapViewRefreshed = self.lastLapDataRefreshed
        except:
            ac.log("MultiLaps class: Error in updateViewNewlap: " + traceback.format_exc())

    def updateViewFast(self):
        # Refresh current lap projection and performance
        #if self.sfCrossed and info.graphics.status != 1 and self.position > 0.00001:
        if self.sfCrossed and len(self.bestLapData) > 0 and info.graphics.status != 1 and self.position > 0.00001:
            if self.lapInvalidated:
                ac.setText(self.timeLabel[self.currLabelId], "†"+timeToString(self.projection))
            else:
                ac.setText(self.timeLabel[self.currLabelId],     timeToString(self.projection))

            if self.pitExitState == PIT_EXIT_STATE_APPLY_OFFSET:
                setDeltaColor(self.deltaLabel[self.currLabelId], self.projection - self.referenceTime -self.pitExitDeltaOffset, False)
                setDeltaColor(self.timeLabel[self.currLabelId] , self.projection - self.referenceTime -self.pitExitDeltaOffset, True)
                # setDeltaColor(self.deltaLabel[self.currLabelId], self.performance-self.pitExitDeltaOffset, False)
                # setDeltaColor(self.timeLabel[self.currLabelId] , self.performance-self.pitExitDeltaOffset, True)
            else:
                setDeltaColor(self.deltaLabel[self.currLabelId], self.projection - self.referenceTime, False)
                setDeltaColor(self.timeLabel[self.currLabelId] , self.projection - self.referenceTime, True)
                # setDeltaColor(self.deltaLabel[self.currLabelId], self.performance, False)
                # setDeltaColor(self.timeLabel[self.currLabelId], self.performance, True)
        else:
            if self.lapInvalidated:
                ac.setText(self.timeLabel[self.currLabelId], "†"+timeToString(self.currentTime))
            else:
                ac.setText(self.timeLabel[self.currLabelId], timeToString(self.currentTime))

            ac.setText(self.deltaLabel[self.currLabelId], "-.---")
            ac.setFontColor(self.deltaLabel[self.currLabelId], 1, 1, 1, 1)

        if self.lapInvalidated:
            ac.setFontColor(self.timeLabel[self.currLabelId], 1, 0.47, 0.34, 1)
        else:
            ac.setFontColor(self.timeLabel[self.currLabelId], 1, 1, 1, 1)

    def writeSession(self):
        try:
            if logLaps and len(self.laps) > 0:
                lapsLog = configparser.ConfigParser()
                if trackConf == "":
                    fileName = "apps/python/MultiLaps/MultiLaps_session/{0} - {1} - {2}.ini".format(
                        trackName, carName, time.strftime("%Y-%m-%d"))
                else:
                    fileName = "apps/python/MultiLaps/MultiLaps_session/{0} [{1}] - {2} - {3}.ini".format(
                        trackName, trackConf, carName, time.strftime("%Y-%m-%d"))

                if os.path.exists(fileName):
                    lapsLog.read(fileName, encoding='utf-8')

                sessionNumer = 1
                sectionName = "Session {0}".format(sessionNumer)

                while lapsLog.has_section(sectionName):
                    sessionNumer += 1
                    sectionName = "Session {0}".format(sessionNumer)

                lapsLog.add_section(sectionName)

                for index in range(len(self.laps)):
                    if self.lapsInvalid[index]:
                        lapsLog.set(sectionName, "Lap {0}".format(index+1), timeToString(self.laps[index])+" †")
                    else:
                        lapsLog.set(sectionName, "Lap {0}".format(index+1), timeToString(self.laps[index]))
                    lapsLog.set(sectionName, "Lap {0} player".format(index+1), self.lapsPlayer[index])

                if reference != "best":
                    lapsLog.set(sectionName, reference.title(), timeToString(self.referenceTime))

                if self.bestLapTimeSessionInvalid:
                    lapsLog.set(sectionName, "Best", timeToString(self.bestLapTimeSession) + " †")
                else:
                    lapsLog.set(sectionName, "Best", timeToString(self.bestLapTimeSession))
                lapsLog.set(sectionName, "Best player", self.bestLapPlayer)

                lapsLog.set(sectionName, "Total", timeToString(self.total))

                lapsLogFile = open(fileName, "w")
                lapsLog.write(lapsLogFile)
                lapsLogFile.close()

        except:
            ac.log("MultiLaps class: Error in writeSession: " + traceback.format_exc())

    def readBestLap(self):
        try:
            global bestLapFile, logBest
            ### return
            if logBest == "always":
                configBestLap = configparser.ConfigParser()
                # ac.log(bestLapFile)
                if os.path.exists(bestLapFile):
                    configBestLap.read(bestLapFile, encoding='utf-8')
                    self.bestLapTime = configBestLap.get("TIME", "best")
                    # ac.log('multilap best: '  + str(self.bestLapTime))
                    if "†" in str(self.bestLapTime):
                        self.bestLapTimeSessionInvalid = True
                        self.bestLapTime = int( str(self.bestLapTime).partition("†")[0] )
                    else:
                        self.bestLapTimeSessionInvalid = False
                        self.bestLapTime = int(self.bestLapTime)

                    self.bestLapData = eval(configBestLap.get("DATA", "data"))
                    self.referenceTime = self.bestLapTime
                else:
                    #ac.log('no multilap best!')
                    self.bestLapTime = 0
                    self.bestLapData = []
                    self.referenceTime = 0

        except:
            ac.log("MultiLaps class: Error in writeBestLap: "  + traceback.format_exc())

    def resetBestLap(self):
        try:
            self.bestLapTime = 0
            self.bestLapData = []
            if os.path.exists(bestLapFile):
                os.remove(bestLapFile)
        except:
            ac.log("MultiLaps class: Error in resetBestLap: " + traceback.format_exc())


    def writeBestLap(self):
        global bestLapFile, logBest
        try:
            # ac.log('saving ' + str(self.bestLapTime) + '  ' + logBest + '  ' + str(self.bestLapData))
            if logBest == "always" and self.bestLapTime and len(self.bestLapData) > 0:
                # ac.log('saving ' + str(self.bestLapTime) + '  ' + logBest + '  ' + str(self.bestLapData))
                configBestLap = configparser.ConfigParser()
                if os.path.isfile(bestLapFile):
                    configBestLap.read(bestLapFile, encoding='utf-8')
                    s = configBestLap.get("TIME", "best")
                    if "†" in s:
                        lastBest = int( str(s).partition("†")[0] )
                    else:
                        lastBest = int( s )
                    if lastBest != 0 and lastBest < self.bestLapTime:
                        return
                else:
                    configBestLap.add_section("TIME")
                    configBestLap.add_section("DATA")

                configBestLap.set("TIME", "best", str(self.bestLapTime))
                configBestLap.set("TIME", "player", str(self.bestLapPlayer))
                configBestLap.set("DATA", "data", str(self.bestLapData))

                fd = open(bestLapFile, "w")
                configBestLap.write(fd)
                fd.close()

        except:
            ac.log("MultiLaps class: Error in writeBestLap: " + traceback.format_exc())

'''
Show header:        Yes           Change
Font size:          18            + -
Opacity:            50 %          + -
Show border:        Yes           Change
Lap count:          6             + -
Show delta:         Yes           Change
Delta color:        White         Change
Red at:             +0.5 s        + -
Green at:           -0.5 s        - +
Show Estimate:      Yes           Change
Reference:          Median        Change
Show ref.:          Yes           Change
Show total:         Yes           Change
Refresh every:      0.1 s         + -
Log sessions:       Yes           Change
Remember best:      Always        Change
Best lap:           1:52.123      Reset
Lock best:          Locked        Lock/Unlock
Show Only on S/F    Yes           Change
Font: name                        + -
'''
class MultiLaps_config:

    def __init__(self, name, headerName, fontSize, showHeader):
        self.headerName = headerName
        self.window = ac.newApp(name)
        if showHeader == 1:
            ac.setTitle(self.window, "")
            ac.setIconPosition(self.window, -10000, -10000)
            self.firstSpacing = 0
        else:
            ac.setTitle(self.window, headerName)
            self.firstSpacing = firstSpacing

        self.fontSize = fontSize

        widthLeft       = fontSize*8
        widthCenter     = fontSize*5
        widthRight      = fontSize*5
        self.width      = widthLeft + widthCenter + widthRight + 2*spacing
        height          = self.firstSpacing + (fontSize*1.5 + spacing)*23.5

        ac.setSize(self.window, self.width, height)

        self.leftLabel = []
        self.centerLabel = []
        self.changeButton = []
        self.plusButton = []
        self.minusButton = []

        ### adjust range!!! important for new options
        for index in range(24):
            self.leftLabel.append(ac.addLabel(self.window, ""))
            ac.setFontSize(self.leftLabel[index], fontSize)
            ac.setPosition(self.leftLabel[index], spacing, self.firstSpacing + index*(fontSize*1.5+spacing))
            ac.setSize(self.leftLabel[index], widthLeft, fontSize+spacing)
            ac.setFontAlignment(self.leftLabel[index], 'left')

            self.centerLabel.append(ac.addLabel(self.window, ""))
            ac.setFontSize(self.centerLabel[index], fontSize)
            ac.setPosition(self.centerLabel[index], spacing + widthLeft, self.firstSpacing + index*(fontSize*1.5+spacing))
            ac.setSize(self.centerLabel[index], widthCenter, fontSize+spacing)
            ac.setFontAlignment(self.centerLabel[index], 'left')

            self.changeButton.append(ac.addButton(self.window, "Change"))
            ac.setFontSize(self.changeButton[index], self.fontSize)
            ac.setPosition(self.changeButton[index], spacing + widthLeft + widthCenter, self.firstSpacing + index*(fontSize*1.5+spacing))
            ac.setSize(self.changeButton[index], fontSize*4, fontSize*1.5)

            self.plusButton.append(ac.addButton(self.window, "+"))
            ac.setFontSize(self.plusButton[index], self.fontSize)
            ac.setPosition(self.plusButton[index], spacing + widthLeft + widthCenter, self.firstSpacing + index*(fontSize*1.5+spacing))
            ac.setSize(self.plusButton[index], fontSize*1.5, fontSize*1.5)

            self.minusButton.append(ac.addButton(self.window, "-"))
            ac.setFontSize(self.minusButton[index], self.fontSize)
            ac.setPosition(self.minusButton[index], spacing + widthLeft + widthCenter + fontSize*2.5, self.firstSpacing + index*(fontSize*1.5+spacing))
            ac.setSize(self.minusButton[index], fontSize*1.5, fontSize*1.5)

        # font different
        ac.setPosition(self.centerLabel[23-1], spacing + widthLeft/3, self.firstSpacing + index*(fontSize*1.5+spacing))
        ac.setFontSize(self.centerLabel[23-1], fontSize-2)

        rowIndex = 0

        ac.setText(self.leftLabel[rowIndex], "Show header:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleHeader)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showHeaderId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Font size:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], fontSizePlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], fontSizeMinus)
        self.fontSizeId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Opacity:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], opacityPlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], opacityMinus)
        self.opacityId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Show border:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleBorder)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showBorderId = rowIndex

        rowIndex += 1

        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Lap count:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], lapCountPlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], lapCountMinus)
        self.lapCountId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Show delta:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleDelta)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showDeltaId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Delta color:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleColor)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.deltaColorId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Red at:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], redAtPlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], redAtMinus)
        self.redAtId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Green at:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], greenAtPlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], greenAtMinus)
        self.greenAtId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Show estimate:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleCurrent)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showCurrentId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Reference:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleRefSource)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.referenceId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Show ref.:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleRef)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showReferenceId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Show total:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleTotal)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showTotalId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Show Who:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleWho)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.showWhoId = rowIndex

        rowIndex += 1

        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Refresh every:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], refreshPlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], refreshMinus)
        self.refreshId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Log sessions:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleLogLaps)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.logLapsId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Remember best:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleLogBest)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.logBestId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Best lap:")
        ac.addOnClickedListener(self.changeButton[rowIndex], resetBestLap)
        ac.setText(self.changeButton[rowIndex], "Reset")
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.resetBestLapId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Lock best:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleLockBest)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.lockBestId = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Only on S/F:")
        ac.addOnClickedListener(self.changeButton[rowIndex], toggleOnlyOnSF)
        ac.setVisible(self.plusButton[rowIndex], 0)
        ac.setVisible(self.minusButton[rowIndex], 0)
        self.onlyonsf = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "For seconds:")
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], ShowTimePlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], ShowTimeMinus)
        self.showtime = rowIndex

        rowIndex += 1

        ac.setText(self.leftLabel[rowIndex], "Font:")
        #ac.addOnClickedListener(self.changeButton[rowIndex], toggleFontPlus)
        #ac.setVisible(self.plusButton[rowIndex], 0)
        #ac.setVisible(self.minusButton[rowIndex], 0)
        ac.setVisible(self.changeButton[rowIndex], 0)
        ac.addOnClickedListener(self.plusButton[rowIndex], toggleFontPlus)
        ac.addOnClickedListener(self.minusButton[rowIndex], toggleFontMinus)
        self.fontname = rowIndex


    def updateView(self):
        ac.setText(self.centerLabel[self.showHeaderId], yesOrNo(showHeader))
        ac.setText(self.centerLabel[self.fontSizeId],   str(fontSize))
        ac.setText(self.centerLabel[self.opacityId],   "{0} %".format(opacity))
        ac.setText(self.centerLabel[self.showBorderId], yesOrNo(showBorder))
        ac.setText(self.centerLabel[self.lapCountId],   str(lapDisplayedCount))
        ac.setText(self.centerLabel[self.showDeltaId],  yesOrNo(showDelta))
        ac.setText(self.centerLabel[self.deltaColorId], deltaColor.title())
        if redAt and self.centerLabel[self.redAtId]:
            ac.setText(self.centerLabel[self.redAtId],      "{:+.1f} s".format(float(redAt)/1000))
        if greenAt and self.centerLabel[self.greenAtId]:
            ac.setText(self.centerLabel[self.greenAtId],    "{:+.1f} s".format(float(greenAt)/1000))
        ac.setText(self.centerLabel[self.showCurrentId], yesOrNo(showCurrent))

        if reference == "best":
            ac.setText(self.centerLabel[self.referenceId], "Best lap")
        elif reference == "median":
            ac.setText(self.centerLabel[self.referenceId], "Median")
        elif reference == "top25":
            ac.setText(self.centerLabel[self.referenceId], "Top 25%")
        elif reference == "top50":
            ac.setText(self.centerLabel[self.referenceId], "Top 50%")
        elif reference == "top75":
            ac.setText(self.centerLabel[self.referenceId], "Top 75%")

        ac.setText(self.centerLabel[self.showReferenceId], yesOrNo(showReference))
        ac.setText(self.centerLabel[self.showTotalId], yesOrNo(showTotal))
        ac.setText(self.centerLabel[self.showWhoId], yesOrNo(showWho))

        if updateTime == 0:
            ac.setText(self.centerLabel[self.refreshId], "Min")
        elif updateTime == 50:
            ac.setText(self.centerLabel[self.refreshId], "0.05 s")
        else:
            ac.setText(self.centerLabel[self.refreshId], "{:.1f} s".format(float(updateTime)/1000))

        ac.setText(self.centerLabel[self.logLapsId], yesOrNo(logLaps))
        ac.setText(self.centerLabel[self.logBestId], logBest.title())
        ac.setText(self.centerLabel[self.resetBestLapId], timeToString(multiLapsApp.bestLapTime))
        ac.setText(self.centerLabel[self.onlyonsf] , yesOrNo(ShowWhenCrossingSF))
        ac.setText(self.centerLabel[self.showtime] , str(ShowTime))

        ac.setText(self.centerLabel[self.fontname] , '"' + customFont + '"')
        ac.setText(self.leftLabel[len(self.leftLabel)-1], "Font:\n                                                  " + str(customFonts.index(customFont)+1) + "/" + str(len(customFonts)))

        if lockBest:
            ac.setText(self.centerLabel[self.lockBestId], "Locked")
        else:
            ac.setText(self.centerLabel[self.lockBestId], "Unlocked")

def toggleFontPlus(d, v):
    global customFonts, customFont
    if customFont in customFonts:
        id = customFonts.index(customFont) + 1
        if id >= len(customFonts) or id<0: id = 0
        customFont = customFonts[id]
    else:
        customFont = customFonts[0]
    refreshAndWriteParameters()

def toggleFontMinus(d, v):
    global customFonts, customFont
    if customFont in customFonts:
        id = customFonts.index(customFont) - 1
        if id < 0: id = len(customFonts)-1
        customFont = customFonts[id]
    else:
        customFont = customFonts[0]
    refreshAndWriteParameters()

def toggleOnlyOnSF(dummy, var):
    global ShowWhenCrossingSF, ShowTimerON, ShowTimer, ShowTime
    if ShowWhenCrossingSF:
        ShowWhenCrossingSF = 0
    else:
        ShowWhenCrossingSF = 1
        ShowTimerON = True
        ShowTimer = ShowTime
    refreshAndWriteParameters()

def toggleHeader(dummy, variable):
    global showHeader

    if showHeader:
        showHeader = 0
    else:
        showHeader = 1

    refreshAndWriteParameters()

def ShowTimeMinus(dummy, variable):
    global ShowTime
    if ShowTime > 2:
        ShowTime -= 1
    refreshAndWriteParameters()
def ShowTimePlus(dummy, variable):
    global ShowTime
    if ShowTime < 15:
        ShowTime += 1
    refreshAndWriteParameters()

def fontSizePlus(dummy, variable):
    global fontSize
    fontSize += 1
    refreshAndWriteParameters()
def fontSizeMinus(dummy, variable):
    global fontSize
    if fontSize > 6:
        fontSize -= 1
    refreshAndWriteParameters()

def opacityPlus(dummy, variable):
    global opacity

    if opacity < 100:
        opacity += 10

    refreshAndWriteParameters()

def opacityMinus(dummy, variable):
    global opacity

    if opacity >= 10:
        opacity -= 10

    refreshAndWriteParameters()

def toggleBorder(dummy, variable):
    global showBorder

    if showBorder:
        showBorder = 0
    else:
        showBorder = 1

    refreshAndWriteParameters()

def lapCountPlus(dummy, variable):
    global lapDisplayedCount

    if lapDisplayedCount < lapLabelCount+3:
        lapDisplayedCount += 1

    refreshAndWriteParameters()

def lapCountMinus(dummy, variable):
    global lapDisplayedCount

    if lapDisplayedCount > 0:
        lapDisplayedCount -= 1

    refreshAndWriteParameters()

def toggleDelta(dummy, variable):
    global showDelta
    if showDelta:
        showDelta = 0
    else:
        showDelta = 1

    refreshAndWriteParameters()

def toggleColor(dummy, variable):
    global deltaColor
    if deltaColor == "yellow":
        deltaColor = "white"
    elif deltaColor == "white":
        deltaColor = "yellow"

    refreshAndWriteParameters()

def redAtPlus(dummy, variable):
    global redAt

    if redAt < 1000:
        redAt += 100
    elif redAt < 2000:
        redAt += 200
    elif redAt < 10000:
        redAt += 1000

    refreshAndWriteParameters()

def redAtMinus(dummy, variable):
    global redAt

    if redAt > 2000:
        redAt -= 1000
    elif redAt > 1000:
        redAt -= 200
    elif redAt > 0:
        redAt -= 100

    refreshAndWriteParameters()

def greenAtPlus(dummy, variable):
    global greenAt

    if greenAt < -2000:
        greenAt += 1000
    elif greenAt < -1000:
        greenAt += 200
    elif greenAt < 0:
        greenAt += 100

    refreshAndWriteParameters()

def greenAtMinus(dummy, variable):
    global greenAt

    if greenAt > -1000:
        greenAt -= 100
    elif greenAt > -2000:
        greenAt -= 200
    elif greenAt > -10000:
        greenAt -= 1000

    refreshAndWriteParameters()

def toggleRefSource(dummy, variable):
    global reference
    if reference == "best":
        reference = "median"
    elif reference == "median":
        reference = "top25"
    elif reference == "top25":
        reference = "top50"
    elif reference == "top50":
        reference = "top75"
    elif reference == "top75":
        reference = "best"
    refreshAndWriteParameters()

def toggleCurrent(dummy, variable):
    global showCurrent
    if showCurrent:
        showCurrent = 0
    else:
        showCurrent = 1
    refreshAndWriteParameters()

def toggleTotal(dummy, variable):
    global showTotal
    if showTotal:
        showTotal = 0
    else:
        showTotal = 1
    refreshAndWriteParameters()

def toggleWho(dummy, variable):
    global showWho
    if showWho:
        showWho = 0
    else:
        showWho = 1
    refreshAndWriteParameters()

def toggleRef(dummy, variable):
    global showReference

    if showReference:
        showReference = 0
    else:
        showReference = 1
    refreshAndWriteParameters()

def refreshPlus(dummy, variable):
    global updateTime
    if updateTime == 0:
        updateTime = 50
    elif updateTime == 50:
        updateTime = 100
    elif updateTime < 200:
        updateTime += 100
    else:
        updateTime = 200
    refreshAndWriteParameters()

def refreshMinus(dummy, variable):
    global updateTime
    if updateTime == 50:
        updateTime = 0
    elif updateTime == 100:
        updateTime = 50
    elif updateTime > 100:
        updateTime -= 100
    else:
        updateTime = 0
    refreshAndWriteParameters()

def toggleLogLaps(dummy, variable):
    global logLaps

    if logLaps:
        logLaps = 0
    else:
        logLaps = 1

    refreshAndWriteParameters()

def toggleLogBest(dummy, variable):
    global logBest
    if logBest == "always":
        logBest = "sessions"
    elif logBest == "sessions":
        logBest = "never"
    elif logBest == "never":
        logBest = "always"

    refreshAndWriteParameters()

def toggleLockBest(dummy, variable):
    global lockBest
    if lockBest:
        lockBest = 0
    else:
        lockBest = 1

    refreshAndWriteParameters()

def resetBestLap(dummy, variable):
    multiLapsApp.resetBestLap()
    refreshAndWriteParameters()

def setDeltaColor(label, delta, skipText=False):
    if not skipText:
        ac.setText(label, deltaToString(delta))
    if delta == 0:
        if deltaColor == "yellow":
            # ac.setFontColor(label, 1, 1, 0.05, 1)
            ac.setFontColor(label, 0.05, 1, 0.05, 1)
        else:
            ac.setFontColor(label, 1, 1, 1, 1)
    elif delta >= redAt:
        ac.setFontColor(label, 1, 0, 0, 1)
    elif delta <= greenAt:
        ac.setFontColor(label, 0, 1, 0, 1)
    else:
        if deltaColor == "yellow":
            if delta > 0:
                # color factor [0..1]
                colorFactor = float(delta)/redAt*0.666
                ac.setFontColor(label, 1, 1-colorFactor, 0, 1)
            else:
                # color factor [0..1]
                colorFactor = float(delta)/greenAt*0.666
                ac.setFontColor(label, 1-colorFactor, 1, 0, 1)

        elif deltaColor == "white":
            if delta > 0:
                # color factor [0..1]
                colorFactor = float(delta)/redAt*0.666
                ac.setFontColor(label, 1, 1-colorFactor, -colorFactor, 1)
            else:
                # color factor [0..1]
                colorFactor = float(delta)/greenAt*0.666
                ac.setFontColor(label, 1-colorFactor, 1, 1-colorFactor, 1)



def updateTrackParams():
    global trackName, trackConf, carName, bestLapFile, nurbTourist, trackLength_int, acpath
    carName = ac.getCarName(0)
    trackName = ac.getTrackName(0)
    trackConf = ac.getTrackConfiguration(0)
    # ac.log(trackConf)
    if trackConf == "":
        bestLapFile = acpath + "apps/python/MultiLaps/MultiLaps_bestlap/{0} - {1}.ini".format(
            trackName, carName)
        trackInfoPath = acpath + "content/tracks/%s/ui/ui_track.json" %trackName
    else:
        bestLapFile = acpath + "apps/python/MultiLaps/MultiLaps_bestlap/{0} [{1}] - {2}.ini".format(
            trackName, trackConf, carName)
        trackInfoPath = acpath + "content/tracks/%s/ui/%s/ui_track.json" %(trackName, trackConf)
    if trackName == "ks_nordschleife" and trackConf == "touristenfahrten":
        nurbTourist = True
    trackLength_int = ac.getTrackLength()
    multiLapsApp.readBestLap()

def ReadMultiLapsRecords(*args):
    try:
        global bestLapFiles, trackName, trackConf, pblaptimes, pages, btn_laptimes2, ghosttime

        bestLapFiles     = "{0} - ".format(trackName.lower())
        if trackConf != "":
            bestLapFiles = "{0} [{1}] - ".format(trackName.lower(), trackConf.lower())

        pblaptimes = []

        ReadPersonalBests(userDir+"/Assetto Corsa/personalbest.ini")
        i=0
        for s in pblaptimes:
            if carName.lower() in carNamesShort:
                s = carNamesLong[carNamesShort.index(carName.lower())]
            if carName.lower() in s[0].lower():
                if multiLapsApp.bestLapTime>pblaptimes[i][2]:
                    # pblaptimes[i][2]=multiLapsApp.bestLapTime
                    multiLapsApp.bestLapTime=pblaptimes[i][2]
                    multiLapsApp.bestLapPlayer=pblaptimes[i][3]
                    if multiLapsApp.lapInvalidated:
                        pblaptimes[i][0] = pblaptimes[i][0] + " †"
                    break
            i+=1

        ghostfile = str(userDir) + "/Assetto Corsa/GhostCar/"
        ## username="leBluem"
        username = ReadUserName()
        if trackConf=='':
            ghostfile = ghostfile + trackName + "/GHOST_CAR_"+username+"_" + carName + ".ghost"
        else:
            ghostfile = ghostfile + trackName + "/GHOST_CAR_"+username+"_" + carName + "_" + trackConf + ".ghost"

        ghosttime = ReadGhost(ghostfile)
        if ghosttime>0:
            ## pblaptimes.append(ghosttime)
            pblaptimes.append(["==>   ghost "+ carName, ghosttime, -1, "ghost__"])
            # pblaptimes.append(["==>   ghost ", ghosttime, -1])
        else:
            pblaptimes.append(["- no ghost for " + carName, -1, -1, "ghost__"])

        global sortid
        pblaptimes = sorted(pblaptimes, key=operator.itemgetter(1))
        if sortid==1:
            sortid=2
        else:
            sortid=1

        findBestsThisTrack(acpath + "apps/python/MultiLaps/MultiLaps_bestlap/", bestLapFiles, '.ini')
        # pblaptimes = sorted(pblaptimes, key=operator.itemgetter(1))

        if __name__ != '__main__':
            pages = int (len(pblaptimes) / 16)
            UpdateLaptimes()
            multiLapsApp.refreshParameters()

    except:
        if __name__ == '__main__':
            print("MultiLaps: Error " + traceback.format_exc())
        else:
            ac.log("MultiLaps: Error " + traceback.format_exc())


def comp_func(s1,s2):
    global sortid
    if s1[sortid]<=0:
        return 1
    if s2[sortid]<=0:
        return 1
    return (1 if s1[sortid] > s2[sortid] else -1)


def UpdateLaptimes():
    global page, pages, pblaptimes, lbLaptimes, btnLapsDn, sortid
    res = "best times       offic. AC  Multilaps\n"
    pblaptimes = sorted(pblaptimes, key=operator.itemgetter(sortid), )
    #pblaptimes = sorted(pblaptimes, key=functools.cmp_to_key(comp_func, ))
    ### config._sections = collections.OrderedDict( sorted(config._sections.items(), key=functools.cmp_to_key(comp_func)) )
    ##ac.log("sortidsortidsortidsortid   " + str(sortid))
    pages = int (len(pblaptimes) / 16)

    i=1
    for s in pblaptimes:
        if (i>page*16 and i<(page+1)*16+1):
            res += s[0] + "   " + timeToString(s[1]) + "   " + timeToString(s[2]) + "   " + s[3] + '\n'
            #res += s[0] +'\n'
        i+=1
    if __name__ == '__main__':
        print(res)
    else:
        ac.setText(lbLaptimes, res)
        ac.setText(btnLapsDn, "v\n\n" + str(page+1) + '/' + str(pages+1))



def ReadGhost(file):
    if not os.path.isfile(file):
        ac.log('no ghostfile found: ' + file)
        return 0

    with open(file, "rb") as buffer:
        header, sig, len1 = struct.unpack("3i", buffer.read(4 * 3))
        # username = struct.unpack('{}s'.format(len1), buffer.read(len1))
        len1 = len1 + 12

        buffer.seek(len1)
        len2 = struct.unpack("1i", buffer.read(4))
        # trackname = struct.unpack('{}s'.format(len2), buffer.read(len2))

        buffer.seek(len1 + len2[0] + 4)
        len3 = struct.unpack("1i", buffer.read(4))
        # tracksubname = struct.unpack('{}s'.format(len3), buffer.read(len3))

        buffer.seek(len1 + len2[0] + 4 + len3[0] + 4)
        len4 = struct.unpack("1i", buffer.read(4))

        buffer.seek(len1 + len2[0] + 4 + len3[0] + 4 + len4[0] + 4)
        pb = struct.unpack("1i", buffer.read(4))

        if __name__ == '__main__':
            print( "                    Ghostcar:        " + timeToString(pb[0]) )
        else:
            ac.log("                    Ghostcar:        " + timeToString(pb[0]) )

        # parts = struct.unpack("1i", buffer.read(4))
        # print(     "                       parts:        " + str( parts[0] ))

        # float4 x4 body;
        # float4 x4 wheels[4];
        # float4 x4 suspensions[4];
        # print("                       bytes:        " + str(
        #     parts[0]*(4+4*4+4*4)*4*4 +
        #     ((namelen + namelen2[0] + 4 + namelen3[0] + 4 + namelen4[0] + 4) +4+4)
        # ) )

        return pb[0]
    return 0











def acMain(ac_version):
    try:
        global multiLapsApp, configApp, config
        global showHeader, fontSize, opacity, showBorder
        global lapDisplayedCount, showDelta, deltaColor, redAt, greenAt
        global reference, showCurrent, showReference, showTotal, showWho
        global updateTime, logLaps, logBest, lockBest
        global trackName, trackConf, carName, bestLapFile
        global nurbTourist, customFont, customFonts, ShowWhenCrossingSF, ShowTime, btn_options
        global laptimesApp, lbLaptimes, btnLapsUp, btnLapsDn, btn_laptimes, btn_laptimes2
        global playerid, players, btn_toggleplayer

        if ac_version < 1.0:
            return "MultiLaps"

        multiLapsApp = MultiLaps("MultiLaps", "Laps")
        multiLapsApp.refreshParameters()

        configApp = MultiLaps_config("MultiLaps_config", "MultiLaps Settings", fontSizeConfig, 0)

        laptimesApp = ac.newApp("MultiLaps_laptimes")
        lbLaptimes = ac.addLabel(laptimesApp, "")
        btnLapsUp = ac.addButton(laptimesApp, "^")
        btnLapsDn = ac.addButton(laptimesApp, "v")
        ac.setFontAlignment(lbLaptimes,'right')
        ac.addOnClickedListener(btnLapsUp, onbtnLapsUp)
        ac.addOnClickedListener(btnLapsDn, onbtnLapsDn)

        customFonts = []
        # customFonts.append("Segoe UI")
        # customFonts.append("Futura Hv BT Heavy")
        # customFonts.append("Futura Hv BT Heavy Italic")

        # customFonts.append("Segoe UI Bold")
        # customFonts.append("Arial")
        # customFonts.append("arial_big")
        # customFonts.append("Futura BdCn BT")
        # customFonts.append("Futura BdCn BT Bold")

        findFonts('content\\fonts\\', ".ttf", customFonts)
        # customFonts.append("Futura BdCn BT")
        # customFonts.append("Futura BdCn BT Bold")
        # customFonts.append("Futura Condensed BT")
        # findFonts('p:\\Steam\\steamapps\\common\\assettocorsa\\content\\fonts\\', ".ttf", fontnames)
        # findFonts('c:\\windows\\fonts\\', ".ttf", fontnames)
        # print(customFonts)

        # customFonts.append("Futura BdCn BT")
        # customFonts.append("Futura Md BT")
        # customFonts.append("Futura Bk BT")
        # customFonts.append("Futura Bk BT")
        # customFonts.append("Futura XBlk BT")


        for i in range(len(customFonts)):
            ac.initFont(0, customFonts[i], 0, 0)

        configdef = configparser.ConfigParser()
        configdef.optionxform = str
        configdef.read("apps/python/MultiLaps/settings/settings_defaults.ini")

        config = configparser.ConfigParser()
        config.optionxform = str
        config.read("apps/python/MultiLaps/settings/settings.ini")

        customFont          =            getSetting(configdef, config, "SETTINGS", "fontName", customFont)
        if not customFont in customFonts:
            customFont = "Segoe UI"

        showHeader          = int(       getSetting(configdef, config, "SETTINGS", "showHeader", showHeader))
        fontSize            = int(       getSetting(configdef, config, "SETTINGS", "fontSize", fontSize))
        opacity             = int(       getSetting(configdef, config, "SETTINGS", "opacity", opacity))
        showBorder          = int(       getSetting(configdef, config, "SETTINGS", "showBorder", showBorder))
        lapDisplayedCount   = int(       getSetting(configdef, config, "SETTINGS", "lapDisplayedCount", lapDisplayedCount))
        showDelta           = int(       getSetting(configdef, config, "SETTINGS", "showDelta", showDelta))
        deltaColor          =            getSetting(configdef, config, "SETTINGS", "deltaColor", deltaColor)
        redAt               =float(      getSetting(configdef, config, "SETTINGS", "redAt", redAt))
        greenAt             =float(      getSetting(configdef, config, "SETTINGS", "greenAt", greenAt))
        reference           =            getSetting(configdef, config, "SETTINGS", "reference", reference)
        showCurrent         = int(       getSetting(configdef, config, "SETTINGS", "showCurrent", showCurrent))
        showTotal           = int(       getSetting(configdef, config, "SETTINGS", "showTotal", showTotal))
        showWho             = int(       getSetting(configdef, config, "SETTINGS", "showWho", showWho))
        showReference       = int(       getSetting(configdef, config, "SETTINGS", "showReference", showReference))
        updateTime          = int(       getSetting(configdef, config, "SETTINGS", "updateTime", updateTime))
        logLaps             = int(       getSetting(configdef, config, "SETTINGS", "logLaps", logLaps))
        logBest             = str(       getSetting(configdef, config, "SETTINGS", "logBest", logBest))
        lockBest            = int(       getSetting(configdef, config, "SETTINGS", "lockBest", lockBest))
        ShowWhenCrossingSF  = int(       getSetting(configdef, config, "SETTINGS", "onlyOnSF", ShowWhenCrossingSF))
        ShowTime            = int(float( getSetting(configdef, config, "SETTINGS", "forSeconds", ShowTime)))

        config = configdef # will be used to save

        updateTrackParams()
        ## ReadPersonalBests(userDir+"/Assetto Corsa/personalbest.ini")

        ac.setTitle(laptimesApp, "MultiLaps other Cars Laptimes\n" + trackName + "   " + trackConf)

        btn_options = ac.addButton(multiLapsApp.window, "settings")
        btn_laptimes = ac.addButton(multiLapsApp.window, "laptimes")
        btn_toggleplayer = ac.addButton(multiLapsApp.window, players[playerid])
        btn_laptimes2 = ac.addButton(laptimesApp, "Sort")

        ac.setVisible(btn_options, 0)
        ac.setVisible(btn_laptimes, 0)
        ac.setVisible(btn_toggleplayer, 0)

        ac.setPosition(btn_options     ,  30, -35)
        ac.setPosition(btn_laptimes    , 130, -35)
        ac.setPosition(btn_laptimes2   , 480,   0)
        ac.setSize(btn_laptimes        ,  80,  30)
        ac.setSize(btn_laptimes2       , 120,  41)
        ac.setSize(btn_options         ,  80,  30)

        ac.setPosition(btn_toggleplayer, -60, -35)
        ac.setSize(btn_toggleplayer    ,  80,  30)

        multiLapsApp.refreshParameters()
        configApp.updateView()
        ReadMultiLapsRecords()

        ac.addOnClickedListener(btn_options, onClickOptions)
        ac.addOnClickedListener(btn_laptimes2, ReadMultiLapsRecords)
        ac.addOnClickedListener(btn_laptimes, onClickLaptimes)
        # ac.addRenderCallback(multiLapsApp.window, onRenderCallback)
        ac.addOnClickedListener(multiLapsApp.window, onClickWindow)
        # ac.addOnClickedListener(configApp.window, onClickWindow)

        ac.addOnClickedListener(btn_toggleplayer, onTogglePlayer)

        return "MultiLaps"
    except:
        ac.log("MultiLaps: Error " + traceback.format_exc())

def onClickOptions(*args):
    global btn_options, hidetimer, btn_laptimes
    global playerid, players, btn_toggleplayer
    ac.setVisible(btn_options, 0)
    ac.setVisible(btn_laptimes, 0)
    ac.setVisible(btn_toggleplayer, 0)
    ac.setVisible(configApp.window, 1)
    hidetimer=5

def onClickLaptimes(*args):
    global btn_options, hidetimer, btn_laptimes
    global playerid, players, btn_toggleplayer
    ac.setVisible(btn_options, 0)
    ac.setVisible(btn_toggleplayer, 0)
    ac.setVisible(btn_laptimes, 0)
    ac.setVisible(laptimesApp, 1)
    hidetimer=5


def onClickWindow(*args):
    global ShowTimerON, ShowTimer
    ShowTimerON = False
    ShowTimer = 0.0

    global btn_options, hidetimer, btn_laptimes
    global playerid, players, btn_toggleplayer

    hidetimer=5.0
    # hidetimer=0.0
    ac.setVisible(btn_options, 1)
    ac.setVisible(btn_toggleplayer, 1)
    ac.setVisible(btn_laptimes, 1)
    ac.setText(btn_toggleplayer, players[playerid])

def onTogglePlayer(*args):
    global playerid, players, btn_toggleplayer
    global hidetimer
    playerid = playerid+1
    if playerid>=len(players):
        playerid = 0
    ac.setText(btn_toggleplayer, players[playerid])
    hidetimer=5.0

def acShutdown():
    try:
        if info.graphics.status != 1:
            multiLapsApp.writeSession()
            multiLapsApp.writeBestLap()
    except:
        ac.log("MultiLaps: Error " + traceback.format_exc())

def writeParameters():
    try:
        config.set("SETTINGS", "showHeader", str(showHeader))
        config.set("SETTINGS", "fontSize", str(fontSize))
        config.set("SETTINGS", "opacity", str(opacity))
        config.set("SETTINGS", "showBorder", str(showBorder))
        config.set("SETTINGS", "lapDisplayedCount", str(lapDisplayedCount))
        config.set("SETTINGS", "showDelta", str(showDelta))
        config.set("SETTINGS", "deltaColor", str(deltaColor))
        config.set("SETTINGS", "redAt", str(redAt))
        config.set("SETTINGS", "greenAt", str(greenAt))
        config.set("SETTINGS", "reference", str(reference))
        config.set("SETTINGS", "showCurrent", str(showCurrent))
        config.set("SETTINGS", "showTotal", str(showTotal))
        config.set("SETTINGS", "showWho", str(showWho))
        config.set("SETTINGS", "showReference", str(showReference))
        config.set("SETTINGS", "updateTime",  str(updateTime))
        config.set("SETTINGS", "logLaps",  str(logLaps))
        config.set("SETTINGS", "logBest",  str(logBest))
        config.set("SETTINGS", "lockBest",  str(lockBest))
        config.set("SETTINGS", "fontName",  str(customFont))
        config.set("SETTINGS", "onlyOnSF",  str(ShowWhenCrossingSF))
        config.set("SETTINGS", "forSeconds",  str(ShowTime))
        configFile = open("apps/python/MultiLaps/settings/settings.ini", 'w')
        config.write(configFile)
        configFile.close()

    except:
        ac.log("MultiLaps: Error " + traceback.format_exc())

def refreshAndWriteParameters():
    try:
        global ShowTime, ShowTimer, ShowTimerON
        if ShowWhenCrossingSF:
            ShowTimer = 0.0
            ShowTimerON = False
        ac.setVisible(multiLapsApp.window, 1)
        multiLapsApp.refreshParameters()
        multiLapsApp.updateData()
        multiLapsApp.updateView()
        configApp.updateView()
        writeParameters()

    except:
        ac.log("MultiLaps: Error " + traceback.format_exc())

def acUpdate(deltaT):
    try:
        global multiLapsApp, lastUpdateTime, updateTime, ShowTimerON, ShowWhenCrossingSF, ShowTime, ShowTimer
        global trackName, last
        global btn_options, hidetimer, btn_laptimes
        global playerid, players, btn_toggleplayer

        # ac.setTitle(multiLapsApp.window, str(ac.isAIControlled(0)))
        # ac.setTitle(multiLapsApp.window, str(info.physics.isAIControlled))

        if hidetimer>0.0:
            hidetimer-=deltaT
            if hidetimer<=0.0:
                ac.setVisible(btn_options, 0)
                ac.setVisible(btn_laptimes, 0)
                ac.setVisible(btn_toggleplayer, 0)

        if ShowTimerON:
            ShowTimer -= deltaT
            if ShowTimer<0.0 and ShowWhenCrossingSF:
                ShowTimerON = False
                ac.setVisible(multiLapsApp.window, 0)

        lastUpdateTime += deltaT
        if lastUpdateTime < float(updateTime)/1000:
            return

        lastUpdateTime = 0
        # block refresh during replay

        #if self.lastLapViewRefreshed != self.lastLapDataRefreshed and info.graphics.status != 1:
        #    self.updateViewNewLap()

        if multiLapsApp and configApp and info.graphics.status != 1: ## and multiLapsApp.lastLapDataRefreshed != multiLapsApp.lapDone:
            multiLapsApp.updateData()
            multiLapsApp.updateView()
            configApp.updateView()

        ac.setBackgroundOpacity(laptimesApp, 0.5) ### float(opacity)/100)
        ac.setBackgroundOpacity(multiLapsApp.window, float(opacity)/100)
        ac.drawBorder(multiLapsApp.window, showBorder)
        ac.drawBorder(laptimesApp, showBorder)
    except:
        ac.log("MultiLaps: Error in acUpdate: " + traceback.format_exc())


# if __name__ == '__main__':
#     acpath = "p:/Steam/steamapps/common/assettocorsa/"
#     carName = "ac_legends_bmw_csl"
#     trackName = "rt_california_highway"
#     trackConf = "roamfree"
#     # carName = "bmw_z4_gt3"
#     # carName = "ks_mazda_mx5_cup"
#     # trackName = "ks_laguna_seca"
#     # trackConf = ""

# # "c:\Users\klausi\Documents\Assetto Corsa\GhostCar\rt_california_highway\GHOST_CAR_leBluem_ac_legends_bmw_csl_roamfree.ghost"

#     # trackName = "rt_azure_coast"
#     # trackConf = "reverse"
#     # trackName = "ks_nordschleife"
#     # trackConf = "nordschleife"
#     ### "†"
#     # ReadPersonalBests("c:/Users/klausi/Documents/Assetto Corsa/personalbest.ini")
#     # ReadMultiLapsRecords()
#     ##ReadGhost()

#     customFonts = []
#     # findFonts("p:\\Tools\\Fonts\\_schmuckNeu3\\", ".ttf", customFonts)
#     # findFonts('content\\fonts\\', ".ttf", customFonts)
#     #findFonts('p:\\Steam\\steamapps\\common\\assettocorsa\\content\\fonts\\', ".ttf", customFonts)
#     # findFonts('c:\\windows\\fonts\\', ".ttf", fontnames)
#     # print(customFonts)

#     # getTTFFontName("p:\\Tools\\Fonts\\_schmuckNeu3\\", "01 Digit.ttf", customFonts)
#     getTTFFontName("p:/Steam/steamapps/common/assettocorsa/content/fonts/", "Futura Bold font.ttf", customFonts)

#     # for i in range(len(customFonts)):
#     #     print(customFonts[i])
