﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.VisualBasic;

namespace kn5_converter
{
    class Program
    {

        private static string MakeRelative(string filePath, string referencePath)
        {
            if (filePath != "" && referencePath != "")
            {
                var fileUri = new Uri(filePath);
                var referenceUri = new Uri(referencePath);
                return referenceUri.MakeRelativeUri(fileUri).ToString().Replace('/', Path.DirectorySeparatorChar);
            }
            else
            {
                return "";
            }
        }

        private static string generate_key(string car_name)
        {
            int i = 0;
            int key1 = 0;
            while (i < car_name.Length)
            {
                key1 += Convert.ToInt32(car_name[i]);
                i += 1;
            }
            key1 &= 0xff;
            i = 0;
            var key2 = 0;
            while (i < car_name.Length - 1)
            {
                key2 *= Convert.ToInt32(car_name[i]);
                i += 1;
                key2 -= Convert.ToInt32(car_name[i]);
                i += 1;
                //ac.print(str(key2) + ' - '+str(type(key2)))
            }
            key2 &= 0xff;
            // ac.print(str(key2) + ' - '+str(type(key2)))
            i = 1;
            var key3 = 0;
            while (i < car_name.Length - 3)
            {
                key3 *= Convert.ToInt32(car_name[i]);
                i += 1;
                key3 = Convert.ToInt32(key3 / (Convert.ToInt32(car_name[i]) + 0x1b));
                i -= 2;
                key3 += -0x1b - Convert.ToInt32(car_name[i]);
                i += 4;
            }
            key3 &= 0xff;
            i = 1;
            var key4 = 0x1683;
            while (i < car_name.Length)
            {
                key4 -= Convert.ToInt32(car_name[i]);
                i += 1;
            }
            key4 &= 0xff;
            i = 1;
            var key5 = 0x42;
            while (i < car_name.Length - 4)
            {
                var tmp = (Convert.ToInt32(car_name[i]) + 0xf) * key5;
                i -= 1;
                key5 = (Convert.ToInt32(car_name[i]) + 0xf) * tmp + 0x16;
                i += 5;
            }
            key5 &= 0xff;
            i = 0;
            var key6 = 0x65;
            while (i < car_name.Length - 2)
            {
                key6 -= Convert.ToInt32(car_name[i]);
                i += 2;
            }
            key6 &= 0xff;
            i = 0;
            var key7 = 0xab;
            while (i < car_name.Length - 2)
            {
                key7 %= Convert.ToInt32(car_name[i]);
                i += 2;
            }
            key7 &= 0xff;
            i = 0;
            var key8 = 0xab;
            while (i < car_name.Length - 1)
            {
                key8 = Convert.ToInt32(key8 / Convert.ToInt32(car_name[i])) + Convert.ToInt32(car_name[i + 1]);
                i += 1;
            }
            key8 &= 0xff;
            return string.Format("{0}-{1}-{2}-{3}-{4}-{5}-{6}-{7}",key1, key2, key3, key4, key5, key6, key7, key8);
        }

        private static bool ACD_Extract(string path, string dirname)
        {
            string basedir = path.Replace("\\data.acd", "");
            string key = generate_key(dirname);
            Console.WriteLine("Loading " + dirname + "\\data.acd ...");
            Console.WriteLine("key: {0}", key);

            if (! Directory.Exists(basedir + "\\data\\"))
                Directory.CreateDirectory(basedir + "\\data\\");

            using (var stream = File.Open(path + "/data.acd", FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                if (stream.Length > 8)
                {
                    using (var reader = new BinaryReader(stream))   //, Encoding.UTF8
                    {
                        int fnameLen = 0;
                        int offset = 0;

                        fnameLen = reader.ReadInt32();
                        offset += 4;
                        //check version
                        if (fnameLen<0)
                        {
                            offset += 4;
                            fnameLen = reader.ReadInt32();
                        } else {
                            offset = 0;
                            stream.Seek(0,SeekOrigin.Begin);
                        }

                        while (offset < stream.Length && fnameLen > 0)
                        {
                            string fName = "";
                            int fLen = 0;
                            
                            fnameLen = reader.ReadInt32();
                            offset += fnameLen;

                            fName = new string(reader.ReadChars(fnameLen));
                            offset += 4;

                            fLen = reader.ReadInt32();

                            int[] packed_content = new int[fLen*4];
                            for (int i = 0; i < fLen; i++)
                            {
                                packed_content[i] = reader.ReadInt32();
                            }
                            offset += fLen*4;

                            byte[] decrypted_content =  new Byte[fLen*4];
                            for (int i=0; i < fLen; i++)
                            {
                                int code = Convert.ToByte( packed_content[i] ) - Convert.ToByte( key[i % key.Length] );
                                if (code<0)
                                    code = 256 + code;
                                decrypted_content[i] = Convert.ToByte(code);
                            }

                            Console.WriteLine(string.Format("{0,5} byte - {1,32}", fLen, fName));
                            using (var outstream = File.Open(basedir + "\\data\\" + fName, FileMode.Create))
                            {
                                using (var writer = new BinaryWriter(outstream))  //, 
                                {
                                    //writer.Write(Encoding.Default.GetBytes(decrypted_content));
                                    writer.Write(decrypted_content, 0, fLen);
                                }
                            }

                            offset += 4;
                        }
                    }
                } else
                {
                    Console.WriteLine("  empty acd-file");
                }
            }
            return true;
        }

        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            string path = "";
            string acdpath = "";
            switch (args.Length)
            {
                case 0:
                    path = AppDomain.CurrentDomain.BaseDirectory;
                    Console.WriteLine("Using current folder...");
                    break;
                case 1:
                    path = args[0];
                    break;
                default:
                    Console.WriteLine("Assetto Corsa " + "ACD_file.exe" + " acd-file/car-folder");
                    break;
            }

            if (path.ToLower().Contains("\\data.acd"))
            {
                
            } else {
                if (path[path.Length-1] != 92)
                {
                    path += "/";
                }
                acdpath = path + "data.acd";
            }
            

            
            if (File.Exists(acdpath))
            {
                // in case only dirname is given
                acdpath = Path.GetFullPath(acdpath); 
                string dirname = MakeRelative(acdpath, (Path.GetDirectoryName(acdpath))).Replace("\\data.acd", "");
                ACD_Extract(path, dirname);
                Console.WriteLine("Finished. Press any key to exit...");
                //Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Invalid input file/folder: {0}\n", path);
                Console.WriteLine("acd_file.exe" + " acd-file or car-folder");
            }
        }

    }
}
