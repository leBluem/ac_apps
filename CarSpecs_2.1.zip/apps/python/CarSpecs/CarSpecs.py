### --- extra torque feature --- control
joystickid        = 0
joystickbutton    = 3     # joystick button
keyboardbutton    = "E"   # some keyboard key

### --- extra torque feature --- time and amount
TorqueExtraAmount = 100 # Nm extra
extraHoldtime     = 2.0 # seconds, after half that time,
                        # extraT gets decreased to 0 (also in half that time)

'''
CarSpecs v2.1
https://www.racedepartment.com/downloads/carspecs.47760/
inspiration:
hp/to curve
https://www.youtube.com/watch?v=Nbev14oIH6I
slip angle
https://www.youtube.com/watch?v=MwrUz1WI5GY
'''

# read from ini
appSettingsPath        = 'apps/python/CarSpecs/settings/settings.ini'
appSettingsPathDefault = 'apps/python/CarSpecs/settings/settings_defaults.ini'


maxgforce = 6.0
updateTimerFast   = 0.01
peakholdtime      = 5.0
btn_peakholdtimeUp=0
btn_peakholdtimeDn=0
btn_resetmax=0

#DOAUTOLOADDIFFERENTCAR = False   ### disables loading on car change (Ctrl+NumPad 1/3)
DOAUTOLOADDIFFERENTCAR = True   ### enables  loading on car change (Ctrl+NumPad 1/3) ; doesnt work for all params though

dCurves      = [0.0]*(13+3)
dCurvesL     = [0.0]*(13+3)
dCurvesMaxes = [0.0]*(13+3)
dCurvesTimer = [0.0]*(13+3)
# 13 14 15 are g forces
dCurvesSubtract = [ # also 13 entries
  1,    # orange     - torque
  1,    # yellow     - power
  0.01,    # lightred   - turbo
  0.01,    # green      - gas
  0.01,    # red        - brake
  0.01,    # violett    - ffb
  0.01,    # blue       - grip
  0.01,    # grey       - steer
  0.01,    # aqua       - handbrake
  1,    # green      - ERScharge
  1,    # blue       - ERSinput
  1,    # yellow     - ERSused
  0.01,    # darkorange - clutch
  0.01,    # darkorange - clutch
  0.01,    # darkorange - clutch
  0.01,    # darkorange - clutch
]
colors = [ # also 13+3 entries
  [1.00, 0.60, 0.10],    # orange     - torque
  [1.00, 1.00, 0.00],    # yellow     - power
  [1.00, 0.60, 0.60],    # lightred   - turbo
  [0.25, 1.00, 0.25],    # green      - gas
  [1.00, 0.25, 0.25],    # red        - brake
  [1.00, 0.25, 1.00],    # violett    - ffb
  [0.25, 0.25, 1.00],    # blue       - grip
  [0.80, 0.80, 0.80],    # grey       - steer
  [0.00, 1.00, 1.00],    # aqua       - handbrake
  [0.50, 1.00, 0.50],    # green      - ERScharge
  [0.50, 0.75, 1.00],    # blue       - ERSinput
  [1.00, 1.00, 0.00],    # yellow     - ERSused
  [0.50, 0.20, 0.10],    # darkorange - clutch
  [1.00, 1.00, 0.10],    # x g-force yellow
  [1.00, 0.40, 0.40],    # y g-force red/green
  [0.50, 0.50, 1.00],    # z g-force bright blue
]


bSHOWINFO = False
bSHOW_ERS = True
KersCharge=0.0      # KersCharge                    = round( ac.getCarState(currcar, acsys.CS.KersCharge)*100, 1)
KersInput=0.0       # KersInput                     = round( ac.getCarState(currcar, acsys.CS.KersInput)*100, 2)
ERSCurrentKJ=0.0    # ERSCurrentKJ                  = round( ac.getCarState(currcar, acsys.CS.ERSCurrentKJ), 1)
ERSMaxJ=0.0         # ERSMaxJ                       = round( ac.getCarState(currcar, acsys.CS.ERSMaxJ)/100000, 1)
ERSlastKJ=0.0
ERStotalKJ=0.0

import sys, os, platform, io, traceback, re, math, codecs, json
from configparser import ConfigParser
if platform.architecture()[0] == '64bit':
    sys.path.insert(0, 'apps/python/CarSpecs/DLLs/stdlib64')
else:
    sys.path.insert(0, 'apps/python/CarSpecs/DLLs/stdlib')
os.environ['PATH'] = os.environ['PATH'] + ';.'
if __name__ == '__main__':
    ### with python installed, run this on console:
    # pip install ac-stubs
    ### ---in editor use the stub
    from AcDummyLib import ac
else:
    ### ---in ac just use this
    import ac, acsys
    from cssim_info import info

sys.path.insert(0, 'apps/python/system')
# https://pypi.org/project/Pillow/2.4.0/
from PIL import Image, ImageDraw # , ImageOps, ImageFont, ImageEnhance
# import PIL


# original: lt_acd.py
# @author: albertowd - thx for making ACD extractor available
# https://www.racedepartment.com/downloads/live-telemetry.31666/
from mylt_acd import ACD
from mylt_acd import get_tire_name, get_tire_namelong, get_val_from_lut, get_float, get_tire_id_max, get_tire_name_by_id, get_tire_id

global ACD_FILE
dataDict = {}


rtFlag = True
rtIndex0 = -1
rtIndex1 = -1

bCurve0ON=False # Torque
bCurve1ON=False # Power
bCurve2ON=False # Turbo (hidden if car has none)
bCurve3ON=True # Gas
bCurve4ON=True # Brake
bCurve5ON=False # FFB
bCurve6ON=True # grip
bCurve7ON=True # steering
bCurve8ON=False # handbrake
bCurve9ON=True # erscharge
bCurve10ON=False # ersinput
bCurve11ON=False # ersused
bCurve12ON=False # clutch
bCurve13ON=False # gforcex
bCurve14ON=False # gforcey
bCurve15ON=False # gforcez

PowerGraphMode = 0 # 0..2
btnSwitchUseJson=0

btn_Curve0ON=0
btn_Curve1ON=0
btn_Curve2ON=0
btn_Curve3ON=0
btn_Curve4ON=0
btn_Curve5ON=0
btn_Curve6ON=0
btn_Curve7ON=0
btn_Curve8ON=0
btn_Curve9ON=0
btn_Curve10ON=0
btn_Curve11ON=0
btn_Curve12ON=0
btn_Curve13ON=0
btn_Curve14ON=0
btn_Curve15ON=0
lbG0=0
lbG1=0
lbG2=0
lbG3=0
lbG4=0
lbG5=0
lbG6=0
lbG7=0
lbG8=0
lbG9=0
lbG10=0
lbG11=0
lbG12=0
lbG13=0
lbG14=0
lbG15=0

tyreTempM         = { "FL" : 0.0, "FR" : 0.0, "RL" : 0.0, "RR" : 0.0 }

gOPACITYPower = 0.5
gOPACITYAero = 0.5
gOPACITYCurves = 0.5

gShowTextPower = True
gShowTextAero = True
gShowTextCurves = True
gShowCValues = True
maxRpmSAVED=0.0
maxPowerSAVED=0.0

FANCYMODE = False
DOPEMODE = False
gCURVESCONNECTED = False
graphLineWidth2 = 2
shiftleft = 2

cbVertical=0
cbFancy=0
cbTextPower=0
cbTextAero=0
cbTextCurves=0
cbConnected=0
cbDope=0
export_curve_linewidth=3


### --- extra torque feature --- requirements
# 1-use CSP >= 0.1.77
# 2-you need to add this to the cars "data\car.ini"  (without # !):
#   [HEADER]
#   VERSION=extended-2
# 3-you need to add this to the cars "data\engine.ini" (without # !):
#   [_EXTENSION]
#   ENABLED=1
#   PYTHON_TORQUE_ALLOWED=1


### ui
fontname = "Consolas"
#fontname = "Arial"
#fontname = "Digital-7"
bVertical=True
histGraphMinValue = 0
histGraphMaxValue = 100
graphHeight=100
graphWidth =300
lasttyres=""
PRACTICAL_TEMP_RATIO = -1000.0
bCPhysCarcassEnabled = True
bNewTyreParams       = False
bCPhysicsActive      = False





bExtraTorqueAvail = False
if 'ext_setExtraTorque' in dir(ac):
    # from CSP 0.1.71 and up
    bExtraTorqueAvail = True

bAeroRollAvail = False
if 'ext_getAeroRoll' in dir(ac):
    # from CSP 0.1.71 and up
    bAeroRollAvail = True

cspActiveHandbrake = False
if 'ext_getHandbrake' in dir(ac):
    cspActiveHandbrake = True

cspActive = False
if 'ext_debugLights' in dir(ac):
    cspActive = True

# ac.log('\n')
# for s in dir(ac):
#     ac.log('ac.' + str(s) + '()')
# ac.log('\n')
# ac.log('\n')

# not really dynamic, it resets aero if speed<5 km/h
# so it would reset slipstream baseline
bDynAero  = False

bShowAero = True
TorqueTimer = 0.0
bTorqueTimerOn = False

TorqueTimerSteps = 10
AEROCDv=0.0
AEROCLf=0.0
AEROCLr=0.0
AEROdens=0.0
baseAEROdens = -1.0
slipStreamLevel = 0.01

gAPPSIZEAero= 1.0
graphWAero=300
graphHAero=100
gGRAPHAeroWMult=1.0
gGRAPHAeroHMult=1.0

gAPPSIZEPower=1.0
graphWPower=300
graphHPower=100
gGRAPHPowerWMult=1.0
gGRAPHPowerHMult=1.0

gAPPSIZECurves=1.0
graphWCurves=300
graphHCurves=200
gGRAPHCurvesWMult=1.0
gGRAPHCurvesHMult=1.0

btnAppPowerSizeUp=0
btnAppPowerSizeDn=0
btnAppPowerWUp=0
btnAppPowerWDn=0
btnAppPowerHUp=0
btnAppPowerHDn=0
btnPowerBG=0

btnAppAeroSizeUp=0
btnAppAeroSizeDn=0
btnAppAeroWUp=0
btnAppAeroWDn=0
btnAppAeroHUp=0
btnAppAeroHDn=0

btnAppCurvesSizeUp=0
btnAppCurvesSizeDn=0
btnAppCurvesWUp=0
btnAppCurvesWDn=0
btnAppCurvesHUp=0
btnAppCurvesHDn=0

appCarSpecs = 0
appPower = 0
appAero = 0
appCurves = 0

lbCarSpecs1 = 0
lbCarSpecs2 = 0
lbTimer = 0
lbAero = 0
lbPowerRpm = 0
lbPowerTorque = 0
lbPowerPower = 0
lbPowerTurbo = 0
lbPowerExtra = 0

b_Aero = 0
btnExtraTUp=0
btnExtraTDn=0
btnOpacityUp=0
btnOpacityDn=0
btnOpacityUpAero=0
btnOpacityDnAero=0
btnOpacityUpCurves=0
btnOpacityDnCurves=0
btnCurvesWidthUp=0
btnCurvesWidthDn=0
btnCurvesSpeedUp=0
btnCurvesSpeedDn=0
btnBoost=0

# rest
f1=0 # FontMeasures for ext_glFont stuff
sCarSpecs1  = ""
sCarSpecs2 = ""
extraT = 0.0
extraTEnabled = False
firstRun = True
lastCar = -1
currentCar = -1
fTimer3 = 0.0
fTimer2 = 0.0
fTimer = 0.0
TimeCount = 0.0
bDiffMode = False
extralines = 0
maxTurboBoost = 0.0
bHideTimerOn = False
hideTimer = 0.0
labelTimer = 0.0
labelTimerEnabled = False
bStartFlag = True
# data
transLoss = 0.88
torquehandBrake = 0.0
torqueBrake = 1.0
carsteerlock = 0
carffbmult = 0.0
powcurPOWRPM = []
powcurPOWPOW = []
powcurTORRPM = []
powcurTORTOR = []
powcurTORRPMJson=[]
powcurTORJson=[]
powcurPOWJson=[]
powcurPOWRPMJson=[]
maxTorque = 0.0
maxPower = 0.0
maxPowerJson = 0.0
maxTorqueJson = 0.0
maxPowerRpmJson = 0.0
maxPowerJSON2=""
maxTorqueJSON2=""
maxPowerRpmJson = 0
maxTorqueRpmJson = 0
carmassJson=0.0
carmass=0.0
rpmMAX = 1000.0

currentRPM = 0.0
currentGas = 0.0
currentTorque = 0.0
currentPow = 0.0
currTurboBoost=0.0
currentERS=0.0
currentSpeed=0.0
currBrake=0.0
currFFB=0.0
maxFFB=0.0
lastFFB=0.0

isSlipStream = False
slipstreamTime=0.0
jsonWD=""
engineBrake=0.0
rpmLimiter=0
rpmDamage=0
rpmUpshift=0
rpmDownshift=0
# graphics
texture_dot = 0
texture_dot2 = 0
texture_dotb = 0
texture_dotb2 = 0
turbo_count = 0
ac_LocalVelocity = -1.0
AEROaerospeed  = -1.0
AERODrag       = -1.0
AERODownforceF = -1.0
AERODownforceR = -1.0
AERODownforce = -1.0
maxDownForce = 0.1
ac_Grip     = [0.0,0.0,0.0,0.0]
ac_handbrake= 0.0
ac_steer=0.0
tempFtemp=[]
tempRtemp=[]
tempFgrip=[]
tempRgrip=[]

###############################

class FontMeasures:
    def __init__(self, name, italic, bold, size, ratio, distance, heightCompensation, widthCompensation):
        self.n = name					#font name
        self.i = italic					#font italic
        self.b = bold					#font bold
        self.s = size					#font multiplier for one pixel height
        self.r = ratio					#font width compared to height
        self.d = distance				#font distance between the leftmost point of one letter and another, avareage
        self.h = heightCompensation		#font height offset to put it centered vertically
        self.w = widthCompensation		#font width offset to put it centered horizontally
        self.f = 0						#font object to be used in rendering
        return

class ExtGL:
    CULL_MODE_FRONT = 0
    CULL_MODE_BACK = 1
    CULL_MODE_NONE = 2
    CULL_MODE_WIREFRAME = 4
    CULL_MODE_WIREFRAME_SMOOTH = 7
    BLEND_MODE_OPAQUE = 0
    BLEND_MODE_ALPHA_BLEND = 1
    BLEND_MODE_ALPHA_TEST = 2
    BLEND_MODE_ALPHA_ADD = 4
    BLEND_MODE_MULTIPLY_BOTH = 5
    FONT_ALIGN_LEFT = 0
    FONT_ALIGN_RIGHT = 1
    FONT_ALIGN_CENTER = 2

def get_numbers(s):
    try:
        result=""
        idx=0
        for l in s.strip():
            if l.isnumeric() or l=='.' or (idx<1 and l=='-'):
                result=result+l
            else:
                break
            idx+=1
        if result=="" or result=="-" or result==".":
            result="1"
        return float(result)
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

#def round5(x, base=5):
#  return int(x * base) / base * base * 10
# int(x * 10) / 5 * 50

def round5(x, base=5):
    try:
        return base * int(x/base)
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

def str2bool(v):
    try:
        return str(v).strip().lower() in ("yes", "true", "t", "1")
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

def bool2str(v):
    return 'on' if v else 'off'

def clamp(n, minn, maxn):
    try:
        if n < minn:
            return minn
        elif n > maxn:
            return maxn
        else:
            return n
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

def lerp(a, b, n):
    try:
        n = clamp(n, 0, 1)
        return a*(1-n)+b*n
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

def mapFromTo(val,a,b,x,y):
    try:
        return (val-a)/(b-a)*(y-x)+x
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

################################

def find_str(s, char):
    index = 0
    if len(char)>0 and char in s:
        c = char[0]
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index
            index += 1
    return -1

#############################################################

def appGetJsonInfo(CAR_JSON_PATH, carnamedir):
  #print ('------------------------')
  #print (CAR_JSON_PATH)
  global maxPowerRpmJson, maxPowerJson, maxTorqueRpmJson, maxTorqueJson, carmassJson
  global maxPowerJSON2, maxTorqueJSON2, powcurPOWRPM, powcurPOWPOW, powcurTORJson, powcurTORRPMJson, powcurPOWJson, powcurPOWRPMJson
  global jsonDetails, jsonWD, carpwratio
  global dataDict
  try:
    uiDataString = ""
    # with io.open(CAR_JSON_PATH, 'r', errors='ignore') as uiFile:
    # # with codecs.open(CAR_JSON_PATH, "r", "utf_8", errors="ignore") as uiFile:
    #   uiDataString = uiFile.read().replace('\r', '').replace('\t', '') # .replace('\n', '')
    #   uiDataJson = json.loads(uiDataString)

    if not carnamedir+"JSON" in dataDict:
        with io.open(CAR_JSON_PATH,encoding="utf8") as uiFile:
          uiDataString = uiFile.read().encode('ascii', 'ignore').decode('ascii').strip()
        uiDataString = uiDataString.replace('</br>', '').replace('\n\r\n\r', '').replace('\r\n\r\n', '').replace('\r', '').replace('\t', '').replace('\n', '').replace('\r', '')
        uiDataJson = json.loads( uiDataString )
        dataDict[carnamedir+"JSON"] = uiDataJson
    else:
        uiDataJson = dataDict[carnamedir+"JSON"]

    for step in uiDataJson["powerCurve"]:
      #ac.log(str(step))
      if int(float(step[1])) >= maxPowerJson:
        maxPowerJson    = float(step[1])
        maxPowerRpmJson = float(step[0])
      powcurPOWRPMJson.append(float(step[0]))
      powcurPOWJson.append(float(step[1]))
    for step in uiDataJson["torqueCurve"]:
      #ac.log(str(step))
      if int(float(step[1])) >= maxTorqueJson:
        maxTorqueJson       = float(step[1])
        maxTorqueRpmJson    = float(step[0])
      powcurTORRPMJson.append(float(step[0]))
      powcurTORJson.append(   float(step[1]))


    # "weight": "kg",
    # "topspeed": "km/h",
    # "acceleration": "0-100",
    # "pwratio": "kg/hp",
    # "range": ""
    maxPowerJSON2zw = str(uiDataJson["specs"]["bhp"])
    maxTorqueJSON2zw = str(uiDataJson["specs"]["torque"])
    carmassJson = str(uiDataJson["specs"]["weight"])
    carpwratio = str(uiDataJson["specs"]["pwratio"])
    maxPowerJSON2 = str(float(get_numbers(maxPowerJSON2zw)))
    maxTorqueJSON2 = str(float(get_numbers(maxTorqueJSON2zw)))
    if 'kgm' in maxTorqueJSON2zw.lower():
      maxTorqueJSON2 = str(float(maxTorqueJSON2) * 9.80665)
    if 'nmm' in maxTorqueJSON2zw.lower():
      maxTorqueJSON2 = str(float(maxTorqueJSON2) / 1000.0)

    jsonWD=""
    for tag in uiDataJson["tags"]:
      # ac.log(str(tag))
      if tag.lower()=="awd":
        jsonWD = "awd"
        break
      elif tag.lower()=="awd2":
        jsonWD = "awd2"
        break
      elif tag.lower()=="rwd":
        jsonWD = "rwd"
        break
      elif tag.lower()=="fwd":
        jsonWD = "fwd"
        break
      elif tag.lower()=="4wd":
        jsonWD = "4wd"
        break
  except:
    # ac.log('CarSpecs app: ' + carnamedir + '\n' +traceback.format_exc())
    #print('CarSpecs app: ' + carnamedir + '\n' +traceback.format_exc())
    maxPowerJson = 0
    maxPowerRpmJson = 0
    maxTorqueJson = 0
    maxTorqueRpmJson = 0

  try:
    jsonDetails = ""
    if uiDataString.lower().find('country')>0:
      jsonDetails+=(str(uiDataJson["country"]) + " ")
    if uiDataString.lower().find("author")>0:
      jsonDetails+=(' by ' + str(uiDataJson["author"]) + "   ")
    if uiDataString.lower().find("topspeed")>0:
      jsonDetails+=(str(uiDataJson["specs"]["topspeed"]) + " ")
    if uiDataString.lower().find("acceleration")>0:
      jsonDetails+=(str(uiDataJson["specs"]["acceleration"]) + " ")
    if uiDataString.lower().find("year")>0:
      jsonDetails+=(str(uiDataJson["year"]) + "   ")
    if jsonDetails!="":
      jsonDetails+='\n'
  # except KeyError:
  except:
    ac.log('CarSpecs reading json: ' + traceback.format_exc() )
    # print('CarSpecs reading json: ' + traceback.format_exc() )

##########################################################################
def thick_line(canvas, xy, direction, fill=None, width=0):
        #xy – Sequence of 2-tuples like [(x, y), (x, y), ...]
        #direction – Sequence of 2-tuples like [(x, y), (x, y), ...]
        if xy[0] != xy[1]:
            canvas.line(xy, fill = fill, width = width)
        else:
            x1, y1 = xy[0]
            dx1, dy1 = direction[0]
            dx2, dy2 = direction[1]
            if dy2 - dy1 < 0:
                x1 -= 1
            if dx2 - dx1 < 0:
                y1 -= 1
            if dy2 - dy1 != 0:
                if dx2 - dx1 != 0:
                    k = - (dx2 - dx1)/(dy2 - dy1)
                    a = 1/math.sqrt(1 + k**2)
                    b = (width*a - 1) /2
                else:
                    k = 0
                    b = (width - 1)/2
                x3 = x1 - math.floor(b)
                y3 = y1 - int(k*b)
                x4 = x1 + math.ceil(b)
                y4 = y1 + int(k*b)
            else:
                x3 = x1
                y3 = y1 - math.floor((width - 1)/2)
                x4 = x1
                y4 = y1 + math.ceil((width - 1)/2)
            canvas.line([(x3, y3), (x4, y4)], fill = fill, width = 1)
        return

def dashed_line(canvas, xy, dash=(2,2), fill=None, width=0):
    #xy – Sequence of 2-tuples like [(x, y), (x, y), ...]
    for i in range(len(xy) - 1):
        x1, y1 = xy[i]
        x2, y2 = xy[i + 1]
        x_length = x2 - x1
        y_length = y2 - y1
        length = math.sqrt(x_length**2 + y_length**2)
        dash_enabled = True
        postion = 0
        while postion <= length:
            for dash_step in dash:
                if postion > length:
                    break
                if dash_enabled:
                    start = postion/length
                    end = min((postion + dash_step - 1) / length, 1)
                    thick_line(canvas, [(round(x1 + start*x_length),
                                         round(y1 + start*y_length)),
                                        (round(x1 + end*x_length),
                                         round(y1 + end*y_length))],
                                    xy, fill, width)
                dash_enabled = not dash_enabled
                postion += dash_step
    return
##########################################################################

def DrawSavePowerCurves(carnamedir, addturbo):
  global histGraphMaxValue
  global maxPowerSAVED
  global powcurTORJson, powcurTORRPMJson, powcurTORTOR, powcurTORRPM, powcurPOWPOW, powcurPOWRPM, powcurPOWJson, powcurPOWRPMJson
  global transLoss
  try:                  # 350x210
    w=350 ### *2 ### *4
    h=200 ### *2 ### *4
    h2=h-export_curve_linewidth*1.9
    img = Image.new("RGBA", (w,h),(255,255,255,0) )
    canvas = ImageDraw.Draw(img)

    ### v3
    if maxTurboBoost>=0.0 and addturbo:
      turboTORTOR=powcurTORTOR.copy()
      turboPOWPOW=powcurTORTOR.copy()
      for i in range(0,len(powcurTORRPM)):
        turboTORTOR[i]=powcurTORTOR[i]*(1+maxTurboBoost)
        turboPOWPOW[i]=turboTORTOR[i]*powcurTORRPM[i]* 0.10472 / 745.7
      maxPowerSAVED = max(max(turboTORTOR), max(turboPOWPOW))

      ### Torque Nm in yellow
      xl=powcurTORRPM[0]/rpmMAX         *w
      yl=h-powcurTORTOR[0]/maxPowerSAVED*h2
      for i in range(1,len(powcurTORTOR)):
        x=  powcurTORRPM[i]/rpmMAX       *w
        y=h-powcurTORTOR[i]/maxPowerSAVED*h2
        if x>xl:
          if addturbo:
            canvas.ellipse((x-1,y-1, x+1,y+1), outline='yellow')
          else:
            canvas.line((xl,yl, x,y),fill=('yellow'), width=export_curve_linewidth)
          #canvas.line((xl,yl, x,y),fill=('yellow'), width=linewidth)
          xl=x
          yl=y
      ### BHP power in red
      xl=powcurTORRPM[0]/rpmMAX         *w
      yl=h-powcurTORTOR[0] * powcurTORRPM[0] * 0.10472 / 745.7 / maxPowerSAVED * h2
      for i in range(1,len(powcurTORTOR)):
        x=  powcurTORRPM[i]/rpmMAX       *w
        y=h-powcurTORTOR[i]  * powcurTORRPM[i] * 0.10472 / 745.7 / maxPowerSAVED * h2
        if x>xl:
          if addturbo:
            canvas.ellipse((x-1,y-1, x+1,y+1), outline='red')
          else:
            canvas.line((xl,yl, x,y),fill=('red'), width=export_curve_linewidth)
          #canvas.line((xl,yl, x,y),fill=('red'), width=linewidth)
          xl=x
          yl=y

    else:
      # json without turbo stuff
      maxPowerSAVEDlocal = max(max(powcurTORJson), max(powcurPOWJson))
      ### Torque Nm in yellow
      xl=  powcurTORRPMJson[0]/rpmMAX        *w
      yl=h-powcurTORJson   [0]/maxPowerSAVEDlocal  *h2
      for i in range(0,len(powcurTORRPMJson)):
        x=  powcurTORRPMJson[i]/rpmMAX       *w
        y=h-powcurTORJson   [i]/maxPowerSAVEDlocal *h2
        if x>xl:
          canvas.line((xl,yl, x,y),fill=('yellow'), width=export_curve_linewidth)
          xl=x
          yl=y
      ### BHP power in red
      xl=  powcurPOWRPMJson[0]/rpmMAX          * w
      yl=h-powcurPOWJson   [0] / maxPowerSAVEDlocal * h2
      for i in range(0,len(powcurPOWRPMJson)):
        x=  powcurPOWRPMJson[i]/rpmMAX         * w
        y=h-powcurPOWJson   [i] / maxPowerSAVEDlocal * h2
        if x>xl:
          canvas.line((xl,yl, x,y),fill=('red'), width=export_curve_linewidth)
          xl=x
          yl=y



    if addturbo:
      ### full Torque Nm in yellow
      xl=  powcurTORRPM[0]/rpmMAX         * w
      yl=h-turboTORTOR[0]/maxPowerSAVED   * h2
      for i in range(0,len(powcurTORRPM)):
        x=  powcurTORRPM[i]/rpmMAX        * w
        y=h-turboTORTOR[i]/maxPowerSAVED  * h2
        if x>xl:
          canvas.line((xl,yl, x,y),fill=('yellow'), width=export_curve_linewidth)
          xl=x
          yl=y
      ### full BHP power in red
      xl=  powcurTORRPM[0]/rpmMAX         *w
      yl=h-turboPOWPOW[0] / maxPowerSAVED * h2
      for i in range(0,len(powcurTORRPM)):
        x=  powcurTORRPM[i]/rpmMAX       *w
        y=h-turboPOWPOW[i] / maxPowerSAVED * h2
        if x>xl:
          canvas.line((xl,yl, x,y),fill=('red'), width=export_curve_linewidth)
          xl=x
          yl=y


    img.save(carnamedir)

  except:
    ac.log('CarSpecs app: \n' +traceback.format_exc())


##########################################################################

def appCheckCarSpecs(currentCar, carnamedir):
  global powmaxrpm, ersCurve, ersmaxrpmpow, ersmaxpowrpm, sturbo, ersmaxrpmpow, ersmaxpowrpm, turbo, turbo_count, powmaxrpmpow, torqueBrake
  global extralines, carmass, sCarSpecs1, sCarSpecs2, maxPower, maxPowerJSON2, maxTorqueJSON2, torquehandBrake, carsteerlock, carffbmult
  global extraTEnabled, powcurPOWPOW, powcurPOWRPM, rpmLimiter, rpmDamage, rpmUpshift, rpmDownshift, powcurTORRPM, powcurTORTOR
  global appCarSpecs, lbCarSpecs1, lbCarSpecs2, rpmMAX, maxTurboBoost, maxTorque, powcurTORJson
  global ersRPM, ersPOW, jsonDetails, jsonWD, engineBrake, bExtraTorqueAvail, lbPowerTurbo
  global histGraphMaxValue, histGraph, PRACTICAL_TEMP_RATIO, btnPowerBG, powcurTORRPMJson
  global tempFtemp, tempFgrip, tempRtemp, tempRgrip, path_v
  global dataDict

  ### read data/*.ini files or data.acd
  try:
    sTyres = ''
    sturbo=''
    rpmInfo = ''
    extralines=0
    powmaxrpm=0
    powmaxrpmpow=0
    powmaxpowrpm=0
    powmaxpow=0
    ersmaxrpmpow=0
    ersmaxpowrpm=0
    ersmaxrpm=0
    ersmaxpow=0
    powcurPOWRPM = []
    powcurPOWPOW = []
    powcurTORRPM = []
    powcurTORTOR = []
    powcurTORRPMJson=[]
    powcurTORJson=[]
    ersRPM = []
    ersPOW = []

    ac.log('---CarSpecs app loading---')

    path_v = os.path.dirname(os.path.realpath(__file__))
    path_v = path_v.replace('\\','/').lower().replace('apps/python/carspecs','')
    if len(path_v)==0:
      ac.log('CarSpecs: couldnt find my own path!')
      return

    # "dlc_ui_car.json" ? nothing usefull in there
    CAR_JSON_PATH = path_v + "content/cars/%s/ui/ui_car.json" % carnamedir
    CARDIR = path_v + "content/cars/{}".format(carnamedir)

    ### get data from 'ui_car.json'
    appGetJsonInfo(CAR_JSON_PATH, carnamedir)

    if not carnamedir in dataDict:
        dataDict[carnamedir] = carnamedir
        # ACD_FILE = ACD("content/cars/{}".format(carname))
        ACD_FILE = ACD(CARDIR)
        dataDict[carnamedir+'ACD'] = ACD_FILE
    else:
        ACD_FILE = dataDict[carnamedir+'ACD']

    ##### appGetJsonInfo('p:/Steam/steamapps/common/assettocorsa/' + CAR_JSON_PATH, carnamedir)
    ##### CARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/' + carnamedir

    #[BASIC]
    #GRAPHICS_OFFSET=0,-0.51,-0.04				; 3 axis correction (x,y,z), applies only to the 3D object of the car (meters)
    #GRAPHICS_PITCH_ROTATION=0				; Changes 3D object rotation in pitch (degrees)
    #TOTALMASS=1165							; Total vehicle weight in kg with driver and no fuel

    config = ConfigParser(empty_lines_in_values=False, inline_comment_prefixes=(";","#","/",), comment_prefixes=(";","#","/",), strict=False, allow_no_value=True)
    config.optionxform = str

    powcur   = re.sub(r'^\s*$', '',  str(ACD_FILE.get_power_curve()).strip() )
    ersCurve = re.sub(r'^\s*$', '',  str(ACD_FILE.get_ers_curve()).strip() )

    carname         = ACD_FILE.get_carname()
    carmass         = ACD_FILE.get_totalmass()
    if carmass==0.0:
      carmass = carmassJson
    carmass = get_numbers( str(carmassJson).lower().replace('kg','') )

    torqueBrake     = ACD_FILE.get_brakeTorque()
    torquehandBrake = ACD_FILE.get_handbrakeTorque()
    if torqueBrake>0.0:
      torquehandBrakeRatio = math.floor( float(torquehandBrake)/float(torqueBrake)*100.0 )
    else:
      torquehandBrakeRatio = 0.0
    gearcount       = ACD_FILE.get_gearcount()
    driveType       = ACD_FILE.get_driveType()
    if driveType=="":
      driveType = jsonWD
    rpmLimiter  = int(ACD_FILE.get_rpm_limiter())
    rpmDamage   = int(ACD_FILE.get_rpm_damage())
    rpmUpshift  = int(ACD_FILE.get_rpm_upshift())
    rpmDownshift= int(ACD_FILE.get_rpm_downshift())
    engineBrake =     ACD_FILE.get_coast_torque()

    # turbo           = ACD_FILE.get_turbo()
    turbo           = ACD_FILE.get_wastegate()
    #turbo           = ACD_FILE.get_wastegate_display()
    turbo_count     = ACD_FILE.get_turbo_count()

    maxRpm = rpmLimiter # info.static.maxRpm
    maxTurboBoost = turbo # info.static.maxTurboBoost
    # maxTorque = info.static.maxTorque * (1+maxTurboBoost)

    if turbo > 0.0 and turbo < maxTurboBoost and maxTurboBoost > 0.0:
      maxTurboBoost = turbo
    # if float(maxTorqueJSON2)>maxTorque:
    #   # ac.log('CarSpecs: using json maxTorque, before: ' + str(round(maxTorque,2)))
    #   maxTorque = float(maxTorqueJSON2) #  * (maxTurboBoost)

    # maxPower = info.static.maxPower / 1000.0 #  maxPowerJSON2
    #maxPower = maxPowerJson
    #if maxPower==0.0 and maxPowerJSON2!="" and maxPowerJSON2.isnumeric():
    # if maxTorqueJSON2!='':
    #   maxTorque = float(maxTorqueJSON2)
    # if maxPowerJSON2!='':
    #   maxPower = float(maxPowerJSON2)
    # if maxTorqueJson>maxTorque:
    #   maxTorque=maxTorqueJson
    # if maxPowerJson>maxPower:
    #   maxPower=maxPowerJson
    # if maxTorqueJson>maxTorque:
    #   maxTorque=maxTorqueJson
    # if maxPowerJson>maxPower:
    #   maxPower=maxPowerJson
    #histGraphMaxValue=0
    #histGraphMaxValue




    global maxPowerSAVED, maxRpmSAVED

    if len(powcur)>0:
      ac.log('CarSpecs: using curve from data/power.lut')
      # ac.log( str(maxTorque) )
      # ac.log(str(maxTurboBoost))
      # ac.log(str(maxPower))
      # [DATA]
      # MAX_TORQUE=800			; Maximum Brake torque in Nm
      # FRONT_SHARE=0.56
      # [COAST_REF]
      # RPM=9000						; rev number reference
      # TORQUE=85						; engine braking torque value in Nm at rev number reference
      powcurTORRPM=[]
      powcurTORTOR=[]
      powcurPOWRPM=[]
      powcurPOWPOW=[]

      lreadRPMS=0
      for line in powcur.strip('').split('\n'):
        if find_str(line.strip(),';')!=0 and '|' in line:
          line = line.replace("\r","").replace("\n","")
          a=line.replace("'","").split('|')
          if ',' in a[0]:
            a = a[0].split(',')
          if len(a)>1:
            # ac.log( str(a) )
            readRPMS=float(get_numbers(a[0]))
            if ',' in a[1]:
              a[1] = a[1].split(',')[0]
            readTORQUE=float(get_numbers(a[1]))
            if ';' in a[1]:
              readTORQUE = float(get_numbers(a[1].split(';')[0]))
            if readRPMS>lreadRPMS:
              powcurTORRPM.append(readRPMS)
              powcurTORTOR.append(readTORQUE) #  * (1+maxTurboBoost))
              powcurPOWRPM.append(readRPMS)
              powcurPOWPOW.append(readTORQUE * readRPMS * 0.10472 / 745.7) # convert Nm to PS
              if int(powmaxrpmpow)<readTORQUE:
                powmaxrpm=readRPMS # max rpm
                powmaxrpmpow=readTORQUE
              if int(powmaxpowrpm)<readRPMS:
                powmaxpowrpm=readRPMS
              maxRpmSAVED = powmaxrpmpow
            lreadRPMS=readRPMS

      if ersCurve !='':
        for line in str(ersCurve).split('\n'):
          if find_str(line.strip(),';')!=0 and '|' in line:
            line = line.replace("\r","").replace("\n","")
            a=line.replace("'","").split('|')
            if len(a)>1:
              # ac.log( str(a) )
              ersRPMS=int(float(get_numbers(a[0])))
              ersTORQUE=int(float(get_numbers(a[1])))
              # ac.log(str(ersRPMS) + '  |  ' + str(ersTORQUE) )
              if ';' in a[1]:
                ersTORQUE = int(get_numbers(a[1].split(';')[0]))
              ersRPM.append(ersRPMS)
              ersPOW.append(ersTORQUE)
              if int(ersmaxrpmpow)<ersTORQUE:
                ersmaxrpm=ersRPMS # max rpm
                ersmaxrpmpow=ersTORQUE
              if int(ersmaxpowrpm)<ersRPMS:
                ersmaxpowrpm=ersRPMS
                ersmaxpow=ersTORQUE

      if len(powcurPOWPOW)>0 and len(powcurTORTOR)>0:
        maxPowerSAVED=max(max(powcurTORTOR),max(powcurPOWPOW))
      else:
        maxRpm=max(powcurPOWRPMJson)
        if len(powcurPOWPOW)==0:
          powcurPOWPOW = powcurPOWJson.copy()
          powcurTORTOR = powcurTORJson.copy()
          powcurPOWRPM = powcurPOWRPMJson.copy()
          powcurTORRPM = powcurTORRPMJson.copy()
          maxPowerSAVED=max(max(powcurTORTOR),max(powcurPOWPOW))
          #maxPowerSAVED=max(maxTorqueJson, maxPowerJson)
        if len(powcurPOWPOW)>0:
          maxPowerSAVED=max(powcurPOWPOW)
        elif len(powcurTORTOR)>0:
          maxPowerSAVED=max(powcurTORTOR)
        else:
          maxPowerSAVED=max(maxTorqueJson, maxPowerJson)

      # ac.log('powcurPOWRPM  '+str(len(powcurPOWRPM)))
      # ac.log('powcurTORRPM  '+str(len(powcurTORRPM)))
      #ac.log('TORQUE  '+str(powcurTORTOR))
      #ac.log('POWER  '+str(powcurPOWPOW))
      #maxPowerSAVED=
      #maxPowerSAVED=maxTorqueJson
      #if maxTurboBoost>0.0:
      #  maxPowerSAVED=max(max(powcurTORTOR), maxTorqueJson)*(1+maxTurboBoost)/2
      #  maxPowerSAVED=max(maxPowerSAVED, maxPowerJson)*(1+maxTurboBoost)/2
      #  #maxPowerSAVED=max(maxTorqueJson,maxPowerJson)    *(1+maxTurboBoost)
      #  #maxPowerSAVED=max(powcurTORTOR)*(1+maxTurboBoost)

      #maxPowerSAVED=max(maxTorqueJson,maxPowerJson)
      #maxPowerSAVED=max(max(powcurTORTOR), max(powcurPOWPOW))
      #if maxTurboBoost>0.0:
      #  maxPowerSAVED=max(max(powcurTORTOR), max(powcurPOWPOW))    *(1+maxTurboBoost)

      # ac.log('maxPowerSAVED: ' + str(maxPowerSAVED) +
      #      '\nmaxRpmSAVED  : ' + str(maxRpmSAVED))
      # ac.log('maxTorqueJson: ' + str(maxTorqueJson) +
      #      '\nmaxPowerJson : ' + str(maxPowerJson))
      # ac.log('maxTurboBoost: ' + str(maxTurboBoost))
      # ac.log('limiter      : ' + str(rpmLimiter))
      # ac.log('rpmMAX       : ' + str(rpmMAX))
      #ac.log(str(powcurTORTOR))
      #currentPow = max(0.0, currentTorque * currentRPM*0.10472 / 745.7)
      #currentPow = max(0.0, currentTorque * currentRPM*0.10472 / 525.2)
      #currentPow = max(0.0, currentTorque * currentRPM / 5252.0)
      #currentPow = max(0.0, currentTorque * currentRPM / 6300)


    if 'formula_lithium' in carname:
      maxPowerSAVED = maxPowerSAVED*0.5

    if rpmLimiter==0.0 and len(powcurPOWRPM)>0:
      rpmLimiter = max(powcurPOWRPM)
    elif rpmLimiter==0.0:
      rpmLimiter = maxRpm
    if rpmDamage<powmaxrpm:
      rpmDamage=powmaxrpm
    if rpmDamage<rpmLimiter:
      rpmDamage=rpmLimiter
    rpmMAX = rpmLimiter
    if maxRpm>rpmMAX and maxRpm>0.0: # from shared mem
      rpmMAX = maxRpm
    if rpmMAX == 0.0:
      rpmMAX = maxRpm



    # ac.log('CarSpecs: using curve from ui/ui.json')
    # ac.log('max(powcurTORTOR) '+str(max(powcurTORTOR)))
    # ac.log('max(powcurPOWPOW) '+str(max(powcurPOWPOW)))
    # ac.log('TORQUE  '+str(powcurTORTOR))
    # ac.log('TORQUEr '+str(powcurTORRPM))
    # ac.log('POWER   '+str(powcurPOWPOW))
    # ac.log('POWERr  '+str(powcurPOWRPM))
    # ac.log('JPOWER  '+str(powcurTORJson))
    # ac.log('JPOWERr '+str(powcurTORRPMJson))

    #if len(powcurPOWPOW)>1:
    #  # add some rpm values for strange curves
    #powcurPOWPOW.append(powcurPOWPOW[len(powcurPOWPOW)-1]/3*2)
    #powcurPOWRPM.append(powcurPOWRPM[len(powcurPOWRPM)-1]+500)
    #powcurPOWPOW.append(powcurPOWPOW[len(powcurPOWPOW)-1]/3)
    #powcurPOWRPM.append(powcurPOWRPM[len(powcurPOWRPM)-1]+1000)
    #powcurPOWPOW.append(powcurPOWPOW[len(powcurPOWPOW)-1]/3)
    #powcurPOWRPM.append(powcurPOWRPM[len(powcurPOWRPM)-1]+1000)
    #powcurTORTOR.append(powcurTORTOR[len(powcurTORTOR)-1]/3*2)
    #powcurTORRPM.append(powcurTORRPM[len(powcurTORRPM)-1]+500)
    #powcurTORTOR.append(powcurTORTOR[len(powcurTORTOR)-1]/3)
    #powcurTORRPM.append(powcurTORRPM[len(powcurTORRPM)-1]+1000)
    #powcurTORTOR.append(powcurTORTOR[len(powcurTORTOR)-1]/3)
    #powcurTORRPM.append(powcurTORRPM[len(powcurTORRPM)-1]+1000)


    maxRpmSAVED=max(maxTorqueRpmJson,maxPowerRpmJson)
    if len(powcurPOWPOW)>0 and len(powcurTORTOR)>0:
      maxPowerSAVED=max(max(powcurTORTOR), max(powcurPOWPOW))

    #histGraphMaxValue = max(100, max( maxTorque, maxPower ) )
    histGraphMaxValue = maxPowerSAVED

    ### debug standalone ###
    if __name__ != '__main__':
      ### app version ###
      ac.setRange(histGraph, 0, int(histGraphMaxValue), int(graphWidth))
    #else:
    #  ac.log('-------------  histGraphMaxValue             ' + str(histGraphMaxValue))

    #######################################################################
    #######################################################################




    ### draw Power/Torque curve
    if len(powcurTORJson)>0 and len(powcurTORRPMJson)>0 and len(powcurPOWPOW)>0 and len(powcurPOWRPM)>0:
      #powcurTORTOR=powcurTORJson
      #powcurTORRPM=powcurTORRPMJson
      #powcurTORTOR=powcurTORJson
      #powcurTORRPM=powcurTORRPMJson
      #if not os.path.isfile(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_json.png'):
      DrawSavePowerCurves(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_json.png', False)
      # DrawSavePowerCurves(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_json.png', powcurTORTOR , powcurTORRPM)
    else:
      ac.log('CarSpecs app: no Torque/Power curve found')
  # try:
  #   img.save(carnamedir)
  # except:
  #   ac.log('CarSpecs app: \n' +traceback.format_exc())

    if len(powcurTORTOR)>0 and len(powcurTORRPM)>0 and len(powcurPOWPOW)>0 and len(powcurPOWRPM)>0:
      #if not os.path.isfile(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_data.png'):
      DrawSavePowerCurves(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_data.png', True)
    else:
      ac.log('CarSpecs app: no Torque/Power curve found')





#    ac.log('')
#    ac.log('len(powcurTORTOR)    '  +  str(len(powcurTORTOR)))
#    ac.log('len(powcurTORRPM)    '  +  str(len(powcurTORRPM)))
#    ac.log('len(powcurPOWPOW)    '  +  str(len(powcurPOWPOW)))
#    ac.log('len(powcurPOWRPM)    '  +  str(len(powcurPOWRPM)))
#
#    if len(powcurPOWPOW)==0 and len(powcurTORJson)>0:
#      powcurTORTOR = powcurTORJson
#      powcurTORRPM = powcurTORRPMJson
#      powcurPOWPOW = []
#      powcurPOWRPM = []
#      for i in range(len(powcurTORTOR)):
#        # currentTorque * currentRPM*0.10472 / 745.7
#        powcurPOWPOW.append(powcurTORTOR[i] * powcurTORRPM[i]*0.10472 / 745.7)
#        powcurPOWRPM.append(powcurTORRPM[i])
#
#    ac.log('')
#    ac.log('len(powcurTORTOR)    '  +  str(len(powcurTORTOR)))
#    ac.log('len(powcurTORRPM)    '  +  str(len(powcurTORRPM)))
#    ac.log('len(powcurPOWPOW)    '  +  str(len(powcurPOWPOW)))
#    ac.log('len(powcurPOWRPM)    '  +  str(len(powcurPOWRPM)))
#
#
#    ### calculate new stepped torque/power curves
#    RPMsteps = 250
#
#    tmppowcurPOWRPM = powcurTORRPM.copy()
#    tmppowcurPOWPOW = powcurTORTOR.copy()
#    ac.log('-------------here------------------')
#    ac.log('len(tmppowcurPOWPOW)   '  +  str(len(tmppowcurPOWPOW)))
#    ac.log('len(tmppowcurPOWRPM)   '  +  str(len(tmppowcurPOWRPM)))
#    powcurTORRPM = []
#    powcurTORTOR = []
#    ac.log('-------------here2------------------')
#    ac.log('len(tmppowcurPOWPOW)   '  +  str(len(tmppowcurPOWPOW)))
#    ac.log('len(tmppowcurPOWRPM)   '  +  str(len(tmppowcurPOWRPM)))
#    for i in range(int(maxRpm/RPMsteps)):
#      powcurTORRPM.append(i*RPMsteps)
#      #x = get_val_from_lut(info.physics.tyreTempM[0], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,0), tempFtemp, tempFgrip)
#      x = get_val_from_lut(i*RPMsteps, tmppowcurPOWRPM, tmppowcurPOWPOW)
#      powcurTORTOR.append( x )
#
#    ac.log('')
#    ac.log('len(powcurTORTOR)    '  +  str(len(powcurTORTOR)))
#    ac.log('len(powcurTORRPM)    '  +  str(len(powcurTORRPM)))
#    ac.log('len(powcurPOWPOW)    '  +  str(len(powcurPOWPOW)))
#    ac.log('len(powcurPOWRPM)    '  +  str(len(powcurPOWRPM)))
#
#    if len(powcurPOWPOW)==0 and len(powcurTORJson)>0:
#      tmppowcurPOWRPM = powcurTORRPMJson
#      tmppowcurPOWPOW = powcurTORJson
#    else:
#      tmppowcurPOWRPM = powcurPOWRPM
#      tmppowcurPOWPOW = powcurPOWPOW
    #tmppowcurPOWRPM = powcurPOWRPM.copy()
    #tmppowcurPOWPOW = powcurPOWPOW.copy()
    #powcurPOWRPM = []
    #powcurPOWPOW = []
    #for i in range(int(maxRpm/RPMsteps)):
    #  powcurPOWRPM.append(i*RPMsteps)
    #  #x = get_val_from_lut(info.physics.tyreTempM[0], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,0), tempFtemp, tempFgrip)
    #  x = get_val_from_lut(i*RPMsteps, tmppowcurPOWRPM, tmppowcurPOWPOW)
    #  powcurPOWPOW.append( x )
#
#    ac.log('')
#    ac.log('len(powcurTORTOR)    '  +  str(len(powcurTORTOR)))
#    ac.log('len(powcurTORRPM)    '  +  str(len(powcurTORRPM)))
#    ac.log('len(powcurPOWPOW)    '  +  str(len(powcurPOWPOW)))
#    ac.log('len(powcurPOWRPM)    '  +  str(len(powcurPOWRPM)))
























    ### now read some stuff just to display in info window

    # steerlock and ff mult from car.ini
    config.read_string(ACD_FILE.get_file("car.ini"))
    if config.has_section('CONTROLS'):
      if config.has_option('CONTROLS','STEER_LOCK'):
        carsteerlock = config['CONTROLS']['STEER_LOCK']
      if config.has_option('CONTROLS','FFMULT'):
        carffbmult = config['CONTROLS']['FFMULT']

    # tyres.ini
    #config.read_string(ACD_FILE.get_file("tyres.ini"))
    config.read_string("[ACHEADER]\n" + ACD_FILE.get_file("tyres.ini"))

    tyresVersion = ""
    if config.has_section('HEADER'):
      if config.has_option('HEADER','VERSION'):
        tyresVersion = str(config['HEADER']['VERSION'])

    ### debug standalone ###
    if __name__ == '__main__':
      tirenameShort = 'PZ'
    else:
      ### app version ###
      tirenameShort = ac.getCarTyreCompound(currentCar)

    tirename      = get_tire_namelong(tirenameShort, config, 0)

    temp_curveF      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_FRONT", "PERFORMANCE_CURVE"   , "SHORT_NAME", tirenameShort)
    wear_curveF      = ACD_FILE.get_file_section_value_as_curve(config, "FRONT"        , "WEAR_CURVE"          , "SHORT_NAME", tirenameShort)
    temp_curveR      = ACD_FILE.get_file_section_value_as_curve(config, "THERMAL_REAR" , "PERFORMANCE_CURVE"   , "SHORT_NAME", tirenameShort)
    wear_curveR      = ACD_FILE.get_file_section_value_as_curve(config, "REAR"         , "WEAR_CURVE"          , "SHORT_NAME", tirenameShort)
    if len(temp_curveF)>0 and len(temp_curveR)>0:
        for s in temp_curveF.split('\n'):
            t=s.split('|')
            if len(t)>1:
                tempFtemp.append(get_float(t[0]))
                tempFgrip.append(get_float(t[1]))
        for s in temp_curveR.split('\n'):
            t=s.split('|')
            if len(t)>1:
                tempRtemp.append(get_float(t[0]))
                tempRgrip.append(get_float(t[1]))

    if config.has_section('_EXTENSION') and config.has_option('_EXTENSION', 'PRACTICAL_TEMP_RATIO'):
        s = config['_EXTENSION']['PRACTICAL_TEMP_RATIO']
        ss = s
        if ';' in s:
            ss = float(s.split(';')[0])
        if '#' in s:
            ss = float(s.split('#')[0])
        if ' ' in ss:
            ss = float(s.split(' ')[0])
        if ss.isnumeric():
            PRACTICAL_TEMP_RATIO = float(ss)
        # ac.log(str(PRACTICAL_TEMP_RATIO))




    # temp_curve = re.sub(r'^\s*$', '',  str( ACD_FILE.get_temp_curve(tirenameShort, 0) ).strip() )
    # wear_curve = re.sub(r'^\s*$', '',  str( ACD_FILE.get_wear_curve(tirenameShort, 2) ).strip() )

    radiiTyreF  = ACD_FILE.getTyreRadiusFront(tirenameShort)
    radiiTyreR  = ACD_FILE.getTyreRadiusFront(tirenameShort)
    tyreWidthF  = ACD_FILE.getTyreWidthFront( tirenameShort)
    tyreWidthR  = ACD_FILE.getTyreWidthRear ( tirenameShort)
    # i.e. RIM_RADIUS=0.255  ; rim radius in meters (use 1 inch more than nominal)
    # so we substract 1 inch from value we got
    radiiRimF   = ACD_FILE.getRimRadiusFront( tirenameShort)
    radiiRimR   = ACD_FILE.getRimRadiusRear ( tirenameShort)
    radiiRimF   = radiiRimF + 0.0127  ###0.0254
    radiiRimR   = radiiRimR + 0.0127  ###0.0254

    # 1 inch = 2.54cm
    sTyres=''
    if tyreWidthF>=0.001 and tyreWidthR>=0.001:
      ratioF = (radiiTyreF - (radiiRimF) ) / tyreWidthF * 100
      ratioR = (radiiTyreR - (radiiRimR) ) / tyreWidthR * 100
      sTyres  = str(int(tyreWidthF*1000)) + " / " + str(round(ratioF/5)*5) + " R" + str(int( radiiRimF*100/2.54*2) - 1) + "''"
      sTyresR = str(int(tyreWidthR*1000)) + " / " + str(round(ratioR/5)*5) + " R" + str(int( radiiRimR*100/2.54*2) - 1) + "''"
    else:
      radii = ac.getCarState(currentCar, acsys.CS.TyreRadius)
      radiiRimF = radii[0]*1000.0
      radiiRimR = radii[2]*1000.0
      sTyres  = " R" + str(int(radiiRimF*100/2.54*2)-1) + "''"
      sTyresR = " R" + str(int(radiiRimR*100/2.54*2)-1) + "''"
    if sTyres!=sTyresR:
      sTyres = "Front: " + sTyres + "  -  Rear: " + sTyresR
      #extralines +=1
    else:
      sTyres = "Front+Rear: " + sTyres

    if ersCurve!='' and int(ersmaxrpmpow)>0 and int(ersmaxpowrpm)>0:
      sturbo='\n + KERS: ' + str(ersmaxrpmpow) + 'Nm @ ' + str(ersmaxpowrpm) + 'rpm'
      #extralines +=1
    if ( float(turbo)>1.0 and float(turbo)!=0.0 ) or sturbo!='':
      powCombined = ( float(ersmaxrpmpow) + float(powmaxrpmpow) + math.floor(powmaxrpmpow*(1.0+turbo)) )
      # ac.log('powCombined raw: ' + str(powmaxrpmpow*turbo/turbo_count))
      # powCombined = ( float(ersmaxrpmpow) + float(powmaxrpmpow) + powmaxrpmpow*turbo )
      powCombined = (1.0-transLoss) * powCombined
      # powCombined = powCombined / (1+transLoss)
      # powCombined = float(ersmaxrpmpow) + float(powmaxrpmpow) + math.floor(*(1.0+turbo))
      if turbo_count>1:
        sturbo = "\n"+ str(turbo_count) + "x Turbo: x" + str(round(turbo,2)) + sturbo ###  + " = calc'd: " + str(int(powCombined*0.735499)) + "PS / " + str(int(powCombined)) + "Nm @ " + str(powmaxrpm) + "rpm"
      else:
        sturbo = ("\nTurbo: x" + str(round(turbo,2)) + sturbo
            #" = calc'd: " + str(int(powCombined*0.735499)) + "PS / " + str(int(powCombined)) + "Nm @ " + str(powmaxrpm) + "rpm"
            #" = calc'd: " + str(int(powCombined*0.735499)) + "PS / " + str(int(powCombined)) + "Nm @ " + str(powmaxrpm) + "rpm" )
            )
      sturbo = " - Turbo: x" + str(round(turbo,2)) + sturbo ### + "\nacalc'd: " + str(int(powCombined*0.735499)) + "PS / " + str(int(powCombined)) + "Nm @ " + str(powmaxrpm) + "rpm (loss:" + str(int(transLoss*100)) + "%)"
      # extralines +=1
    else: # 0.735499   1.35962
      powCombined = (1.0-transLoss) * ( powmaxrpmpow )
      #if powCombined>0.0:
        # powCombined = powmaxrpmpow / (1+transLoss)
        #ac.log('powCombined raw: ' + str(powCombined))
      if maxTurboBoost>0.0:
        sturbo = "\n"+ str(round(maxTurboBoost,2)) + "x Turbo"
      else:
        sturbo = "\n"
            # + " = calc'd: " + str(int(powCombined*0.735499)) + " PS / " + str(int(powCombined)) + "Nm @ " + str(powmaxrpm) + "rpm (loss:" + str(int(transLoss*100)) + "%)")

    sturboJson = '\njson curves: ' + str(int(maxPowerJson)) + 'PS @ ' + str(int(maxPowerRpmJson)) + 'rpm  -  ' + str(int(maxTorqueJson)) + 'Nm @ ' + str(int(maxTorqueRpmJson)) + 'rpm'

    if rpmLimiter>0:
      rpmInfo += '\nLimiter: ' + str(rpmLimiter   ) + 'rpm      '
    if rpmUpshift>0 and rpmDownshift>0:
      rpmInfo += 'Up/Down @ ' + str(rpmUpshift   ) + ' / ' + str(rpmDownshift   ) + 'rpm  '




    diffInfo = ''
    config.read_string(ACD_FILE.get_file("electronics.ini"))
    if config.has_section("ABS"):
      if config.has_option("ABS", "PRESENT"):
        if get_numbers(config["ABS"]["PRESENT"]) == 1:
          diffInfo += "    ABS "
          diffInfo += bool2str( str2bool( str(get_numbers(config["ABS"]["ACTIVE"])) ))
    if config.has_section("ABS_V2"):
      if config.has_option("ABS_V2", "PRESENT"):
        if get_numbers(config["ABS_V2"]["PRESENT"]) == 1:
          diffInfo += "    ABS_V2 "
          diffInfo += bool2str( str2bool( str(get_numbers(config["ABS_V2"]["ACTIVE"])) ))
    if config.has_section("TRACTION_CONTROL"):
      if config.has_option("TRACTION_CONTROL", "PRESENT"):
        if get_numbers(config["TRACTION_CONTROL"]["PRESENT"]) == 1:
          diffInfo += "    TC "
          diffInfo += bool2str( str2bool( str(get_numbers(config["TRACTION_CONTROL"]["ACTIVE"])) ))
    if config.has_section("EDL"):
      if config.has_option("EDL", "PRESENT"):
        if get_numbers(config["EDL"]["PRESENT"]) == 1:
          diffInfo += "    EDL "
          diffInfo += bool2str( str2bool( str(get_numbers(config["EDL"]["ACTIVE"])) ))

    # diffInfo += '\n'
    config.read_string(ACD_FILE.get_file("suspensions.ini"))
    sf=''
    sr=''
    if config.has_section("FRONT"):
      if config.has_option("FRONT", "TYPE"):
        sf=config["FRONT"]["TYPE"]
    if config.has_section("REAR"):
      if config.has_option("REAR", "TYPE"):
        sr=config["REAR"]["TYPE"]

    if sf==sr:
      diffInfo += "    Susp: " + str(sf)
    else:
      diffInfo += "    Susp f/r: " + str(sf) + '/' + str(sr)

    # diffInfo += '\n'
    config.read_string(ACD_FILE.get_file("drivetrain.ini"))
    if config.has_section('GEARBOX'):
      if config.has_option('GEARBOX', 'SUPPORTS_SHIFTER'):
        if get_numbers(config["GEARBOX"]["SUPPORTS_SHIFTER"]) == 1:
          diffInfo += '    Shifter'
        else:
          diffInfo += '    Paddles'
    # if config.has_section("DIFFERENTIAL"):
    #   if config.has_option("DIFFERENTIAL", "POWER"):
    #     d = get_numbers(config["DIFFERENTIAL"]["POWER"])
    #     diffInfo += "    DIFF " + str(round(float(d)*100, 2))+'%'
    # if config.has_section("AWD"):
    #   if config.has_option("AWD", "REAR_DIFF_POWER"):
    #     d = get_numbers(config["AWD"]["REAR_DIFF_POWER"])
    #     diffInfo += "    AWD diff " + str(round(float(d)*100, 2))+'%'
    # if config.has_section("AWD2"):
    #   if config.has_option("AWD2", "REAR_DIFF_POWER"):
    #     d = get_numbers(config["AWD2"]["REAR_DIFF_POWER"])
    #     diffInfo += "    AWD2 diff " + str(round(float(d)*100, 2))+'%'

    sturbo += diffInfo



    # trackname = ac.getTrackName(0)
    # layout    = ac.getTrackConfiguration(0)
    # if layout!=trackname:
    #   trackname = trackname + ' / ' + layout

    sCarSpecs1 = ( ''  ### trackname + '\n'
                  + carname + ' (' + carnamedir + ')\n'
                  + str(jsonDetails) ##+ '\n'
                  + str(maxPowerJSON2) + ' PS - ' + str(int(maxTorque)) + ' Nm - '
                  + driveType + ' - ' + str(gearcount) + ' gears - '
                  + str( math.floor(float(carmass)) ) + 'Kg - '
                  + str( round((float(carmass)-75)/maxPowerSAVED, 2))
                  + 'kg/HP'
                  + str(rpmInfo)
                  + '\nTyres: ' + 'V' + str(tyresVersion) + '  -  ' + tirename + ' (' + tirenameShort + ')' + '\n'
                  + sTyres
                )

    sCarSpecs2 = (
          '\nMax. Brake Torque: '+ str(int(torqueBrake)) + ' Nm'
        + '    Handbrake ratio: ' + str(round(torquehandBrakeRatio,1)) + ' %'
        + '\nEngine brake: '     + str(int(engineBrake)) + ' Nm'
        + '    SteerLock: ' + str(carsteerlock)
        + '    FFB-Mult: ' +  str(carffbmult) + 'x'
        #+ '\nEngine brake: '     + str( round(ac.getCarState(currentCar, acsys.CS.EngineBrake),1) )
        #+ '\nEngine brake: '     + str( round(info.physics.engineBrake,1) )
        + str(sturbo) + str(sturboJson)
        )

    # engine.ini
    extraTEnabled = False
    if bExtraTorqueAvail:
      config.read_string(ACD_FILE.get_file("car.ini"))
      if config.has_section("HEADER"):
        if config.has_option("HEADER", "VERSION"):
          extraTEnabled = bool("extended" in str(config["HEADER"]["VERSION"]).lower())
          if extraTEnabled:
            config.read_string(ACD_FILE.get_file("engine.ini"))
            if config.has_section("_EXTENSION"):
              if config.has_option("_EXTENSION", "PYTHON_TORQUE_ALLOWED"):
                extraTEnabled = bool(config["_EXTENSION"]["PYTHON_TORQUE_ALLOWED"])
                #ac.log('CarSpecs: ' + str(config["_EXTENSION"]["PYTHON_TORQUE_ALLOWED"]) )
                ac.log('CarSpecs:   PYTHON_TORQUE_ALLOWED = ' + str(extraTEnabled) )
              else:
                extraTEnabled = False
            else:
              extraTEnabled = False

    # ac.log('--------' + str(powcurPOWPOW))

    #   if maxPower<max(powcurPOWPOW):
    #     #     maxPower = max(powcurPOWPOW)
    #     rtio = maxPower/float(maxPowerJson)
    #     for i in range(len(powcurPOWPOW)):
    #       powcurPOWPOW[i] = powcurPOWPOW[i] * rtio
    #     ac.log(str(powcurPOWPOW))















    ### debug out
    if False:
    #if True:
      # ac.log(str(powcurPOWRPM))
      # ac.log(str(powcurPOWPOW))
      # ac.log(str(powcurTORTOR))
      # ac.log(str(powcurTORRPM))
      ac.log('maxRPM  ' + str(maxRpm) + '  |  ' + '  turbo  ' + str(sturbo)
           + '\nmaxTurboBoost  ' + str(maxTurboBoost)
           + '\nmaxTorque  ' + str(maxTorque) + '  |  maxPower: ' + str(maxPower)
           + '\nlimiter  ' + str(rpmLimiter) + '  |  damage  ' + str(rpmDamage)
            )
      ac.log('json maxTorque : ' + str(maxTorqueJson) + ' NM  |  maxPower: ' + str(maxPowerJson) + ' PS ')
      ac.log('json2 maxTorque : ' + str(maxTorqueJSON2) + ' NM  |  maxPower: ' + str(maxPowerJSON2) + ' PS ')

    ac.log('---CarSpecs app loaded---')
    ac.setText(lbCarSpecs1, sCarSpecs1)
    ac.setText(lbCarSpecs2, str(sCarSpecs2).strip())
    appResize()
    ### on_click_app_window(0,0)
  except:
    ac.log('CarSpecs app: \n' +traceback.format_exc())

#########################################################

def onVerticalClick(*args):
    global bVertical
    bVertical = not bVertical
    appResize()

def onDopeClick(*args):
    global DOPEMODE
    DOPEMODE = not DOPEMODE
    on_click_app_window(0,0)

def onConnectedClick(*args):
    global gCURVESCONNECTED
    gCURVESCONNECTED = not gCURVESCONNECTED
    on_click_app_window(0,0)

def onFancyClick(*args):
    global FANCYMODE
    FANCYMODE = not FANCYMODE
    if FANCYMODE:
        ac.setVisible(btnCurvesWidthUp     , 1)
        ac.setVisible(btnCurvesWidthDn     , 1)
        ac.setVisible(cbConnected     , 1)
        ac.setVisible(cbDope     , 1)
        ac.setVisible(btnCurvesSpeedUp     , 1)
        ac.setVisible(btnCurvesSpeedDn     , 1)
    else:
        ac.setVisible(btnCurvesWidthUp     , 0)
        ac.setVisible(btnCurvesWidthDn     , 0)
        ac.setVisible(cbConnected     , 0)
        ac.setVisible(cbDope     , 0)
        ac.setVisible(btnCurvesSpeedUp     , 0)
        ac.setVisible(btnCurvesSpeedDn     , 0)
    appResize()

def onVerticalClickTextPower(*args):
    global gShowTextPower
    gShowTextPower = not gShowTextPower
    #ac.console(str(gShowTextPower))
    appResize()

def onVerticalClickTextAero(*args):
    global gShowTextAero
    gShowTextAero = not gShowTextAero
    #ac.console(str(gShowTextAero))
    appResize()

def resetmaxvalues():
    global maxFFB, dCurvesMaxes
    maxFFB = 0.0
    for i, m in enumerate(dCurvesMaxes):
        dCurvesMaxes[i]=0.0

def onVerticalClickTextCurves(*args):
    global gShowTextCurves, maxFFB
    gShowTextCurves = not gShowTextCurves
    # ac.console(str(gShowTextCurves))
    resetmaxvalues()
    appResize()

def appresetmax(*args):
    resetmaxvalues()
    appHideControls()

def uppeakholdtime(*args):
    global peakholdtime
    peakholdtime = float(int( clamp(peakholdtime+1,0, 10)))
    #resetmaxvalues()
    on_click_app_window(0,0)
    # appResize()
def dnpeakholdtime(*args):
    global peakholdtime
    peakholdtime = float(int( clamp(peakholdtime-1,0, 10)))
    #resetmaxvalues()
    on_click_app_window(0,0)
    # appResize()


# power
def upOpacity(*args):
    global gOPACITYPower
    gOPACITYPower = round( clamp(gOPACITYPower+0.1, 0.0,1.0) , 1)
    on_click_app_window(0,0)
    # appResize()
def downOpacity(*args):
    global gOPACITYPower
    gOPACITYPower = round( clamp(gOPACITYPower-0.1, 0.0,1.0) , 1)
    on_click_app_window(0,0)
    # appResize()

def upAppsize(*args):
    global gAPPSIZEPower
    gAPPSIZEPower = round( clamp(gAPPSIZEPower+0.1, 0,4) , 1)
    appResize()
def downAppsize(*args):
    global gAPPSIZEPower
    gAPPSIZEPower = round( clamp(gAPPSIZEPower-0.1, 0.2,4) , 1)
    appResize()

def upAppPowerWUp(*args):
    global gGRAPHPowerWMult
    gGRAPHPowerWMult = round( clamp(gGRAPHPowerWMult+0.1, 0.2,4.0) , 1)
    appResize()
def downAppPowerWDn(*args):
    global gGRAPHPowerWMult
    gGRAPHPowerWMult = round( clamp(gGRAPHPowerWMult-0.1, 0.2,4.0) , 1)
    appResize()

def upAppPowerHUp(*args):
    global gGRAPHPowerHMult
    gGRAPHPowerHMult = round( clamp(gGRAPHPowerHMult+0.1, 0.2,4.0) , 1)
    appResize()
def downAppPowerHDn(*args):
    global gGRAPHPowerHMult
    gGRAPHPowerHMult = round( clamp(gGRAPHPowerHMult-0.1, 0.2,4.0) , 1)
    appResize()

# aero
def upOpacityAero(*args):
    global gOPACITYAero
    gOPACITYAero = round( clamp(gOPACITYAero+0.1, 0.0,1.0) , 1)
    on_click_app_window(0,0)
    # appResize()
def downOpacityAero(*args):
    global gOPACITYAero
    gOPACITYAero = round( clamp(gOPACITYAero-0.1, 0.0,1.0) , 1)
    on_click_app_window(0,0)
    # appResize()

def AupAppsize(*args):
    global gAPPSIZEAero
    gAPPSIZEAero = round( clamp(gAPPSIZEAero+0.1, 0,4) , 1)
    appResize()
def AdownAppsize(*args):
    global gAPPSIZEAero
    gAPPSIZEAero = round( clamp(gAPPSIZEAero-0.1, 0.2,4) , 1)
    appResize()

def AupAppPowerWUp(*args):
    global gGRAPHAeroWMult
    gGRAPHAeroWMult = round( clamp(gGRAPHAeroWMult+0.1, 0.2,4.0) , 1)
    appResize()
def AdownAppPowerWDn(*args):
    global gGRAPHAeroWMult
    gGRAPHAeroWMult = round( clamp(gGRAPHAeroWMult-0.1, 0.2,4.0) , 1)
    appResize()

def AupAppPowerHUp(*args):
    global gGRAPHAeroHMult
    gGRAPHAeroHMult = round( clamp(gGRAPHAeroHMult+0.1, 0.2,4.0) , 1)
    appResize()
def AdownAppPowerHDn(*args):
    global gGRAPHAeroHMult
    gGRAPHAeroHMult = round( clamp(gGRAPHAeroHMult-0.1, 0.2,4.0) , 1)
    appResize()

# curves
def upCurvesWidth(*args):
    global graphLineWidth2
    graphLineWidth2 = clamp(graphLineWidth2+1, 1,10.0)
    on_click_app_window(0,0)
    #appResize()
def dnCurvesWidth(*args):
    global graphLineWidth2
    graphLineWidth2 = clamp(graphLineWidth2-1, 1,10.0)
    on_click_app_window(0,0)
    #appResize()

def upSpeedWidth(*args):
    global updateTimerFast
    updateTimerFast = round(clamp(updateTimerFast+0.005, 0.005, 0.050),3)
    on_click_app_window(0,0)
    #appResize()
def dnSpeedWidth(*args):
    global updateTimerFast
    updateTimerFast = round(clamp(updateTimerFast-0.005, 0.005, 0.050),3)
    on_click_app_window(0,0)
    #appResize()

def upOpacityCurves(*args):
    global gOPACITYCurves
    gOPACITYCurves = round( clamp(gOPACITYCurves+0.1, 0.0,1.0) , 1)
    on_click_app_window(0,0)
    # appResize()
def downOpacityCurves(*args):
    global gOPACITYCurves
    gOPACITYCurves = round( clamp(gOPACITYCurves-0.1, 0.0,1.0) , 1)
    on_click_app_window(0,0)
    # appResize()

def CupAppsize(*args):
    global gAPPSIZECurves
    gAPPSIZECurves = round( clamp(gAPPSIZECurves+0.1, 0.0,4.0) , 1)
    appResize()
def CdownAppsize(*args):
    global gAPPSIZECurves
    gAPPSIZECurves = round( clamp(gAPPSIZECurves-0.1, 0.2,4.0) , 1)
    appResize()


def CupAppPowerWUp(*args):
    global gGRAPHCurvesWMult
    gGRAPHCurvesWMult = round( clamp(gGRAPHCurvesWMult+0.1, 0.2,10.0) , 1)
    appResize()
def CdownAppPowerWDn(*args):
    global gGRAPHCurvesWMult
    gGRAPHCurvesWMult = round( clamp(gGRAPHCurvesWMult-0.1, 0.2,10.0) , 1)
    appResize()

def CupAppPowerHUp(*args):
    global gGRAPHCurvesHMult
    gGRAPHCurvesHMult = round( clamp(gGRAPHCurvesHMult+0.1, 0.2,10.0) , 1)
    appResize()
def CdownAppPowerHDn(*args):
    global gGRAPHCurvesHMult
    gGRAPHCurvesHMult = round( clamp(gGRAPHCurvesHMult-0.1, 0.2,10.0) , 1)
    appResize()


###

def onbtnSwitchUseJson(*a):
    global PowerGraphMode, currentCar, btnPowerBG, path_v
    PowerGraphMode += 1
    if PowerGraphMode>2:
        PowerGraphMode=0
    if currentCar!=ac.getFocusedCar():
        currentCar=ac.getFocusedCar()
    carnamedir=str(ac.getCarName(currentCar))
    # ac.log(str(carnamedir))
    if carnamedir!='':
        if PowerGraphMode==0:
            if os.path.isfile(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_json.png'):
              ac.setBackgroundTexture(btnPowerBG, 'apps/python/CarSpecs/curves/' + carnamedir +'_json.png')
        elif PowerGraphMode==1:
            if os.path.isfile(path_v + 'apps/python/carspecs/curves/' + carnamedir +'_data.png'):
              ac.setBackgroundTexture(btnPowerBG, 'apps/python/CarSpecs/curves/' + carnamedir +'_data.png')
        else:
            ac.setBackgroundTexture(btnPowerBG, 'apps/python/CarSpecs/blanc.png')
    appResize()

def onbtn_Curve0ON(*a):
    global bCurve0ON
    bCurve0ON = not bCurve0ON
    appResize()

def onbtn_Curve1ON(*a):
    global bCurve1ON
    bCurve1ON = not bCurve1ON
    appResize()

def onbtn_Curve2ON(*a):
    global bCurve2ON
    bCurve2ON = not bCurve2ON
    appResize()

def onbtn_Curve3ON(*a):
    global bCurve3ON
    bCurve3ON = not bCurve3ON
    appResize()

def onbtn_Curve4ON(*a):
    global bCurve4ON
    bCurve4ON = not bCurve4ON
    appResize()

def onbtn_Curve5ON(*a):
    global bCurve5ON
    bCurve5ON = not bCurve5ON
    appResize()

def onbtn_Curve6ON(*a):
    global bCurve6ON
    bCurve6ON = not bCurve6ON
    appResize()

def onbtn_Curve7ON(*a):
    global bCurve7ON
    bCurve7ON = not bCurve7ON
    appResize()

def onbtn_Curve8ON(*a):
    global bCurve8ON, cspActiveHandbrake
    bCurve8ON = not bCurve8ON
    if not cspActiveHandbrake:
        bCurve8ON = False
    appResize()

def onbtn_Curve9ON(*a):
    global bCurve9ON
    bCurve9ON = not bCurve9ON
    appResize()
def onbtn_Curve10ON(*a):
    global bCurve10ON
    bCurve10ON = not bCurve10ON
    appResize()
def onbtn_Curve11ON(*a):
    global bCurve11ON
    bCurve11ON = not bCurve11ON
    appResize()

def onbtn_Curve12ON(*a):
    global bCurve12ON
    bCurve12ON = not bCurve12ON
    appResize()

def onbtn_Curve13ON(*a):
    global bCurve13ON
    bCurve13ON = not bCurve13ON
    appResize()

def onbtn_Curve14ON(*a):
    global bCurve14ON
    bCurve14ON = not bCurve14ON
    appResize()

def onbtn_Curve15ON(*a):
    global bCurve15ON
    bCurve15ON = not bCurve15ON
    appResize()

##########################################################

def upExtraTorque(*args):
    global TorqueExtraAmount, extraTEnabled
    if extraTEnabled and bExtraTorqueAvail:
        TorqueExtraAmount+=10
    appResize()

def downExtraTorque(*args):
    global TorqueExtraAmount, extraTEnabled
    if extraTEnabled:
        TorqueExtraAmount-=10
    appResize()

def appBoost():
    global bExtraTorqueAvail, extraT, extraTEnabled, bTorqueTimerOn, TorqueExtraAmount, TorqueTimerSteps, btnBoost
    if not extraTEnabled:
        return
    bTorqueTimerOn=True
    TorqueTimerSteps=0
    extraT+=TorqueExtraAmount
    ac.ext_setExtraTorque(extraT)

def onBoostClick(*args):
    global bTorqueTimerOn
    if bTorqueTimerOn==False:
        appBoost()

def appCreateLabel(app, desc, x=0, y=0, w=24, h=40, align="left", ftsize=12):
    l = ac.addLabel(app, desc)
    ac.setPosition(l, x, y)
    ac.setSize(l, w, h)
    ac.setFontAlignment(l,align)
    ac.setFontSize(l,ftsize)
    ac.setVisible(l, 1)
    return l

def appCreateButton(app, desc, x, y, w, h, fsize=12, align="center", fn=None):
    btn = ac.addButton(app, desc)
    ac.setPosition(btn, x,y)
    ac.setSize(btn, w, h)
    ac.setFontSize(btn, fsize)
    ac.setFontAlignment(btn, align)
    if fn!=None:
        ac.addOnClickedListener(btn, fn)
    return btn

def appCreateCheckbox(appWindow, text, value, x, y, width, height, visible=False, fn=None):
    newCB = ac.addCheckBox(appWindow, text)
    ac.setFontSize(newCB, 10)
    ac.setPosition(newCB, x, y)
    ac.setSize(newCB, width, height)
    ac.setValue(newCB, value)
    ac.setVisible(newCB, visible)
    if fn!=None:
        ac.addOnClickedListener(newCB, fn)
    return newCB

######################################

def drawBox(x, y, w, h, r, g, b):
    ac.glColor3f(r,g,b)
    ac.glBegin(0)
    ac.glVertex2f(x, y)
    ac.glVertex2f(x+w, y)
    ac.glVertex2f(x+w, y+h)
    ac.glVertex2f(x, y+h)
    ac.glVertex2f(x, y)
    ac.glVertex2f(x+1, y+1)
    ac.glVertex2f(x+w, y)
    ac.glVertex2f(x+w, y+h)
    ac.glVertex2f(x+1, y+h-1)
    ac.glVertex2f(x+1, y+1)
    ac.glEnd()

def appDrawTextShadow(t, x, y, sz=12, align=ExtGL.FONT_ALIGN_LEFT):
    global f1
    ac.ext_glFontUse(f1.f, t, x, y, sz, align)

def appDrawText(t, r, g, b, a, x, y, sz=12, align=ExtGL.FONT_ALIGN_LEFT, shadow=True):
    global f1
    if shadow:
        ac.ext_glFontColor(f1.f, 0.1, 0.1, 0.1, 1)
        appDrawTextShadow(t, x+1, y-1, sz, align)
        appDrawTextShadow(t, x-1, y-1, sz, align)
        appDrawTextShadow(t, x+1, y+1, sz, align)
        appDrawTextShadow(t, x+2, y+2, sz, align)
        #appDrawTextShadow(t, x-1, y+1, sz, align)
        #appDrawTextShadow(t, x-1, y  , sz, align)
        #appDrawTextShadow(t, x+1, y  , sz, align)
        # appDrawTextShadow(t, x+1, y-1, sz, align)
        #appDrawTextShadow(t, x+1, y+2, sz, align)
        #appDrawTextShadow(t, x+3, y+2, sz, align)
    ac.ext_glFontColor(f1.f, r, g, b, a)
    ac.ext_glFontUse(f1.f, t, x, y, sz, align)

# from tyres app/locked bars
#def appDrawLineCalced(r,g,b,a,x1,y1,x2,y2, width=2):
def appDrawLine0(r,g,b,a,x1,y1,x2,y2,width=2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Lines)
    ac.glVertex2f(    x1     , y1+max(1,width/2)-1)
    ac.glVertex2f(    x2     , y2-int(width/2)-1)
    for i in range(1,int(width)):
      ac.glVertex2f(  x1-i   , y1+max(1,width/2)-1+i)
      ac.glVertex2f(  x2-i   , y2-int(width/2)-1)
    if width>=2.0:
      ac.ext_glSetBlendMode(1)
      appDrawDot(r,g,b,a,x1,y1,max(1,width))
      appDrawDot(r,g,b,a,x2,y2,max(1,width))
    ac.glEnd()

def appDrawLine(x1,y1,x2,y2,width=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1        ,y1)
    ac.glVertex2f(x2-width/2,y2)
    ac.glVertex2f(x2        ,y2)
    ac.glVertex2f(x1+width/2,y1)
    ac.glEnd()

def appDrawLine3(x1,y1,x2,y2,height=4):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1         )
    ac.glVertex2f(x2,y2-height/2)
    ac.glVertex2f(x2,y2         )
    ac.glVertex2f(x1,y1+height/2)
    ac.glEnd()

def appDrawLine4(x1,y1,x2,y2):
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x1,y2)
    ac.glVertex2f(x2,y2)
    ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawLine5A(r,g,b,a,x1,y1,x2,y2,y3):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x1,y2)
    ac.glVertex2f(x2,y3)
    ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawLine5B(r,g,b,a,x1,y1,x2,y2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Triangles)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x2,y1)
    ac.glVertex2f(x2,y2)
    ac.glEnd()

# class GL:Lines,LineStrip,Triangles,Quads=range(4)

def appDrawLine5(r,g,b,a,x1,y1,x2,y2,y3):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Quads)
    global bVertical
    if bVertical:
        ac.glVertex2f(x1,y1)
        ac.glVertex2f(x2,y1)
        ac.glVertex2f(x2,y2)
        ac.glVertex2f(x1,y3)
    else:
        ac.glVertex2f(x1,y1)
        ac.glVertex2f(x1,y3)
        ac.glVertex2f(x2,y2)
        ac.glVertex2f(x2,y1)
    ac.glEnd()

def appDrawLine6(r,g,b,a,h,x1,x2,y1,y2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Quads)
    global bVertical
    if bVertical:
        ac.glVertex2f(h-x1,y1)
        ac.glVertex2f(h-x2,y2)
        ac.glVertex2f(h+x2,y2)
        ac.glVertex2f(h+x1,y1)
    else:
        ac.glVertex2f(h-x1,y1)
        ac.glVertex2f(h-x2,y2)
        ac.glVertex2f(h+x2,y2)
        ac.glVertex2f(h+x1,y1)
    ac.glEnd()

def appDrawLine6B(r,g,b,a,h,x1,x2,y1,y2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(h-x2,y2)
    ac.glVertex2f(h-x1,y1)
    ac.glVertex2f(h+x1,y1)
    ac.glVertex2f(h+x2,y2)
    ac.glEnd()

def appDrawLine7(r,g,b,a,h,x1,x2,y1,y2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(h-x1,y1)
    ac.glVertex2f(h+x1,y1)
    ac.glVertex2f(h+x2,y2)
    ac.glVertex2f(h-x2,y2)
    ac.glEnd()

def appDrawLine8Tri(r,g,b,a,x1,x2,y1,y2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Triangles)
    ac.glVertex2f(x2,y1)
    ac.glVertex2f(x1,y2)
    ac.glVertex2f(x2,y2)
    ac.glEnd()

def appDrawLine666(r,g,b,a,h,x1,x2,y1,y2):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Triangles)
    ac.glVertex2f(h-x1,y2)
    ac.glVertex2f(h+x1,y2)
    ac.glVertex2f(h   ,y1)
    ac.glEnd()
    #ac.glQuad(x-(triangleWidth/2),104-(triangleWidth + triangleWidth/2),triangleWidth,triangleWidth/2)

def appDrawLine2(r,g,b,a,x1,y1,width=10,height=10):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Quads)
    ac.glVertex2f(x1      ,y1)
    ac.glVertex2f(x1+width,y1)
    ac.glVertex2f(x1+width,y1+height)
    ac.glVertex2f(x1      ,y1+height)
    ac.glEnd()

###################################################

def appDrawLineTriHori(r,g,b,a,x1,y1,x2,height=4):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Triangles)
    ac.glVertex2f(x1        ,y1-height/2)
    ac.glVertex2f(x2        ,y1)
    ac.glVertex2f(x1        ,y1+height/2)
    ac.glEnd()

def appDrawLineTriVert(r,g,b,a,x1,y1,y2,width=4):
    ac.glColor4f(r,g,b,a)
    ac.glBegin(acsys.GL.Triangles)
    ac.glVertex2f(x1-width/2,y2)
    ac.glVertex2f(x1        ,y1)
    ac.glVertex2f(x1+width/2,y2)
    ac.glEnd()

###################################################

def appDrawLineDir0(r,g,b,a,x1,y1,x2,y2,width=2):
  ac.glBegin(acsys.GL.Quads)
  ac.glColor4f(r,g,b,a)
  ac.glVertex2f(x1-(width/2),y1-width/2)
  ac.glVertex2f(x2+min(1,width/2),y2-width/2)
  ac.glVertex2f(x2+min(1,width/2),y2+width/2)
  ac.glVertex2f(x1-(width/2),y1+width/2)
  ac.glEnd()

def appDrawLineDir1(r,g,b,a,x1,y1,x2,y2,width=2):
    ac.glBegin(acsys.GL.Quads)
    ac.glColor4f(r,g,b,a)
    dx=(x2 - x1)
    dy=(y2 - y1)
    m=dx/dy
    direction = ( -math.degrees( math.atan2(y1 - y2, x2 - x1)))
    dx1 = 0 # math.cos((-direction + 90) * math.pi / 180) * width/2
    dy1 = 0 # math.sin((-direction + 90) * math.pi / 180) * width
    dx2 = 1 # math.cos((-direction - 90) * math.pi / 180) * width/2
    dy2 = 0 # math.sin((-direction - 90) * math.pi / 180) * width

    if y1>y2:
        ac.glVertex2f(x1+(dx1/2), y1+dy1)
        ac.glVertex2f(x2+(dx1/2), y2+dy2)
        ac.glVertex2f(x2+(dx2/2), y2+dy2)
        ac.glVertex2f(x1+(dx2/2), y1+dy1)
    else:
        ac.glVertex2f(x1+(dx1/2), y1+dy1)
        ac.glVertex2f(x2+(dx1/2), y2+dy2)
        ac.glVertex2f(x2+(dx2/2), y2+dy2)
        ac.glVertex2f(x1+(dx2/2), y1+dy1)
    #ac.glVertex2f(x1-width/2,y1)
    #ac.glVertex2f(x2-width/2,y2)
    #ac.glVertex2f(x2+width/2,y2)
    #ac.glVertex2f(x1+width/2,y1)
    ac.glEnd()

def appDrawLineDirNew(r,g,b,a,x1,y1,x2,y2,width=1):
  ac.glColor4f(r,g,b,a)
  for i in range(int(width)):
    ac.glBegin(acsys.GL.Lines)
    if y1>y2:
      ac.glVertex2f(x1-i,y1+i)
      ac.glVertex2f(x2-i,y2)
    else:
      ac.glVertex2f(x1-i,y1)
      ac.glVertex2f(x2-i,y2+i)
    ac.glEnd()

def appDrawLineSpaced(r,g,b,a,x1,y1,x2,y2,width=1):
  if y1==y2:
    ac.glBegin(acsys.GL.Quads)
    ac.glColor4f(r,g,b,a)
    ac.glVertex2f(x1-width/3,y1-width/2)
    ac.glVertex2f(x2-width/3,y2+width/2)
    ac.glVertex2f(x2+width/3,y2+width/2)
    ac.glVertex2f(x1+width/3,y1-width/2)
    ac.glEnd()
  else:
    ac.glBegin(acsys.GL.Quads)
    ac.glColor4f(r,g,b,a)
    ac.glVertex2f(x1-width/3,y1-width/3)
    ac.glVertex2f(x2-width/3,y2+width/3)
    ac.glVertex2f(x2+width/3,y2+width/3)
    ac.glVertex2f(x1+width/3,y1-width/3)
    ac.glEnd()

# get vector of line: v :(x2 - x1, y2 - y1)
# normalize v: n 3- get orthogonal (normal) of the vector : o (easy in 2d)
# add and subtract o from the line's end and start point to get 4 corner points
def appDrawLineDir(r,g,b,a,x1,y1,x2,y2,width=1):
  #w=width/2
  #if abs(x1-x2)>abs(y1-y2):
  #if x1==x2:
  #  x1+=1
    #x2-=1
  #if y1==y2:

  if width<2:
  #if True:
    ac.glBegin(acsys.GL.Lines)
    ac.glColor4f(r,g,b,a)
    ac.glVertex2f(x1,y1)
    ac.glVertex2f(x2,y2)
    ac.glEnd()
  else:
    if y1==y2:
      #y2+=1
      ac.glBegin(acsys.GL.Quads)
      ac.glColor4f(r,g,b,a)
      ac.glVertex2f(x1-width/2,y1-width/2)
      ac.glVertex2f(x2-width/2,y2+width/2)
      ac.glVertex2f(x2+width/2,y2+width/2)
      ac.glVertex2f(x1+width/2,y1-width/2)
      ac.glEnd()
    else:
      if abs(y1-y2)<=2.0:
        ##pass
        if width>2:
          appDrawLineLEB0(r,g,b,a,x1,y1,x2,y2,width)
          #appDrawLineDir0(r,g,b,a,x1,y1,x2,y2,width)
        else:
          appDrawLineLEB0(r,g,b,a,x1,y1,x2,y2,width)
          #appDrawLineDir0(r,g,b,a,x1,y1,x2,y2,width)
      else:
        if abs(x1-x2)>2 and abs(y1-y2)>=3.0:
          #pass
          #appDrawLineDir1(r,g,b,a,x1,y1,x2,y2,width)
          appDrawLineLEB1(r,g,b,a,x1,y1,x2,y2,width)
        else:
          appDrawLineDirNew(r,g,b,a,x1,y1,x2,y2,1)
          #appDrawLineLEB1(r,g,b,a,x1,y1,x2,y2,width)

  #s=-int(width/2)
  #for i in range(int(width)):
  #  ac.glBegin(acsys.GL.Lines)
  #  ac.glColor4f(r,g,b,a)
  #  ac.glVertex2f(x1+s,y1)
  #  ac.glVertex2f(x2,y2)
  #  ac.glEnd()
  #  s+=1



def appDrawLineLEB0(x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Lines)
  ac.glVertex2f(    x1     , y1)
  ac.glVertex2f(    x2     , y2)
  for i in range(1,int(width)):
    ac.glVertex2f(  x1, y1+i)
    ac.glVertex2f(  x2, y2+i)
  ac.glEnd()

def appDrawLineLEB1(x1,y1,x2,y2,width=4):
  ac.glBegin(acsys.GL.Lines)
  ac.glVertex2f(    x1     , y1)
  ac.glVertex2f(    x2     , y2)
  for i in range(1,int(width)):
    ac.glVertex2f(  x1+i, y1)
    ac.glVertex2f(  x2+i, y2)
  ac.glEnd()

def appDrawLineCalced(r,g,b,a,x1,y1,x2,y2, width=2):
    ac.ext_glSetBlendMode(1)
    #appDrawDot(r,g,b,a,x1,y1,max(1,width))
    appDrawDot(r,g,b,a,x2,y2,max(1,width))

    if gCURVESCONNECTED:
        # ac.ext_glSetBlendMode(1)
        #appDrawDot(r,g,b,a,x1,y1,max(1,width))
        # appDrawDot(r,g,b,a,x2,y2,max(1,width))
        if y1==y2:
            appDrawLineLEB0(x1,y1,x2,y2,width)
        elif x1==x2:
            appDrawLineLEB1(x1,y1,x2,y2,width)
        else:
            direction = ( -math.degrees( math.atan2(y1 - y2, x2 - x1)))
            dx1 = math.cos((-direction + 90) * math.pi / 180) * width*0.5
            dy1 = math.sin((-direction + 90) * math.pi / 180) * width*0.5
            dx2 = math.cos((-direction - 90) * math.pi / 180) * width*0.5
            dy2 = math.sin((-direction - 90) * math.pi / 180) * width*0.5
            ac.glBegin(acsys.GL.Quads)
            ac.glVertex2f(x1+dx1, y1-dy1)
            ac.glVertex2f(x2-dx2, y2+dy2)
            ac.glVertex2f(x2+dx2, y2-dy2)
            ac.glVertex2f(x1-dx1, y1+dy1)
            ac.glEnd()

        ### for debug draw corners
        #appDrawDot(0,10,0,1, x1+dx1, y1-dy1, 2)
        #appDrawDot(0,10,0,1, x2-dx2, y2+dy2, 2)
        #appDrawDot(0,10,0,1, x2+dx2, y2-dy2, 2)
        #appDrawDot(0,10,0,1, x1-dx1, y1+dy1, 2)
        #appDrawDot(1,1,1,1,x1, y1, 1, texture_dot)
        #appDrawDot(1,1,1,1,x2, y2, 1, texture_dot)
        #appDrawDot(r,g,b,a,x2-width/2, y2, width*10)

def appDrawDot(r,g,b,a,x1,y1,size):
    global texture_dot
    wh = size/2
    ac.glColor4f(r,g,b,a)
    ac.glQuadTextured(x1-wh, y1-wh, size, size, texture_dot)





######################################################

def appOnCarSpecsActivated(*args):
    global bHideTimerOn, hideTimer, appCarSpecs, lbTimer, labelTimerEnabled, bStartFlag
    labelTimerEnabled = False
    bStartFlag = False
    bHideTimerOn = True
    hideTimer = 5.0
    ac.setText(lbTimer, "")
    ac.setIconPosition(appCarSpecs, -30, 0)

def appOnPowerActivated(*args):
    global extraT, extraTEnabled, bHideTimerOn, hideTimer, appCurves, appPower, appCarSpecs, appAero
    global btnExtraTUp, btnExtraTDn, btnAppPowerSizeDn, btnAppPowerSizeUp, btnOpacityDn, btnOpacityUp, btnBoost
    global btnAppPowerHDn, btnAppPowerHUp, btnAppPowerWDn, btnAppPowerWUp, cbVertical, btnOpacityUpAero, btnOpacityDnAero, btnOpacityUpCurves, btnOpacityDnCurves, btnCurvesWidthUp, btnCurvesWidthDn
    global cbTextPower, cbTextAero, cbTextCurves, btnSwitchUseJson
    bHideTimerOn = True
    hideTimer = 5.0
    # off!
    ac.setVisible(cbVertical       , 1)
    ac.setIconPosition(appPower   , -30, 0)
    ac.setTitle(appPower, "Power")
    ac.setVisible(btnAppPowerSizeDn, 1)
    ac.setVisible(btnAppPowerSizeUp, 1)
    ac.setVisible(btnOpacityDn     , 1)
    ac.setVisible(btnOpacityUp     , 1)
    ac.setVisible(btnAppPowerHDn   , 1)
    ac.setVisible(btnAppPowerHUp   , 1)
    ac.setVisible(btnAppPowerWDn   , 1)
    ac.setVisible(btnAppPowerWUp   , 1)
    ac.setVisible(cbTextPower      , 1)
    ac.setVisible(btnSwitchUseJson , 1)
    if not extraTEnabled:
        ac.setVisible(btnExtraTDn, 0)
        ac.setVisible(btnExtraTUp, 0)
        ac.setVisible(btnBoost   , 0)
    else:
        ac.setVisible(btnExtraTDn, 1)
        ac.setVisible(btnExtraTUp, 1)
        ac.setVisible(btnBoost   , 1)

def appOnCurvesActivated(*args):
    global cspActive, btn_Curve0ON, btn_Curve1ON, btn_Curve2ON, btn_Curve3ON, btn_Curve4ON, btn_Curve5ON, btn_Curve6ON, btn_Curve7ON, btn_Curve8ON, btn_Curve10ON, btn_Curve11ON, btn_Curve12ON, btn_Curve13ON, btn_Curve14ON, btn_Curve15ON, btn_Curve9ON
    global extraT, extraTEnabled, bHideTimerOn, hideTimer, appCurves
    global btnAppCurvesSizeDn, btnAppCurvesSizeUp, btnSwitchUseJson
    global btnAppCurvesHDn, btnAppCurvesHUp, btnAppCurvesWDn, btnAppCurvesWUp
    global btnOpacityDnCurves, btnOpacityUpCurves, btnCurvesWidthUp, btnCurvesWidthDn, bSHOW_ERS, btn_peakholdtimeUp, btn_peakholdtimeDn, btn_resetmax
    global cbFancy, cbTextPower, cbTextAero, cbTextCurves, FANCYMODE, cbConnected, cbDope, btnCurvesSpeedUp, btnCurvesSpeedDn
    bHideTimerOn = True
    hideTimer = 5.0
    ac.setIconPosition(appCurves   , -30, 0)
    ac.setTitle(appCurves, "")
    if cspActive:
        ac.setVisible(cbFancy          , 1)
    else:
        ac.setVisible(cbFancy          , 0)
    ac.setVisible(cbTextCurves     , 1)
    if FANCYMODE and cspActive:
        ac.setVisible(btnCurvesWidthUp, 1)
        ac.setVisible(btnCurvesWidthDn, 1)
        ac.setVisible(cbConnected, 1)
        ac.setVisible(cbDope, 1)
        ac.setVisible(btnCurvesSpeedUp     , 1)
        ac.setVisible(btnCurvesSpeedDn     , 1)
    else:
        ac.setVisible(cbConnected, 0)
        ac.setVisible(cbDope, 0)
        ac.setVisible(btnCurvesWidthUp, 0)
        ac.setVisible(btnCurvesWidthDn, 0)
        ac.setVisible(btnCurvesSpeedUp     , 0)
        ac.setVisible(btnCurvesSpeedDn     , 0)

    if maxTurboBoost>0.0:
        ac.setVisible(btn_Curve2ON, 1)

    ac.setVisible(btn_resetmax           , 1)
    ac.setVisible(btn_peakholdtimeUp     , 1)
    ac.setVisible(btn_peakholdtimeDn     , 1)
    ac.setVisible(btnOpacityDnCurves     , 1)
    ac.setVisible(btnOpacityUpCurves     , 1)
    ac.setVisible(btnAppCurvesSizeDn, 1)
    ac.setVisible(btnAppCurvesSizeUp, 1)
    ac.setVisible(btnAppCurvesHDn   , 1)
    ac.setVisible(btnAppCurvesHUp   , 1)
    ac.setVisible(btnAppCurvesWDn   , 1)
    ac.setVisible(btnAppCurvesWUp   , 1)
    ac.setVisible(btn_Curve0ON, 1)
    ac.setVisible(btn_Curve1ON, 1)
    ac.setVisible(btn_Curve3ON, 1)
    ac.setVisible(btn_Curve4ON, 1)
    ac.setVisible(btn_Curve5ON, 1)
    ac.setVisible(btn_Curve6ON, 1)
    ac.setVisible(btn_Curve7ON, 1)
    ac.setVisible(btn_Curve8ON, 1)
    if bSHOW_ERS and ERSMaxJ>0:
        ac.setVisible(btn_Curve9ON, 1)
        ac.setVisible(btn_Curve10ON, 1)
        ac.setVisible(btn_Curve11ON, 1)
    else:
        ac.setVisible(btn_Curve9ON, 0)
        ac.setVisible(btn_Curve10ON, 0)
        ac.setVisible(btn_Curve11ON, 0)
    ac.setVisible(btn_Curve12ON, 1)
    ac.setVisible(btn_Curve13ON, 1)
    ac.setVisible(btn_Curve14ON, 1)
    ac.setVisible(btn_Curve15ON, 1)

def appOnAeroActivated(*args):
    global bHideTimerOn, hideTimer, appAero, btnAppAeroSizeUp, btnAppAeroSizeDn, btnAppAeroHDn, btnAppAeroHUp, btnAppAeroWDn, btnAppAeroWUp
    global btnOpacityDnAero, btnOpacityUpAero, cbTextAero
    bHideTimerOn = True
    hideTimer = 5.0
    ac.setIconPosition(appAero    , -30, 0)
    ac.setTitle(appAero, "Aero ")
    ac.setVisible(cbTextAero       , 1)
    ac.setIconPosition(appAero    , -30, 0)
    ac.setVisible(btnOpacityDnAero, 1)
    ac.setVisible(btnOpacityUpAero, 1)
    ac.setVisible(btnAppAeroSizeUp, 1)
    ac.setVisible(btnAppAeroSizeDn, 1)
    ac.setVisible(btnAppAeroHDn   , 1)
    ac.setVisible(btnAppAeroHUp   , 1)
    ac.setVisible(btnAppAeroWDn   , 1)
    ac.setVisible(btnAppAeroWUp   , 1)

def appHideControls():
    global appPower, appAero, appCarSpecs, appCurves
    global btnExtraTUp, btnExtraTDn, btnAppPowerSizeDn, btnAppPowerSizeUp, btnOpacityDn, btnOpacityUp, btnBoost
    global btnAppPowerHDn, btnAppPowerHUp, btnAppPowerWDn, btnAppPowerWUp, btnAppAeroSizeUp, btnAppAeroSizeDn, btnAppAeroHDn, btnAppAeroHUp, btnAppAeroWDn, btnAppAeroWUp
    global btnAppCurvesHDn, btnAppCurvesHUp, btnAppCurvesWDn, btnAppCurvesWUp, btnAppCurvesSizeDn, btnAppCurvesSizeUp, cbVertical, btn_peakholdtimeUp, btn_peakholdtimeDn, btn_resetmax
    global btn_Curve0ON, btn_Curve1ON, btn_Curve2ON, btn_Curve3ON, btn_Curve4ON, btn_Curve5ON, btn_Curve6ON, btn_Curve7ON, btn_Curve8ON, btnOpacityUpAero, btnOpacityDnAero, btnOpacityUpCurves, btnOpacityDnCurves
    global btn_Curve9ON, btn_Curve10ON, btn_Curve11ON, btn_Curve12ON, btn_Curve13ON, btn_Curve14ON, btn_Curve15ON
    global cbFancy, cbTextPower, cbTextAero, cbTextCurves, btnCurvesWidthUp, btnCurvesWidthDn, cbDope, cbConnected, btnCurvesSpeedUp, btnCurvesSpeedDn
    global btnSwitchUseJson, gShowTextCurves
    ac.setBackgroundOpacity(appCarSpecs, 0.5 )
    ac.setBackgroundOpacity(appPower   , float(gOPACITYPower) )
    ac.setBackgroundOpacity(appAero    , float(gOPACITYAero) )
    ac.drawBorder(appCarSpecs, 0)
    ac.drawBorder(appPower   , 0)
    ac.drawBorder(appAero    , 0)
    ac.drawBorder(appCurves  , 0)
    if gShowTextCurves:
        ac.drawBackground(graphBG, 1)
        ac.drawBackground(appCurves, 1)
        ac.setBackgroundOpacity(appCurves, gOPACITYCurves )
    else:
        ac.drawBackground(graphBG, 0)
        ac.drawBackground(appCurves, 0)
        ac.setBackgroundOpacity(appCurves, 0 )

    if FANCYMODE:
        ac.setBackgroundOpacity(histGraph, gOPACITYCurves )
        ac.setBackgroundOpacity(graphBG, gOPACITYCurves )
    else:
        ac.setBackgroundOpacity(histGraph, 0 )
        ac.setBackgroundOpacity(graphBG, gOPACITYCurves )
    ac.setTitle(appCarSpecs, " ")
    ac.setTitle(appPower, " ")
    ac.setTitle(appAero, " ")
    ac.setIconPosition(appPower      , 0, -20000)
    ac.setIconPosition(appAero       , 0, -20000)
    ac.setIconPosition(appCarSpecs   , 0, -20000)
    ac.setIconPosition(appCurves     , 0, -20000)
    ac.setVisible(btnExtraTDn        , 0)
    ac.setVisible(btnExtraTUp        , 0)
    ac.setVisible(btnBoost           , 0)
    ac.setVisible(btnExtraTDn        , 0)
    ac.setVisible(btnExtraTUp        , 0)
    ac.setVisible(btnAppPowerSizeDn  , 0)
    ac.setVisible(btnAppPowerSizeUp  , 0)
    ac.setVisible(btnOpacityDn       , 0)
    ac.setVisible(btnOpacityUp       , 0)
    ac.setVisible(btnOpacityDnAero   , 0)
    ac.setVisible(btnOpacityUpAero   , 0)
    ac.setVisible(btnOpacityDnCurves , 0)
    ac.setVisible(btnOpacityUpCurves , 0)
    ac.setVisible(btn_resetmax       , 0)
    ac.setVisible(btn_peakholdtimeUp , 0)
    ac.setVisible(btn_peakholdtimeDn , 0)
    ac.setVisible(btnCurvesWidthUp   , 0)
    ac.setVisible(btnCurvesSpeedUp   , 0)
    ac.setVisible(btnCurvesSpeedDn   , 0)
    ac.setVisible(btnCurvesWidthDn   , 0)
    ac.setVisible(btnAppPowerHDn     , 0)
    ac.setVisible(btnAppPowerHUp     , 0)
    ac.setVisible(btnAppPowerWDn     , 0)
    ac.setVisible(btnAppPowerWUp     , 0)
    ac.setVisible(cbVertical         , 0)
    ac.setVisible(cbFancy            , 0)
    ac.setVisible(cbDope             , 0)
    ac.setVisible(cbConnected        , 0)
    ac.setVisible(cbTextPower        , 0)
    ac.setVisible(cbTextAero         , 0)
    ac.setVisible(cbTextCurves       , 0)
    ac.setVisible(btnAppAeroSizeUp   , 0)
    ac.setVisible(btnAppAeroSizeDn   , 0)
    ac.setVisible(btnAppAeroHDn      , 0)
    ac.setVisible(btnAppAeroHUp      , 0)
    ac.setVisible(btnAppAeroWDn      , 0)
    ac.setVisible(btnAppAeroWUp      , 0)
    ac.setVisible(btnAppCurvesSizeUp , 0)
    ac.setVisible(btnAppCurvesSizeDn , 0)
    ac.setVisible(btnAppCurvesHDn    , 0)
    ac.setVisible(btnAppCurvesHUp    , 0)
    ac.setVisible(btnAppCurvesWDn    , 0)
    ac.setVisible(btnAppCurvesWUp    , 0)
    ac.setVisible(btnSwitchUseJson, 0)
    ac.setVisible(btn_Curve0ON, 0)
    ac.setVisible(btn_Curve1ON, 0)
    ac.setVisible(btn_Curve2ON, 0)
    ac.setVisible(btn_Curve3ON, 0)
    ac.setVisible(btn_Curve4ON, 0)
    ac.setVisible(btn_Curve5ON, 0)
    ac.setVisible(btn_Curve6ON, 0)
    ac.setVisible(btn_Curve7ON, 0)
    ac.setVisible(btn_Curve8ON, 0)
    ac.setVisible(btn_Curve9ON, 0)
    ac.setVisible(btn_Curve10ON, 0)
    ac.setVisible(btn_Curve11ON, 0)
    ac.setVisible(btn_Curve12ON, 0)
    ac.setVisible(btn_Curve13ON, 0)
    ac.setVisible(btn_Curve14ON, 0)
    ac.setVisible(btn_Curve15ON, 0)

#########################################################

def acShutdown():
    global appSettingsPath, gOPACITYPower, gAPPSIZEPower, gGRAPHPowerWMult, gGRAPHPowerHMult, gGRAPHAeroHMult, gGRAPHAeroWMult, gAPPSIZEAero, gAPPSIZECurves, gGRAPHCurvesWMult, gGRAPHCurvesHMult, bVertical
    global bCurve0ON, bCurve1ON, bCurve2ON, bCurve3ON, bCurve4ON, bCurve5ON, bCurve6ON, bCurve7ON, bCurve8ON, updateTimerFast
    global gOPACITYAero, gOPACITYCurves, gShowTextPower, gShowTextAero, gShowTextCurves, FANCYMODE, graphLineWidth2, DOPEMODE, gCURVESCONNECTED
    global PowerGraphMode, bSHOW_ERS, cspActive, peakholdtime, rtIndex0, rtIndex1
    try:
        #ac.log('shut0')
        if cspActive and rtIndex0>0:
            ac.ext_disposeRenderTarget(rtIndex0)
            ac.ext_disposeRenderTarget(rtIndex1)

        config = ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_"), comment_prefixes=(";","#","/","_"))
        config.optionxform = str
        if os.path.isfile(appSettingsPath):
            config.read(appSettingsPath)
            if not config.has_section('GENERAL'):
                config.add_section('GENERAL')

        #updateTimerFast   = 0.01
        config['GENERAL']['UPDATETIMER']        = str(round(updateTimerFast,3))
        config['GENERAL']['POWERGRAPH_VERTICAL']= str(bVertical)
        config['GENERAL']['POWERAPPSIZE']       = str(round(gAPPSIZEPower    ,1))
        config['GENERAL']['POWERGRAPH_H_MULT']  = str(round(gGRAPHPowerHMult ,1))
        config['GENERAL']['POWERGRAPH_W_MULT']  = str(round(gGRAPHPowerWMult ,1))
        config['GENERAL']['CURVESGRAPH_H_MULT'] = str(round(gGRAPHCurvesHMult,1))
        config['GENERAL']['CURVESGRAPH_W_MULT'] = str(round(gGRAPHCurvesWMult,1))
        config['GENERAL']['AEROGRAPH_H_MULT']   = str(round(gGRAPHAeroHMult  ,1))
        config['GENERAL']['AEROGRAPH_W_MULT']   = str(round(gGRAPHAeroWMult  ,1))
        config['GENERAL']['CURVESAPPSIZE']      = str(round(gAPPSIZECurves   ,1))
        config['GENERAL']['AEROAPPSIZE']        = str(round(gAPPSIZEAero     ,1))
        config['GENERAL']['POWERGRAPH_OPACITY'] = str(round(gOPACITYPower    ,1))
        config['GENERAL']['AEROGRAPH_OPACITY']  = str(round(gOPACITYAero     ,1))
        config['GENERAL']['CURVESGRAPH_OPACITY']= str(round(gOPACITYCurves   ,1))
        config['GENERAL']['CURVESFANCYWIDTH']   = str(round(graphLineWidth2  ,1))

        if cspActive:
            config['GENERAL']['CURVESFANCY']= str(FANCYMODE)
        config['GENERAL']['PEAKHOLDTIME']= str(int(peakholdtime))
        config['GENERAL']['CURVESDOPE']= str(DOPEMODE)
        config['GENERAL']['CURVESCONNECTED']= str(gCURVESCONNECTED)
        config['GENERAL']['POWERTEXT']= str(gShowTextPower)
        config['GENERAL']['AEROTEXT']= str(gShowTextAero)
        config['GENERAL']['CURVESTEXT']= str(gShowTextCurves)
        config['GENERAL']['Curve0ON']= str(bCurve0ON)
        config['GENERAL']['Curve1ON']= str(bCurve1ON)
        config['GENERAL']['Curve2ON']= str(bCurve2ON)
        config['GENERAL']['Curve3ON']= str(bCurve3ON)
        config['GENERAL']['Curve4ON']= str(bCurve4ON)
        config['GENERAL']['Curve5ON']= str(bCurve5ON)
        config['GENERAL']['Curve6ON']= str(bCurve6ON)
        config['GENERAL']['Curve7ON']= str(bCurve7ON)
        config['GENERAL']['Curve8ON']= str(bCurve8ON)
        config['GENERAL']['Curve12ON']= str(bCurve12ON)
        config['GENERAL']['Curve13ON']= str(bCurve13ON)
        config['GENERAL']['Curve14ON']= str(bCurve14ON)
        config['GENERAL']['Curve15ON']= str(bCurve15ON)
        if bSHOW_ERS and ERSMaxJ>0:
            config['GENERAL']['Curve9ON']= str(bCurve9ON)
            config['GENERAL']['Curve10ON']= str(bCurve10ON)
            config['GENERAL']['Curve11ON']= str(bCurve11ON)

        config['GENERAL']['POWERGRAPH_MODE']= str(PowerGraphMode)

        with open(appSettingsPath, 'w') as configfile:
            config.write(configfile, space_around_delimiters=False)
        #ac.log('shut4')
    except:
        ac.log('CarSpecs app: \n' +traceback.format_exc())

def getSetting(cfgdef, cfg, sect, value, valdef):
    res = valdef
    try:
        if cfgdef.has_option(sect, value):
            res = cfgdef[sect][value]
            if ';' in res:
                res = res.split(';')[0]
            if cfg.has_option(sect, value):
                res = cfg[sect][value]
                if ';' in res:
                    res = res.split(';')[0]
    except:
        ac.log('CarSpecs app: reading settings error ' + traceback.format_exc() )
    return str(res)

def acMain(ac_version):
    global gOPACITYPower, gAPPSIZEPower, gGRAPHAeroHMult, gGRAPHAeroWMult, gAPPSIZEAero, appCarSpecs, appAero, appCurves, appPower, lbTimer, lbCarSpecs1, lbCarSpecs2
    global btnExtraTUp, btnExtraTDn, btnAppPowerSizeDn, btnAppPowerSizeUp, btnOpacityDn, btnOpacityUp, btnBoost
    global fontname, f1, texture_dot, texture_dot2, texture_dotb, texture_dotb2, cspActive
    global btnAppPowerWUp, btnAppPowerWDn, btnAppPowerHUp, btnAppPowerHDn, gGRAPHPowerWMult, gGRAPHPowerHMult
    global btnAppAeroWUp, btnAppAeroWDn, btnAppAeroHUp, btnAppAeroHDn, btnAppAeroSizeDn, btnAppAeroSizeUp
    global btnAppCurvesWUp, btnAppCurvesWDn, btnAppCurvesHUp, btnAppCurvesHDn, btnAppCurvesSizeDn, btnAppCurvesSizeUp
    global lbAero, lbPowerRpm, lbPowerTorque, lbPowerPower, lbPowerTurbo, lbPowerExtra, lbG0, lbG1, lbG2, lbG3, lbG4, lbG5, lbG6, lbG7, lbG8
    global lbG9, lbG10, lbG11, lbG12, lbG13, lbG14, lbG15
    global gAPPSIZECurves, gGRAPHCurvesWMult, gGRAPHCurvesHMult, appSettingsPathDefault, appSettingsPath, cbVertical, bVertical
    global bNewTyreParams, bCPhysicsActive, btn_Curve0ON, btn_Curve1ON, btn_Curve2ON, btn_Curve3ON, btn_Curve7ON, btn_Curve8ON, btn_Curve4ON, btn_Curve5ON, btn_Curve6ON
    global btn_Curve9ON, btn_Curve10ON, btn_Curve11ON, btn_Curve12ON, btn_Curve13ON, btn_Curve14ON, btn_Curve15ON
    global bCurve0ON, bCurve1ON, bCurve2ON, bCurve3ON, bCurve4ON, bCurve5ON, bCurve6ON, bCurve7ON, bCurve8ON, btnSwitchUseJson, PowerGraphMode
    global bCurve9ON, bCurve10ON, bCurve11ON, bCurve12ON, lastCar, bCurve13ON, bCurve14ON, bCurve15ON
    global gOPACITYAero, gOPACITYCurves, gShowTextPower, gShowTextAero, gShowTextCurves, btnOpacityUpAero, btnOpacityDnAero, btnOpacityUpCurves, btnOpacityDnCurves
    global cbFancy, cbTextPower, cbTextAero, cbTextCurves, FANCYMODE, btnCurvesWidthUp, btnCurvesWidthDn, btnCurvesSpeedUp, btnCurvesSpeedDn
    global cbDope, cbConnected, gCURVESCONNECTED, DOPEMODE, graphLineWidth2, btnPowerBG, updateTimerFast
    global btn_resetmax, cspActiveHandbrake, btn_peakholdtimeUp, btn_peakholdtimeDn, peakholdtime, bSHOWINFO

    try:
        ac.initFont(0, fontname, 0, 0)
        ac.initFont(0, fontname, 0, 1)

        if not os.path.isdir('apps/python/CarSpecs/curves'):
            os.mkdir('apps/python/CarSpecs/curves')

        texture_dot   = ac.newTexture("apps/python/CarSpecs/gforce_dot4.png")
        texture_dot2  = ac.newTexture("apps/python/CarSpecs/gforce_dot4_2.png")
        texture_dotb  = ac.newTexture("apps/python/CarSpecs/gforce_dot4_3.png")
        texture_dotb2 = ac.newTexture("apps/python/CarSpecs/gforce_dot4_4.png")

        appCarSpecs = ac.newApp("CarSpecs")
        appAero     = ac.newApp("CarSpecs_Aero")
        appCurves   = ac.newApp("CarSpecs_Curves")
        appPower    = ac.newApp("CarSpecs_Power")
        createGraph()

        configdefault = ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_",","), comment_prefixes=(";","#","/","_",","))
        configdefault.optionxform = str
        configdefault.read(appSettingsPathDefault)

        config        = ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_",","), comment_prefixes=(";","#","/","_",","))
        config.optionxform = str
        if not os.path.isfile(appSettingsPath):
            config.add_section('GENERAL')
            items = configdefault.items('GENERAL')
            for item in items:
                if not '__' in item[0]:
                    res=item[1]
                    if ';' in res:
                        res=res.split(';')[0]
                    config.set('GENERAL', item[0], res)
            with open(appSettingsPath, 'w') as configfile:
                config.write(configfile, space_around_delimiters=False)
        else:
            config.read(appSettingsPath)

        #ac.log('a - \n' + str(configdefault))
        #ac.log('b - \n' + str(config))


        # zForce     = str2bool(  getSetting(configdefault, config, 'GENERAL', 'SHOWVERTICALG'    , str(zForce) ) )
        # texid      = int(       getSetting(configdefault, config, 'GENERAL', 'TEXTUREID', str(texid) ) )
        gOPACITYPower     =     float( getSetting(configdefault, config, 'GENERAL', 'POWERGRAPH_OPACITY' , str(gOPACITYPower) ) )
        gOPACITYAero      =     float( getSetting(configdefault, config, 'GENERAL', 'AEROGRAPH_OPACITY'  , str(gOPACITYAero) ) )
        gOPACITYCurves    =     float( getSetting(configdefault, config, 'GENERAL', 'CURVESGRAPH_OPACITY', str(gOPACITYCurves) ) )
        gAPPSIZEPower     =     float( getSetting(configdefault, config, 'GENERAL', 'POWERAPPSIZE'       , str(gAPPSIZEPower) ) )
        gGRAPHPowerWMult  =     float( getSetting(configdefault, config, 'GENERAL', 'POWERGRAPH_W_MULT'  , str(gGRAPHPowerWMult) ) )
        gGRAPHPowerHMult  =     float( getSetting(configdefault, config, 'GENERAL', 'POWERGRAPH_H_MULT'  , str(gGRAPHPowerHMult) ) )
        gAPPSIZEAero      =     float( getSetting(configdefault, config, 'GENERAL', 'AEROAPPSIZE'        , str(gAPPSIZEAero) ) )
        gGRAPHAeroWMult   =     float( getSetting(configdefault, config, 'GENERAL', 'AEROGRAPH_W_MULT'   , str(gGRAPHAeroWMult) ) )
        gGRAPHAeroHMult   =     float( getSetting(configdefault, config, 'GENERAL', 'AEROGRAPH_H_MULT'   , str(gGRAPHAeroHMult) ) )
        gAPPSIZECurves    =     float( getSetting(configdefault, config, 'GENERAL', 'CURVESAPPSIZE'      , str(gAPPSIZECurves) ) )
        gGRAPHCurvesWMult =     float( getSetting(configdefault, config, 'GENERAL', 'CURVESGRAPH_W_MULT' , str(gGRAPHCurvesWMult) ) )
        gGRAPHCurvesHMult =     float( getSetting(configdefault, config, 'GENERAL', 'CURVESGRAPH_H_MULT' , str(gGRAPHCurvesHMult) ) )
        peakholdtime      =     float( getSetting(configdefault, config, 'GENERAL', 'PEAKHOLDTIME', str(peakholdtime)))
        gShowTextPower    =  str2bool( getSetting(configdefault, config, 'GENERAL', 'POWERTEXT', str(gShowTextPower)))
        gShowTextAero     =  str2bool( getSetting(configdefault, config, 'GENERAL', 'AEROTEXT', str(gShowTextAero)))
        gShowTextCurves   =  str2bool( getSetting(configdefault, config, 'GENERAL', 'CURVESTEXT', str(gShowTextCurves)))

        bVertical         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'POWERGRAPH_VERTICAL', str(bVertical) ) )
        bSHOWINFO         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'SHOWINFO'           , bSHOWINFO ) )
        bCurve0ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve0ON', str(bCurve0ON)))
        bCurve1ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve1ON', str(bCurve1ON)))
        bCurve2ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve2ON', str(bCurve2ON)))
        bCurve3ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve3ON', str(bCurve3ON)))
        bCurve4ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve4ON', str(bCurve4ON)))
        bCurve5ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve5ON', str(bCurve5ON)))
        bCurve6ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve6ON', str(bCurve6ON)))
        bCurve7ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve7ON', str(bCurve7ON)))
        bCurve8ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve8ON', str(bCurve8ON)))
        bCurve9ON         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve9ON', str(bCurve9ON)))
        bCurve10ON        =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve10ON', str(bCurve10ON)))
        bCurve11ON        =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve11ON', str(bCurve11ON)))
        bCurve12ON        =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve12ON', str(bCurve12ON)))
        bCurve13ON        =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve13ON', str(bCurve13ON)))
        bCurve14ON        =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve14ON', str(bCurve14ON)))
        bCurve15ON        =  str2bool( getSetting(configdefault, config, 'GENERAL', 'Curve15ON', str(bCurve15ON)))
        PowerGraphMode    =  int( getSetting(configdefault, config, 'GENERAL', 'POWERGRAPH_MODE', str(PowerGraphMode)))

        ###########################

        updateTimerFast   =     float( getSetting(configdefault, config, 'GENERAL', 'UPDATETIMER'       , updateTimerFast ) )
        graphLineWidth2   =     float( getSetting(configdefault, config, 'GENERAL', 'CURVESFANCYWIDTH'  , graphLineWidth2 ) )
        FANCYMODE         =  str2bool( getSetting(configdefault, config, 'GENERAL', 'CURVESFANCY'       , FANCYMODE ) )
        DOPEMODE          =  str2bool( getSetting(configdefault, config, 'GENERAL', 'CURVESDOPE'        , DOPEMODE ) )
        gCURVESCONNECTED  =  str2bool( getSetting(configdefault, config, 'GENERAL', 'CURVESCONNECTED'   , gCURVESCONNECTED ) )

        btnPowerBG         = appCreateButton(appPower, "" , 0, 0, 100, 100)
        btnBoost           = appCreateButton(appPower, "*", -40, -80, 24, 40, 14, "center", onBoostClick      )
        btnExtraTUp        = appCreateButton(appPower, "˄",   0, -80, 24, 20, 14, "center", upExtraTorque     )
        btnExtraTDn        = appCreateButton(appPower, "˅",   0, -60, 24, 20, 14, "center", downExtraTorque   )
        btnOpacityUp       = appCreateButton(appPower, "˄",  40, -80, 24, 20, 14, "center", upOpacity         )
        btnOpacityDn       = appCreateButton(appPower, "˅",  40, -60, 24, 20, 14, "center", downOpacity       )

        btnAppPowerSizeUp  = appCreateButton(appPower, "˄",  80, -80, 24, 20, 14, "center", upAppsize         )
        btnAppPowerSizeDn  = appCreateButton(appPower, "˅",  80, -60, 24, 20, 14, "center", downAppsize       )
        btnAppPowerWUp     = appCreateButton(appPower, "<", 140, -60, 24, 20, 14, "center", downAppPowerWDn   )
        btnAppPowerWDn     = appCreateButton(appPower, ">", 180, -60, 24, 20, 14, "left"  , upAppPowerWUp     )
        btnAppPowerHUp     = appCreateButton(appPower, "˄", 160, -80, 24, 20, 14, "center", downAppPowerHDn   )
        btnAppPowerHDn     = appCreateButton(appPower, "˅", 160, -40, 24, 20, 14, "center", upAppPowerHUp     )
        btnSwitchUseJson   = appCreateButton(appPower, "j", 250, -30, 44, 20, 12, "left"  , onbtnSwitchUseJson)
        cbVertical         = appCreateCheckbox(appPower, "vertical", int(bVertical)    , 250, -100, 50, 20, True, onVerticalClick)
        cbTextPower        = appCreateCheckbox(appPower , "text" , int(gShowTextPower) , 250, -60, 50, 20, True, onVerticalClickTextPower)

        btnAppAeroSizeUp   = appCreateButton(appAero, "˄",  80, -80, 24, 20, 14, "center", AupAppsize         )
        btnAppAeroSizeDn   = appCreateButton(appAero, "˅",  80, -60, 24, 20, 14, "center", AdownAppsize       )
        btnAppAeroWUp      = appCreateButton(appAero, "<", 140, -60, 24, 20, 14, "center", AdownAppPowerWDn   )
        btnAppAeroWDn      = appCreateButton(appAero, ">", 180, -60, 24, 20, 14, "left"  , AupAppPowerWUp     )
        btnAppAeroHUp      = appCreateButton(appAero, "˄", 160, -80, 24, 20, 14, "center", AdownAppPowerHDn   )
        btnAppAeroHDn      = appCreateButton(appAero, "˅", 160, -40, 24, 20, 14, "center", AupAppPowerHUp     )
        btnOpacityUpAero   = appCreateButton(appAero, "˄",  40, -80, 24, 20, 14, "center", upOpacityAero         )
        btnOpacityDnAero   = appCreateButton(appAero, "˅",  40, -60, 24, 20, 14, "center", downOpacityAero       )
        cbTextAero         = appCreateCheckbox(appAero  , "text" , int(gShowTextAero)  , 250, -60, 50, 20, True, onVerticalClickTextAero)

        btn_resetmax       = appCreateButton(appCurves, "reset",    0,    -22, 100, 20, 14, "center", appresetmax)
        btn_peakholdtimeUp = appCreateButton(appCurves, "˄"    ,  -40, -80-25,  24, 20, 14, "center", uppeakholdtime)
        btn_peakholdtimeDn = appCreateButton(appCurves, "˅"    ,  -40, -60-25,  24, 20, 14, "center", dnpeakholdtime)
        btnOpacityUpCurves = appCreateButton(appCurves, "˄"    ,   40, -80-25,  24, 20, 14, "center", upOpacityCurves         )
        btnOpacityDnCurves = appCreateButton(appCurves, "˅"    ,   40, -60-25,  24, 20, 14, "center", downOpacityCurves       )
        btnAppCurvesSizeUp = appCreateButton(appCurves, "˄"    ,   80, -80-25,  24, 20, 14, "center", CupAppsize         )
        btnAppCurvesSizeDn = appCreateButton(appCurves, "˅"    ,   80, -60-25,  24, 20, 14, "center", CdownAppsize       )
        btnAppCurvesWUp    = appCreateButton(appCurves, "<"    ,  140, -60-25,  24, 20, 14, "center", CdownAppPowerWDn   )
        btnAppCurvesWDn    = appCreateButton(appCurves, ">"    ,  180, -60-25,  24, 20, 14, "left"  , CupAppPowerWUp     )
        btnAppCurvesHUp    = appCreateButton(appCurves, "˄"    ,  160, -80-25,  24, 20, 14, "center", CdownAppPowerHDn   )
        btnAppCurvesHDn    = appCreateButton(appCurves, "˅"    ,  160, -40-25,  24, 20, 14, "center", CupAppPowerHUp     )


        btn_Curve1ON=appCreateButton(appCurves,  "-",  40, -160, 28, 23, 14, "center", onbtn_Curve1ON)
        btn_Curve2ON=appCreateButton(appCurves,  "-",  80, -160, 28, 23, 14, "center", onbtn_Curve2ON)
        btn_Curve3ON=appCreateButton(appCurves,  "-", 120, -160, 28, 23, 14, "center", onbtn_Curve3ON)
        btn_Curve4ON=appCreateButton(appCurves,  "-", 160, -160, 28, 23, 14, "center", onbtn_Curve4ON)
        btn_Curve5ON=appCreateButton(appCurves,  "-", 200, -160, 28, 23, 14, "center", onbtn_Curve5ON)
        btn_Curve6ON=appCreateButton(appCurves,  "-", 240, -160, 28, 23, 14, "center", onbtn_Curve6ON)
        btn_Curve7ON=appCreateButton(appCurves,  "-", 280, -160, 28, 23, 14, "center", onbtn_Curve7ON)
        btn_Curve8ON=appCreateButton(appCurves,  "-", 320, -160, 28, 23, 14, "center", onbtn_Curve8ON)
        btn_Curve9ON=appCreateButton(appCurves,  "-", 360, -160, 28, 23, 14, "center", onbtn_Curve9ON)
        btn_Curve10ON=appCreateButton(appCurves, "-", 400, -160, 28, 23, 14, "center", onbtn_Curve10ON)
        btn_Curve11ON=appCreateButton(appCurves, "-", 440, -160, 28, 23, 14, "center", onbtn_Curve11ON)
        btn_Curve12ON=appCreateButton(appCurves, "-", 480, -160, 28, 23, 14, "center", onbtn_Curve12ON)
        btn_Curve13ON=appCreateButton(appCurves, "-", 520, -160, 28, 23, 14, "center", onbtn_Curve13ON)
        btn_Curve14ON=appCreateButton(appCurves, "-", 560, -160, 28, 23, 14, "center", onbtn_Curve14ON)
        btn_Curve15ON=appCreateButton(appCurves, "-", 600, -160, 28, 23, 14, "center", onbtn_Curve15ON)
        btn_Curve0ON=appCreateButton(appCurves,  "-",   0, -160, 28, 23, 14, "left"  , onbtn_Curve0ON)


        lbAero       = appCreateLabel(appAero , "", 0, 0)
        lbPowerRpm   = appCreateLabel(appPower, "", 0, 0)
        lbPowerTorque= appCreateLabel(appPower, "", 0, 0, align="right")
        lbPowerPower = appCreateLabel(appPower, "", 0, 0, align="right")
        lbPowerTurbo = appCreateLabel(appPower, "", 0, 0)
        lbPowerExtra = appCreateLabel(appPower, "", 0, 0, align="right")

        lbTimer      = appCreateLabel(appCarSpecs,"", 350,0,50,25,ftsize=14)
        lbCarSpecs1  = appCreateLabel(appCarSpecs,"", 0,0, align="center")
        lbCarSpecs2  = appCreateLabel(appCarSpecs,"", 0,0, align="center")

        lbG0         = appCreateLabel(appCurves  , "yellow"    ,   20, 10, align="center")
        lbG1         = appCreateLabel(appCurves  , "orange"    ,   90, 10, align="center")
        lbG2         = appCreateLabel(appCurves  , "blue"      ,  160, 10, align="center")
        lbG3         = appCreateLabel(appCurves  , "green"     ,  230, 10, align="center")
        lbG4         = appCreateLabel(appCurves  , "red"       ,  300, 10, align="center")
        lbG5         = appCreateLabel(appCurves  , "violett"   ,  370, 10, align="center")
        lbG6         = appCreateLabel(appCurves  , "redbright" ,  430, 10, align="center")
        lbG7         = appCreateLabel(appCurves  , "grey"      ,  500, 10, align="center")
        lbG8         = appCreateLabel(appCurves  , "aqua"      ,  570, 10, align="center")
        lbG9         = appCreateLabel(appCurves  , "redbright" ,  640, 10, align="center")
        lbG10        = appCreateLabel(appCurves  , "grey"      ,  710, 10, align="center")
        lbG11        = appCreateLabel(appCurves  , "aqua"      ,  780, 10, align="center")
        lbG12        = appCreateLabel(appCurves  , "dkgray"    ,  850, 10, align="center")
        lbG13        = appCreateLabel(appCurves  , "yellow"    ,  920, 10, align="center")
        lbG14        = appCreateLabel(appCurves  , "green/red" ,  990, 10, align="center")
        lbG15        = appCreateLabel(appCurves  , "gray"      , 1080, 10, align="center")

        cbTextCurves   = appCreateCheckbox(appCurves, "text - toggle to reset ALL max vals" , int(gShowTextCurves) , 250, -110, 50, 20, True, onVerticalClickTextCurves)
        cbFancy        = appCreateCheckbox(appCurves, "fancy", int(FANCYMODE)       , 250,  -80, 50, 20, True, onFancyClick)
        cbConnected    = appCreateCheckbox(appCurves, "lines", int(gCURVESCONNECTED), 250,  -55, 50, 20, True, onConnectedClick)
        cbDope         = appCreateCheckbox(appCurves, "dope" , int(DOPEMODE)        , 250,  -30, 50, 20, True, onDopeClick)
        btnCurvesWidthUp = appCreateButton(appCurves, "˄",  350, -80, 24, 20, 14, "center", upCurvesWidth)
        btnCurvesWidthDn = appCreateButton(appCurves, "˅",  350, -60, 24, 20, 14, "center", dnCurvesWidth)

        btnCurvesSpeedUp = appCreateButton(appCurves, "˄",  410, -80, 24, 20, 14, "center", upSpeedWidth)
        btnCurvesSpeedDn = appCreateButton(appCurves, "˅",  410, -60, 24, 20, 14, "center", dnSpeedWidth)


        ac.setCustomFont(lbAero       , fontname, 0, 0)
        ac.setCustomFont(lbPowerRpm   , fontname, 0, 0)
        ac.setCustomFont(lbPowerTorque, fontname, 0, 1)
        ac.setCustomFont(lbPowerPower , fontname, 0, 1)
        ac.setCustomFont(lbPowerTurbo , fontname, 0, 1)
        ac.setCustomFont(lbPowerExtra , fontname, 0, 1)

        ac.setBackgroundColor(btn_Curve0ON, colors[0][0], colors[0][1], colors[0][2])
        ac.setBackgroundColor(btn_Curve1ON, colors[1][0], colors[1][1], colors[1][2])
        ac.setBackgroundColor(btn_Curve2ON, colors[2][0], colors[2][1], colors[2][2])
        ac.setBackgroundColor(btn_Curve3ON, colors[3][0], colors[3][1], colors[3][2])
        ac.setBackgroundColor(btn_Curve4ON, colors[4][0], colors[4][1], colors[4][2])
        ac.setBackgroundColor(btn_Curve5ON, colors[5][0], colors[5][1], colors[5][2])
        ac.setBackgroundColor(btn_Curve6ON, colors[6][0], colors[6][1], colors[6][2])
        ac.setBackgroundColor(btn_Curve7ON, colors[7][0], colors[7][1], colors[7][2])
        ac.setBackgroundColor(btn_Curve8ON, colors[8][0], colors[8][1], colors[8][2])
        ac.setBackgroundColor(btn_Curve9ON, colors[9][0], colors[9][1], colors[9][2])
        ac.setBackgroundColor(btn_Curve10ON, colors[10][0], colors[10][1], colors[10][2])
        ac.setBackgroundColor(btn_Curve11ON, colors[11][0], colors[11][1], colors[11][2])
        ac.setBackgroundColor(btn_Curve12ON, colors[12][0], colors[12][1], colors[12][2])
        ac.setBackgroundColor(btn_Curve13ON, colors[13][0], colors[13][1], colors[13][2])
        ac.setBackgroundColor(btn_Curve14ON, colors[14][0], colors[14][1], colors[14][2])
        ac.setBackgroundColor(btn_Curve15ON, colors[15][0], colors[15][1], colors[15][2])
        ac.setText(lbG0, "")
        ac.setText(lbG1, "")
        ac.setText(lbG2, "")
        ac.setText(lbG3, "")
        ac.setText(lbG4, "")
        ac.setText(lbG5, "")
        ac.setText(lbG6, "")
        ac.setText(lbG7, "")
        ac.setText(lbG8, "")
        ac.setText(lbG9, "")
        ac.setText(lbG10, "")
        ac.setText(lbG11, "")
        ac.setText(lbG12, "")
        ac.setText(lbG13, "")
        ac.setText(lbG14, "")
        ac.setText(lbG15, "")

        # ac.addOnAppDismissedListener(appWindow, appOnClosed)
        ac.addOnClickedListener     (appCarSpecs, appOnCarSpecsActivated)
        ac.addOnAppActivatedListener(appCarSpecs, appOnCarSpecsActivated)
        ac.addOnClickedListener     (appPower   , appOnPowerActivated)
        ac.addOnAppActivatedListener(appPower   , appOnPowerActivated)
        ac.addOnClickedListener     (appAero    , appOnAeroActivated)
        ac.addOnAppActivatedListener(appAero    , appOnAeroActivated)
        ac.addOnClickedListener     (appCurves  , appOnCurvesActivated)
        ac.addOnAppActivatedListener(appCurves  , appOnCurvesActivated)

        ac.addRenderCallback        (appPower   , onFormRenderPower)
        ac.addRenderCallback        (appAero    , onFormRenderAero)
        ac.addRenderCallback        (appCurves  , onFormRenderCurves)

        ### this would fail on Vanilla AC...
        f1 = FontMeasures(fontname, 0, 0, 1.25, 0.69, 0.629, 0.616, 0.066)
        f1.f = ac.ext_glFontCreate(f1.n, f1.s, f1.i, f1.b)

        ### ...so we assume CSP is on
        cspActive = True

        ### now also testing for more
        bCPhysicsActive = False
        bNewTyreParams = False
        bCPhysicsActive = ac.ext_isExtendedPhysics()
        if bCPhysicsActive:
            if 'ext_getTyreTempMult' in dir(ac):
                bNewTyreParams = True

    except:
        cspActive = False
        ac.log('CarSpecs app: CSP not active')

    if not cspActive:
        FANCYMODE=False # only default kunos graph style with onle 1 pixel width lines
    bCurve8ON = cspActiveHandbrake and bCurve8ON

    # appCheckCarSpecs(0, ac.getCarName(0))
    lastCar=-1

    resetmaxvalues()
    appResize()
    appOnCurvesActivated()
    appHideControls()
    # appOnPowerActivated()
    # appOnAeroActivated()
    if bSHOWINFO:
        ac.setVisible(appCarSpecs, 1)
    else:
        ac.setVisible(appCarSpecs, 0)

    return "CarSpecs"

##########################################################################

def createGraph():
    global graphBG, histGraph, fpsBackgroundPath, fpsBackgroundFile, histGraphMinValue, histGraphMaxValue, gAPPSIZECurves

    try:
        graphBG = ac.addLabel(appCurves, "")
        histGraph = ac.addGraph(appCurves, "Curves")
        ac.drawBorder(histGraph, 0)
        ac.setVisible(histGraph, True)
        # ac.setRange(histGraph, histGraphMinValue, height-12*2*gAPPSIZEPower, 300)
        ac.addSerieToGraph(histGraph, colors[0][0] , colors[0][1] , colors[0][2])
        ac.addSerieToGraph(histGraph, colors[1][0] , colors[1][1] , colors[1][2])
        ac.addSerieToGraph(histGraph, colors[2][0] , colors[2][1] , colors[2][2])
        ac.addSerieToGraph(histGraph, colors[3][0] , colors[3][1] , colors[3][2])
        ac.addSerieToGraph(histGraph, colors[4][0] , colors[4][1] , colors[4][2])
        ac.addSerieToGraph(histGraph, colors[5][0] , colors[5][1] , colors[5][2])
        ac.addSerieToGraph(histGraph, colors[6][0] , colors[6][1] , colors[6][2])
        ac.addSerieToGraph(histGraph, colors[7][0] , colors[7][1] , colors[7][2])
        ac.addSerieToGraph(histGraph, colors[8][0] , colors[8][1] , colors[8][2])
        ac.addSerieToGraph(histGraph, colors[9][0] , colors[9][1] , colors[9][2])
        ac.addSerieToGraph(histGraph, colors[10][0], colors[10][1], colors[10][2])
        ac.addSerieToGraph(histGraph, colors[11][0], colors[11][1], colors[11][2])
        ac.addSerieToGraph(histGraph, colors[12][0], colors[12][1], colors[12][2])
        ac.addSerieToGraph(histGraph, colors[13][0], colors[13][1], colors[13][2])
        ac.addSerieToGraph(histGraph, colors[14][0], colors[14][1], colors[14][2])
        ac.addSerieToGraph(histGraph, colors[15][0], colors[15][1], colors[15][2])
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

#########################################################

def appResize():
    global cspActive, gAPPSIZEPower, gAPPSIZEAero, appPower, appAero, appCarSpecs, lbCarSpecs1, lbCarSpecs2, extralines, lbTimer
    global TorqueExtraAmount, graphWPower, graphHPower, gOPACITYPower, gGRAPHPowerWMult, gGRAPHPowerHMult, gGRAPHAeroHMult, gGRAPHAeroWMult
    global btnExtraTUp, btnExtraTDn, btnAppPowerSizeDn, btnAppPowerSizeUp, btnOpacityDn, btnOpacityUp, btnBoost
    global btnAppPowerWUp, btnAppPowerHDn, btnAppAeroSizeDn, btnAppAeroWUp, btnAppAeroHDn, graphWAero, graphHAero
    global graphHeight, graphWidth, histGraphMaxValue, histGraph, maxPower, maxTorque, ac_steer
    global lbAero, lbPowerRpm, lbPowerTorque, lbPowerPower, lbPowerTurbo, lbPowerExtra, extraTEnabled, maxTurboBoost, btnAppCurvesSizeDn, btnAppCurvesWDn, btnAppCurvesHDn
    global AEROaerospeed, AERODrag, AERODownforceF, AERODownforceR, AERODownforce, appCurves, gGRAPHCurvesWMult, gGRAPHCurvesHMult, graphWCurves, graphHCurves, gAPPSIZECurves
    global bCurve0ON, bCurve1ON, bCurve2ON, bCurve3ON, bCurve4ON, bCurve5ON, rtIndex0, rtFlag, rtIndex1
    global lbG0, lbG1, lbG2, lbG3, lbG4, lbG5, lbG6, lbG7, lbG8, dCurves, lbG13, lbG14, lbG15
    global lbG9, lbG10, lbG11, lbG12, currentCar
    global gOPACITYAero, gOPACITYCurves, gShowTextPower, gShowTextAero, gShowTextCurves, btnAppCurvesSizeUp, btnPowerBG
    global btn_Curve0ON, btn_Curve1ON, btn_Curve2ON, btn_Curve3ON, btn_Curve7ON, btn_Curve8ON, btn_Curve4ON, btn_Curve5ON, btn_Curve6ON
    global btn_Curve9ON, btn_Curve10ON, btn_Curve11ON, btn_Curve12ON, btn_Curve13ON, btn_Curve14ON, btn_Curve15ON
    # ac.log("gShowTextCurves resize" + str(gShowTextCurves))

    try:
        graphWPower  = int(340*gAPPSIZEPower *gGRAPHPowerWMult)
        graphHPower  = int(160*gAPPSIZEPower *gGRAPHPowerHMult)
        graphWAero   = int(340*gAPPSIZEAero  *gGRAPHAeroWMult)
        graphHAero   = int(160*gAPPSIZEAero  *gGRAPHAeroHMult)
        graphWCurves = int(340*gAPPSIZECurves*gGRAPHCurvesWMult)
        graphHCurves = int(160*gAPPSIZECurves*gGRAPHCurvesHMult)

        # dCurves
        dCurves  = [0.0] * (13+3)

        if cspActive:
            if rtIndex0 != -1:
                #ac.ext_clearRenderTarget(rtIndex0)
                ac.ext_disposeRenderTarget(rtIndex0)
                ac.ext_disposeRenderTarget(rtIndex1)
            # create memory image
            rtIndex0 = ac.ext_createRenderTarget(int(graphWCurves), int(graphHCurves), False)
            rtIndex1 = ac.ext_createRenderTarget(int(graphWCurves), int(graphHCurves), False)

        ac.setSize(appCarSpecs , 450, 160+(extralines+3) *22)
        ac.setSize(appAero     , graphWAero , graphHAero)
        ac.setSize(appPower    , graphWPower, graphHPower)
        ac.setSize(btnPowerBG  , graphWPower, graphHPower)


        fontSize = 12
        ac.setPosition(lbCarSpecs1       , 0, 0)
        ac.setPosition(lbCarSpecs2       , 0, 140 ) ###  (graphHPower+(7)*21*gAPPSIZEPower )/2 )
        ac.setSize(lbTimer     ,     graphWPower/2, 24)
        ac.setSize(lbCarSpecs1 , 450, 180)
        ac.setSize(lbCarSpecs2 , 450, 180)
        ac.setFontSize(lbCarSpecs1, fontSize+2)
        ac.setFontSize(lbCarSpecs2, fontSize  )

        fontSize = 12 * gAPPSIZECurves
        graphWidth = graphWCurves - 2
        graphHeight = graphHCurves - fontSize * 5.5

        # #######################################################################
        # #######################################################################
        # if len(powcurTORTOR)>0 and len(powcurPOWPOW)>0:
        #     maxPowerSAVED=max(100, max(powcurTORTOR), max(powcurPOWPOW))
        # else:
        #     maxPowerSAVED=max(100,max(maxTorque, maxPower))
        # #######################################################################
        # #######################################################################


        # #histGraphMaxValue = max(100, max( maxTorque, maxPower ) )
        # histGraphMaxValue = max(100, maxPowerSAVED )

        # ac.log('-------------  histGraphMaxValue             ' + str(histGraphMaxValue))

        ac.setVisible(graphBG, 1)
        ac.drawBorder(graphBG, 0)
        ac.setBackgroundColor(graphBG, 0.15,0.15,0.15)
        if FANCYMODE:
            ac.setVisible(histGraph, 0)
        else:
            ac.setVisible(histGraph, 1)
            ac.setSize(histGraph, graphWidth  , graphHeight )
            ac.setPosition(histGraph, 1, graphHCurves - graphHeight-1)
            ac.setRange(histGraph, 0, int(histGraphMaxValue), int(graphWidth))
            ac.setBackgroundColor(histGraph, 0.0, 0.0, 0.0)

        if maxTurboBoost>0.0:
          ac.setBackgroundTexture(graphBG, "apps/python/CarSpecs/line_turbo.png")
        else:
          ac.setBackgroundTexture(graphBG, "apps/python/CarSpecs/line.png")
        ac.setBackgroundColor(btnPowerBG, 0,0,0)
        ac.setBackgroundOpacity(btnPowerBG, 0)
        ac.drawBorder(btnPowerBG, 0)
        ac.drawBackground(btnPowerBG, 1)

        ###
        ac.setTitle(appCurves, "")
        ac.setSize(appCurves   , graphWCurves, graphHCurves)
        ac.setSize(graphBG     , graphWidth  , graphHeight )
        ac.setPosition(graphBG, 1, graphHCurves - graphHeight-1)

        w=42*gAPPSIZECurves
        gap=w*0.3
        x=gap

        if maxTurboBoost<=0.0:
            ac.setVisible(lbG2, 0)
        else:
            ac.setVisible(lbG2, bCurve2ON)

        ac.setVisible(lbG0, bCurve0ON)
        ac.setVisible(lbG1, bCurve1ON)
        ac.setVisible(lbG3, bCurve3ON)
        ac.setVisible(lbG4, bCurve4ON)
        ac.setVisible(lbG5, bCurve5ON)
        ac.setVisible(lbG6, bCurve6ON)
        ac.setVisible(lbG7, bCurve7ON)
        ac.setVisible(lbG8, bCurve8ON)
        if bSHOW_ERS and ERSMaxJ>0:
            ac.setVisible(lbG9, bCurve9ON)
            ac.setVisible(lbG10, bCurve10ON)
            ac.setVisible(lbG11, bCurve11ON)
        ac.setVisible(lbG12, bCurve12ON)
        ac.setVisible(lbG13, bCurve13ON)
        ac.setVisible(lbG14, bCurve14ON)
        ac.setVisible(lbG15, bCurve15ON)
        if bCurve0ON:
            ac.setPosition(lbG0,  x, 10)
            x=x+w+gap
        if bCurve1ON:
            ac.setPosition(lbG1,  x, 10)
            x=x+w+gap
        if maxTurboBoost>0.0:
            if bCurve2ON:
                ac.setPosition(lbG2,  x, 10)
                x=x+w+gap
        if bCurve3ON:
            ac.setPosition(lbG3,  x, 10)
            x=x+w+gap
        if bCurve4ON:
            ac.setPosition(lbG4,  x, 10)
            x=x+w+gap
        if bCurve5ON:
            ac.setPosition(lbG5,  x, 10)
            x=x+w+gap
        if bCurve6ON:
            ac.setPosition(lbG6,  x, 10)
            x=x+w+gap
        if bCurve7ON:
            ac.setPosition(lbG7,  x, 10)
            x=x+w+gap
        if bCurve8ON:
            ac.setPosition(lbG8,  x, 10)
            x=x+w+gap
        if bSHOW_ERS and ERSMaxJ>0:
            if bCurve9ON:
                ac.setPosition(lbG9,  x, 10)
                x=x+w+gap
            if bCurve10ON:
                ac.setPosition(lbG10,  x, 10)
                x=x+w+gap
            if bCurve11ON:
                ac.setPosition(lbG11,  x, 10)
                x=x+w+gap
        if bCurve12ON:
            ac.setPosition(lbG12,  x, 10)
            x=x+w+gap
        if bCurve13ON:
            ac.setPosition(lbG13,  x, 10)
            x=x+w+gap
        if bCurve14ON:
            ac.setPosition(lbG14,  x, 10)
            x=x+w+gap
        if bCurve15ON:
            ac.setPosition(lbG15,  x, 10)
            x=x+w+gap

        ##ac.log(str(gShowTextCurves))
        if not gShowTextCurves:
            ac.setVisible(lbG0, 0)
            ac.setVisible(lbG1, 0)
            ac.setVisible(lbG2, 0)
            ac.setVisible(lbG3, 0)
            ac.setVisible(lbG4, 0)
            ac.setVisible(lbG5, 0)
            ac.setVisible(lbG6, 0)
            ac.setVisible(lbG7, 0)
            ac.setVisible(lbG8, 0)
            ac.setVisible(lbG9, 0)
            ac.setVisible(lbG10, 0)
            ac.setVisible(lbG11, 0)
            ac.setVisible(lbG12, 0)
            ac.setVisible(lbG13, 0)
            ac.setVisible(lbG14, 0)
            ac.setVisible(lbG15, 0)

            x=0
            ac.setPosition(btn_Curve0ON      ,    x, -160)
            x=x+40
            ac.setPosition(btn_Curve1ON      ,    x, -160)
            x=x+40
            if maxTurboBoost>0.0:
                ac.setPosition(btn_Curve2ON  ,    x, -160)
                x=x+40
            ac.setPosition(btn_Curve3ON  ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve4ON  ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve5ON  ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve6ON  ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve7ON  ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve8ON  ,   x, -160)
            x=x+40
            if bSHOW_ERS and ERSMaxJ>0:
                ac.setPosition(btn_Curve9ON  ,   x, -160)
                x=x+40
                ac.setPosition(btn_Curve10ON ,   x, -160)
                x=x+40
                ac.setPosition(btn_Curve11ON ,   x, -160)
                x=x+40
            ac.setPosition(btn_Curve12ON ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve13ON ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve14ON ,   x, -160)
            x=x+40
            ac.setPosition(btn_Curve15ON ,   x, -160)


        ac.setSize(lbG0, w, 2)
        ac.setSize(lbG1, w, 2)
        ac.setSize(lbG2, w, 2)
        ac.setSize(lbG3, w, 2)
        ac.setSize(lbG4, w, 2)
        ac.setSize(lbG5, w, 2)
        ac.setSize(lbG6, w, 2)
        ac.setSize(lbG7, w, 2)
        ac.setSize(lbG8, w, 2)
        ac.setSize(lbG9, w, 2)
        ac.setSize(lbG10, w, 2)
        ac.setSize(lbG11, w, 2)
        ac.setSize(lbG12, w, 2)
        ac.setSize(lbG13, w, 2)
        ac.setSize(lbG14, w, 2)
        ac.setSize(lbG15, w, 2)
        ac.setFontSize(lbG0, fontSize-1)
        ac.setFontSize(lbG1, fontSize-1)
        ac.setFontSize(lbG2, fontSize-1)
        ac.setFontSize(lbG3, fontSize-1)
        ac.setFontSize(lbG4, fontSize-1)
        ac.setFontSize(lbG5, fontSize-1)
        ac.setFontSize(lbG6, fontSize-1)
        ac.setFontSize(lbG7, fontSize-1)
        ac.setFontSize(lbG8, fontSize-1)
        ac.setFontSize(lbG9, fontSize-1)
        ac.setFontSize(lbG10, fontSize-1)
        ac.setFontSize(lbG11, fontSize-1)
        ac.setFontSize(lbG12, fontSize-1)
        ac.setFontSize(lbG13, fontSize-1)
        ac.setFontSize(lbG14, fontSize-1)
        ac.setFontSize(lbG15, fontSize-1)
        ac.setBackgroundColor(lbG0, colors[0][0], colors[0][1], colors[0][2])
        ac.setBackgroundColor(lbG1, colors[1][0], colors[1][1], colors[1][2])
        ac.setBackgroundColor(lbG2, colors[2][0], colors[2][1], colors[2][2])
        ac.setBackgroundColor(lbG3, colors[3][0], colors[3][1], colors[3][2])
        ac.setBackgroundColor(lbG4, colors[4][0], colors[4][1], colors[4][2])
        ac.setBackgroundColor(lbG5, colors[5][0], colors[5][1], colors[5][2])
        ac.setBackgroundColor(lbG6, colors[6][0], colors[6][1], colors[6][2])
        ac.setBackgroundColor(lbG7, colors[7][0], colors[7][1], colors[7][2])
        ac.setBackgroundColor(lbG8, colors[8][0], colors[8][1], colors[8][2])
        ac.setBackgroundColor(lbG9, colors[9][0], colors[9][1], colors[9][2])
        ac.setBackgroundColor(lbG10, colors[10][0], colors[10][1], colors[10][2])
        ac.setBackgroundColor(lbG11, colors[11][0], colors[11][1], colors[11][2])
        ac.setBackgroundColor(lbG12, colors[12][0], colors[12][1], colors[12][2])
        ac.setBackgroundColor(lbG13, colors[13][0], colors[13][1], colors[13][2])
        ac.setBackgroundColor(lbG14, colors[14][0], colors[14][1], colors[14][2])
        ac.setBackgroundColor(lbG15, colors[15][0], colors[15][1], colors[15][2])
        ac.drawBackground(lbG0,1)
        ac.drawBackground(lbG1,1)
        ac.drawBackground(lbG2,1)
        ac.drawBackground(lbG3,1)
        ac.drawBackground(lbG4,1)
        ac.drawBackground(lbG5,1)
        ac.drawBackground(lbG6,1)
        ac.drawBackground(lbG7,1)
        ac.drawBackground(lbG8,1)
        ac.drawBackground(lbG9,1)
        ac.drawBackground(lbG10,1)
        ac.drawBackground(lbG11,1)
        ac.drawBackground(lbG12,1)
        ac.drawBackground(lbG13,1)
        ac.drawBackground(lbG14,1)
        ac.drawBackground(lbG15,1)
        ac.setBackgroundOpacity(lbG0,1)
        ac.setBackgroundOpacity(lbG1,1)
        ac.setBackgroundOpacity(lbG2,1)
        ac.setBackgroundOpacity(lbG3,1)
        ac.setBackgroundOpacity(lbG4,1)
        ac.setBackgroundOpacity(lbG5,1)
        ac.setBackgroundOpacity(lbG6,1)
        ac.setBackgroundOpacity(lbG7,1)
        ac.setBackgroundOpacity(lbG8,1)
        ac.setBackgroundOpacity(lbG9,1)
        ac.setBackgroundOpacity(lbG10,1)
        ac.setBackgroundOpacity(lbG11,1)
        ac.setBackgroundOpacity(lbG12,1)
        ac.setBackgroundOpacity(lbG13,1)
        ac.setBackgroundOpacity(lbG14,1)
        ac.setBackgroundOpacity(lbG15,1)


        fontSize = 12 * gAPPSIZEPower

        # ac.setPosition(lbPowerRpm    , graphWPower/3*2               , graphHPower-12*gAPPSIZEPower*2.5)
        # ac.setPosition(lbPowerTurbo  , graphWPower/2+graphWPower/6+10, graphHPower/2                 )
        ###ac.setPosition(lbPowerRpm    , graphWPower/3*2               , )
        ac.setPosition(lbPowerTurbo  , graphWPower/2+graphWPower/5+10, graphHPower-12*gAPPSIZEPower*2.5)
        ac.setPosition(lbPowerPower  , graphWPower/2-graphWPower/5-10,                                1)
        ac.setPosition(lbPowerTorque , graphWPower/2-graphWPower/5-10, graphHPower-12*gAPPSIZEPower*2.5)
        ac.setPosition(lbPowerExtra  , gAPPSIZEPower*12*4.5          , graphHPower/2                   )
        ac.setFontSize(lbPowerRpm    , gAPPSIZEPower*12*1.5)
        ac.setFontSize(lbPowerTorque , gAPPSIZEPower*12*2.00)
        ac.setFontSize(lbPowerPower  , gAPPSIZEPower*12*2.00)
        ac.setFontSize(lbPowerTurbo  , gAPPSIZEPower*12*2.00)
        ac.setFontSize(lbPowerExtra  , gAPPSIZEPower*12*2.00)

        ac.setPosition(lbAero        , 10,10)
        ac.setFontSize(lbAero        , gAPPSIZEAero*12*1.0)

        ac.setSize(   lbPowerRpm     , 10,10)
        ac.setSize(   lbPowerTorque  , 10,10)
        ac.setSize(   lbPowerPower   , 10,10)
        ac.setSize(   lbPowerTurbo   , 10,10)
        ac.setSize(   lbPowerExtra   , 10,10)
        ac.setSize(   lbAero         , 10,10)
        ac.setVisible(lbPowerRpm     , 0)

        ac.setFontColor(lbPowerRpm    , 1,1,1,1)
        ac.setFontColor(lbPowerTorque , 0.35, 0.35, 1.00, 1)  # 0.45, 0.50, 1.00, 1)
        ac.setFontColor(lbPowerPower  , 0.35, 1.00, 0.35, 1)  # 0.30, 0.80, 0.30, 1)
        ac.setFontColor(lbPowerTurbo  , 0.75, 0.35, 0.35, 1)  # 1.00, 0.75, 0.75, 1)
        ac.setFontColor(lbPowerExtra  , 0.75, 0.50, 0.25, 1)  # 1.00, 0.70, 0.40, 1)

        if currentCar!=ac.getFocusedCar():
            currentCar=ac.getFocusedCar()
            carnamedir=str(ac.getCarName(currentCar))
            # ac.log(str(carnamedir))
            if carnamedir!='':
                if PowerGraphMode==0:
                    ac.setBackgroundTexture(btnPowerBG, 'apps/python/CarSpecs/curves/' + carnamedir +'_json.png')
                elif PowerGraphMode==1:
                    ac.setBackgroundTexture(btnPowerBG, 'apps/python/CarSpecs/curves/' + carnamedir +'_data.png')
                else:
                    ac.setBackgroundTexture(btnPowerBG, 'apps/python/CarSpecs/blanc.png')

        on_click_app_window(0,0) # update
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )

####################################

def on_click_app_window(arg1, arg2):
    global gAPPSIZEPower, gAPPSIZEAero, appPower, appAero, appCarSpecs, lbCarSpecs1, lbCarSpecs2, extralines, lbTimer
    global TorqueExtraAmount, graphWPower, graphHPower, gOPACITYPower, gGRAPHPowerWMult, gGRAPHPowerHMult, gGRAPHAeroHMult, gGRAPHAeroWMult
    global btnExtraTUp, btnExtraTDn, btnAppPowerSizeDn, btnAppPowerSizeUp, btnOpacityDn, btnOpacityUp, btnBoost
    global btnAppPowerWUp, btnAppPowerHDn, btnAppAeroSizeDn, btnAppAeroWUp, btnAppAeroHDn, graphWAero, graphHAero
    global graphHeight, graphWidth, histGraphMaxValue, histGraph, maxPower
    global lbAero, lbPowerRpm, lbPowerTorque, lbPowerPower, lbPowerTurbo, lbPowerExtra, extraTEnabled, maxTurboBoost, btnAppCurvesSizeDn, btnAppCurvesWDn, btnAppCurvesHDn
    global AEROaerospeed, AERODrag, AERODownforceF, AERODownforceR, AERODownforce, appCurves, gGRAPHCurvesWMult, gGRAPHCurvesHMult, graphWCurves, graphHCurves, gAPPSIZECurves
    global bCurve0ON, bCurve1ON, bCurve2ON, bCurve3ON, bCurve4ON, bCurve5ON, rtIndex0, rtFlag, rtIndex1
    global lbG0, lbG1, lbG2, lbG3, lbG4, lbG5, lbG6, lbG7, lbG8, dCurves
    global lbG9, lbG10, lbG11, lbG12, peakholdtime, lbG13, lbG14, lbG15
    global gOPACITYAero, gOPACITYCurves, gShowTextPower, gShowTextAero, btnAppCurvesSizeUp
    global bHideTimerOn, hideTimer, btnCurvesSpeedDn, shiftleft, bSHOW_ERS, PowerGraphMode

    bHideTimerOn = True
    hideTimer = 5.0
    if gShowTextAero:
        ac.setVisible(lbAero,1)
    else:
        ac.setVisible(lbAero,0)

    shiftleft = 4 # max(1, int(graphLineWidth2 / 2))

    ac.setText(btnBoost          , 'boost\n'        + str(int(TorqueExtraAmount)))
    ac.setText(btnOpacityDn      , "˅\nopac\n"      + str(int(gOPACITYPower      *100))+'%')
    ac.setText(btnOpacityDnAero  , "˅\nopac\n"      + str(int(gOPACITYAero       *100))+'%')
    ac.setText(btnOpacityDnCurves, "˅\nopac\n"      + str(int(gOPACITYCurves     *100))+'%')
    if peakholdtime==0:
        ac.setText(btn_peakholdtimeDn, "˅\npeak hold time\noff")
    else:
        ac.setText(btn_peakholdtimeDn, "˅\npeak hold time\n" + str(int(peakholdtime))+'sec')
    ac.setText(btnAppPowerSizeDn , "˅\nsize\n "     + str(int(gAPPSIZEPower      *100))+'%')
    ac.setText(btnAppPowerWDn    , " >   W\n    "   + str(int(gGRAPHPowerWMult   *100))+'%')
    ac.setText(btnAppPowerHDn    , "˅\nH "          + str(int(gGRAPHPowerHMult   *100))+'%')
    ac.setText(btnAppAeroSizeDn  , "˅\nsize\n "     + str(int(gAPPSIZEAero       *100))+'%')
    ac.setText(btnAppAeroWDn     , " >   W\n    "   + str(int(gGRAPHAeroWMult    *100))+'%')
    ac.setText(btnAppAeroHDn     , "˅\nH "          + str(int(gGRAPHAeroHMult    *100))+'%')
    ac.setText(btnAppCurvesSizeDn, "˅\nsize\n "     + str(int(gAPPSIZECurves     *100))+'%')
    ac.setText(btnAppCurvesWDn   , " >   W\n    "   + str(int(gGRAPHCurvesWMult  *100))+'%')
    ac.setText(btnAppCurvesHDn   , "˅\nH "          + str(int(gGRAPHCurvesHMult  *100))+'%')
    ac.setText(btnCurvesWidthDn  , "˅\nwidth\n "    + str(int(graphLineWidth2        ))+'px')
    ac.setText(btnCurvesSpeedDn  , "˅\nupdate\n "   + str(int(updateTimerFast*1000   ))+'ms')
    if PowerGraphMode==0:
        ac.setText(btnSwitchUseJson, "json")
    elif PowerGraphMode==1:
        ac.setText(btnSwitchUseJson, "data")
    else:
        ac.setText(btnSwitchUseJson, "+gas")


    # KersCharge    = ac.getCarState(currentCar, acsys.CS.KersCharge)     *100  ### KersCharge
    # KersInput     = ac.getCarState(currentCar, acsys.CS.KersInput)      *100  ### KersInput
    # ERSCurrentKJ  = ac.getCarState(currentCar, acsys.CS.ERSCurrentKJ)         ### ERSCurrentKJ

    #  tor     pow     tur     gas     bra     ffb
    s=""
    if maxTurboBoost>0:
        if bSHOW_ERS and ERSMaxJ>0:
            s="tor     pow     tur     gas     bra     ffb     grip   steer  handb ersCrg ersInp ersEn  clutch  G-x     G-y     G-z"
        else:
            s="tor     pow     tur     gas     bra     ffb     grip   steer  handb clutch  G-x     G-y     G-z"
    else:
        if bSHOW_ERS and ERSMaxJ>0:
            s="tor     pow     gas     bra     ffb     grip   steer  handb ersCrg ersInp ersEn  clutch  G-x     G-y     G-z"
        else:
            s="tor     pow     gas     bra     ffb     grip   steer  handb clutch  G-x     G-y     G-z"
    if bCurve0ON:
        ac.setText(btn_Curve0ON, "On\n" + s)
    else:
        ac.setText(btn_Curve0ON, "Off\n" + s)

    if bCurve1ON:
        ac.setText(btn_Curve1ON, "ON")
    else:
        ac.setText(btn_Curve1ON, "off")
    if bCurve2ON:
        ac.setText(btn_Curve2ON, "ON")
    else:
        ac.setText(btn_Curve2ON, "off")
    if bCurve3ON:
        ac.setText(btn_Curve3ON, "ON")
    else:
        ac.setText(btn_Curve3ON, "off")
    if bCurve4ON:
        ac.setText(btn_Curve4ON, "ON")
    else:
        ac.setText(btn_Curve4ON, "off")
    if bCurve5ON:
        ac.setText(btn_Curve5ON, "ON")
    else:
        ac.setText(btn_Curve5ON, "off")
    if bCurve6ON:
        ac.setText(btn_Curve6ON, "ON")
    else:
        ac.setText(btn_Curve6ON, "off")
    if bCurve7ON:
        ac.setText(btn_Curve7ON, "ON")
    else:
        ac.setText(btn_Curve7ON, "off")
    if bCurve8ON:
        ac.setText(btn_Curve8ON, "ON")
    else:
        ac.setText(btn_Curve8ON, "off")
    if bCurve9ON:
        ac.setText(btn_Curve9ON, "ON")
    else:
        ac.setText(btn_Curve9ON, "off")
    if bCurve10ON:
        ac.setText(btn_Curve10ON, "ON")
    else:
        ac.setText(btn_Curve10ON, "off")
    if bCurve11ON:
        ac.setText(btn_Curve11ON, "ON")
    else:
        ac.setText(btn_Curve11ON, "off")
    if bCurve12ON:
        ac.setText(btn_Curve12ON, "ON")
    else:
        ac.setText(btn_Curve12ON, "off")
    if bCurve13ON:
        ac.setText(btn_Curve13ON, "ON")
    else:
        ac.setText(btn_Curve13ON, "off")
    if bCurve14ON:
        ac.setText(btn_Curve14ON, "ON")
    else:
        ac.setText(btn_Curve14ON, "off")
    if bCurve15ON:
        ac.setText(btn_Curve15ON, "ON")
    else:
        ac.setText(btn_Curve15ON, "off")

    if maxTurboBoost>0.0:
        ac.setVisible(lbPowerTurbo, 1)
    else:
        ac.setVisible(lbPowerTurbo, 0)

    if extraTEnabled:
        ac.setVisible(lbPowerExtra, 1)
    else:
        ac.setVisible(lbPowerExtra, 0)


#############################

def onFormRenderPower(deltaT):
    global texture_dot, texture_dot2, maxPower, gAPPSIZEPower, powcurPOWPOW, powcurPOWRPM, currentTorque, powcurTORRPM, powcurTORTOR
    global rpmDamage, rpmLimiter, powmaxrpm, rpmUpshift, rpmDownshift, graphWPower, graphHPower, rpmMAX
    global currentRPM, f1, currentGas, currTurboBoost, maxTurboBoost, currentPow
    global ersmaxrpmpow, ersmaxpowrpm, ersRPM, ersPOW, currBrake
    global cspActive, lbG0, lbG1, lbG2, lbG3, lbG4, lbG5, bVertical
    global maxPowerSAVED, maxRpmSAVED, bSHOW_ERS

    if maxPower==0.0 or rpmMAX == 0.0 or maxPowerSAVED==0.0: return

    if PowerGraphMode<2:
        #appDrawDot(1,0,0,1,currentRPM/rpmMAX*graphWPower, graphHPower-      currentPow    /(histGraphMaxValue)*(graphHPower-linewidth), 8 )
        #appDrawDot(1,1,0,1,currentRPM/rpmMAX*graphWPower, graphHPower-max(0,currentTorque)/(histGraphMaxValue)*(graphHPower-linewidth), 8 )
        if maxTurboBoost==0:
            appDrawDot(1,0,0,1,currentRPM/rpmMAX*graphWPower, graphHPower-      currentPow    /max(maxPower,maxTorque)*(graphHPower), 10 )
            appDrawDot(1,1,0,1,currentRPM/rpmMAX*graphWPower, graphHPower-max(0,currentTorque)/max(maxPower,maxTorque)*(graphHPower), 10 )
        else:
            appDrawDot(1,0,0,1,currentRPM/rpmMAX*graphWPower, graphHPower-      currentPow    /maxPowerSAVED*(graphHPower), 10 )
            appDrawDot(1,1,0,1,currentRPM/rpmMAX*graphWPower, graphHPower-max(0,currentTorque)/maxPowerSAVED*(graphHPower), 10 )
    else:
        x1=0
        y1=graphHPower
        xl=0
        yl=graphHPower
        a=0.9
        #ac.log(str(maxPowerSAVED))
        #ac.log('---')

        # first - (mostly) green power curve, from json or from power.lut
        currentPowLocal = 0.0   # somewhere down we get current Power value
        turboratio=1.0
        if maxTurboBoost>0.0 and currTurboBoost>0.01:
            turboratio=currTurboBoost/maxTurboBoost

        for i in range(len(powcurPOWRPM)-1):
            #if powcurPOWRPM[i]<=rpmMAX:

            if bVertical:
                x1 =                   powcurPOWRPM[i] /rpmMAX    * graphWPower
                if maxTurboBoost>0.0:
                    y1 = graphHPower - powcurPOWPOW[i] /maxPowerSAVED * graphHPower* maxTurboBoost*1.75
                else:
                    y1 = graphHPower - powcurPOWPOW[i] /maxPowerSAVED * graphHPower
            else:
                if maxTurboBoost>0.0:
                    x1 =               powcurPOWPOW[i] /maxPowerSAVED * graphWPower/2* maxTurboBoost*0.8
                else:
                    x1 =               powcurPOWPOW[i] /maxPowerSAVED * graphWPower/2
                y1 = graphHPower -     powcurPOWRPM[i] /rpmMAX    * graphHPower

            a=0.5       # default for background curve very transparent
            if i>0 and currentPowLocal==0.0 and powcurPOWRPM[i]>=currentRPM and powcurPOWRPM[i-1]!=0.0 and powcurPOWPOW[i-1]!=0.0:
                if not cspActive:
                    a=0.5   # current more transparent, compensate for not drawing text ontop of graph, its a label behind graph
                else:
                    a=0.9   # current very intransparent

                if maxTurboBoost>0.0:
                    currentPowLocal = powcurPOWPOW[i] * maxTurboBoost
                else:
                    currentPowLocal = powcurPOWPOW[i]
                # ac.console(str(int(currentPowLocal)))

                if bVertical:
                    yy  = yl+ ( (graphHPower-yl) * (1-currentGas) )
                    yy2 = y1+ ( (graphHPower-y1) * (1-currentGas) )
                    appDrawLine5( 0.5-currentPowLocal/maxPowerSAVED, currentPowLocal/maxPowerSAVED, 0.5-currentPowLocal/maxPowerSAVED/2, a, xl, graphHPower, x1, yy2, yy )
                else:
                    #xx = powcurPOWPOW[i]/maxTorque * graphWPower/2 * currentGas
                    appDrawLine6( 0.4, 1, 0.4, a , graphWPower/2, x1*currentGas, xl*currentGas, y1, max(y1+5,yl) )


            else:
                if bVertical:
                    appDrawLine5( 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, powcurPOWPOW[i]/maxPowerSAVED, 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, a/3*2, xl, graphHPower, x1, y1, yl )
                else:
                    appDrawLine6( 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, powcurPOWPOW[i]/maxPowerSAVED, 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, a/3*2,     graphWPower*1.0/2, x1, xl, y1, yl)

            xl = x1
            yl = y1
            ### remember values
            if (bVertical and xl>=graphWPower-2) or (not bVertical and yl<=0):
               break

        ### rest of graph
        if xl<=graphWPower:
            if currentPowLocal==0.0:
                ### draw rest when over then end highlighted, current RPM/power quite opaque
                a=0.9
                if bVertical:
                    appDrawLine5( 0.4, 1, 0.4, a, xl, graphHPower*1.0, graphWPower, y1+y1/2, yl)
                else:
                    appDrawLine6( 0.4, 1, 0.4, a, graphWPower*1.0/2, x1/4*3  , x1               , 0, yl)
            else:
                ### draw rest when over then end, quite transparent
                a=0.5
                if len(powcurPOWPOW)>0:
                    if bVertical:
                        appDrawLine5( 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, powcurPOWPOW[i]/maxPowerSAVED, 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, a/3*2,
                                    xl, graphHPower*1.0, graphWPower, y1+y1/2, yl)
                    else:
                        appDrawLine6( 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, powcurPOWPOW[i]/maxPowerSAVED, 0.5-powcurPOWPOW[i]/maxPowerSAVED/2, a/3*2,
                                    graphWPower/2, x1/4*3         , x1         , 0     , yl)

        ###### second - ~~blue torque Nm triangle~~
        # second - blue Power PS triangle
        if maxTorque>0.0 and currentTorque!=None:
            if currentTorque > maxTorque:
                # with boost enabled
                if bVertical:
                    x1 =   (currentTorque - maxTorque)/maxTorque* graphWPower
                    y1 = currentTorque / maxTorque             * graphHPower/2
                    yy = graphHPower - currentTorque/maxTorque * graphHPower/2
                    #blue until maxTorque
                    appDrawLine5B( 0, 0, 1, 0.5, 0, graphHPower, graphWPower, graphHPower/2)
                    #orange over maxTorque
                    appDrawLine5A( 1, 0.75, 0.35, 0.75, graphWPower, graphHPower, graphWPower+x1, graphHPower/2, yy)
                else:
                    x1 = currentTorque / maxTorque             * graphWPower/4
                    y1 = graphHPower - currentTorque/maxTorque * graphHPower
                    #blue until maxTorque
                    appDrawLine6( 0, 0, 1, 0.5       , graphWPower/2,             0, graphWPower/4, graphHPower, 0)
                    #orange over maxTorque
                    appDrawLine6( 1, 0.75, 0.35, 0.75, graphWPower/2, graphWPower/4, x1           , 0          , y1)
            else:
                # no extra boost enabled
                if bVertical:
                    x1 = currentTorque/maxTorque*graphWPower
                    if currentTorque < 0.0:
                        y1 = graphHPower - currentTorque/maxTorque * graphHPower/2
                        appDrawLine5A( 1-currentTorque/maxTorque*1.5, 1-currentTorque/maxTorque*1,  currentTorque/(maxTorque), 0.5, -x1, graphHPower, 0, graphHPower, graphHPower - (y1-graphHPower) )
                    else:
                        y1 = graphHPower - currentTorque/maxTorque * graphHPower/2
                        #appDrawLine5B( 1-currentTorque/maxTorque*1.5, 1-currentTorque/maxTorque*1,  currentTorque/(maxTorque), 0.5, 0, graphHPower, x1, y1)
                        appDrawLine5B( 1-currentTorque/maxTorque*1.5, 1-currentTorque/maxTorque*1,  currentTorque/(maxTorque), 0.5, 0, graphHPower, x1, y1)
                else:
                    x1 = currentTorque/maxTorque*graphWPower/2
                    y1 = currentTorque/maxTorque * graphHPower/2
                    if currentTorque < 0.0:
                        appDrawLine6( 1-currentTorque/maxTorque*1.5, 1-currentTorque/maxTorque*1, currentTorque/maxTorque, 0.5, graphWPower/2, 0, currentTorque/maxTorque*graphWPower/4, graphHPower+y1, graphHPower)
                    else:
                        #appDrawLine6( 1-currentTorque/maxTorque*1.5, 1-currentTorque/maxTorque*1, currentTorque/maxTorque, 0.5, graphWPower/2, 0, currentTorque/maxTorque*graphWPower/4, graphHPower, graphHPower- currentTorque/maxTorque*graphHPower)
                        appDrawLine6B( 1-currentTorque/maxTorque*1.5, 1-currentTorque/maxTorque*1, currentTorque/maxTorque, 0.5, graphWPower/2, 0, currentTorque/maxTorque*graphWPower/4, graphHPower, graphHPower- currentTorque/maxTorque*graphHPower)


    if bSHOW_ERS and ERSMaxJ>0:
        # third - ers power triangle in blue
        if KersInput>0:
            ratio=KersInput/100
            if bVertical:
                if PowerGraphMode==2:
                    appDrawLine5B( 0.75, 0.75, 1, 0.75, 0, graphHPower, graphWPower*ratio, graphHPower - graphHPower/3*ratio)
                else:
                    appDrawLine5B( 0.75, 0.75, 1, 0.75, 0, graphHPower, graphWPower*ratio, graphHPower - graphHPower/3*ratio)
            else:
                if PowerGraphMode==2:
                    appDrawLine8Tri( 0.75, 0.75, 1, 0.2+ratio*0.5, graphWPower-graphWPower/8, graphWPower, graphHPower, graphHPower-ratio*graphHPower)
                else:
                    appDrawLine8Tri( 0.75, 0.75, 1, 0.2+ratio*0.5, graphWPower-graphWPower/8, graphWPower, graphHPower, graphHPower-ratio*graphHPower)

    # forth - boost triangle on top in orange
    if maxTurboBoost>0.0 and currentTorque!=None: ###  and currTurboBoost>0.01
        turboratio=1.0
        turboratio=currTurboBoost/maxTurboBoost
        if bVertical:
            if PowerGraphMode==2:
                appDrawLine5B( 1, 0.5-turboratio/2, 0.5-turboratio/2, 0.2+turboratio*0.5, 0, graphHPower, graphWPower*turboratio, graphHPower - graphHPower/4*turboratio)
            else:
                appDrawLine5B( 0.5-turboratio/2, 0.5-turboratio/2, 1, 0.2+turboratio*0.5, 0, graphHPower, graphWPower*turboratio, graphHPower - graphHPower/4*turboratio)
        else:
            if PowerGraphMode==2:
                appDrawLine8Tri( 1, 0.5-turboratio/2, 0.5-turboratio/2, 0.2+turboratio*0.5, graphWPower-graphWPower/16, graphWPower, graphHPower, graphHPower-turboratio*graphHPower)
            else:
                appDrawLine8Tri( 0.5-turboratio/2, 0.5-turboratio/2, 1, 0.2+turboratio*0.5, graphWPower-graphWPower/16, graphWPower, graphHPower, graphHPower-turboratio*graphHPower)
        # boost text ie 1.5 x
        if cspActive and currentTorque!=None and gShowTextPower:
            if PowerGraphMode==2:
                appDrawText(str(round(currTurboBoost,2)) + ' x', 1.0, 0.65, 0.65, 1, graphWPower/6*5.5, graphHPower-12*gAPPSIZEPower*2, 12*gAPPSIZEPower*1.25, ExtGL.FONT_ALIGN_RIGHT)
            else:
                appDrawText(str(round(currTurboBoost,2)) + ' x', 0.65, 0.65, 1.0, 1, graphWPower/6*5.5, graphHPower-12*gAPPSIZEPower*2, 12*gAPPSIZEPower*1.25, ExtGL.FONT_ALIGN_RIGHT)



    if cspActive and gShowTextPower:
        # ps/nm text
        if currentTorque!=None:
            if PowerGraphMode==2:
                appDrawText(str(int(currentTorque)) + ' Nm', 0.5, 0.5, 1,  1, 12*gAPPSIZEPower*8 , graphHPower/2-12*gAPPSIZEPower*4, 12*gAPPSIZEPower*1.5, ExtGL.FONT_ALIGN_RIGHT)
            else:
                appDrawText(str(int(currentTorque)) + ' Nm', 1, 1, 0,      1, 12*gAPPSIZEPower*8 , graphHPower/2-12*gAPPSIZEPower*4, 12*gAPPSIZEPower*1.5, ExtGL.FONT_ALIGN_RIGHT)
        if PowerGraphMode==2:
            appDrawText(str(max(0,int(currentPow)))+' PS', 0.6, 1  , 0.6,  1, 12*gAPPSIZEPower*8 , graphHPower/2+12*gAPPSIZEPower*2, 12*gAPPSIZEPower*1.5, ExtGL.FONT_ALIGN_RIGHT)
        else:
            appDrawText(str(max(0,int(currentPow)))+' PS', 0.9, 0.1, 0.1,  1, 12*gAPPSIZEPower*8 , graphHPower/2+12*gAPPSIZEPower*2, 12*gAPPSIZEPower*1.5, ExtGL.FONT_ALIGN_RIGHT)
        if extraT>0.0:
            appDrawText(str(int(extraT)) + ' Nm boost' , 1, 0.75, 0.5,     1, 12*gAPPSIZEPower*14, graphHPower/2-(12*gAPPSIZEPower*2)/2, 12*gAPPSIZEPower*1.5, ExtGL.FONT_ALIGN_RIGHT)

        if KersInput > 0.0 and bSHOW_ERS:
            appDrawText(str(int(KersInput))+ ' % ers', 0.75, 0.75, 1, 1, graphWPower  , graphHPower/2  , 12*gAPPSIZEPower*1.25, ExtGL.FONT_ALIGN_RIGHT)


############################





def onFormRenderAero(deltaT):
    global AEROCDv, AEROCLf, AEROCLr, AEROdens, baseAEROdens, basecgHeight, ac_ndslip, ac_TyreSlip, bShowAero, bShowMore, bShowVals, hideTimer, bShowLess
    global bDynAero, bHideTimerOn, STEERtorque, maxBrakeTorque, bCPhysBrakesEnabled, currPal, angle_steerwheel, currentCar, currentSpeed
    global cspActive, gAPPSIZEAero, maxDownForce
    global slipstreamTime, isSlipStream, gShowCValues, graphHAero, graphWAero
    global AEROaerospeed, AERODrag, AERODownforceF, AERODownforceR, AERODownforce
    # if not gSHOWTEXTAero: # dummy call, some bug does not draw everytime?
    #     appDrawText(0, '.', 0, 0, gAPPSIZEAero*0.5*0.01)

    # ac.getWindSpeed()
    # ac.getWindDirection()

    try:
        if bShowAero:
            # front/rear CL triangles ; CD triangle
            if AEROCLf!=0.0:
                appDrawLine7(0.3,0.3,0.3,0.5 , graphWAero/2, 0, graphWAero/2*AEROCLf/100, graphHAero/2, 0           )
            if AEROCLr!=0.0:
                appDrawLine7(0.3,0.3,0.3,0.5 , graphWAero/2, 0, graphWAero  *AEROCLr/100, graphHAero  , graphHAero/2)
            if AEROCDv!=0.0:
                appDrawLine7(0.3,0.3,0.7,0.5, graphWAero/2, 0, graphWAero/2*AEROCDv/100, graphHAero  , 0           )

            if cspActive:
                # front/rear downforce triangles
                appDrawLineTriVert(0.3,0.5,0.5,0.5 , graphWAero/4*3, graphHAero, graphHAero-graphHAero*AERODownforceF/(maxDownForce/2), graphWAero/4)
                appDrawLineTriVert(0.3,0.5,0.5,0.5 , graphWAero/4  , graphHAero, graphHAero-graphHAero*AERODownforceR/(maxDownForce/2), graphWAero/4)
                #if AERODownforce!=0.0:
                # appDrawLineTriVert(0.5,0.3,0.3,0.25 , graphWAero/2  , graphHAero, graphHAero - AERODownforce /50, 8)

            if baseAEROdens>0.0:
                x = AEROdens/baseAEROdens
                #ww = (1-x)*graphWAero*gAPPSIZEAero
                ww = (1-x)*graphHAero*gAPPSIZEAero
                if AEROdens>baseAEROdens and currentSpeed>5:
                    # draw more transparent full triangle in red
                    #ac.glColor4f( 0.65,0.35,0.35,0.4)
                    # draw current higher airdensity in red, less transparent
                    #ac.glColor4f(0.7,0.7+(1-x)*20,0.7+(1-x)*20,0.85)
                    appDrawLine7( 0.65,       0.35,        0.35, 0.4, graphWAero/2, 0, graphWAero/8, graphHAero/2, 0)
                    appDrawLine6( 0.7,0.7+(1-x)*20,0.7+(1-x)*20,0.85, graphWAero/2, 0, ww/2        , graphHAero/2, graphHAero/2+ww)

                elif AEROdens<baseAEROdens and currentSpeed>5:

                    #ac.glColor4f(0.35,0.65,0.35,0.4)
                    # draw more transparent full triangle in green
                    # draw current lower airdensity in green
                    #ac.glColor4f(0.7,0.7+(1-x)*20, 0.7,0.85)
                    appDrawLine6( 0.35,       0.65, 0.35, 0.4      , graphWAero/2, 0, graphWAero/8, graphHAero/2, graphHAero     )
                    appDrawLine6( 0.7,0.7+(1-x)*20,  0.7, 0.85     , graphWAero/2, 0, ww/2        , graphHAero/2, graphHAero/2+ww)
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )


################################################################################################################################

def appGetTorque():
    global cspActive, rpmMAX, maxTorque, currentRPM, powcurTORTOR, powcurTORRPM, extraT, currentGas, currentCar, DOAUTOLOADDIFFERENTCAR, histGraphMaxValue, maxPower, histGraph, graphWidth
    try:
        result=0.0
        if rpmMAX<=0.0 or currentRPM<=0: return result
        #if rpmMAX < currentRPM and extraT==0.0 and not bTorqueTimerOn:
        #    rpmMAX = currentRPM

        if cspActive and (currentCar==0 and DOAUTOLOADDIFFERENTCAR):
            # with csp enabled
            result = ac.ext_getCurrentTorque()
        else:
            if len(powcurTORRPM)>0:
                # second best method from torque lut in json or csp is not enabled
                for i in range(len(powcurTORRPM)-1):
                    if i>0 and powcurTORRPM[i] >= currentRPM and powcurTORTOR[i-1]!=0 and powcurTORRPM[i-1]!=0:
                        tmp = powcurTORRPM[i] - powcurTORRPM[i-1]
                        zw = (tmp - (powcurTORRPM[i] - currentRPM)) / tmp
                        # result = currentGas * powcurTORTOR[i-1] + zw * ( powcurTORTOR[i] - powcurTORTOR[i-1] )
                        result = powcurTORTOR[i-1] + zw * ( powcurTORTOR[i] - powcurTORTOR[i-1] )
                        break


            else:
                # simplest wrongest method, if car has no torque lut in json or csp is not enabled
                result = currentRPM/rpmMAX * maxTorque * currentGas

        # ersRPM, ersPOW
        #NMadd = 0.0
        #if len(ersRPM)>0:
        #    for i in range(len(ersRPM)-1):
        #        if currentRPM>ersRPM[i] and ersRPM[i-1]!=0 and ersRPM[i-1]!=0:
        #            # NMadd = ersPOW[i]
        #            # result = NMadd
        #            tmp = ersRPM[i] - ersRPM[i-1]
        #            zw = (tmp - (ersRPM[i] - currentRPM)) / tmp
        #            result = ersPOW[i-1] + zw * ( ersPOW[i] - ersPOW[i-1] )
        #            break

        if result > maxTorque and extraT==0.0 and not bTorqueTimerOn:
            maxTorque = result
            #ac.log('! ' +str(histGraphMaxValue))

        return result
    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )






######################

def acUpdate(delta_t):
    global currentCar, lastCar, fTimer2, fTimer3, appCurves, appCarSpecs, appPower, appAero, TimeCount, sCarSpecs1, sCarSpecs2, firstRun
    global bHideTimerOn, hideTimer, carsteerlock, carffbmult, lbCarSpecs2, lbCarSpecs1, lbTimer, extraT
    global currTurboBoost, currentSpeed, currBrake, maxFFB, currFFB, currentGas, currentRPM, maxTorque, torquehandBrake, torqueBrake, currentTorque
    global AEROCDv, AEROCLf, AEROCLr, AEROdens, baseAEROdens, bShowAero, bDynAero, bTorqueTimerOn, TorqueTimer, TorqueTimerSteps, TorqueExtraAmount
    global TimeCount, bDiffMode, labelTimer, labelTimerEnabled, bStartFlag, updateTimerFast, extraHoldtime, joystickid, joystickbutton
    global isSlipStream, slipstreamTime, ac_LocalVelocity
    global AEROaerospeed, AERODrag, AERODownforceF, AERODownforceR, AERODownforce, lbPowerRpm, lbAero, currentPow, maxTurboBoost
    global maxDownForce, slipStreamLevel, lastFFB, gOPACITYPower
    global graphWidth, graphHeight, histGraphMaxValue, histGraph, FANCYMODE, DOPEMODE, maxPower
    global ac_Grip, lasttyres, bNewTyreParams, bCPhysicsActive, rtIndex0, colors, dCurves, rtFlag, rtIndex1, graphLineWidth2
    global gOPACITYAero, gOPACITYCurves, gShowTextPower, gShowTextAero, gShowTextCurves, gCURVESCONNECTED, shiftleft, cspActiveHandbrake
    global tempFgrip, tempRgrip, tempFtemp, tempRtemp, ERSlastKJ, ERStotalKJ
    global KersCharge, KersInput, ERSCurrentKJ, ERSMaxJ, bCurve9ON, bCurve10ON, bCurve11ON, bCurve12ON, bSHOW_ERS
    global lbG10, lbG11, lbG9, lbG12, bCurve13ON, bCurve14ON, bCurve15ON, lbG13, lbG14, lbG15
    global dCurvesMaxes, dCurvesTimer, peakholdtime, dCurvesL
    global ac_handbrake
    try:
        # lazy update for ui and car switch
        fTimer3 += delta_t
        if fTimer3>=0.5:
            fTimer3 = 0.0
            ac.setBackgroundOpacity(appCarSpecs, 0.5 )
            ac.setBackgroundOpacity(appPower   , float(gOPACITYPower) )
            ac.setBackgroundOpacity(appAero    , float(gOPACITYAero) )
            ac.drawBorder(appCarSpecs, 0)
            ac.drawBorder(appPower   , 0)
            ac.drawBorder(appAero    , 0)
            ac.drawBorder(appCurves  , 0)
            if gShowTextCurves:
                ac.drawBackground(graphBG, 1)
                ac.drawBackground(appCurves, 1)
                ac.setBackgroundOpacity(appCurves, gOPACITYCurves )
            else:
                ac.drawBackground(graphBG, 0)
                ac.drawBackground(appCurves, 0)
                ac.setBackgroundOpacity(appCurves, 0 )

            if FANCYMODE:
                ac.setBackgroundOpacity(histGraph, gOPACITYCurves )
                ac.setBackgroundOpacity(graphBG, gOPACITYCurves )
            else:
                ac.setBackgroundOpacity(histGraph, 0 )
                ac.setBackgroundOpacity(graphBG, gOPACITYCurves )

            if DOAUTOLOADDIFFERENTCAR:
                currentCar = ac.getFocusedCar()
            else:
                currentCar = 0
            currentTyres = str(ac.getCarTyreCompound(currentCar))
            if (DOAUTOLOADDIFFERENTCAR and lastCar != currentCar) or lasttyres!=currentTyres:
                lasttyres = currentTyres
                lastCar = currentCar
                firstRun = True

            if firstRun and currentCar>-1 and currentTyres!='':
                appCheckCarSpecs(currentCar, ac.getCarName(currentCar))
                #ac.log(str(maxTorque))
                #ac.log(str(maxPower))
                #ac.log(str(histGraphMaxValue))
                # ac.log('__')
                # ac.setRange(histGraph, 0, int(histGraphMaxValue), int(graphWidth))
                firstRun = False

        if bStartFlag==True:
            if labelTimerEnabled:
                labelTimer += delta_t
                if labelTimer>10.0 or currentSpeed>50:
                    ac.setVisible(appCarSpecs, 0)
                    ac.setText(lbTimer, "")
                    labelTimerEnabled = False
                    bStartFlag=False
                else:
                    ac.setText(lbTimer, str(10-int(labelTimer)))

        try:
            if bTorqueTimerOn:
                TorqueTimer += delta_t
                if TorqueTimer >= 0.1:
                    TorqueTimer=0.0
                    TorqueTimerSteps+=1
                    if TorqueTimerSteps>=extraHoldtime*10:
                        if TorqueTimerSteps<extraHoldtime*20 and extraT>0:
                            extraT -= TorqueExtraAmount/10
                        else:
                            bTorqueTimerOn = False
                            extraT = 0.0
                        ac.setVisible(lbPowerExtra, 1 )
                        ac.setText(lbPowerExtra, "")
                        ac.ext_setExtraTorque(max(0,extraT))
        except:
            ac.log('CarSpecs app: error ' + traceback.format_exc() )

        sTextAero = ""
        if bHideTimerOn:
            hideTimer -= delta_t
            if hideTimer <= 0.0:
                bHideTimerOn = False
                appHideControls()

        # fast update for data
        fTimer2 += delta_t
        if fTimer2 >= updateTimerFast:
            fTimer2 = 0.0
            try:
                if bTorqueTimerOn==False and ( ac.ext_isJoystickButtonPressed(joystickid,joystickbutton) or ac.ext_isButtonPressed(keyboardbutton)):
                    appBoost()
            except:
                pass

            # currentSpeed    = ac.getCarState(currentCar,acsys.CS.SpeedMPH)
            ac_steer        = ac.getCarState(currentCar, acsys.CS.Steer)
            currentSpeed    = ac.getCarState(currentCar,acsys.CS.SpeedKMH)   # not displayed, only internal use
            currentGas      = ac.getCarState(currentCar,acsys.CS.Gas)
            currBrake       = ac.getCarState(currentCar,acsys.CS.Brake)
            currFFB         = ac.getCarState(currentCar,acsys.CS.LastFF)
            currTurboBoost  = ac.getCarState(currentCar,acsys.CS.TurboBoost)
            currentRPM      = ac.getCarState(currentCar,acsys.CS.RPM)
            if cspActiveHandbrake:
                ac_handbrake = ac.ext_getHandbrake(0)

            currCarFFB = ac.getCarFFB()
            if lastFFB != currCarFFB:
                lastFFB = currCarFFB
                maxFFB = 0
            else:
                if maxFFB < currFFB:
                    maxFFB = currFFB

            if bStartFlag:
                if currentSpeed > 40:
                    labelTimerEnabled = True
                    # ac.setVisible(appCarSpecs, 0)
                    # ac.setText(lbTimer, "")
                    bStartFlag=True

            if bNewTyreParams and bCPhysicsActive and cspActive:
                ac_Grip[0] = float(ac.ext_getTyreTempMult(0, 0))*100
                ac_Grip[1] = float(ac.ext_getTyreTempMult(0, 1))*100
                ac_Grip[2] = float(ac.ext_getTyreTempMult(0, 2))*100
                ac_Grip[3] = float(ac.ext_getTyreTempMult(0, 3))*100
                # ac.setTitle(appCurves, 'eek-1')
            elif len(tempFgrip)>0 and len(tempRgrip)>0 and len(tempFtemp)>0 and len(tempRtemp):
                # ac.log(str(len(tempFtemp)))
                # ac.log(str(bCPhysicsActive))
                # ac.log(str(PRACTICAL_TEMP_RATIO))
                if bCPhysicsActive and PRACTICAL_TEMP_RATIO!=-1000:
                    if bCPhysCarcassEnabled:
                        # surface x practical_temp_ratio + CARCASStemp x (1-practical_temp_ratio)
                        ac_Grip[0] = 100* get_val_from_lut(info.physics.tyreTempM[0], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,0), tempFtemp, tempFgrip)
                        ac_Grip[1] = 100* get_val_from_lut(info.physics.tyreTempM[1], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,1), tempFtemp, tempFgrip)
                        ac_Grip[2] = 100* get_val_from_lut(info.physics.tyreTempM[2], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,2), tempRtemp, tempRgrip)
                        ac_Grip[3] = 100* get_val_from_lut(info.physics.tyreTempM[3], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(ac.ext_getTyreCarcassTemp(0,3), tempRtemp, tempRgrip)
                    else:
                        # surface x practical_temp_ratio + COREtemp x (1-practical_temp_ratio)
                        ac_Grip[0] = 100* get_val_from_lut(info.physics.tyreTempM[0], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[0], tempFtemp, tempFgrip)
                        ac_Grip[1] = 100* get_val_from_lut(info.physics.tyreTempM[1], tempFtemp, tempFgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[1], tempFtemp, tempFgrip)
                        ac_Grip[2] = 100* get_val_from_lut(info.physics.tyreTempM[2], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[2], tempRtemp, tempRgrip)
                        ac_Grip[3] = 100* get_val_from_lut(info.physics.tyreTempM[3], tempRtemp, tempRgrip)*PRACTICAL_TEMP_RATIO + (1-PRACTICAL_TEMP_RATIO) * get_val_from_lut(info.physics.tyreCoreTemperature[3], tempRtemp, tempRgrip)
                else:
                    # from temp lut, 25% surface temp, 75% core temp
                    ac_Grip[0] = 100* get_val_from_lut(info.physics.tyreTempM[0]*0.25 + info.physics.tyreCoreTemperature[0]*0.75, tempFtemp, tempFgrip)
                    ac_Grip[1] = 100* get_val_from_lut(info.physics.tyreTempM[1]*0.25 + info.physics.tyreCoreTemperature[1]*0.75, tempFtemp, tempFgrip)
                    ac_Grip[2] = 100* get_val_from_lut(info.physics.tyreTempM[2]*0.25 + info.physics.tyreCoreTemperature[2]*0.75, tempRtemp, tempRgrip)
                    ac_Grip[3] = 100* get_val_from_lut(info.physics.tyreTempM[3]*0.25 + info.physics.tyreCoreTemperature[3]*0.75, tempRtemp, tempRgrip)

            currentTorque   = appGetTorque()
            currentPow      = max(0.0, currentTorque * currentRPM*0.10472 / 745.7)
            if currentPow > maxPower:
                maxPower = currentPow
                histGraphMaxValue = max( maxTorque, maxPower )
                ac.setRange(histGraph, 0, int(histGraphMaxValue), int(graphWidth))
                # ac.log(        str(math.floor(maxPower))
                #    + '  -  ' + str(math.floor(maxTorque))
                #    + '  -  ' + str(math.floor(histGraphMaxValue))
                #    + '  -  ' + str(math.floor(len(powcurPOWRPM))))


            if bSHOW_ERS:
                KersCharge    = ac.getCarState(currentCar, acsys.CS.KersCharge)     *100  ### KersCharge
                KersInput     = ac.getCarState(currentCar, acsys.CS.KersInput)      *100  ### KersInput
                ERSCurrentKJ  = ac.getCarState(currentCar, acsys.CS.ERSCurrentKJ)         ### ERSCurrentKJ
                ERSMaxJ       = ac.getCarState(currentCar, acsys.CS.ERSMaxJ)     /100000    ### ERSMaxJ
                if ERSCurrentKJ < ERSlastKJ:
                    ERStotalKJ += ERSlastKJ
                ERSlastKJ = ERSCurrentKJ

                if ERSMaxJ == 0:
                    bSHOW_ERS=False
                    bCurve9ON=False
                    bCurve10ON=False
                    bCurve11ON=False
                    ac.setText(lbG9,   'no ERS')
                    ac.setText(lbG10,   'no ERS')
                    ac.setText(lbG11,   'no ERS')
                    ac.setVisible(lbG9, 0)
                    ac.setVisible(lbG10, 0)
                    ac.setVisible(lbG11, 0)


            if bShowAero:
                AEROdens        = info.physics.airDensity
                if baseAEROdens == -1.0:
                    baseAEROdens = AEROdens

                if AEROdens>baseAEROdens and currentSpeed>5:
                    # draw more transparent full triangle in red
                    # draw current higher airdensity in red, less transparent
                    isSlipStream=False
                    slipstreamTime=0.0
                    sTextAero = ( str(round(baseAEROdens-AEROdens,4)) + '\n' +
                                  str(round(baseAEROdens         ,5)) + ' base AirPressure')

                elif AEROdens<baseAEROdens and currentSpeed>5:
                    # draw more transparent full triangle in green
                    # draw current lower airdensity in green
                    ### slipstream sensitivity level
                    if baseAEROdens-AEROdens > slipStreamLevel:
                        isSlipStream=True
                        slipstreamTime+=delta_t
                        sTextAero = ( '+' + str(round(baseAEROdens-AEROdens,4)) + '\n' +
                                            str(round(baseAEROdens         ,5)) + ' base AirPressure      ' + 'slipstream ! ' + str(round(slipstreamTime,1))+'s'
                                          )
                    else:
                        isSlipStream=False
                        slipstreamTime=0.0
                        sTextAero = ( str(round(baseAEROdens-AEROdens,4)) + '\n'
                                    + str(round(baseAEROdens         ,5)) + ' base AirPressure\n')

                else:
                    isSlipStream=False
                    slipstreamTime=0.0
                    if abs(baseAEROdens-AEROdens)>0.01:
                        sTextAero = (      str(round(AEROdens-baseAEROdens,5)) + '\n'
                                          + str(round(baseAEROdens         ,5)) + ' base AirPressure\n')
                    else:
                        sTextAero = '\n' + str(round(baseAEROdens         ,5)) + ' base AirPressure'
                # AEROCDv         = ac.getCarState(currentCar, acsys.AERO.CD)       # drag Coefficient
                # AEROCLf         = ac.getCarState(currentCar, acsys.AERO.CL_Front) # lift Coefficient front
                # AEROCLr         = ac.getCarState(currentCar, acsys.AERO.CL_Rear)  # lift Coefficient rear
                #ac_LocalVelocity = ac.getCarState(currentCar, acsys.CS.LocalAngularVelocity)
                ac_LocalVelocity = ac.getCarState(currentCar, acsys.CS.LocalVelocity)
                #if type(ac_LocalVelocity) != int:
                AEROCDv         = ac.getCarState(currentCar, acsys.AERO.CD      ) / 9.81 # / 0.5 * AEROdens*ac_LocalVelocity[1]*ac_LocalVelocity[1] / 9.81 #  / 100 # drag Coefficient
                AEROCLf         = ac.getCarState(currentCar, acsys.AERO.CL_Front) / 9.81 # / 0.5 * AEROdens*ac_LocalVelocity[1]*ac_LocalVelocity[1] / 9.81 #  / 100 # lift Coefficient front
                AEROCLr         = ac.getCarState(currentCar, acsys.AERO.CL_Rear ) / 9.81 # / 0.5 * AEROdens*ac_LocalVelocity[1]*ac_LocalVelocity[1] / 9.81 #  / 100 # lift Coefficient rear
                # AEROCDv         = ac.getCarState(currentCar, acsys.CS.Aero, acsys.AERO.CD      ) #  /  (0.5 * AEROdens)*ac_LocalVelocity[2]*ac_LocalVelocity[2] ) * 100 #  / 100 # drag Coefficient
                # AEROCLf         = ac.getCarState(currentCar, acsys.CS.Aero, acsys.AERO.CL_Front) #  /  (0.5 * AEROdens)*ac_LocalVelocity[2]*ac_LocalVelocity[2] ) * 100 #  / 100 # lift Coefficient front
                # AEROCLr         = ac.getCarState(currentCar, acsys.CS.Aero, acsys.AERO.CL_Rear ) #  /  (0.5 * AEROdens)*ac_LocalVelocity[2]*ac_LocalVelocity[2] ) * 100 #  / 100 # lift Coefficient rear
                if cspActive and AEROCLr+AEROCLf != 0.0:
                    rearRatio = AEROCLr / (AEROCLr+AEROCLf)
                    AEROaerospeed   = ac.ext_getAeroSpeed()
                    AERODrag        = ac.ext_getDrag()       * 0.102 # / 9.81   ### todo: div by g or not?
                    AERODownforce   = ac.ext_getDownforce(2) * 0.102 # / 9.81   ### todo: div by g or not?
                    #AERODownforceF  = ac.ext_getDownforce(0) * 0.102 # / 9.81   ### todo: div by g or not?
                    #AERODownforceR  = ac.ext_getDownforce(1) * 0.102 # / 9.81   ### todo: div by g or not?
                    # AERODownforce = AERODownforceF + AERODownforceR
                    AERODownforceF = (1-rearRatio) * AERODownforce
                    AERODownforceR = (  rearRatio) * AERODownforce

                    if maxDownForce < AERODownforce*2:
                        maxDownForce = AERODownforce*2

                sText     = ""
                if gShowCValues:
                    sText = (
                            #'AirSpeed: '  + str(round(ac.ext_getAeroSpeed() ,1)) + '\n' +
                            #'Drag: '      + str(int  (ac.ext_getDrag()        )) + '\n' +
                            #'down front: '+ str(int  (ac.ext_getDownforce(0)  )) + '\n' +
                            #'down rear : '+ str(int  (ac.ext_getDownforce(1)  )) + '\n' +
                            #'down force: '+ str(int  (ac.ext_getDownforce(2)  )) + '\n' +
                            'CLA  f/r/sum: '+ str(round(AEROCLf  ,1)) + ' / '+ str(round(AEROCLr,1)) + ' / ' + str(round(AEROCLr+AEROCLf,2)) + '\n' +
                            'CDA         : '+ str(round(AEROCDv  ,2)) + '\n'
                            )
                else:
                    sText = '\n\n'

                if AEROCLr+AEROCLf != 0.0:
                    rearRatio = AEROCLr / (AEROCLr+AEROCLf)
                    # ac.log( str(rearRatio) )
                    AERODownforceFlocal = (1-rearRatio) * AERODownforce
                    AERODownforceRlocal = (  rearRatio) * AERODownforce
                    if gShowCValues and AERODownforceRlocal!=0.0 and AEROCLf!=0:
                        ttt = ''
                        if cspActive and bAeroRollAvail:
                            ttt = '    AirRoll : '+ str(round(ac.ext_getAeroRoll(),5)) + '\n'
                        sText = ( sText
                              + 'Drag        : '+ str(int  (AERODrag       ))
                              + '    AirSpeed: 0'
                              + ttt
                              + 'DwnF f/r/sum: '+ str(int  (AERODownforceFlocal )) + 'kg / ' + str(int  (AERODownforceRlocal )) + 'kg / ' + str(int  (AERODownforce  )) + 'kg\n'
                            )
                    else:
                        sText = '\n\n\n\n'

                if gShowTextAero:
                    # if not cspActive:
                    ac.setText(lbAero, '\n' + sText + sTextAero)

                if gShowTextPower:
                    # turbo boost text
                    if maxTurboBoost>0.0:
                        if currTurboBoost>maxTurboBoost:
                            maxTurboBoost=currTurboBoost
                        if currTurboBoost>0.01:
                            # turbo text color
                            #appDrawLine6( 1, 0.5-x/2, 0.5-x/2, x*0.5, graphWPower/2, 0, x*graphWPower/16, graphHPower, graphHPower-x*graphHPower)
                            sstr='x'+str(round(currTurboBoost,2))
                        else:
                            sstr='x0.00'

                        # draw boost text in red
                        if currTurboBoost+0.0099 >= maxTurboBoost:
                            if not cspActive:
                                #ac.setFontColor(lbPowerTurbo, 1,0.2,0.2, 1)
                                ac.setText(lbPowerTurbo, sstr )
                        elif currTurboBoost+0.0099 >= maxTurboBoost:
                            if not cspActive:
                                #ac.setFontColor(lbPowerTurbo, 1,0.3,0.3, 1)
                                ac.setText(lbPowerTurbo, sstr )
                        else:
                            if not cspActive:
                                #ac.setFontColor(lbPowerTurbo, 1,0.5, 0.5, 1)
                                ac.setText(lbPowerTurbo, sstr )

                    if extraT>0.0:
                        # extra torque in orange
                        if not cspActive:
                            ac.setText(lbPowerExtra, '+ ' + str(int(extraT)) +' Nm')
                            ac.setVisible(lbPowerExtra, 1 )
                            ac.setBackgroundOpacity(lbPowerExtra, 0 )
                            # ac.setBackgroundColor(lbPowerExtra, 1,1,1 )

                    # draw PS / RPM text
                    if not cspActive and gShowTextPower:
                        sstr=str(int(currentPow))+' PS'
                        ac.setText(lbPowerPower, sstr)

                    # draw Nm or Kw text in blue
                    if not cspActive and currentTorque!=None and gShowTextPower:
                        sstr=str(int(currentTorque))+' Nm'
                        ac.setText(lbPowerTorque, sstr)

            ############################################
            if int(histGraphMaxValue)!=0:
                dCurves[0] = max(0,currentTorque)
                dCurves[1] =       currentPow
                if maxTurboBoost!=0.0:
                    dCurves[2] = currTurboBoost
                dCurves[3] = currentGas
                dCurves[4] = currBrake
                dCurves[5] = currFFB
                dCurves[6] = ( float(min(ac_Grip)) - 95) / 5
                dCurves[7] = min(1.0,max(0.0, 0.5 - ac_steer /360))
                if cspActiveHandbrake:
                    #dCurves[8]=ac.ext_getHandbrake(0)  ##ac_handbrake
                    dCurves[8] = ac_handbrake
                if bSHOW_ERS and ERSMaxJ>0:
                    dCurves[9] = KersCharge/100
                    dCurves[10] = KersInput/100
                    dCurves[11] = (ERSMaxJ-ERSCurrentKJ)/ERSMaxJ
                dCurves[12]     = (1-ac.getCarState(currentCar,acsys.CS.Clutch))
                # dCurves[13]     = min( maxgforce, maxgforce/2+ac.getCarState(currentCar, acsys.CS.AccG)[0] ) / maxgforce
                # dCurves[14]     = min( maxgforce, maxgforce/2+ac.getCarState(currentCar, acsys.CS.AccG)[1] ) / maxgforce
                # dCurves[15]     = min( maxgforce, maxgforce/2+ac.getCarState(currentCar, acsys.CS.AccG)[2] ) / maxgforce
                dCurves[13]     = ac.getCarState(currentCar, acsys.CS.AccG)[0]
                dCurves[14]     = ac.getCarState(currentCar, acsys.CS.AccG)[1]
                dCurves[15]     = ac.getCarState(currentCar, acsys.CS.AccG)[2]
                if ac.getCarState(currentCar, acsys.CS.AccG)[1]>0:
                    colors[14][0]=1.00
                    colors[14][1]=0.40
                    colors[14][2]=0.40
                else:
                    colors[14][0]=0.40
                    colors[14][1]=1.00
                    colors[14][2]=0.40
                # gforce_x, gforce_z, gforce_y = ac.getCarState(currentCar, acsys.CS.AccG)[0]

                # collect max vals across all curves, count down when peak stuff is on
                for i, crvval in enumerate(dCurves):
                    if i<12:
                        if crvval>=dCurvesMaxes[i] and crvval<=maxgforce:
                            dCurvesMaxes[i] = crvval
                            dCurvesTimer[i] = peakholdtime
                        elif peakholdtime>0.0:
                            dCurvesTimer[i] -= delta_t
                            if dCurvesTimer[i] <= 0 and dCurvesMaxes[i]>=dCurvesSubtract[i]:
                                dCurvesMaxes[i] -= dCurvesSubtract[i]
                    elif not i in [6,7]:
                        if abs(crvval)>=dCurvesMaxes[i]:
                            dCurvesMaxes[i] = abs(crvval)
                            dCurvesTimer[i] = peakholdtime
                        elif peakholdtime>0.0:
                            dCurvesTimer[i] -= delta_t
                            if dCurvesTimer[i] <= 0 and dCurvesMaxes[i]>=dCurvesSubtract[i]:
                                dCurvesMaxes[i] -= dCurvesSubtract[i]
                dCurves[0] /= histGraphMaxValue
                dCurves[1] /= histGraphMaxValue
                if maxTurboBoost!=0.0:
                    dCurves[2] /= maxTurboBoost*0.9
                # dCurves[5] /= 2
                # dCurves[13]     = min( maxgforce, maxgforce/2+dCurves[13] ) / maxgforce
                # dCurves[14]     = min( maxgforce, maxgforce/2+dCurves[14] ) / maxgforce
                # dCurves[15]     = min( maxgforce, maxgforce/2+dCurves[15] ) / maxgforce

            ############################################
            if gShowTextCurves:
                if bCurve0ON and currentTorque!=None:
                    ac.setText(lbG0,   'Torque\nmax '+ str(int(dCurvesMaxes[0]))+ '\n'+ str(int(currentTorque)) + ' Nm')
                if bCurve1ON and currentTorque!=None:
                    if currentPow!=None and currentGas!=None:
                        ac.setText(lbG1,   'Power\nmax '+ str(int(dCurvesMaxes[1]))+ '\n'+ str(max(0,int(currentPow))) + ' PS')
                if bCurve2ON and maxTurboBoost>0:
                    ac.setText(lbG2, 'Turbo\nmax '+ str(round(dCurvesMaxes[2],2   ))+ '\n'+ str(round(currTurboBoost,2   )) + 'x')
                if bCurve3ON:
                    ac.setText(lbG3, 'Gas\nmax ' + str(int(dCurvesMaxes[3]*100))+ '\n' + str(int(dCurves[3]*100       )) + ' %')
                if bCurve4ON:
                    ac.setText(lbG4, 'Brake\nmax ' + str(int(dCurvesMaxes[4]*100))+ '\n' + str(int(dCurves[4]*100    )) + ' %')
                if bCurve5ON:
                    ac.setText(lbG5, 'FFB\nmax '+ str(int(dCurvesMaxes[5]*100         ))+ '\n'+ str(int(currFFB*100        )) + ' %' )
                if bCurve6ON:
                    ac.setText(lbG6, 'Grip\n95-100\n'+ str( round((dCurvesMaxes[6]),2)) + ' %')
                if bCurve7ON:
                    ac.setText(lbG7, 'Steer\n±180\n'+ str( int(ac.getCarState(currentCar, acsys.CS.Steer))) + ' °')
                if bCurve8ON:
                    # ac_handbrake
                    # ac.setText(lbG8, 'Handbr.\nmax '+ str(int(dCurvesMaxes[8]*100)) +'\n'+ str( int(ac.ext_getHandbrake()*100)) + '%')
                    ac.setText(lbG8, 'Handbr.\nmax '+ str(int(dCurvesMaxes[8]*100.0)) +'\n'+ str( int(ac_handbrake*100.0)) + '%')
                if bCurve9ON and bSHOW_ERS and ERSMaxJ>0:
                    ac.setText(lbG9, 'ersCharge\nmax 100\n'+ str(round(dCurvesMaxes[9],1)) + ' %')
                if bCurve10ON and bSHOW_ERS and ERSMaxJ>0:
                    ac.setText(lbG10, 'ersInput\nmax 100\n'+ str(max(0,round(dCurvesMaxes[10],1))) + ' %')
                if bCurve11ON and bSHOW_ERS and ERSMaxJ>0:
                    # ac.log("---")
                    # ac.log(str(ERSMaxJ))
                    # ac.log(str(ERSCurrentKJ))
                    ac.setText(lbG11, 'ersLeft\nmax '+str(round(dCurvesMaxes[11],1))+' kJ\n'+ str( round((ERSMaxJ-ERSCurrentKJ)/1000,2)) + ' kJ')
                if bCurve12ON:
                    ac.setText(lbG12, 'Clutch\nmax '+ str(int(dCurvesMaxes[12]*100))+'\n'+ str( int(dCurves[12]*100) ) + ' %')
                if bCurve13ON:
                    ac.setText(lbG13, 'G x\nmax ±'+ str(round(dCurvesMaxes[13],2))+'\n'+ str( round(dCurves[13],2) ) + ' g')
                if bCurve14ON:
                    ac.setText(lbG14, 'G y\nmax ±'+ str(round(dCurvesMaxes[14],2))+'\n'+ str( round(dCurves[14],2) ) + ' g')
                if bCurve15ON:
                    ac.setText(lbG15, 'G z\nmax ±'+ str(round(dCurvesMaxes[15],2))+'\n'+ str( round(dCurves[15],2) ) + ' g')

                # if bCurve0ON and currentTorque!=None:
                #     ac.setText(lbG0,   'Torque\nmax '+ str(int(maxTorque))+ '\n'+ str(int(currentTorque)) + ' Nm')
                # if bCurve1ON and currentTorque!=None:
                #     if currentPow!=None and currentGas!=None:
                #         ac.setText(lbG1,   'Power\nmax '+ str(int(maxPower))+ '\n'+ str(max(0,int(currentPow))) + ' PS')
                # if bCurve2ON and maxTurboBoost>0:
                #     ac.setText(lbG2, 'Turbo\nmax '+ str(round(maxTurboBoost,2   ))+ '\n'+ str(round(currTurboBoost,2   )) + 'x')
                # if bCurve3ON:
                #     ac.setText(lbG3, 'Gas\n\n' + str(int(currentGas*100       )) + ' %')
                # if bCurve4ON:
                #     ac.setText(lbG4, 'Brake\n\n' + str(int(currBrake*100        )) + ' %')
                # if bCurve5ON:
                #     ac.setText(lbG5, 'FFB\nmax '+ str(int(maxFFB*100         ))+ '\n'+ str(int(currFFB*100        )) + ' %' )
                # if bCurve6ON:
                #     ac.setText(lbG6, 'Grip\n95-100\n'+ str( round((min(ac_Grip)),2)) + ' %')
                # if bCurve7ON:
                #     ac.setText(lbG7, 'Steer\n±180\n'+ str( int(ac.getCarState(currentCar, acsys.CS.Steer))) + ' °')
                # if bCurve8ON:
                #     ac.setText(lbG8, 'Handbr.\n\n'+ str( int(ac_handbrake*100)) + '%')
                # if bCurve9ON and bSHOW_ERS and ERSMaxJ>0:
                #     ac.setText(lbG9,   'ersCharge\nmax 100\n'+ str(round(KersCharge,1)) + ' %')
                # if bCurve10ON and bSHOW_ERS and ERSMaxJ>0:
                #     ac.setText(lbG10,   'ersInput\nmax 100\n'+ str(max(0,round(KersInput,1))) + ' %')
                # if bCurve11ON and bSHOW_ERS and ERSMaxJ>0:
                #     ac.setText(lbG11, 'ersLeft\nmax '+str(round(ERSMaxJ/1000,1))+' kJ\n'+ str( round((ERSMaxJ-ERSCurrentKJ)/1000,2)) + ' kJ')
                # if bCurve12ON:
                #     ac.setText(lbG12, 'Clutch\n\n'+ str( int(dCurves[12])*100 ) + ' %')


            ############################################
            if cspActive and FANCYMODE:
                #BitBlt(  Handle,   0, 0, W-1, H,   // dest
                #         Handle,   W, 0,           // src
                #         SRCCOPY);                 // scroll left

                ### move memory image one pixel aside to the left
                ### and discarding most left column of pixels
                ### making room on the right to paint on

                ac.ext_clearRenderTarget(rtIndex1)
                ac.ext_bindRenderTarget(rtIndex1)
                ac.ext_glSetBlendMode(0)
                ac.glBegin(acsys.GL.Quads)
                ac.ext_glSetTexture(rtIndex0, 0)
                ac.glColor4f(1,1,1,1)
                if DOPEMODE:
                    rtFlag = not rtFlag
                    if rtFlag:
                        # pinch
                        ac.ext_glSetBlendMode(2)
                        ac.ext_glVertexTex(                 0,            0, 0, 0)
                        ac.ext_glVertexTex(                 0, graphHCurves, 0, 1)
                        ac.ext_glVertexTex(    graphWCurves-3, graphHCurves, 1, 1)
                        ac.ext_glVertexTex(    graphWCurves-3,            0, 1, 0)
                        ac.ext_glSetBlendMode(0)
                    else:
                        # shift only
                        ac.ext_glVertexTex(                -2,            0, 0, 0)
                        ac.ext_glVertexTex(                -2, graphHCurves, 0, 1)
                        ac.ext_glVertexTex(    graphWCurves-2, graphHCurves, 1, 1)
                        ac.ext_glVertexTex(    graphWCurves-2,            0, 1, 0)
                else:
                    # shift only
                    ac.ext_glVertexTex(                -2,            0, 0, 0)
                    ac.ext_glVertexTex(                -2, graphHCurves, 0, 1)
                    ac.ext_glVertexTex(    graphWCurves-2, graphHCurves, 1, 1)
                    ac.ext_glVertexTex(    graphWCurves-2,            0, 1, 0)
                ac.glEnd()
                ac.ext_restoreRenderTarget()

                ### clear drawing part
                ac.ext_clearRenderTarget(rtIndex0)

                # blend buffer onto screen image
                ac.ext_bindRenderTarget(rtIndex0)
                ac.glBegin(acsys.GL.Quads)
                ac.ext_glSetTexture(rtIndex1, 0)
                ac.ext_glSetBlendMode(0)
                ac.glColor4f(1,1,1,1)
                ac.ext_glVertexTex(0,0                       , 0, 0)
                ac.ext_glVertexTex(0,            graphHCurves, 0, 1)
                ac.ext_glVertexTex(graphWCurves, graphHCurves, 1, 1)
                ac.ext_glVertexTex(graphWCurves,            0, 1, 0)
                ac.glEnd()

                ### paint on memory image - paint all active channels at this dT
                dCurves[13]     = min( maxgforce, maxgforce/2+dCurves[13] ) / maxgforce
                dCurves[14]     = min( maxgforce, maxgforce/2+dCurves[14] ) / maxgforce
                dCurves[15]     = min( maxgforce, maxgforce/2+dCurves[15] ) / maxgforce
                for j, col in enumerate(colors):
                    bon = globals()['bCurve'+str(j)+'ON']
                    if bon:
                        if maxTurboBoost==0.0 and j==2:
                            pass # skip turbo
                        else:
                            if DOPEMODE:
                                if gCURVESCONNECTED:
                                    appDrawLineCalced(col[0], col[1], col[2], 1,
                                        int(graphWCurves-1), graphHCurves - dCurves[j]*graphHeight,
                                        int(graphWCurves-3), graphHCurves - dCurvesL[j]*graphHeight, graphLineWidth2)
                                else:
                                    appDrawLineCalced(col[0], col[1], col[2], 1,
                                        int(graphWCurves-1), graphHCurves - dCurves[j]*graphHeight,
                                        int(graphWCurves-3), graphHCurves - dCurvesL[j]*graphHeight, graphLineWidth2)
                            else:
                                if gCURVESCONNECTED:
                                    appDrawLineCalced(col[0], col[1], col[2], 1,
                                        int(graphWCurves-1), graphHCurves - dCurves[j]*graphHeight,
                                        int(graphWCurves-3), graphHCurves - dCurvesL[j]*graphHeight, graphLineWidth2)
                                else:
                                    appDrawLineCalced(col[0], col[1], col[2], 1,
                                        int(graphWCurves-1), graphHCurves - dCurves[j]*graphHeight,
                                        int(graphWCurves-3), graphHCurves - dCurvesL[j]*graphHeight, graphLineWidth2)
                    dCurvesL[j] = dCurves[j]

                ac.ext_restoreRenderTarget()
                ac.ext_generateMips(rtIndex0)

    except:
        ac.log('CarSpecs app: error ' + traceback.format_exc() )


#############################

def onFormRenderCurves(deltaT):
    global ac_handbrake
    # appDrawTextShadow('ac_handbrake var      : ' + str(round(ac_handbrake,2         )), 0, -80)
    # appDrawTextShadow('ac.ext_getHandbrake() : ' + str(round(ac.ext_getHandbrake(),2)), 0, -100)

    global histGraph, currTurboBoost, maxTurboBoost, maxPower, maxTorque, currentPow, currentGas, currentTorque, currBrake, histGraphMaxValue
    global bCurve0ON, bCurve1ON, bCurve2ON, bCurve3ON, bCurve4ON, bCurve5ON, bCurve6ON, bCurve7ON, currFFB, maxFFB, ac_Grip, bCurve8ON
    global dCurves, graphWCurves, graphHCurves, cspActive, rtIndex1, rtFlag, rtIndex0
    global ac_steer
    global FANCYMODE, lx, ly, ac_Grip, KersCharge, KersInput, ERSCurrentKJ, bSHOW_ERS
    if cspActive and FANCYMODE:
        ### use csp graph - bitblit (blend) painted memory image to screen
        ac.glBegin(acsys.GL.Quads)
        ac.glColor4f(1,1,1,1)
        ac.ext_glSetTexture(rtIndex0, 0)
        ac.ext_glVertexTex(0           ,            0, 0, 0)
        ac.ext_glVertexTex(0           , graphHCurves, 0, 1)
        ac.ext_glVertexTex(graphWCurves, graphHCurves, 1, 1)
        ac.ext_glVertexTex(graphWCurves,            0, 1, 0)
        ac.glEnd()

        ### debug for testing drawing lines ;()
        # appDrawText(str(ac_Grip[0]), 1,1,1,1,-100, -100, 16)
        # appDrawLine0(1, 1, 1, 1, -100, -100, 100, -100, graphLineWidth2)
        # appDrawLine0(1, 1, 1, 1, 100, -100, 200, -200, graphLineWidth2)
        # appDrawLine0(1, 1, 1, 1, 210, 200, 200, -200, graphLineWidth2)
        # appDrawLine0(1, 1, 1, 1, 100, 100, 200,   0, graphLineWidth2)
        #appDrawLineCalced(1, 1, 1, 1, 100, 100, 200,  50, 10, 1)
        #appDrawLineCalced(1, 1, 1, 1, 100, 100, 200, 100, 10, 1)
        #appDrawLineCalced(1, 1, 1, 1, 100, 100, 200, 150, 10)
        #appDrawLineCalced(1, 1, 1, 1, 100, 100, 200, 200, 10)
        #appDrawLineCalced(1, 1, 1, 1, 100, 100, 200, 250, 10)
        # appDrawLineCalced(1, 1, 1, 1, 100, 100, 200,   0, 10, 1)
        # appDrawLineCalced(1, 1, 1, 1, 200,   0, 400,   0, 10, 1)
        # appDrawLineCalced(1, 1, 1, 1, 400,   0, 410, 200, 10, 1)
        #appDrawLineDir(1, 1, 1, 1, graphWCurves-100, graphHCurves, graphWCurves, graphHCurves - 10, graphLineWidth2 )
        #appDrawLineDir(1, 1, 1, 1, graphWCurves-100, graphHCurves, graphWCurves-100, graphHCurves - 10, graphLineWidth2 )

        # appDrawText(0.8,'KersCharge %             ' + str(KersCharge)                           , hw*8, fntSize*  0, fntSize*1.25, ExtGL.FONT_ALIGN_LEFT)
        # appDrawText(0.8,'KersInput %              ' + str(KersInput)                            , hw*8, fntSize*  2, fntSize*1.25, ExtGL.FONT_ALIGN_LEFT)
        # appDrawText(0.8,'ERSCurrentKJ             ' + str(ERSCurrentKJ)                         , hw*8, fntSize*  4, fntSize*1.25, ExtGL.FONT_ALIGN_LEFT)
        # appDrawText(0.8,'ERSMaxJ                  ' + str(ERSMaxJ)                              , hw*8, fntSize*  6, fntSize*1.25, ExtGL.FONT_ALIGN_LEFT)

    else:
        ###  use kunos graph - one pixel wide lines only
        if bCurve1ON and currentTorque!=None:
            if currentPow!=None and currentGas!=None:
                ac.addValueToGraph(histGraph, 0, currentPow)
        else:
            ac.addValueToGraph(histGraph, 0, -10)###

        if bCurve0ON and currentTorque!=None:
            ac.addValueToGraph(histGraph, 1, currentTorque)
        else:
            ac.addValueToGraph(histGraph, 1, -10)###

        if bCurve2ON and maxTurboBoost>0:
            #ac.addValueToGraph(histGraph, 2, currTurboBoost      )
            ac.addValueToGraph(histGraph, 2, currTurboBoost/maxTurboBoost*0.9*histGraphMaxValue      )
        else:
            ac.addValueToGraph(histGraph, 2, -10)###

        if bCurve3ON:
            ac.addValueToGraph(histGraph, 3, currentGas* histGraphMaxValue  )
        else:
            ac.addValueToGraph(histGraph, 3, -10)###

        if bCurve4ON:
            ac.addValueToGraph(histGraph, 4, currBrake* histGraphMaxValue-2   )
        else:
            ac.addValueToGraph(histGraph, 4, -10)###

        if bCurve5ON:
            ac.addValueToGraph(histGraph, 5, currFFB*histGraphMaxValue-3   )
        else:
            ac.addValueToGraph(histGraph, 5, -10)###

        if bCurve6ON:
            # ac.addValueToGraph(histGraph, 6, int((x-95)/5*histGraphMaxValue)-3   )
            ac.addValueToGraph(histGraph, 6, int(((min(ac_Grip))-95)/5*histGraphMaxValue)-3   )
        else:
            ac.addValueToGraph(histGraph, 6, -10)###

        if bCurve7ON:
            ac.addValueToGraph(histGraph, 7, int(dCurves[7]* histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 7, -10)###

        if bCurve8ON:
            ac.addValueToGraph(histGraph, 8, int(dCurves[8] * histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 8, -10)###

        if bCurve9ON and bSHOW_ERS and ERSMaxJ>0:
            ac.addValueToGraph(histGraph, 9, int(dCurves[9] * histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 9, -10)###

        if bCurve10ON and bSHOW_ERS and ERSMaxJ>0:
            ac.addValueToGraph(histGraph, 10, int(dCurves[10] * histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 10, -10)###

        if bCurve11ON and bSHOW_ERS and ERSMaxJ>0:
            ac.addValueToGraph(histGraph, 11, int(( dCurves[11] * histGraphMaxValue)-3   ))
        else:
            ac.addValueToGraph(histGraph, 11, -10)###

        if bCurve12ON and bSHOW_ERS and ERSMaxJ>0:
            ac.addValueToGraph(histGraph, 12, int(( dCurves[12] * histGraphMaxValue)-3   ))
        else:
            ac.addValueToGraph(histGraph, 12, -10)###

        if bCurve13ON:
            ac.addValueToGraph(histGraph, 13, int(dCurves[13] * histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 13, -10)###
        if bCurve14ON:
            ac.addValueToGraph(histGraph, 14, int(dCurves[14] * histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 14, -10)###
        if bCurve15ON:
            ac.addValueToGraph(histGraph, 15, int(dCurves[15] * histGraphMaxValue))
        else:
            ac.addValueToGraph(histGraph, 15, -10)###














# for testing
if __name__ == '__main__':
    # THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/dhs_nissan_skyline_2000gtr_Turbo"
    THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/bmw_e46_m3_csl"
    # THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/ag_subaru_impreza_wrx_tuned"
    # THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/rt_bacmono"
    # THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/bmw_z4_gt3"
    # THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/delage_15s8"
    # THECARDIR = "p:/Steam/steamapps/common/assettocorsa/content/cars/darche"
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/devel_sixteen'
    # THECARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/ks_toyota_ae86_tuned'
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ddm_toyota_mr2_sw20_shuto'
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/bo_singer_awd'
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ac_legends_bmw_csl'
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ier_p13c'
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/ks_porsche_cayenne
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/TeamEffort_LS400'
    # THECARDIR = 'p:/Steam/steamapps/common/assettocorsa/content/cars/shelby_cobra_427sc'
    # THECARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/volvo_p1800_cyan'
    THECARDIR = 'P:/Steam/steamapps/common/assettocorsa/content/cars/bmw_e46_m3_csl'
    ACD_FILE = ACD( THECARDIR )

    # appCheckCarSpecs(0, THECARDIR)
    # appCheckCarSpecs(0, 'tmm_clio_cup_x98')
    # appCheckCarSpecs(0, 'volvo_p1800_cyan')
    appCheckCarSpecs(0, 'bmw_e46_m3_csl')

    # appGetJsonInfo(THECARDIR + 'ui/ui_car.json', 'tmm_clio_cup_x98')
    # appGetJsonInfo('p:/Steam/steamapps/common/assettocorsa/content/cars/ac_legends_bmw_csl/ui/ui_car.json', 'ac_legends_bmw_csl')
