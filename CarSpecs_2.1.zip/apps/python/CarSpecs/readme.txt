v2.1
-added "apps\python\CarSpecs\curves\" folder in archive, required for the app to load at all :(

v2.0
-fixes for curves/traces plot
-made switching to another car a bit smother (some data might still be from your own car)

v1.9
-fixed max g-vals

v1.8
-added G-forces to curves

v1.7
-fix!

v1.6
-fix?

v1.5
-added peak holdtime for max values
--from Off/1-10 seconds

v1.4
-cleaner lines in curves window with linewidth > 1
-more robust creating of NM/HP graphs

v1.3
-fixes :)

v1.2
-fixed curves with text off
-added clutch

v1.1
-fixed ers display in torque/power graph
-fixed 'vanilla' AC compatibility

v1.0
-added ers stuff
-added option to toggle btw 3 modes: json, data, +gas (json+throttle info)
-slightly less choppy line drawing in curves window
-other fixes

v0.999g
-fixed saving opacity

v0.999f
-fixed fancy window always visible

v0.999
-update timer will be saved now
-window background hidden with no text
-added steering angle line (gray) to non-fancy mode too
-switched to using torque curve for power window, removed quirky power/rpm/throttle
-added handbrake
Note: fancy mode is required for lines with more than 1 pixel width
(non-fancy-mode uses original kunos graphs, which do not allow to change line width)
Note2: fancy mode should perform almost equally to non-fancy mode,
you must let python-debug app cool down a bit after using the controls :)

v0.99
-fixed drawing curves with some certain scaling values
-added steering angle to curves (grey)

v0.98
-added custom fancy drawing mode, plus some options for it
-the 3 sub-windows now have their own text/opacity settings
-more fault tolerant on strange cars

v0.97
-fixed load/save of enabled/disabled curves

v0.96
-added buttons in ui to disable any curve
-added grip to curves window (used minimum from the 4 tyres)
-made info window optional, also static in size, added some info
-disabled loading info from other cars when switching to them

v0.95
final

v0.92
fixed values for hybrid/electric cars

wip v0.91
most things work better with CSP




reference: lt_acd ACD extractor library from XuCrUtZ:
https://www.racedepartment.com/downloads/live-telemetry.31666/
(sorry i butcherd it badly)


-CarSpec app window has some car info
-the dim green graph in the background is trimmed down power/rpm graph, rotated 90°, mirrored to left/right, so rpm is up/down
-current power is the bright green bar, moving up and down, variing in wideness
-torque reading in blue is from csp, i guess negative values are motor brake or something?
-if car has a turbo, thats the red bar in the middle



--- extra torque feature ---
---    3 requirements    ---

1. use CSP >= 0.1.71

2. you need to add this to the cars
data\car.ini:
[HEADER]
VERSION=extended-2

3. you need to add this to the cars
data\engine.ini:
[_EXTENSION]
ENABLED=1
PYTHON_TORQUE_ALLOWED=1




on top of "...apps\python\CarSpecs\CarSpecs.py" there are some options:

--- extra torque feature --- control
joystickid        = 0
joystickbutton    = 3     # joystick button
keyboardbutton    = "3"   # some keyboard key

--- extra torque feature --- time and amount
TorqueExtraAmount = 100 # Nm extra
extraHoldtime     = 2.0 # seconds, after half that time,
                        # extraT gets decreased to 0 (also in half that time)
