### either run this script via commandline:
# python _standalone_ai2cam.py full_path_to_fastlane.ai

### or edit line 388 to insert a full filename for fast_lane.ai and just run:
# python _standalone_ai2cam.py

#############################################################################
### user vars for camera generating #########################################
###    in the last function for 3 camera sets
#############################################################################

import sys, os, io, struct, math, random

### for a-b tracks, if ai line is longer than only btw start/finish gates
### dont touch!
offIN = 0
offOUT = 0
#############################################################################
camCount    = 0    ### running camera number in new cameras.ini
camINIid    = 0    ### id of cameras.ini
scaling     = 0.01  ### unused atm
odd         = True ### unused atm
camini      = []
lowcams     = 0
lowFOVcams  = 0
highcams    = 0
anims       = 0

def distance(point1, point2) -> float:
    return math.sqrt((point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2)

def appGetNumberedFilename(sBase, sExt):
    global camINIid
    newname=sBase + sExt
    i=1
    while os.path.isfile(newname) and i<50:
        newname = sBase + '_' + str(i) + sExt
        i+=1
    if i>=50:
        print('filenames outnumbered!')
        return ''
    camINIid = i
    return newname

def get_ac_coords(ob):
  return(str(round(ob[0],6))+', '
        +str(round(ob[2],6))+', '
        +str(round(ob[1],6)) )

def get_ac_coordsBlenderVector(ob):
  #ss=str(ob.matrix_world.to_translation()).replace('<Vector (','')
  ss=str(ob.matrix_world.to_translation()).replace('<Vector (','')
  ss=ss.replace(')>','')
  ss=ss.replace(' ','')
  sss = ss.split(',')
  return(str(round(float(sss[0])* 100.0, 4) )+', '
        +str(round(float(sss[2])* 100.0, 4) ) + ', '
        +str(round(float(sss[1])*-100.0, 4) ) )

def buildCameraEntry(cCount, fCamPos, fOrientation, fOrientationUP, potL, potC, vminFov=30, vmaxFov=50, isFixed=False):
    lines=[]
    lines.append('[CAMERA_' + str(cCount) + ']'       + '\n')
    lines.append('NAME=Camera ' + str(cCount)         + '\n')
    lines.append('POSITION=' + fCamPos                + '\n')
    lines.append('FORWARD=' + fOrientation            + '\n')
    lines.append('UP=' + fOrientationUP               + '\n')
    lines.append('IN_POINT=' + '{:.6f}'.format(potL)  + '\n')
    lines.append('OUT_POINT=' + '{:.6f}'.format(potC) + '\n')
    lines.append('MIN_FOV=' + str(vminFov)            + '\n')
    lines.append('MAX_FOV=' + str(vmaxFov)            + '\n')
    lines.append('SHADOW_SPLIT0=50'                   + '\n')
    lines.append('SHADOW_SPLIT1=250'                  + '\n')
    lines.append('SHADOW_SPLIT2=1350'                 + '\n')
    lines.append('NEAR_PLANE=0.1'                     + '\n')
    lines.append('FAR_PLANE=10000'                    + '\n')
    lines.append('MIN_EXPOSURE=0.35'                  + '\n')
    lines.append('MAX_EXPOSURE=0.55'                  + '\n')
    lines.append('DOF_FACTOR=1'                       + '\n')
    lines.append('DOF_RANGE=100'                      + '\n')
    lines.append('DOF_FOCUS=0'                        + '\n')
    lines.append('DOF_MANUAL=0'                       + '\n')
    lines.append('SPLINE='                            + '\n')
    lines.append('SPLINE_ROTATION=0'                  + '\n')
    lines.append('FOV_GAMMA=0.5'                      + '\n')
    lines.append('SPLINE_ANIMATION_LENGTH=0'          + '\n')
    lines.append('IS_FIXED=' + str(int(isFixed))      + '\n')
    lines.append(''                                   + '\n')
    return lines

def CreateCamerasFromDataPoints(filepath, data_ideal, data_detail, scaling):
    global camCount, odd, camini, offIN, offOUT, lowcams, lowFOVcams, highcams, anims, camINIid
    global distIN, distOUT, maxCamheight, minCamheight, minFOV, maxFOV

    baseIdx = offIN + 1
    datalen = len(data_ideal) - 1 - offOUT
    tracklen = 0 # data_ideal[datalen][3] - data_ideal[offIN][3]
    for i in range(baseIdx, datalen):
        #data_ideal[i][3] = tracklen
        distl = distance( data_ideal[i], data_ideal[i-1] )
        if distl<100.0:
            tracklen += distl

    lastPoTIN = 0.0
    camCount = 0
    slopeIN = 0.0
    slopeOUT = 0.0
    slopeCAM = 0.0
    slopeINlast = 0.0
    slopeOUTlast = 0.0
    coords=(0.0,0.0,0.0)
    lastLOWFOV=0
    animDone = False
    straight = 0
    dist = 0.0
    distI = 0.0
    distO = 0.0
    lastdist = 0.0

    # print('first coord:             ' + str(data_ideal[0]      [0])+',' + str(data_ideal[0]      [1])+',' + str(data_ideal[0]      [2]))
    # print(' last coord:             ' + str(data_ideal[datalen][0])+',' + str(data_ideal[datalen][1])+',' + str(data_ideal[datalen][2]))
    #tracklen = tracklen * scaling ### ???
    print("Calculated track length: " + str(tracklen))

    while baseIdx < datalen and lastdist <= tracklen:
        xin, zin, yin, _, _ = data_ideal[baseIdx]
        xin1, zin1, yin1, _, _ = data_ideal[baseIdx-1]
        distLin = data_detail[baseIdx][6]
        distRin = data_detail[baseIdx][7]
        global minFOV, maxFOV, maxCamheight, minCamheight
        camheightDiff = maxCamheight - minCamheight



        # fast forward from last OUT_POINT/current IN_POINT to next campos
        distI = lastdist
        while baseIdx<datalen and distI < lastdist + distIN:
            # dist += data_ideal[baseIdx][3] - data_ideal[baseIdx-1][3]
            distI += distance( data_ideal[baseIdx], data_ideal[baseIdx-1] )
            baseIdx += 1



        ### we dont need that
        ### currPoTCalced = abs( (data_ideal[baseIdx][3] ) / tracklen  )

        ### but wee need cam/border pos here
        ### baseIdx/camera at cPoT current Point of Track
        x, z, y, _, _ = data_ideal[baseIdx]
        x1, z1, y1, _, _ = data_ideal[baseIdx-1]
        distLcam = data_detail[baseIdx][6]
        distRcam = data_detail[baseIdx][7]
        direction = -math.degrees( math.atan2(data_ideal[baseIdx-1][2] - data_ideal[baseIdx][2], data_ideal[baseIdx][0] - data_ideal[baseIdx-1][0]))
        xl = x + math.cos((-direction + 90) * math.pi / 180) * data_detail[baseIdx][6] # _wallLeft
        yl = y - math.sin((-direction + 90) * math.pi / 180) * data_detail[baseIdx][6] # _wallLeft
        xr = x + math.cos((-direction - 90) * math.pi / 180) * data_detail[baseIdx][7] # _wallRight
        yr = y - math.sin((-direction - 90) * math.pi / 180) * data_detail[baseIdx][7] # _wallRight

        slopeCAM = (y-y1) / (x-x1)
        slopeIN  = (yin-yin1) / (xin-xin1)

        # fast forward from current pot to OUT_POINT
        distO = distI
        while baseIdx<datalen and distO < lastdist + distIN + distOUT:
            # dist += data_ideal[baseIdx][3] - data_ideal[baseIdx-1][3]
            distO += distance( data_ideal[baseIdx], data_ideal[baseIdx-1] )
            baseIdx += 1

        if distI>0.0 and distO>0.0:
            # currPoTOUT = abs( (data_ideal[baseIdx][3] ) / tracklen  )
            currPoTOUT = abs( ( distO ) / tracklen  )
            xout, zout, yout, _, _    = data_ideal[baseIdx]
            xout1, zout1, yout1, _, _ = data_ideal[baseIdx-1]
            slopeOUT = (yout-yout1) / (xout-xout1)
            angle1 = (math.degrees( math.atan(slopeIN)   ) + 90) * 2
            angle2 = (math.degrees( math.atan(slopeCAM)  ) + 90) * 2
            angle3 = (math.degrees( math.atan(slopeOUT)  ) + 90) * 2
            angle4 = math.degrees( math.atan2((yin -yin1 ) , (xin  -xin1 )) ) +180
            angle5 = math.degrees( math.atan2((y   -y1   ) , (x    -x1   )) ) +180
            angle6 = math.degrees( math.atan2((yout-yout1) , (xout -xout1)) ) +180

            if abs(angle1-angle2)<2.5 and abs(angle2-angle3)<2.5:
                straight += 1
            #    print('  straight                            '  + str(int(angle1)) + '    ' + str(int(angle2)) + '    ' + str(int(angle3)) + '    ' + str(int(angle4))  + '    ' + str(int(angle5))   + '    ' + str(int(angle6)) )
            #else:
            #    print('                                      '  + str(int(angle1)) + '    ' + str(int(angle2)) + '    ' + str(int(angle3)) + '    ' + str(int(angle4))  + '    ' + str(int(angle5))   + '    ' + str(int(angle6)) )

            # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
            print(str(camCount) + '   ' + str(int(distI)) + ' m  -  id ' + str(baseIdx) + ' -  ' + str(round(100*currPoTOUT,1)) + '%')
            # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

            # more vars to set
            FOV2 = minFOV + random.random()*(maxFOV-minFOV)
            if FOV2>40:
                FOV=FOV2
            else:
                FOV=FOV2*0.666

            ##########################################################
            ### variation - just switch one from one side to the other, incative
            # if odd:
            #     coords = ( float(xl), float(yl), float(z+camheightMin+random.random()*camheightDiff)  )
            # else:
            #     coords = ( float(xr), float(yr), float(z+camheightMin+random.random()*camheightDiff)  )
            # odd = not odd

            ##########################################################
            ### guessing by distance from ai line
            distL = data_detail[baseIdx][6]
            distR = data_detail[baseIdx][7]
            # right corner
            if distL > distR and distLin > distRin and distLcam < distRcam:
                # use right side
                coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )
            # left corner
            elif distL < distR and distLin < distRin and distLcam > distRcam:
                # use left side
                coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
            # ai on the left
            elif distL < distR and distLin < distRin and distLcam < distRcam:
                # use right side
                coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )
            # ai on the right
            elif distL > distR and distLin > distRin and distLcam > distRcam:
                # use left side
                coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
            elif distLin > distRin:
                if distLcam > distRcam:
                    # use left side
                    coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
                else:
                    # use right side
                    coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )
            else:
                if distLcam > distRcam:
                    # use left side
                    coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
                else:
                    # use right side
                    coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )

            ##########################################################
            ### -if ai-line slope only changed so much then put cam very low
            if abs(slopeINlast -slopeIN )>0.35 and \
                abs(slopeOUTlast-slopeOUT)>0.35 and \
                abs(zin         -       z)>0.1  and \
                abs(z           -    zout)>0.1 :
                coords = ( coords[0], coords[1], z+maxCamheight*0.8666)
                lowcams += 1
                ### hack to have MORE anims
                # lastLOWFOV += 1

            ##########################################################
            ### in case of a long straight go low with fov
            if abs(slopeINlast -slopeIN )>0.25 and \
                abs(slopeOUTlast-slopeOUT)>0.25 and \
                abs(zin         -       z)>1.0  and \
                abs(z           -    zout)>1.0  and \
                ((distL < distR and distLin < distRin and distLcam < distRcam) or (distL > distR and distLin > distRin and distLcam > distRcam)) :
                FOV = minFOV
                lowFOVcams += 1
                lastLOWFOV += 1

            ### hack to not have too much anims
            #if abs(zin-z)>1 and abs(z-zout)>1:
            #    lastLOWFOV -= 1

            ##########################################################
            ### special case when it goes up/down a lot, then we go high with cam
            if abs(zin-z)>6.5 and abs(z-zout)>6.5:
                coords = ( coords[0], coords[1], z+maxCamheight)
                highcams += 1

            ##########################################################
            # fOrientation, fOrientationUP FORWARD= and UP=
            ### !!! this is probably completely wrong
            ### !!! not tested with IS_FIXED=0
            xdir = math.sin(direction)
            ydir = math.cos(direction)

            ##########################################################
            # now build cam section
            camini += buildCameraEntry(camCount,
                get_ac_coords(coords),                      ### POSITION
                str(round(xdir,4))+",0,"+str(round(ydir,4)),  ### FORWARD
                "0,1,0",                                    ### UP
                lastPoTIN, currPoTOUT,
                int(FOV), int(FOV2))

            ##########################################################
            # add anims
            if lastLOWFOV>0 and anims<=3:   ### and not animDone:
                coords = ( coords[0], coords[1], z+maxCamheight-camheightDiff/8 )
                get_ac_coords(coords)
                ### build new csv filename
                sFileDir = os.path.dirname(filepath).replace('\\', '/').replace('/ai', '/data')
                if not os.path.isdir(sFileDir):
                    sFileDir = os.path.dirname(filepath)
                sFileCSV = sFileDir + '/c_' + str(camINIid-1) + '_' + str(camCount) + '.csv'
                camini[len(camini)-6] = 'SPLINE=' + os.path.basename(sFileCSV)+'\n'
                camini[len(camini)-3] = 'SPLINE_ANIMATION_LENGTH=20\n'
                with io.open(sFileCSV, 'w', encoding='utf-8') as f:
                    if animDone:
                        f.writelines("0.0,0.0,0.0\n")
                        f.writelines("0.0,5.0,0.0\n")
                        animDone = False
                    else:
                        f.writelines("0.0,5.0,0.0\n")
                        f.writelines("0.0,0.0,0.0\n")
                        animDone = True
                anims += 1

            baseIdx += 1
            camCount += 1
            lastPoTIN = currPoTOUT
            slopeINlast = slopeIN
            slopeOUTlast = slopeOUT
            if lastLOWFOV>0:
                lastLOWFOV -= 1
        else:
            print('could not find in/out points')
            break

        lastdist = distO

    ### done
    print('generated '+ str(camCount) + ' cams: ' + str(lowcams) +  ' lowcams, '+ str(lowFOVcams) +  ' lowFOVcams, ' + str(highcams) + ' highcams, ' + str(anims) + ' anims, ' + str(straight) + ' straights' )
    return camini

def loadailineandcreatecams(filepath):
    global camini
    if not os.path.isfile(filepath):
        print('file does not exist! ' + filepath)
    else:
        with open(filepath, "rb") as buffer:
            # temporary arrays
            data_ideal = []
            data_detail = []

            # should be at start, but do it anyway
            buffer.seek(0)
            # read header, detailCount is number of data points available
            header, detailCount, u1, u2 = struct.unpack("4i", buffer.read(4 * 4))

            # read ideal-line data
            for i in range(detailCount):       # 4 floats, one integer
                data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
            # read more details data
            for i in range(detailCount):        # 18 floats
                data_detail.append(struct.unpack("18f", buffer.read(4 * 18)))

            print('len  : ' + str(detailCount) + ' | ' + str(data_ideal[detailCount-1][3]) + '  |  ' + filepath)

            ### find new camera filename
            sFileDir = os.path.dirname(filepath).replace('\\', '/').replace('/ai', '/data')
            if os.path.isdir(sFileDir):
                sFileCameras = appGetNumberedFilename(sFileDir + '/cameras', '.ini')
            else:
                sFileCameras = appGetNumberedFilename(os.path.dirname(os.path.realpath(filepath)) + '/cameras', '.ini')

            # create CAMERAS.ini in memory
            camini = []
            camini = CreateCamerasFromDataPoints(filepath, data_ideal, data_detail, scaling)
            if len(camini)>0:
                ### write all the lines
                with io.open(sFileCameras, 'w', encoding='utf-8') as f:
                    f.writelines('[HEADER]\n')
                    f.writelines('VERSION=3'+'\n')
                    f.writelines('CAMERA_COUNT=' + str(camCount)+'\n')
                    f.writelines('SET_NAME=Set'  + str(camINIid-1)+'\n')
                    f.writelines('\n')
                    camini[len(camini)-20] = 'OUT_POINT=1.0\n'
                    for s in camini:
                        f.writelines(s)
                    print('written ' + sFileCameras)






THEFILE     = ''
if __name__ == '__main__':
    ### uncomment and set THEFILE manually ###
    # THEFILE = ''
    # THEFILE = ''
    # THEFILE = ''
    # THEFILE = ''
    # THEFILE = ''
    #THEFILE = 'p:/Steam/steamapps/common/assettocorsa/content/tracks/rt_azure_coast/tcombreverse/ai/fast_lane.ai'
    #THEFILE = 'p:/Steam/steamapps/common/assettocorsa/content/tracks/rmi_suncity_evolution/city/ai/fast_lane.ai'

    ### set by cmd params ###
    if THEFILE == '':
        if len(sys.argv)<=1:
            print('filename missing. Exit.')
            sys.exit()
        THEFILE = sys.argv[1]

    if os.path.isfile(THEFILE):
        print('file not found: ' + THEFILE)
    else:
        ### added anims depends on how many straights there are
        ### anims are simple up/down anims, max 4 times atm, lock for "anims" to unlock more

        distIN       = 90     ### in meters, both added equals wanted distance btw cameras
        distOUT      = 110     ###
        maxCamheight = 5      ### will be randomly choosen between those two
        minCamheight = 0.5   ### on curvy hillclimbs ai borders maybe under the road
        minFOV       = 20     ### will be randomly choosen between those two
        maxFOV       = 50
        anims = 0
        loadailineandcreatecams( THEFILE )

        distIN       = 100     ### in meters, both added equals wanted distance btw cameras
        distOUT      = 120     ###
        maxCamheight = 10      ### will be randomly choosen between those two
        minCamheight = 2       ### on curvy hillclimbs ai borders maybe under the road
        minFOV       = 10      ### will be randomly choosen between those two
        maxFOV       = 40
        anims = 0
        loadailineandcreatecams( THEFILE )

        distIN       = 120     ### in meters, both added equals wanted distance btw cameras
        distOUT      = 140     ###
        maxCamheight = 20      ### will be randomly choosen between those two
        minCamheight = 2       ### on curvy hillclimbs ai borders maybe under the road
        minFOV       = 5      ### will be randomly choosen between those two
        maxFOV       = 40
        anims = 0
        loadailineandcreatecams( THEFILE )

