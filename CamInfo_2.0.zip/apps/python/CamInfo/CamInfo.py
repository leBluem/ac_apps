### user vars for camera generating ##############################################
###   in the last function !!!

### for a-b tracks, if you know at which PoT start/finish gates are
### dont touch!
offIN = 0
offOUT = 0

##################################################################################
camCount    = 0    ### running camera number in new cameras.ini
camINIid    = 0    ### id of cameras.ini
scaling     = 100  ### unused atm
odd         = True ### unused atm
camini      = []
lowcams     = 0
lowFOVcams  = 0
highcams    = 0
anims       = 0
updateInterval =  0.25
fileID = 0
camID  = 0
camINIspinner = 0
camIDspinner  = 0
currCamINI=''
currCamID=''
currINIID=0
##################################################################################

import ac, acsys
import os, traceback, configparser, re, threading, collections, functools, io, struct, math, random

# unused atm
# import sys, platform, codecs, stat,
# from cam_siminfo import info

bCSPactive = False
if 'ext_getCameraPos' in dir(ac):
    bCSPactive = True

iCSPcode = 0
if not 'ext_getCurrentTrackCamera' in dir(ac):
    bCSPactive = False
else:
    iCSPcode = ac.ext_patchVersionCode()

sappversion = "2.0"
camnames = ["Cockpit","Car","Drivable","Track","Helicopter","OnBoardFree","Free","Random","ImageGeneratorCamera","Start"]
# acfolder = os.path.dirname(os.path.realpath(__file__)).lower().replace('apps\\python\\caminfo','')

error = 0
timer = 0.0
app = 0
label1 = 0
label2 = 0
camfileNum = 0
lbcamINIspinner = 0
lbcamIDspinner = 0
bUpdatingControls = False
hidden=False
minfovspinner = 0
maxfovspinner = 0
currSect = ''
thread = 0
btnSave = 0
btnUpdateIN = 0
btnUpdateOUT = 0
btnEditor = 0
btnAddCams = 0
btnCopy = 0
btnDelete = 0
btnAdd = 0
btnReload = 0
chkbox_isFixed = 0
sOrientationFORW = ''
sOrientationUP = ''
sVer = ''
sCurrCam = ''
btimerMsg = False
timerMsg = 5.0

cams=[]
camsIN=[]
camsOUT=[]
camsCSV=[]
camsNums=[]
camsSections=[]
camsHeader=[]
camsFileNames=[]
# bKeepReplayInsync = True
sTrack =''
sLayout =''
sFileOverlay =''
sFileCameras =''
sFilefastlaneAI =''

#####################################################################

def HideControls():
    global chkbox_isFixed, minfovspinner, maxfovspinner, btnSave, btnUpdateIN, btnUpdateOUT, hidden
    global btnAdd, btnDelete, label2
    if not hidden:
        # ac.setVisible(label2,0)
        ac.setVisible(minfovspinner,0)
        ac.setVisible(maxfovspinner,0)
        ac.setVisible(btnSave,0)
        ac.setVisible(btnUpdateIN,0)
        ac.setVisible(btnUpdateOUT,0)
        ac.setVisible(chkbox_isFixed,0)
        ac.setVisible(btnAdd  ,0)
        ac.setVisible(btnDelete,0)
        ac.setSize(app, 300, 250)
        hidden=True

def ShowControls():
    global chkbox_isFixed, minfovspinner, maxfovspinner, btnSave, btnUpdateIN, btnUpdateOUT, hidden
    global btnAdd, btnDelete, label2
    if hidden:
        ac.setSize(app, 300, 500)
        #ac.setVisible(label2,1)
        ac.setVisible(minfovspinner,1)
        ac.setVisible(maxfovspinner,1)
        ac.setVisible(btnSave,1)
        ac.setVisible(btnUpdateIN,1)
        ac.setVisible(btnUpdateOUT,1)
        ac.setVisible(chkbox_isFixed,1)
        ac.setVisible(btnAdd  ,1)
        ac.setVisible(btnDelete,1)
        hidden=False

def doStuffminFOV():
    global minfovspinner, maxfovspinner, bUpdatingControls
    currFOV = ac.getValue(minfovspinner)
    vmaxFov  = ac.getValue(maxfovspinner)
    if vmaxFov<currFOV:
        bUpdatingControls=True
        ac.setValue(maxfovspinner, currFOV)
        bUpdatingControls=False
    ac.ext_setCameraFov(currFOV)

def doStuffmaxFOV():
    global minfovspinner, maxfovspinner, bUpdatingControls
    vminFov  = ac.getValue(minfovspinner)
    currFOV = ac.getValue(maxfovspinner)
    if vminFov>currFOV:
        bUpdatingControls=True
        ac.setValue(minfovspinner, currFOV)
        bUpdatingControls=False
    ac.ext_setCameraFov(currFOV)

def onminFOVspin(*args):
    doStuffminFOV()

def onmaxFOVspin(*args):
    doStuffmaxFOV()

def appUpdateCurrValues():
    global camINIspinner, camIDspinner, camID, fileID
    global timerMsg, btimerMsg, minfovspinner, maxfovspinner, currCamID, currCamINI, camsFileNames
    fileID = int(ac.getValue(camINIspinner))
    camID = int(ac.getValue(camIDspinner))
    currCamINI = camsFileNames[fileID]
    currCamID = 'CAMERA_'+ str(camID)

###############################################################################

def comp_func(s1,s2):
    if not '_' in s1[0] or not '_' in s2[0]:
        return 1
    s11, s12 = s1[0].split('_')
    s21, s22 = s2[0].split('_')
    r = 1 if int(s12) > int(s22) else -1
    return r

def getvalue(s):
    if ';' in s:
        return s.split(';')[0]
    if '#' in s:
        return s.split('#')[0]
    if '/' in s:
        return s.split('/')[0]
    if '_' in s:
        return s.split('_')[0]
    if '|' in s:
        return s.split('|')[0]
    return s

def writeitems(f, items):
    for item in items:
        f.write(item[0] + '=' + item[1] + '\n')

def appAddNewCam(*args):
    global app, timerMsg, btimerMsg, camID, minfovspinner, maxfovspinner, currCamINI, currCamID, currINIID, bUpdatingControls, fileID
    global bCSPactive
    if not bCSPactive:
        return
    try:
        currCar = 0   ### ac.getFocusedCar()
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        appUpdateCurrValues()
        currCamID = 'CAMERA_'+ str(camID)
        nextCamID = 'CAMERA_'+ str(camID+1)
        prevCamID = 'CAMERA_'+ str(camID-1)

        config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_","|"), comment_prefixes=(";","#","/","_","|"))
        config.optionxform = str
        config.read(currCamINI)

        ### ie #############################################################
        # [CAMERA_5]             [CAMERA_5]                                #
        # IN_POINT=0.1           IN_POINT=0.1                              #
        # OUT_POINT=0.2          OUT_POINT=0.1666   [CAMERA_6]             #
        #                                           IN_POINT=0.1666        #
        # [CAMERA_6]             [CAMERA_7]         OUT_POINT=0.2333       #
        # IN_POINT=0.2           IN_POINT=0.2333                           #
        # OUT_POINT=0.3          OUT_POINT=0.3                             #
        if camID == 0:
            # first cam
            lIN      = float(getvalue( config.get(currCamID, 'IN_POINT' ) ))
            lOUT     = float(getvalue( config.get(currCamID, 'OUT_POINT') ))
            if config.has_section(nextCamID):
                lIN2     = float(getvalue( config.get(nextCamID, 'IN_POINT' ) ))
                lOUT2    = float(getvalue( config.get(nextCamID, 'OUT_POINT') ))
                new_pointOUT = str ( round( lOUT/2.0, 6) )
            else:
                lOUT2    = float(getvalue( config.get(nextCamID, 'OUT_POINT') ))
                new_pointOUT = str ( round( lOUT/2.0, 6) )
            new_pointIN  = str ( "0.0" )
            config.set(currCamID, 'OUT_POINT'  , new_pointOUT)
        elif   camID >= camsNums[int(fileID)]-1:
            # last cam
            lIN      = float(getvalue( config.get(currCamID, 'IN_POINT' ) ))
            lOUT     = float(getvalue( config.get(currCamID, 'OUT_POINT') ))
            if config.has_section(prevCamID):
                lIN2     = float(getvalue( config.get(prevCamID, 'IN_POINT' ) ))
                lOUT2    = float(getvalue( config.get(prevCamID, 'OUT_POINT') ))
                diff=(lOUT-lIN)/2
                new_pointIN  = str ( abs(round( 1-lOUT - lOUT2, 6)) )
                new_pointOUT = str ( round( lIN-diff, 6) )
                config.set(currCamID, 'IN_POINT'  , new_pointIN)
                new_pointIN = str ( round( lIN+diff, 6) )
                config.set(currCamID, 'OUT_POINT' , new_pointIN)
                new_pointOUT = "1.0"
            else:
                new_pointIN  = str ( round( lIN, 6) )
                new_pointOUT = "1.0"
            if lOUT>=1.0:
                new_pointOUT = str ( "1.0" )
            else:
                new_pointOUT = str ( round( 1.0-lOUT, 6) )
            if lOUT<currPoT:
                new_pointOUT = min(1.0, currPoT + (1-new_pointOUT)/2)
        else:
            # cam in between
            #lIN2     = currPoT
            #lOUT2    = 1.0
            lIN      = float(getvalue( config.get(currCamID, 'IN_POINT' ) ))
            lOUT     = float(getvalue( config.get(currCamID, 'OUT_POINT') ))
            lIN2     = float(getvalue( config.get(nextCamID, 'IN_POINT' ) ))
            lOUT2    = float(getvalue( config.get(nextCamID, 'OUT_POINT') ))
            if lOUT!=lIN2:   ### just close the gap, dont recalc
                new_pointIN  = str ( round(lOUT, 6))
                new_pointOUT = str ( round(lIN2, 6))
                # config.set(currCamID , 'OUT_POINT' , new_pointIN)
                # config.set(nextCamID , 'IN_POINT'  , new_pointOUT)
            else:
                diffa = (lIN2-lIN)/3 # 0.06666
                if currPoT>lIN and currPoT<lOUT2:
                    new_pointIN  = str ( round(currPoT       , 6) )
                else:
                    new_pointIN  = str ( round(lIN  + diffa  , 6) ) # 0.06666
                new_pointOUT = str ( round(lIN2 + diffa  , 6) ) # 0.13333
                config.set(currCamID , 'OUT_POINT' , new_pointIN)
                config.set(nextCamID , 'IN_POINT'  , new_pointOUT)



        ### rename sections, removing new CurrCamID
        c2 = camsNums[int(fileID)]+2
        if config.has_section(currCamID):
            while c2 > camID+2:
                sect1 = 'CAMERA_'+ str(c2-1)
                sect2 = 'CAMERA_'+ str(c2-2)
                c2-=1
                if config.has_section(sect2) and not config.has_section(sect1):
                    #print('rename ' + sect2 + ' -> ' + sect1)
                    items = config.items(sect2)
                    config.remove_section(sect2)
                    config.add_section(sect1)
                    for item in items:
                        config.set(sect1, item[0], item[1])
                    config.set(sect1, 'NAME', 'Camera ' + str(c2))

        ### nextCamID is now the new camera section
        # copy all vals from previous
        if not config.has_section(nextCamID):
            config.add_section(nextCamID)
            for key in config[currCamID]:
                config.set(nextCamID, key, config[currCamID][key])
        # but set in/out
        if camID == 0 or camID == camsNums[int(fileID)]:
            #config.set(currCamID, 'IN_POINT'   , new_pointIN )
            config.set(currCamID, 'OUT_POINT'  , new_pointOUT)
            config.set(nextCamID, 'IN_POINT'   , new_pointOUT)
            config.set(nextCamID, 'OUT_POINT'  , str(round(float(lOUT), 6)) )
        else:
            config.set(nextCamID, 'IN_POINT'   , new_pointIN)
            config.set(nextCamID, 'OUT_POINT'  , new_pointOUT)

        config.set(nextCamID, 'NAME', 'Camera ' + str(camID+1))
        # set values from controls
        campos = ', '.join(str(round(x, 6)) for x in ac.ext_getCameraPos())
        fovMin = int(ac.getValue(minfovspinner))
        fovMax = int(ac.getValue(maxfovspinner))
        camview1= ', '.join(str(round(x, 6)) for x in ac.ext_getCameraView())
        camview = camview1.split(',')
        camfor  = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
        camup   = str(float(camview[1])) + ", " + str( float(camview[5])) + ", " + str(float(camview[ 9]))
        config.set(nextCamID, 'POSITION', campos)
        config.set(nextCamID, 'FORWARD' , camfor)
        config.set(nextCamID, 'UP'      , camup)
        config.set(nextCamID, 'MIN_FOV' , str(fovMin))
        config.set(nextCamID, 'MAX_FOV' , str(fovMax))

        config.set('HEADER', 'CAMERA_COUNT', str(len(config.sections())-1))

        ### # write v2
        config._sections = collections.OrderedDict( sorted(config._sections.items(), key=functools.cmp_to_key(comp_func)) )
        with open(currCamINI, 'w') as f:
            config.write(f, space_around_delimiters=False)

        # refresh all cam data
        bUpdatingControls=True
        readAllCams()
        bUpdatingControls=True
        doStuffcamID()
        bUpdatingControls=False
        ac.setCameraMode(3)

        ac.setTitle(app, 'written to ini!')
        btimerMsg=True
        timerMsg=2.0

    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())


def appDelCurrentCam(*args):
    global app, label2, timerMsg, btimerMsg, minfovspinner, maxfovspinner, currCamINI, currCamID, currINIID, bUpdatingControls, fileID
    try:
        currCar = ac.getFocusedCar()
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        appUpdateCurrValues()

        config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_"), comment_prefixes=(";","#","/","_"))
        config.optionxform = str
        config.read(currCamINI)

        if not config.has_section(currCamID):
            ac.setText(label2, ac.getText(label2) + '\ncam missing: ' + currCamID)

            # refresh all cam data
            bUpdatingControls=True
            readAllCams()
            bUpdatingControls=True
            doStuffcamID()
            bUpdatingControls=False

            btimerMsg=True
            timerMsg=2.0
        else:
            lIN = config.get(currCamID, 'IN_POINT')
            lOUT = config.get(currCamID, 'OUT_POINT')
            config.remove_section(currCamID)

            maxsect = len(config.sections())
            c2=camID
            while c2<maxsect-1:
                sect1 = 'CAMERA_'+ str(c2)
                sect2 = 'CAMERA_'+ str(c2+1)
                # ac.log('rename ' + sect2 + ' -> ' + sect1)
                # ac.log('rename ' + sect2 + ' -> ' + sect1)
                c2+=1
                items = config.items(sect2)
                config.remove_section(sect2)
                config.add_section(sect1)
                for item in items:
                    config.set(sect1, item[0], item[1])

            if camID==0:
                config.set(currCamID, 'IN_POINT','0.0')  # only set IN_POINT to 0.0
            elif camID+1>=len(config.sections()):
                currCamID2 = 'CAMERA_'+ str(camID-1)
                config.set(currCamID2, 'OUT_POINT', '1.0') # only set OUT_POINT to 1.0
            else:
                # set OUT for previous and IN for current camera (the one we deleted)
                currCamID2 = 'CAMERA_'+ str(camID-1)
                # average out old values
                new_point = str ( ( float(lOUT)+float(lIN) ) / 2.0 )
                config.set(currCamID2, 'OUT_POINT', new_point)
                config.set(currCamID , 'IN_POINT' , new_point)
            config.set('HEADER', 'CAMERA_COUNT', str(len(config.sections())-1))

            with open(currCamINI, 'w') as f:
                config.write(f, space_around_delimiters=False)

            # refresh all cam data
            bUpdatingControls=True
            readAllCams()
            bUpdatingControls=True
            doStuffcamID()
            bUpdatingControls=False
            ac.setCameraMode(3)

            ac.setTitle(app, 'written to ini!')
            btimerMsg=True
            timerMsg=2.0
    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())


def appUpdateIN(*args):
    global camINIspinner, camIDspinner, bUpdatingControls, camsNums, camID, fileID
    global timerMsg, btimerMsg, minfovspinner, maxfovspinner, currCamINI, currCamID, currINIID
    try:
        currCar = ac.getFocusedCar()
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        appUpdateCurrValues()

        config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_","|"), comment_prefixes=(";","#","/","_","|"))
        config.optionxform = str
        config.read(currCamINI)
        ac.log('Updating IN ' + currCamINI + ' ' + currCamID)

        # update IN_POINT= of current
        # update OUT_POINT= of previous camera
        if camID-1 >= 0:
            config.set(currCamID, 'IN_POINT', str(round(currPoT, 5)) )
            currCamID = 'CAMERA_'+ str(camID-1)
            ac.log('  and ' + currCamID)
            config.set(currCamID, 'OUT_POINT', str(round(currPoT, 5)) )
        else:
            # on first cam set 0 and no outpoint
            config.set(currCamID, 'IN_POINT', '0.0' )

        with open(currCamINI, 'w') as f:
            config.write(f, space_around_delimiters=False)

        # refresh all cam data
        bUpdatingControls=True
        readAllCams()
        bUpdatingControls=True
        doStuffcamID()
        bUpdatingControls=False
        ac.setCameraMode(3)

        ac.setTitle(app, 'written to ini!')
        btimerMsg=True
        timerMsg=2.0
    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())

def appUpdateOUT(*args):
    global camINIspinner, camIDspinner, bUpdatingControls, camID, fileID
    global timerMsg, btimerMsg, minfovspinner, maxfovspinner, currCamINI, currCamID, currINIID, camsNums
    try:
        currCar = ac.getFocusedCar()
        currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
        appUpdateCurrValues()

        ac.log('Updating ' + currCamINI)
        ac.log('Updating OUT ' + currCamINI + ' ' + currCamID)
        # currCamID = 'CAMERA_'+ str(camID)
        # if camID>0:
        #     camID -= 1
        # currCamID = 'CAMERA_'+ str(camID)

        config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_","|"), comment_prefixes=(";","#","/","_","|"))
        config.optionxform = str
        config.read(currCamINI)

        # update OUT_POINT= of current
        # update IN_POINT= of next camera
        if camID+1>=camsNums[fileID]:
            ### last cam
            config.set(currCamID, 'OUT_POINT', '1.0' )
        else:
            config.set(currCamID, 'OUT_POINT', str(round(currPoT, 5)) )
            currCamID = 'CAMERA_'+ str(camID+1)
            config.set(currCamID, 'IN_POINT', str(round(currPoT, 5)) )

        with open(currCamINI, 'w') as f:
            config.write(f, space_around_delimiters=False)

        # refresh all cam data
        bUpdatingControls=True
        readAllCams()
        bUpdatingControls=True
        doStuffcamID()
        bUpdatingControls=False
        ac.setCameraMode(3)

        ac.setTitle(app, 'written to ini!')
        btimerMsg=True
        timerMsg=2.0
    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())

def appSaveToCamerasINI(*args):
    global camINIspinner, camIDspinner, bUpdatingControls
    global timerMsg, btimerMsg, minfovspinner, maxfovspinner, currCamINI, currCamID
    try:
        global bCSPactive
        if not bCSPactive:
            return
        appUpdateCurrValues()

        campos = ', '.join(str(round(x, 5)) for x in ac.ext_getCameraPos())
        fovMin = int(ac.getValue(minfovspinner))
        fovMax = int(ac.getValue(maxfovspinner))
        # ac.log( str(currCamINI) +  str(currCamID) + 'POSITION' +  str(campos))

        camview1= ', '.join(str(round(x, 5)) for x in ac.ext_getCameraView())
        camview = camview1.split(',')
        camfor  = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
        camup   = str( float(camview[1])) + ", " + str(float(camview[5])) + ", " + str( float(camview[ 9]))

        # ac.log('POSITION=' + campos)
        # ac.log('FORWARD= ' + camfor)
        # ac.log('UP='       + camup)
        config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_","|"), comment_prefixes=(";","#","/","_","|"))
        config.optionxform = str
        config.read(currCamINI)
        config.set(currCamID, 'POSITION', campos)
        config.set(currCamID, 'FORWARD', camfor)
        config.set(currCamID, 'UP', camup)
        config.set(currCamID, 'MIN_FOV', str(fovMin))
        config.set(currCamID, 'MAX_FOV', str(fovMax))

        with open(currCamINI, 'w') as f:
            config.write(f, space_around_delimiters=False)

        # refresh all cam data
        bUpdatingControls=True
        readAllCams()
        bUpdatingControls=True
        doStuffcamID()
        bUpdatingControls=False
        ac.setCameraMode(3)

        ac.setTitle(app, 'written to ini!')
        btimerMsg=True
        timerMsg=2.0
    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())

def doStuffcamID():
    global camINIspinner, camIDspinner, lbcamINIspinner, lbcamIDspinner, minfovspinner, maxfovspinner
    global bUpdatingControls, app, timerMsg, chkbox_isFixed, currINIID, camfileNum, camsNums, camsHeader, currCamID, camsSections, camsFileNames, currCar
    global currCamINI, currCamID, currCar, cams, camsIN, camsOUT, camsCSV
    # global bKeepReplayInsync

    try:
        fileID = int(ac.getValue(camINIspinner))
        camID = int(ac.getValue(camIDspinner))
        CamINI = str(camsFileNames[fileID])
        ac.setText(lbcamINIspinner, os.path.basename(CamINI) + '  -  ' + camsHeader[fileID] + '\n                                    (' + str(camfileNum)+ ')')
        if camsCSV[camID]!="":
            CamIDString = 'CAMERA_'+ str(camID) + "  -  SPLINE: '" + camsCSV[camID] + "'"
        else:
            CamIDString = 'CAMERA_'+ str(camID)

        ac.setText(lbcamIDspinner , CamIDString  + '\n                            (' + str(int(camsNums[fileID])) + ')') # + '  -  fov min/max  ' + str(fovMin) + '/'+str(fovMax))
        i=-1
        for cam in cams:
            i+=1
            if os.path.basename(CamINI) in cam and CamIDString in cam:
                line = cam.split('=')
                s1 = line[1].split(',')
                fx = float(s1[0])
                fy = float(s1[1])
                fz = float(s1[2])

                fovMin  =       re.search(r"MIN_FOV=.*"  , camsSections[i]).group(0).replace('MIN_FOV=' ,'')
                fovMax  =       re.search(r"MAX_FOV=.*"  , camsSections[i]).group(0).replace('MAX_FOV=' ,'')
                isFixed =       re.search(r"IS_FIXED=.*" , camsSections[i]).group(0).replace('IS_FIXED=','')

                # set values to ac cam
                if not bUpdatingControls:
                    ac.setCameraMode(6) # set freecam
                    ac.ext_setCameraPosition( fx, fy, fz )
                    # ac.ext_setCameraFov(float(fovMax))

                    ### could not figure how to set direction
                    #x,y,z = sDir.split(',')
                    #ac.ext_setCameraDirection(float(x),float(y),float(z))

                # set values on gui controls
                bUpdatingControls=True
                ac.setValue(minfovspinner , int(float(fovMin)))
                ac.setValue(maxfovspinner , int(float(fovMax)))
                ac.setValue(chkbox_isFixed, int(float(isFixed)))
                bUpdatingControls=False

                break
    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())

def doStuffCamINI():
    global camINIspinner, camIDspinner, lbcamINIspinner, lbcamIDspinner
    global bUpdatingControls, camsNums, currCamINI
    try:
        fileID = int(ac.getValue(camINIspinner))
        camID = int(ac.getValue(camIDspinner))
        # currCamINI = camsFileNames[fileID]
        # appUpdateCurrValues()
        # ac.log('DoStuffCamINI ' + currCamINI)
        if fileID>=0:
            ac.setRange(camIDspinner, 0, camsNums[int(fileID)]-1)
            if camID>camsNums[int(fileID)]-1:
                ac.setValue(camIDspinner, camsNums[int(fileID)]-1)
            if bUpdatingControls or fileID<0:
                return
            doStuffcamID()
    except:
        ac.log("CamInfoxxxx: " + traceback.format_exc())



def doStuffIsFixed(isfixed):
    global camINIspinner, camIDspinner
    global timerMsg, btimerMsg, minfovspinner, maxfovspinner, bUpdatingControls, currCamINI, currCamID
    if bUpdatingControls:
        return
    appUpdateCurrValues()
    # ac.log('DostuffISFixed ' + currCamINI)

    config = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_","|"), comment_prefixes=(";","#","/","_","|"))
    config.optionxform = str
    config.read(currCamINI)
    config.set(currCamID, 'IS_FIXED', str(isfixed))
    with open(currCamINI, 'w') as f:
        config.write(f, space_around_delimiters=False)

    # refresh all cam data
    bUpdatingControls=True
    readAllCams()
    bUpdatingControls=True
    doStuffcamID()
    bUpdatingControls=False

    ac.setTitle(app, 'written to ini!')
    btimerMsg=True
    timerMsg=2.0

def appISFIXED(*args):
    doStuffIsFixed(args[1])

def onCamINIspin(*args):
    doStuffCamINI()

def onCamIDspin(*args):
    doStuffcamID()

##########################

def threadDoRunEditor(sf):
    os.startfile(sf)

def threadRunEditor(sf):
    global thread
    try:
        if not thread or not thread.is_alive():
            thread = threading.Thread(target=threadDoRunEditor, args=(sf,))
            thread.start()
    except:
        ac.log("CamInfo error: " + traceback.format_exc())
        ac.console("CamInfo error: " + traceback.format_exc())
def runEditor(sF):
    try:
        threadRunEditor('"' + os.path.abspath(sF) + '"')
    except:
        ac.log('CamInfo - '+ sF + '\n' +traceback.format_exc())

def appRunEditor(*args):
    global currCamINI
    appUpdateCurrValues()
    runEditor(currCamINI)

def appCopy(*args):
    global bCSPactive
    if not bCSPactive:
        return
    currCar = ac.getFocusedCar()
    currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
    camview1= ', '.join(str(round(x, 5)) for x in ac.ext_getCameraView())
    camview = camview1.split(',')
    camfor  = str(-float(camview[2])) + ", " + str(-float(camview[6])) + ", " + str(-float(camview[10]))
    camup   = str( float(camview[1])) + ", " + str( float(camview[5])) + ", " + str(float(camview[ 9]))
    campos = ', '.join(str(round(x, 5)) for x in ac.ext_getCameraPos())
    s='POSITION='+ campos + '\n'
    s+='FORWARD=' + camfor + '\n'
    s+='UP='      + camup + '\n'
    ac.ext_setClipboardData(s + 'PoT=' + str(round(currPoT, 5)))
    global btimerMsg, timerMsg
    ac.setTitle(app, 'copied to Clipboard!')
    btimerMsg=True
    timerMsg=2.0

##########################

def createSpinner(appWindow, text,   value, x, y, width, height, rangeMin, rangeMax, step, visible=True, fntsize=14):
    newSpinner = ac.addSpinner(appWindow, text)
    ac.setFontSize(newSpinner, fntsize)
    ac.setPosition(newSpinner, x, y)
    ac.setSize(newSpinner, width, height)
    ac.setRange(newSpinner, rangeMin, rangeMax)
    ac.setStep(newSpinner, step)
    ac.setValue(newSpinner, value)
    ac.setVisible(newSpinner, visible)
    return newSpinner

def createCheckbox(appWindow, text, value, x, y, width, height, visible=True):
    newCB = ac.addCheckBox(appWindow, text)
    ac.setFontSize(newCB, 10)
    ac.setPosition(newCB, x, y)
    ac.setSize(newCB, width, height)
    ac.setValue(newCB, value)
    ac.setVisible(newCB, visible)
    return newCB

def createButton(appWindow, label, x, y, width, height, visible=True):  # , bg_tex
    btn = ac.addButton(appWindow, label)
    ac.setPosition(btn, x, y)
    ac.drawBackground(btn, 1)
    ac.drawBorder(btn, 1)
    ac.setSize(btn, width, height)
    ac.setVisible(btn, visible)
    return btn

def createLabel(appWindow, label, x, y, width, height, visible=True, fntsize=12):
    lbl = ac.addLabel(appWindow, label)
    ac.setPosition(lbl, x, y)
    ac.setSize(lbl, width, height)
    ac.setVisible(lbl, visible)
    ac.setFontSize(lbl, fntsize)
    return lbl

#######################################################

def readAllCams():
    global app, cams, camsNums, sTrack, sLayout, camfileNum, camINIspinner, camsSections, sFilefastlaneAI
    global bUpdatingControls, currSect, camsHeader, camsFileNames, label2, camsIN, camsCSV, camsOUT, camIDspinner
    try:
        ac.setText(label2, '')
        bUpdatingControls=True
        cams = []
        camsIN = []
        camsOUT = []
        camsCSV = []
        camsNums = []
        camsSections = []
        camsHeader = []
        camsFileNames = []
        if sTrack!='':
            directory = 'content/tracks/' + sTrack+'/'
            if sLayout!='':
                directory = 'content/tracks/' + sTrack+'/'+sLayout+'/'
            sFilefastlaneAI = directory+'ai/fast_lane.ai'
            directory += 'data/'
            cwd = os.path.dirname(os.path.realpath(__file__))
            acFolder = str(cwd).lower().replace('caminfo','')
            acFolder = acFolder.replace('apps\\python\\','').replace('apps/python/','').replace('\\\\','').replace('//','')

            for filename in os.listdir(acFolder + directory):
                lowFN = filename.lower()
                # num = lowFN.replace("cameras_","").replace(".ini","")
                # if (lowFN.startswith("cameras_") and lowFN.endswith(".ini") and num.isnumeric()) or lowFN=="cameras.ini":
                if (lowFN.startswith("cameras") and lowFN.endswith(".ini")):  ### or lowFN=="cameras.ini":
                    camfile = str(directory) + str(lowFN)
                    camConf = configparser.ConfigParser(empty_lines_in_values=False, strict=False, allow_no_value=True, inline_comment_prefixes=(";","#","/","_"), comment_prefixes=(";","#","/","_"))
                    camConf.optionxform = str
                    camConf.read(camfile)
                    camNum=0
                    setname=''
                    lIN = -1
                    lOUT = -1
                    for section in camConf:
                        if 'HEADER' in section:
                            for key, value in camConf.items(section):
                                if key=='SET_NAME':
                                    setname = str(value)
####################################################################################################################################################################################
                        if 'CAMERA_' in section:
                            IN  = float( getvalue( camConf.get(section,'IN_POINT') ) )
                            OUT = float( getvalue( camConf.get(section,'OUT_POINT') ) )
                            POS =        getvalue( camConf.get(section,'POSITION') ).replace(' ','')
                            CSV = camConf.get(section,'SPLINE')
                            #if lIN!=-1 and lOUT!=-1:
                            #    if lOUT!=IN:
                            #        ac.log('CamInfo info: '+ sTrack + '/data/' + lowFN + ' - ' + ' section: ' + section+ ' - ' + ' non-continuous camera' )
                            #        ac.setText(label2, ac.getText(label2) + '\n' + sTrack + '/data/' + lowFN + ' - ' + ' section: ' + section+ ' - ' + ' non-continuous camera' )
                            lIN = IN
                            lOUT = OUT

                            sects = ''
                            # make section strings for info label
                            for key, value in camConf.items(section):
                                if key.upper() in ['NAME', 'POSITION', 'FORWARD', 'UP', 'MIN_FOV', 'MAX_FOV', 'IN_POINT', 'OUT_POINT', 'IS_FIXED']:
                                    sects += str(key).upper()+'='+str(value)+'\n'
                                    # if key.upper() in ['IN_POINT']:
                                    #     ac.log( section + '  -  ' + str(key).upper()+' = '+str(value) )

                                    if key.upper() in ['UP', 'MAX_FOV', 'OUT_POINT', 'DOF_MANUAL', 'IS_FIXED']:
                                        sects += '\n' # add selected line wraps
                            # cammode = ac.getCameraMode()
                            #if currSect=='' and cammode != 6:
                            if currSect=='':
                                currSect=sects

                            # build a list with this: ['cameras.ini -> CAMERA_25', '-1162.54,49.0683,713.82']
                            cams.append( os.path.basename(camfile) + ' -> ' + section + ' =' + POS )
                            camsIN.append(IN)
                            camsOUT.append(OUT)
                            camsCSV.append(CSV)
                            # cams.append( os.path.basename(camfile) + ' -> [' + section + '] = ' + POS )
                            camNum += 1
                            camsSections.append(sects)

####################################################################################################################################################################################
                    camsNums.append(camNum)    # list of cams counts
                    camsHeader.append(setname) # list of names from header
                    camsFileNames.append(directory + lowFN)
                    # IN  = float( getvalue( camConf.get('CAMERA_0'              , 'IN_POINT' ) ) )
                    # OUT = float( getvalue( camConf.get('CAMERA_'+ str(camNum-1), 'OUT_POINT') ) )
                    # if IN != -1.0 and OUT != -1.0:
                    #     if IN != 0.0:
                    #         ac.log('CamInfo info: '+ sTrack + '/data/' + lowFN + ' - 1st cam not starting at 0.0')
                    #         ac.setText(label2, ac.getText(label2) + '\n' + sTrack + '/data/' + lowFN + ' - First cam not starting at 0.0')
                    #     if OUT != 1.0:
                    #         ac.log('CamInfo info: ' + sTrack + '/data/' + lowFN + ' - last cam not ending at 1.0')
                    #         ac.setText(label2, ac.getText(label2) + '\n' + sTrack + '/data/' + lowFN + ' - Last cam not ending at 1.0')
            camfileNum = len(camsFileNames)
            ac.setRange(camINIspinner, 0, camfileNum-1)
            ac.setRange(camIDspinner, 0, camsNums[0]-1)
            ac.setValue(camINIspinner, 0)
            sadd=''
            if len(camsHeader)>0:
                sadd=camsHeader[0]
            # ac.setText(lbcamINIspinner, 'camera.ini (' + str(camfileNum) +')     ' + sadd)
            ac.setText(lbcamINIspinner, 'camera.ini (' + str(camfileNum) +')     ' + sadd)
            if sLayout!='':
                ac.setTitle(app, "CamInfo - " + sTrack + ' / ' + sLayout)
            else:
                ac.setTitle(app, "CamInfo - " + sTrack)

        bUpdatingControls=False
        # ac.log( str(camsNums) + ' - ' + str(cams) )
    except:
        ac.log("CamInfo: " + traceback.format_exc())



def checkCurrentCam(currPosX, currPosY, currPosZ, updateControls=False, sAdd='', doName=True):
    global cams, camIDspinner, camINIspinner, camsSections
    global bUpdatingControls, currSect, camsOUT, camsIN, currPoT, camsCSV
    s='' # result
    try:
        # pull out cameras name
        camINInum = ac.ext_getCurrentTrackCamera()
        i=-1
        for cam in cams:
            i+=1
            if currPoT>=camsIN[i] and currPoT<camsOUT[i]:
                line = cam.split('=')
                s1 = line[1].strip().split(',')
                s1[0] = (float(s1[0]))
                s1[1] = (float(s1[1]))
                s1[2] = (float(s1[2]))
                sDetail = line[0].split(' -> ')

                camIDnum=0
                camIDnums = sDetail[1].lower().replace('camera','').replace('_','').replace('[','').replace(']','').replace(' ','')
                if camIDnums!='':
                    camIDnum = int(camIDnums)
                else:
                    camIDnum = 0

                # file and cam found
                line = '\n' + camsSections[camIDnum]
                scurrSect =currSect.split('\n')
                # currSect = '\n' + camsSections[camIDnum]
                if doName:
                    s=str(line[0]) + '    ' + sAdd  + '\n'+ scurrSect[1]
                else:
                    s=str(line[0]) + '    ' + sAdd
                if updateControls:
                    bUpdatingControls = True
                    # doStuffcamID()
                    # ac.setText(lbcamIDspinner, sDetail[1] )
                    ac.setValue(camINIspinner, camINInum )
                    ac.setRange(camIDspinner, 0, camsNums[camINInum]-1)
                    if camIDnum > camsNums[camINInum]-1:
                        ac.setValue(camIDspinner, camsNums[camINInum]-1)
                    else:
                        ac.setValue(camIDspinner, camIDnum )
                    bUpdatingControls = False
                # break
    except:
        ac.log("CamInfo: " + traceback.format_exc())
    return s

###############################################################################

def acMain(ac_version):
    global app, label2, label1, btnSave, camINIspinner, camIDspinner, lbcamINIspinner, lbcamIDspinner, minfovspinner, maxfovspinner
    global bUpdatingControls, minfovspinner, maxfovspinner, btnReload, btnUpdateIN, btnUpdateOUT, btnEditor, btnAddCams, chkbox_isFixed, btnCopy, btnDelete, btnAdd, sTrack, sLayout
    app = ac.newApp("CamInfo")
    try:
        bUpdatingControls=True
        btnEditor       = createButton (app, ".."          ,   270,  70,  25, 25,   1)
        btnAddCams      = createButton (app, "add"         ,   220,  70,  45, 25,   1)
        sTrack = ac.getTrackName(0)
        sLayout = ac.getTrackConfiguration(0)
        camINIspinner   = createSpinner(app,   ""      ,  0,    10,  70, 200, 25, 0,   1, 1, 1)
        lbcamINIspinner = createLabel(app, "cameras.ini",       10,  50, 50, 20)
        label2          = createLabel(app, "-",                300,   0, 280, 230)

        # ac.addOnValueChangeListener(camINIspinner, onCamINIspin)
        ac.setBackgroundOpacity(label2, 0.5)
        ac.setBackgroundColor(label2, 1,1,1)
        ac.addOnClickedListener(btnEditor, appRunEditor)
        ac.addOnClickedListener(btnAddCams, appAddRandomCams)

        sVer = str(ac.ext_patchVersion())
        sVer = sVer + " - code " + str(ac.ext_patchVersionCode())
        #### fails if csp not active
        btnReload       = createButton (app, "reload"      ,   220,  30,  75, 25,   1)
        btnCopy         = createButton (app, "copy vals"   ,   200, 155,  95, 25,   1)
        btnAdd          = createButton (app, "add"         ,   200, 125,  45, 25,   1)
        btnDelete       = createButton (app, "del"         ,   250, 125,  45, 25,   1)
        btnSave         = createButton (app, "save pos/fov",   200, 250, 100,  25,  0)
        btnUpdateIN     = createButton (app, "save IN\n"   ,   200, 300, 100,  25,  0)
        btnUpdateOUT    = createButton (app, "save OUT"    ,   200, 330, 100,  25,  0)
        camIDspinner    = createSpinner(app, ""            ,     0,  10, 125, 175, 25, 0,   1, 1, 1)
        minfovspinner   = createSpinner(app, ""            ,     0, 130, 370, 160, 20, 2, 120, 1, 0, 12)
        maxfovspinner   = createSpinner(app, ""            ,     0, 130, 400, 160, 20, 2, 120, 1, 0, 12)
        chkbox_isFixed  = createCheckbox(app,'is fixed'    ,     0, 210, 445,  40, 20, 0)
        lbcamIDspinner  = createLabel  (app, "camera id"   ,    30, 110, 30, 20)
        label1          = createLabel  (app, "-"           ,    10, 165, 280, 20)

        # ac.setFontAlignment(chkbox_isFixed, 'right')
        ac.addOnValueChangeListener(camIDspinner, onCamIDspin)
        ac.addOnValueChangeListener(minfovspinner, onminFOVspin)
        ac.addOnValueChangeListener(maxfovspinner, onmaxFOVspin)
        ac.addOnClickedListener(btnSave, appSaveToCamerasINI)
        ac.addOnClickedListener(btnUpdateIN , appUpdateIN)
        ac.addOnClickedListener(btnUpdateOUT, appUpdateOUT)
        ac.addOnClickedListener(btnReload, appbtnReload)
        ac.addOnClickedListener(btnCopy, appCopy)
        ac.addOnClickedListener(btnDelete, appDelCurrentCam)
        ac.addOnClickedListener(btnAdd, appAddNewCam)
        ac.addOnCheckBoxChanged(chkbox_isFixed, appISFIXED)
        bUpdatingControls=False
        # if ac.getCameraMode() == 6: # unlock edit controls in free cam
        ac.setSize(app, 300, 500)
        readAllCams()
        doStuffCamINI()
    except:
        ac.setSize(app, 300, 120)
        ac.setTitle(app, "Caminfo - CSP not installed")
        ac.log("CamInfo: CSP not installed")
        bUpdatingControls=False
    return "CamInfo"

#####################################################################

def acUpdate(delta_t):
    global app, error, timer, label1, timerMsg, btimerMsg, camINIspinner, camIDspinner, sTrack, sLayout
    global camnames, hidden, campos, currPoT, currCar, sCurrCam, bUpdatingControls, bCSPactive, updateInterval

    #ac.setTitle(app, str(ac.ext_getCurrentTrackCamera()) + ' - ' + str(ac.ext_getCurrentCamera()) + ' - ' + str(ac.ext_getTrackCamerasNumber()) )
    if btimerMsg:
        timerMsg -= delta_t
        if timerMsg<=0.0:
            btimerMsg = False
            if bCSPactive:
                if sLayout!='':
                    ac.setTitle(app, "CamInfo - " + sTrack + ' / ' + sLayout)
                else:
                    ac.setTitle(app, "CamInfo - " + sTrack)
                ac.setText(label1, 'CSP not active, cant get camera position\nyou can create a camera ...')

    timer += delta_t
    if timer > updateInterval:
        timer = 0.0
        if len(cams) == 0:
            ac.setText(label1, 'no cams found!')
            ac.setPosition(label1, 10, 40)
            ac.setText(label2, "")
            ac.setVisible(btnAdd, 0)
            ac.setVisible(btnDelete, 0)
            ac.setVisible(btnCopy, 0)
            ac.setVisible(camIDspinner, 0)
            ac.setVisible(camINIspinner, 0)
            ac.setVisible(btnEditor, 0)
            ac.setVisible(lbcamINIspinner, 0)
            ac.setVisible(lbcamIDspinner, 0)
            ac.setSize(app, 300, 120)
        else:
            ac.setPosition(label1, 10, 165)
            ac.setVisible(btnAdd, 1)
            ac.setVisible(btnDelete, 1)
            ac.setVisible(btnCopy, 1)
            ac.setVisible(camIDspinner, 1)
            ac.setVisible(camINIspinner, 1)
            ac.setVisible(btnEditor, 1)
            ac.setVisible(lbcamINIspinner, 1)
            ac.setVisible(lbcamIDspinner, 1)
            cammode = ac.getCameraMode()
            currCar = ac.getFocusedCar()
            currPoT = ac.getCarState(currCar, acsys.CS.NormalizedSplinePosition)
            if bCSPactive:
                campos = ', '.join(str(round(x, 2)) for x in ac.ext_getCameraPos())
                if not 'NaN' in campos:
                    camposXYZ = campos.split(',')
                    sx=(float(camposXYZ[0]))
                    sy=(float(camposXYZ[1]))
                    sz=(float(camposXYZ[2]))
                    sCurrPosPot = '\nCam: ' + campos + '    PoT: ' + str(round(currPoT,5))  +'\n'
                    sFOVinfo = '  FOV: '+ str(int(ac.ext_getCameraFov()))
                    sCurrCam = ''
                    if cammode == 6: # unlock edit controls in free cam
                        ShowControls()
                        # sCurrCam = checkCurrentCam(sx, sy, sz, True, sFOVinfo, False)
                        ac.setText(label1, 'Camera Mode : ' + camnames[cammode] + sCurrPosPot + '(F1 / F3 -> back)                         ' + sFOVinfo + '\n' + currSect)
                    else:
                        HideControls()
                        #ac.console(' sdfgdf')
                        if cammode == 3: # hide edit controls in track cam, but update caminfo
                            bUpdatingControls=True
                            sCurrCam = checkCurrentCam(sx, sy, sz, True, sFOVinfo, True)
                            bUpdatingControls=False
                            ac.setText(label1, 'Camera Mode : ' + camnames[cammode] + '\n' + sCurrPosPot + '\n   F7 -> Enter Controls'
                                #    + '\nac.ext_getTrackCamerasNumber() = ' + str(ac.ext_getTrackCamerasNumber())
                                   )
                        else:
                            # ac.setText(lbcamINIspinner,"-- not available --")
                            ac.setText(lbcamIDspinner ,"-- not available --")
                            sCurrCam = '                                                 ' +sFOVinfo + '\n'
                            # ac.setText(label, 'Camera Mode : ' + camnames[cammode] + sCurrPosPot + str(sCurrCam) + '       (F7 -> controls)')
                            # ac.setText(label1, 'Camera Mode : ' + camnames[cammode] + '\n' + sCurrPosPot + '\n   F7 -> Enter Controls')
                            ac.setText(label1, 'Camera Mode : ' + camnames[cammode] + '\n' + sCurrPosPot + '\n   F3 -> Track Cam   or  click cam sliders'
                                #    + '\nac.ext_getTrackCamerasNumber() = ' + str(ac.ext_getTrackCamerasNumber())
                                   )
            else:
                sCurrPosPot = '\n          PoT: ' + str(round(currPoT,5))  +'\n'
                ac.setText(label1, sCurrPosPot + '\nCSP not active, cant get camera position\nbut you can create a camera ...')
                updateInterval=10.0

def acShutdown(*args):
    pass

#####################################################################

def distance(point1, point2) -> float:
    return math.sqrt((point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2 + (point2[2] - point1[2]) ** 2)

def appGetNumberedFilename(sBase, sExt):
    global camINIid
    newname=sBase + sExt
    i=1
    while os.path.isfile(newname) and i<50:
        newname = sBase + '_' + str(i) + sExt
        i+=1
    if i>=50:
        # ac.log('filenames outnumbered!')
        ac.setText(label2, ac.getText(label2) + '\nfilenames outnumbered! (50) line ~1270')
        return ''
    camINIid = i
    return newname

def get_ac_coords(ob):
  return(str(round(ob[0],5))+', '
        +str(round(ob[2],5))+', '
        +str(round(ob[1],5)) )

def buildCameraEntry(cCount, fCamPos, fOrientation, fOrientationUP, potL, potC, vminFov=30, vmaxFov=50, isFixed=False):
    lines=[]
    lines.append('[CAMERA_' + str(cCount) + ']'       + '\n')
    lines.append('NAME=Camera ' + str(cCount)         + '\n')
    lines.append('POSITION=' + fCamPos                + '\n')
    lines.append('FORWARD=' + fOrientation            + '\n')
    lines.append('UP=' + fOrientationUP               + '\n')
    lines.append('IN_POINT=' + '{:.6f}'.format(potL)  + '\n')
    lines.append('OUT_POINT=' + '{:.6f}'.format(potC) + '\n')
    lines.append('MIN_FOV=' + str(vminFov)            + '\n')
    lines.append('MAX_FOV=' + str(vmaxFov)            + '\n')
    lines.append('SHADOW_SPLIT0=50'                   + '\n')
    lines.append('SHADOW_SPLIT1=250'                  + '\n')
    lines.append('SHADOW_SPLIT2=1350'                 + '\n')
    lines.append('NEAR_PLANE=0.1'                     + '\n')
    lines.append('FAR_PLANE=10000'                    + '\n')
    lines.append('MIN_EXPOSURE=0.35'                  + '\n')
    lines.append('MAX_EXPOSURE=0.55'                  + '\n')
    lines.append('DOF_FACTOR=1'                       + '\n')
    lines.append('DOF_RANGE=100'                      + '\n')
    lines.append('DOF_FOCUS=0'                        + '\n')
    lines.append('DOF_MANUAL=0'                       + '\n')
    lines.append('SPLINE='                            + '\n')
    lines.append('SPLINE_ROTATION=0'                  + '\n')
    lines.append('FOV_GAMMA=0.5'                      + '\n')
    lines.append('SPLINE_ANIMATION_LENGTH=0'          + '\n')
    lines.append('IS_FIXED=' + str(int(isFixed))      + '\n')
    lines.append(''                                   + '\n')
    return lines


def CreateCamerasFromDataPoints(filepath, data_ideal, data_detail, scaling=1.0):
    global camCount, odd, camini, offIN, offOUT, lowcams, lowFOVcams, highcams, anims, camINIid, label2
    try:
        baseIdx = offIN + 1
        datalen = len(data_ideal) - 1 - offOUT
        tracklen = 0 # data_ideal[datalen][3] - data_ideal[offIN][3]
        for i in range(baseIdx, datalen):
            #data_ideal[i][3] = tracklen
            distl = distance( data_ideal[i], data_ideal[i-1] )
            if distl<100.0:
                tracklen += distl

        camheightDiff = maxCamheight - minCamheight
        lastPoTIN = 0.0
        camCount = 0
        slopeIN = 0.0
        slopeOUT = 0.0
        slopeCAM = 0.0
        slopeINlast = 0.0
        slopeOUTlast = 0.0
        coords=(0.0,0.0,0.0)
        lastLOWFOV=0
        animDone = False
        straight = 0
        dist = 0.0
        distI = 0.0
        distO = 0.0
        lastdist = 0.0

        # ac.log('first coord:             ' + str(data_ideal[0]      [0])+',' + str(data_ideal[0]      [1])+',' + str(data_ideal[0]      [2]))
        # ac.log(' last coord:             ' + str(data_ideal[datalen][0])+',' + str(data_ideal[datalen][1])+',' + str(data_ideal[datalen][2]))
        #tracklen = tracklen * scaling ### ???
        ac.log("Calculated track length: " + str(tracklen))

        while baseIdx < datalen and lastdist <= tracklen:
            xin, zin, yin, _, _    = data_ideal[baseIdx]
            xin1, zin1, yin1, _, _ = data_ideal[baseIdx-1]
            distLin = data_detail[baseIdx][6]
            distRin = data_detail[baseIdx][7]



            # fast forward from last OUT_POINT/current IN_POINT to next campos
            distI = lastdist
            while baseIdx<datalen and distI < lastdist + distIN:
                # dist += data_ideal[baseIdx][3] - data_ideal[baseIdx-1][3]
                distI += distance( data_ideal[baseIdx], data_ideal[baseIdx-1] )
                baseIdx += 1



            ### we dont need that
            ### currPoTCalced = abs( (data_ideal[baseIdx][3] ) / tracklen  )

            ### but wee need cam/border pos here
            ### baseIdx/camera at cPoT current Point of Track
            x, z, y, _, _    = data_ideal[baseIdx]
            x1, z1, y1, _, _ = data_ideal[baseIdx-1]
            distLcam = data_detail[baseIdx][6]
            distRcam = data_detail[baseIdx][7]
            direction = -math.degrees( math.atan2(data_ideal[baseIdx-1][2] - data_ideal[baseIdx][2], data_ideal[baseIdx][0] - data_ideal[baseIdx-1][0]))
            xl = x + math.cos((-direction + 90) * math.pi / 180) * data_detail[baseIdx][6] # _wallLeft
            yl = y - math.sin((-direction + 90) * math.pi / 180) * data_detail[baseIdx][6] # _wallLeft
            xr = x + math.cos((-direction - 90) * math.pi / 180) * data_detail[baseIdx][7] # _wallRight
            yr = y - math.sin((-direction - 90) * math.pi / 180) * data_detail[baseIdx][7] # _wallRight

            slopeCAM = (y-y1) / (x-x1)
            slopeIN  = (yin-yin1) / (xin-xin1)

            # fast forward from current pot to OUT_POINT
            distO = distI
            while baseIdx<datalen and distO < lastdist + distIN + distOUT:
                # dist += data_ideal[baseIdx][3] - data_ideal[baseIdx-1][3]
                distO += distance( data_ideal[baseIdx], data_ideal[baseIdx-1] )
                baseIdx += 1

            if distI>0.0 and distO>0.0:
                # currPoTOUT = abs( (data_ideal[baseIdx][3] ) / tracklen  )
                currPoTOUT = abs( ( distO ) / tracklen  )
                xout, zout, yout, _, _    = data_ideal[baseIdx]
                xout1, zout1, yout1, _, _ = data_ideal[baseIdx-1]
                slopeOUT = (yout-yout1) / (xout-xout1)
                angle1 = (math.degrees( math.atan(slopeIN)   ) + 90) * 2
                angle2 = (math.degrees( math.atan(slopeCAM)  ) + 90) * 2
                angle3 = (math.degrees( math.atan(slopeOUT)  ) + 90) * 2
                angle4 = math.degrees( math.atan2((yin -yin1 ) , (xin  -xin1 )) ) +180
                angle5 = math.degrees( math.atan2((y   -y1   ) , (x    -x1   )) ) +180
                angle6 = math.degrees( math.atan2((yout-yout1) , (xout -xout1)) ) +180

                if abs(angle1-angle2)<2.5 and abs(angle2-angle3)<2.5:
                    straight += 1

                # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
                ac.log(str(camCount) + '   ' + str(int(distI)) + ' m  -  id ' + str(baseIdx) + ' -  ' + str(int(100*currPoTOUT)) + '%')
                # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

                # more vars to set
                global minFOV, maxFOV
                FOV2 = minFOV + random.random()*(maxFOV-minFOV)
                if FOV2>40:
                    FOV=FOV2
                else:
                    FOV=FOV2*0.666

                ##########################################################
                ### variation - just switch one from one side to the other, incative
                # if odd:
                #     coords = ( float(xl), float(yl), float(z+camheightMin+random.random()*camheightDiff)  )
                # else:
                #     coords = ( float(xr), float(yr), float(z+camheightMin+random.random()*camheightDiff)  )
                # odd = not odd

                ##########################################################
                ### guessing by distance from ai line
                distL = data_detail[baseIdx][6]
                distR = data_detail[baseIdx][7]
                # right corner
                if distL > distR and distLin > distRin and distLcam < distRcam:
                    # use right side
                    coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )
                # left corner
                elif distL < distR and distLin < distRin and distLcam > distRcam:
                    # use left side
                    coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
                # ai on the left
                elif distL < distR and distLin < distRin and distLcam < distRcam:
                    # use right side
                    coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )
                # ai on the right
                elif distL > distR and distLin > distRin and distLcam > distRcam:
                    # use left side
                    coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
                elif distLin > distRin:
                    if distLcam > distRcam:
                        # use left side
                        coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
                    else:
                        # use right side
                        coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )
                else:
                    if distLcam > distRcam:
                        # use left side
                        coords = ( float(xl), float(yl), float(z+minCamheight+random.random()*camheightDiff)  )
                    else:
                        # use right side
                        coords = ( float(xr), float(yr), float(z+minCamheight+random.random()*camheightDiff)  )

                ##########################################################
                ### -if ai-line slope only changed so much then put cam very low
                if abs(slopeINlast -slopeIN )>0.35 and \
                   abs(slopeOUTlast-slopeOUT)>0.35 and \
                   abs(zin         -       z)>0.1  and \
                   abs(z           -    zout)>0.1 :
                    coords = ( coords[0], coords[1], z+minCamheight+maxCamheight*0.8666)
                    lowcams += 1
                    ### hack to have MORE anims
                    # lastLOWFOV += 1

                ##########################################################
                ### in case of a long straight go low with fov
                if abs(slopeINlast -slopeIN )>0.25 and \
                   abs(slopeOUTlast-slopeOUT)>0.25 and \
                   abs(zin         -       z)>1.0  and \
                   abs(z           -    zout)>1.0  and \
                   ((distL < distR and distLin < distRin and distLcam < distRcam) or (distL > distR and distLin > distRin and distLcam > distRcam)) :
                    FOV = minFOV
                    lowFOVcams += 1
                    lastLOWFOV += 1

                ### hack to not have too much anims
                #if abs(zin-z)>1 and abs(z-zout)>1:
                #    lastLOWFOV -= 1

                ##########################################################
                ### special case when it goes up/down a lot, then we go high with cam
                if abs(zin-z)>6.5 and abs(z-zout)>6.5:
                    coords = ( coords[0], coords[1], z+maxCamheight)
                    highcams += 1

                ##########################################################
                # fOrientation, fOrientationUP FORWARD= and UP=
                ### !!! this is probably completely wrong
                ### !!! not tested with IS_FIXED=0
                xdir = math.sin(direction)
                ydir = math.cos(direction)

                ##########################################################
                # now build cam section
                camini += buildCameraEntry(camCount,
                    get_ac_coords(coords),                      ### POSITION
                    str(round(xdir,4))+",0,"+str(round(ydir,4)),  ### FORWARD
                    "0,1,0",                                    ### UP
                    lastPoTIN, currPoTOUT,
                    int(FOV), int(FOV2))

                ##########################################################
                # add anims
                if lastLOWFOV>0 and anims<=3:   ### and not animDone:
                    coords = ( coords[0], coords[1], z+maxCamheight-camheightDiff/8)
                    get_ac_coords(coords)
                    ### build new csv filename
                    sFileDir = os.path.dirname(filepath).replace('\\', '/').replace('/ai', '/data')
                    if not os.path.isdir(sFileDir):
                        sFileDir = os.path.dirname(filepath)
                    sFileCSV = sFileDir + '/c_' + str(camINIid-1) + '_' + str(camCount) + '.csv'
                    camini[len(camini)-6] = 'SPLINE=' + os.path.basename(sFileCSV)+'\n'
                    camini[len(camini)-3] = 'SPLINE_ANIMATION_LENGTH=20\n'
                    with io.open(sFileCSV, 'w', encoding='utf-8') as f:
                        if animDone:
                            f.writelines("0.0,0.0,0.0\n")
                            f.writelines("0.0,5.0,0.0\n")
                            animDone = False
                        else:
                            f.writelines("0.0,5.0,0.0\n")
                            f.writelines("0.0,0.0,0.0\n")
                            animDone = True
                    anims += 1

                baseIdx += 1
                camCount += 1
                lastPoTIN = currPoTOUT
                slopeINlast = slopeIN
                slopeOUTlast = slopeOUT
                if lastLOWFOV>0:
                    lastLOWFOV -= 1
            else:
                ac.log('could not find in/out points')
                ##print('could not find in/out points')
                break

            lastdist = distO


        ### done
        ac.log(                '\ngenerated '+ str(camCount) + ' cams: ' + str(lowcams) +  ' lowcams, '+ str(lowFOVcams) +  ' lowFOVcams, ' + str(highcams) + ' highcams, ' + str(anims) + ' anims, ' + str(straight) + ' straights' )
        s = ac.getText(label2)
        ac.setText(label2, s + '\ngenerated '+ str(camCount) + ' cams: ' + str(lowcams) +  ' lowcams, '+ str(lowFOVcams) +  ' lowFOVcams, ' + str(highcams) + ' highcams, ' + str(anims) + ' anims, ' + str(straight) + ' straights' )
        return camini
    except:
        ac.log("CamInfo: error creating cams from points " + traceback.format_exc())

def LoadAIlineandCreateCams(filepath):
    if not os.path.isfile(filepath):
        return ("Can't create cameras, file does not exist:\n" + filepath)
    else:
        try:
            with open(filepath, "rb") as buffer:
                # temporary arrays
                data_ideal = []
                data_detail = []

                # should be at start, but do it anyway
                buffer.seek(0)
                # read header, detailCount is number of data points available
                header, detailCount, u1, u2 = struct.unpack("4i", buffer.read(4 * 4))

                ac.log('Caminfo: ai line header: ' + str(header))

                # read ideal-line data
                for i in range(detailCount):       # 4 floats, one integer
                    data_ideal.append(struct.unpack("4f i", buffer.read(4 * 5)))
                # read more details data
                for i in range(detailCount):        # 18 floats
                    data_detail.append(struct.unpack("18f", buffer.read(4 * 18)))

                # print('len  : ' + str(detailCount) + ' | ' + str(data_ideal[detailCount-1][3]) + '  |  ' + filepath)

                ### find new camera filename
                sFileDir = os.path.dirname(filepath).lower().replace('\\', '/').replace('/ai', '/data')
                sFileCameras = appGetNumberedFilename(sFileDir + '/cameras', '.ini')

                ac.log('Caminfo: ai line-length: ' + str(len(data_ideal)) + ' - ' + str(len(data_detail)) )

                # create CAMERAS.ini in memory
                camini      = []
                camini = CreateCamerasFromDataPoints(filepath, data_ideal, data_detail)
                if len(camini)>0:
                    ### write all the lines
                    with io.open(sFileCameras, 'w', encoding='utf-8') as f:
                        f.writelines('[HEADER]\n')
                        f.writelines('VERSION=3'+'\n')
                        f.writelines('CAMERA_COUNT=' + str(camCount)+'\n')
                        f.writelines('SET_NAME=Set'  + str(camINIid-1)+'\n')
                        f.writelines('\n')
                        camini[len(camini)-20] = 'OUT_POINT=1.0\n'
                        for s in camini:
                            f.writelines(s)
                    return ('Written new file: ' + str(os.path.basename(sFileCameras)))
        except:
            ac.log("CamInfo: error reading ai-line " + traceback.format_exc())


def appbtnReload(*args):
    global bUpdatingControls, app, btimerMsg, timerMsg
    # refresh all cam data
    bUpdatingControls=True
    readAllCams()
    bUpdatingControls=True
    doStuffcamID()
    bUpdatingControls=False
    ac.setTitle(app, 'reloaded!')
    btimerMsg=True
    timerMsg=1.0

def appAddRandomCams(*args):
    global sFilefastlaneAI, bUpdatingControls, btimerMsg, timerMsg, app, label2
    global distIN, distOUT, maxCamheight, minCamheight, minFOV, maxFOV, anims, highcams

    ### added anims depends on how many straights there are
    ### anims are simple up/down anims, max 4 times atm, lock for "anims" to unlock more

    ### 1st camera set to be generated
    distIN       = 90     ### in meters, both added equals wanted distance btw cameras
    distOUT      = 110     ###
    maxCamheight = 5      ### will be randomly choosen between those two
    minCamheight = 0.5   ### on curvy hillclimbs ai borders maybe under the road
    minFOV       = 20     ### will be randomly choosen between those two
    maxFOV       = 50
    anims = 0
    highcams = 0
    s = LoadAIlineandCreateCams(sFilefastlaneAI) + '\n'


    ### 2st camera set to be generated
    distIN       = 100     ### in meters, both added equals wanted distance btw cameras
    distOUT      = 120     ###
    maxCamheight = 10      ### will be randomly choosen between those two
    minCamheight = 2       ### on curvy hillclimbs ai borders maybe under the road
    minFOV       = 10      ### will be randomly choosen between those two
    maxFOV       = 40
    anims = 0
    s += LoadAIlineandCreateCams(sFilefastlaneAI)


    ### 3st camera set to be generated
    distIN       = 120     ### in meters, both added equals wanted distance btw cameras
    distOUT      = 140     ###
    maxCamheight = 20      ### will be randomly choosen between those two
    minCamheight = 2       ### on curvy hillclimbs ai borders maybe under the road
    minFOV       = 5      ### will be randomly choosen between those two
    maxFOV       = 40
    anims = 0
    s += LoadAIlineandCreateCams(sFilefastlaneAI)


    # refresh all cam data
    bUpdatingControls=True
    readAllCams()
    bUpdatingControls=True
    doStuffcamID()
    bUpdatingControls=False

    ac.setText(label2, ac.getText(label2) + '\n\nGenerated 3 camera sets!')

    btimerMsg=True
    timerMsg=5.0

